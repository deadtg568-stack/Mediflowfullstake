/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Brand accent — the signature lab-glow green
        brand: {
          50:  '#e8fff3',
          100: '#c9ffe1',
          200: '#94ffc7',
          300: '#5cffae',
          400: '#3DDC84',
          500: '#22c55e',
          600: '#16a34a',
          700: '#0f7a38',
          800: '#0a5c2a',
          900: '#08431f',
          glow: '#39FF88',
        },
        // Dark surfaces — near-black with a green tint
        surface: {
          950: '#06090a',
          900: '#0a0f0d',
          850: '#0d1411',
          800: '#111815',
          750: '#151e1a',
          700: '#1b2622',
          600: '#27352f',
          500: '#3a4a43',
          400: '#5c6f67',
        },
        // Legacy aliases kept for compatibility with existing components
        primary: {
          50:  '#e8fff3',
          100: '#c9ffe1',
          200: '#94ffc7',
          400: '#3DDC84',
          500: '#22c55e',
          600: '#16a34a',
          700: '#0f7a38',
          800: '#0a5c2a',
          900: '#08431f',
        },
        medical: {
          50:  '#ecfdf5',
          100: '#d1fae5',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['"Space Grotesk"', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(61,220,132,0.15), 0 8px 30px -8px rgba(34,197,94,0.35)',
        'glow-lg': '0 0 0 1px rgba(61,220,132,0.18), 0 20px 60px -15px rgba(34,197,94,0.45)',
        'inner-glow': 'inset 0 1px 0 0 rgba(61,220,132,0.08)',
      },
      backgroundImage: {
        'grid-glow': 'radial-gradient(circle at 1px 1px, rgba(61,220,132,0.18) 1px, transparent 0)',
      },
    },
  },
  plugins: [],
}
