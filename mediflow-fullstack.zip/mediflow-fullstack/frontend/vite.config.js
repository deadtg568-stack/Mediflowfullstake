import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    // hls.js is ~520 kB standalone — warn at 600 kB to avoid spurious alerts
    chunkSizeWarningLimit: 600,
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-react': ['react', 'react-dom', 'react-router-dom'],
          'vendor-charts': ['recharts'],
          'vendor-icons': ['lucide-react'],
          'vendor-http': ['axios'],
          'vendor-stream': ['hls.js'],
          'vendor-misc': ['react-hot-toast', 'zustand', 'prop-types'],
        },
      },
    },
  },
})
