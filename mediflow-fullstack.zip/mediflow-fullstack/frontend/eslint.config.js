import js from '@eslint/js'
import globals from 'globals'

export default [
  js.configs.recommended,
  { ignores: ['dist'] },
  {
    files: ['**/*.{js,jsx}'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
      globals: { ...globals.browser, ...globals.es2021 },
      parserOptions: {
        ecmaFeatures: { jsx: true },
      },
    },
    rules: {
      // Focus on syntax errors and likely bugs (pre-build gate)
      'no-undef': 'error',
      'no-unused-vars': 'off',
      'no-unreachable': 'error',
      'no-constant-binary-expression': 'error',
      'no-duplicate-imports': 'error',
      'no-self-compare': 'error',
      'use-isnan': 'error',
      'valid-typeof': 'error',
      'no-extra-boolean-cast': 'off',
      'no-empty': ['error', { allowEmptyCatch: true }],
    },
  },
]
