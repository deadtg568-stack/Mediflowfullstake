import React from 'react'
import { X, Search as SearchIcon, TrendingUp, TrendingDown } from 'lucide-react'

// Shared card surface used everywhere — dark surface with subtle green border
export const cardClass = "bg-surface-900 rounded-2xl border border-surface-700"

export function StatCard({ icon: Icon, label, value, sub, color = 'green', trend }) {
  const colors = {
    green:  'bg-brand-500/10 text-brand-400 border-brand-500/20',
    blue:   'bg-blue-500/10 text-blue-400 border-blue-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    amber:  'bg-amber-500/10 text-amber-400 border-amber-500/20',
    red:    'bg-red-500/10 text-red-400 border-red-500/20',
  }
  return (
    <div className={`${cardClass} p-5 flex flex-col gap-1 hover:border-brand-500/20 transition-colors`}>
      <div className="flex items-start justify-between">
        <div className={`p-2.5 rounded-xl border ${colors[color]}`}>
          <Icon size={20} />
        </div>
        {trend !== undefined && trend !== null && (
          <span className={`flex items-center gap-1 text-xs font-medium ${trend > 0 ? 'text-brand-400' : 'text-red-400'}`}>
            {trend > 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <div className="mt-3">
        <p className="text-2xl font-semibold text-slate-100 font-mono-num">{value}</p>
        <p className="text-sm text-slate-400 mt-0.5">{label}</p>
        {sub && <p className="text-xs text-slate-500 mt-0.5">{sub}</p>}
      </div>
    </div>
  )
}

export function Table({ columns, data, actions }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-surface-700">
            {columns.map(c => (
              <th key={c.key} className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">
                {c.label}
              </th>
            ))}
            {actions && <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Actions</th>}
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i} className="border-b border-surface-800 hover:bg-surface-850 transition-colors">
              {columns.map(c => (
                <td key={c.key} className="px-4 py-3 text-slate-300">
                  {c.render ? c.render(row[c.key], row) : row[c.key]}
                </td>
              ))}
              {actions && (
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-2">{actions(row)}</div>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
      {data.length === 0 && (
        <div className="text-center py-12 text-slate-500 text-sm">No records found</div>
      )}
    </div>
  )
}

export function Modal({ open, onClose, title, children, size = 'md' }) {
  if (!open) return null
  const sizes = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative bg-surface-900 rounded-2xl border border-surface-700 shadow-glow-lg w-full ${sizes[size]} p-6`}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-display font-semibold text-slate-100 text-base">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-surface-800 text-slate-400 transition-colors">
            <X size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function Badge({ status }) {
  const map = {
    active:       'bg-brand-500/10 text-brand-400 border border-brand-500/20',
    completed:    'bg-brand-500/10 text-brand-400 border border-brand-500/20',
    verified:     'bg-brand-500/10 text-brand-400 border border-brand-500/20',
    paid:         'bg-brand-500/10 text-brand-400 border border-brand-500/20',
    confirmed:    'bg-brand-500/10 text-brand-400 border border-brand-500/20',
    pending:      'bg-amber-500/10 text-amber-400 border border-amber-500/20',
    processing:   'bg-blue-500/10 text-blue-400 border border-blue-500/20',
    'in progress':'bg-amber-500/10 text-amber-400 border border-amber-500/20',
    verification: 'bg-purple-500/10 text-purple-400 border border-purple-500/20',
    expired:      'bg-red-500/10 text-red-400 border border-red-500/20',
    inactive:     'bg-red-500/10 text-red-400 border border-red-500/20',
    unpaid:       'bg-red-500/10 text-red-400 border border-red-500/20',
    cancelled:    'bg-red-500/10 text-red-400 border border-red-500/20',
    open:         'bg-amber-500/10 text-amber-400 border border-amber-500/20',
    resolved:     'bg-brand-500/10 text-brand-400 border border-brand-500/20',
    serving:      'bg-blue-500/10 text-blue-400 border border-blue-500/20',
    waiting:      'bg-surface-700 text-slate-400 border border-surface-600',
  }
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium ${map[status?.toLowerCase()] || 'bg-blue-500/10 text-blue-400 border border-blue-500/20'}`}>
      {status}
    </span>
  )
}

export function SearchBar({ value, onChange, placeholder = 'Search...' }) {
  return (
    <div className="relative">
      <SearchIcon size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-64 bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 pl-9 text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500/40 transition-all"
      />
    </div>
  )
}

export function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="flex items-start justify-between mb-6 flex-wrap gap-3">
      <div>
        <h1 className="font-display text-xl font-semibold text-slate-100">{title}</h1>
        {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
    </div>
  )
}
