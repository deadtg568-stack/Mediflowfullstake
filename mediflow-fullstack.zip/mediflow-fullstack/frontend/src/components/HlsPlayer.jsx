import React, { useEffect, useRef, useState } from 'react'
import Hls from 'hls.js'
import { Wifi, WifiOff, Loader2 } from 'lucide-react'

/**
 * HlsPlayer
 * Plays an HLS (.m3u8) stream produced by the backend's RTSP->HLS pipeline.
 * Falls back gracefully with a "Camera Offline" placeholder if the stream
 * is unavailable or hls.js can't load it.
 *
 * Props:
 *  - src: full URL to index.m3u8
 *  - muted, autoPlay, controls: standard video behaviors
 *  - label: optional overlay name (camera name)
 */
export default function HlsPlayer({ src, muted = true, autoPlay = true, controls = false, label }) {
  const videoRef = useRef(null)
  const [status, setStatus] = useState('loading') // loading | playing | error

  useEffect(() => {
    const video = videoRef.current
    if (!video || !src) return

    let hls

    setStatus('loading')

    if (Hls.isSupported()) {
      hls = new Hls({
        maxBufferLength: 6,
        liveSyncDurationCount: 2,
        enableWorker: true,
      })
      hls.loadSource(src)
      hls.attachMedia(video)

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setStatus('playing')
        if (autoPlay) video.play().catch(() => {})
      })

      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) setStatus('error')
      })
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native HLS support (Safari)
      video.src = src
      video.addEventListener('loadedmetadata', () => {
        setStatus('playing')
        if (autoPlay) video.play().catch(() => {})
      })
      video.addEventListener('error', () => setStatus('error'))
    } else {
      setStatus('error')
    }

    return () => {
      if (hls) hls.destroy()
    }
  }, [src, autoPlay])

  return (
    <div className="relative w-full h-full bg-surface-950 overflow-hidden">
      <video
        ref={videoRef}
        muted={muted}
        controls={controls}
        playsInline
        className="w-full h-full object-cover"
      />

      {status === 'loading' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 bg-surface-950">
          <Loader2 size={28} className="animate-spin mb-2" />
          <p className="text-xs">Connecting...</p>
        </div>
      )}

      {status === 'error' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 bg-surface-950">
          <WifiOff size={28} className="mb-2" />
          <p className="text-xs">Camera Offline</p>
        </div>
      )}

      {status === 'playing' && (
        <div className="absolute top-3 left-3 flex items-center gap-1 bg-red-500/100 text-white text-xs px-2 py-0.5 rounded-full">
          <span className="w-1.5 h-1.5 bg-surface-900 rounded-full animate-pulse" />LIVE
        </div>
      )}

      {label && (
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent px-3 py-2">
          <p className="text-white text-sm font-medium">{label}</p>
        </div>
      )}
    </div>
  )
}
