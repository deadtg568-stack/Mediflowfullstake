import React, { useState, useEffect, useRef } from 'react'
import { Inbox } from 'lucide-react'

/* ─── Page fade-in wrapper ─────────────────────────────────────────────── */
export function PageTransition({ children }) {
  return <div className="animate-fadeIn">{children}</div>
}

/* ─── Staggered children ──────────────────────────────────────────────── */
export function Stagger({ children, className = '', style = {} }) {
  return (
    <div className={className} style={style}>
      {React.Children.map(children, (child, i) =>
        child ? <div className="animate-slideUp" style={{ animationDelay: `${i * 60}ms` }}>{child}</div> : null
      )}
    </div>
  )
}

/* ─── Counter that animates from 0 → value ─────────────────────────────── */
export function AnimatedCounter({ value, suffix = '', duration = 600, decimal = 0 }) {
  const [display, setDisplay] = useState(0)
  const startRef = useRef(null)
  const rafRef = useRef(null)

  useEffect(() => {
    if (typeof value !== 'number') { setDisplay(0); return }
    startRef.current = null
    const step = (timestamp) => {
      if (!startRef.current) startRef.current = timestamp
      const progress = Math.min((timestamp - startRef.current) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3) // easeOutCubic
      setDisplay(Math.round(value * eased * 10 ** decimal) / 10 ** decimal)
      if (progress < 1) rafRef.current = requestAnimationFrame(step)
    }
    rafRef.current = requestAnimationFrame(step)
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [value, duration, decimal])

  return <>{display.toLocaleString('en-IN', { minimumFractionDigits: decimal, maximumFractionDigits: decimal })}{suffix}</>
}

/* ─── Shimmer loading skeleton ─────────────────────────────────────────── */
export function Skeleton({ className = '', width, height, rounded = 'xl' }) {
  const roundMap = { sm: 'rounded', md: 'rounded-lg', xl: 'rounded-xl', '2xl': 'rounded-2xl', full: 'rounded-full' }
  return (
    <div
      className={`bg-surface-800/60 animate-shimmer ${roundMap[rounded] || rounded} ${className}`}
      style={{ width, height }}
    />
  )
}

export function CardSkeleton() {
  return (
    <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 space-y-4">
      <div className="flex items-center justify-between">
        <Skeleton width={80} height={16} />
        <Skeleton width={60} height={14} />
      </div>
      <Skeleton width="60%" height={32} />
      <Skeleton width="40%" height={14} />
    </div>
  )
}

export function TableSkeleton({ rows = 5, cols = 6 }) {
  return (
    <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 space-y-3">
      {/* Header */}
      <div className="flex gap-4 pb-3 border-b border-surface-700">
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} className="flex-1" height={14} />
        ))}
      </div>
      {/* Rows */}
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-4 py-2">
          {Array.from({ length: cols }).map((_, j) => (
            <Skeleton key={j} className="flex-1" height={14} rounded="md" />
          ))}
        </div>
      ))}
    </div>
  )
}

/* ─── Empty state ──────────────────────────────────────────────────────── */
export function EmptyState({ icon: Icon = Inbox, title = 'No data found', description = '', action }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="w-16 h-16 rounded-2xl bg-surface-800 border border-surface-700 flex items-center justify-center mb-4">
        <Icon size={28} className="text-slate-500" />
      </div>
      <p className="font-semibold text-slate-400 text-sm">{title}</p>
      {description && <p className="text-xs text-slate-600 mt-1 max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}
