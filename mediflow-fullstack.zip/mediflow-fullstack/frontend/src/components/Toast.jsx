import { Toaster } from 'react-hot-toast'

export default function ToastProvider() {
  return (
    <Toaster
      position="top-right"
      gutter={8}
      toastOptions={{
        duration: 3500,
        style: {
          background: '#0d1411',
          color: '#e6f5ed',
          border: '1px solid #1b2622',
          borderRadius: '12px',
          fontSize: '14px',
          padding: '12px 16px',
          boxShadow: '0 0 0 1px rgba(61,220,132,0.08), 0 8px 30px -8px rgba(0,0,0,0.6)',
        },
        success: { iconTheme: { primary: '#3DDC84', secondary: '#0d1411' } },
        error: { iconTheme: { primary: '#f87171', secondary: '#0d1411' } },
      }}
    />
  )
}
