import { useEffect } from 'react'

const DEFAULTS = {
  title: 'MediFlow Pro AI — Laboratory Information System',
  description: 'Complete laboratory management platform with AI-powered insights, patient management, billing, and real-time analytics for diagnostic labs.',
}

export default function SEO({ title, description }) {
  useEffect(() => {
    document.title = title || DEFAULTS.title
    const metaDesc = document.querySelector('meta[name="description"]')
    if (metaDesc) metaDesc.setAttribute('content', description || DEFAULTS.description)
  }, [title, description])
  return null
}
