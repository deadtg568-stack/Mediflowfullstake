import React, { useEffect, useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import api from '../utils/api'
import {
  LayoutDashboard, Users, FlaskConical, FileText, Receipt, Package,
  TrendingUp, Settings, LogOut, Menu, Bell, Sun, Moon, Search,
  Building2, CreditCard, Activity, Headphones, Microscope,
  ClipboardList, UserCog, Stethoscope, Heart, CalendarDays,
  Wallet, Bot, Video, ChevronDown, Sparkles, WifiOff, Radar,
} from 'lucide-react'

const navConfigs = {
  superadmin: [
    { label: 'Dashboard', icon: LayoutDashboard, to: '/superadmin' },
    { label: 'Lab Management', icon: Building2, to: '/superadmin/labs' },
    { label: 'Subscriptions', icon: CreditCard, to: '/superadmin/subscriptions' },
    { label: 'Revenue Analytics', icon: TrendingUp, to: '/superadmin/revenue' },
    { label: 'User Management', icon: Users, to: '/superadmin/users' },
    { label: 'AI Analytics', icon: Bot, to: '/superadmin/ai' },
    { label: 'Outbreak Radar', icon: Radar, to: '/superadmin/outbreak' },
    { label: 'Support Tickets', icon: Headphones, to: '/superadmin/support' },
    { label: 'Server Health', icon: Activity, to: '/superadmin/server' },
    { label: 'Settings', icon: Settings, to: '/superadmin/settings' },
  ],
  labadmin: [
    { label: 'Dashboard', icon: LayoutDashboard, to: '/labadmin' },
    { label: 'Patients', icon: Users, to: '/labadmin/patients' },
    { label: 'Doctors', icon: Stethoscope, to: '/labadmin/doctors' },
    { label: 'Samples / Tests', icon: FlaskConical, to: '/labadmin/tests' },
    { label: 'Appointments', icon: CalendarDays, to: '/labadmin/appointments' },
    { label: 'Billing', icon: Receipt, to: '/labadmin/billing' },
    { label: 'Reports', icon: FileText, to: '/labadmin/reports' },
    { label: 'Staff', icon: UserCog, to: '/labadmin/staff' },
    { label: 'Inventory', icon: Package, to: '/labadmin/inventory' },
    { label: 'Finance', icon: Wallet, to: '/labadmin/finance' },
    { label: 'Analytics', icon: TrendingUp, to: '/labadmin/analytics' },
    { label: 'AI Insights', icon: Bot, to: '/labadmin/ai' },
    { label: 'Outbreak Radar', icon: Radar, to: '/labadmin/outbreak' },
    { label: 'CCTV · Live View', icon: Video, to: '/labadmin/cctv' },
    { label: 'CCTV · Cameras', icon: Video, to: '/labadmin/cctv/cameras' },
    { label: 'CCTV · Recordings', icon: Video, to: '/labadmin/cctv/recordings' },
    { label: 'CCTV · Motion Events', icon: Video, to: '/labadmin/cctv/motion' },
    { label: 'CCTV · Settings', icon: Video, to: '/labadmin/cctv/settings' },
    { label: 'Settings', icon: Settings, to: '/labadmin/settings' },
  ],
  technician: [
    { label: 'Dashboard', icon: LayoutDashboard, to: '/technician' },
    { label: 'Sample Collection', icon: FlaskConical, to: '/technician/samples' },
    { label: 'Test Entry', icon: ClipboardList, to: '/technician/tests' },
    { label: 'Pending Reports', icon: FileText, to: '/technician/pending' },
    { label: 'Report Upload', icon: Activity, to: '/technician/upload' },
  ],
  reception: [
    { label: 'Dashboard', icon: LayoutDashboard, to: '/reception' },
    { label: 'Patient Registration', icon: Users, to: '/reception/register' },
    { label: 'Token System', icon: Receipt, to: '/reception/tokens' },
    { label: 'Appointments', icon: CalendarDays, to: '/reception/appointments' },
    { label: 'Billing', icon: Wallet, to: '/reception/billing' },
    { label: 'Home Collection', icon: Package, to: '/reception/homecollection' },
  ],
  doctor: [
    { label: 'Dashboard', icon: LayoutDashboard, to: '/doctor' },
    { label: 'Patient Reports', icon: FileText, to: '/doctor/reports' },
    { label: 'Patient History', icon: Heart, to: '/doctor/history' },
    { label: 'Trend Analysis', icon: TrendingUp, to: '/doctor/trends' },
    { label: 'Referrals', icon: Users, to: '/doctor/referrals' },
  ],
  patient: [
    { label: 'Dashboard', icon: LayoutDashboard, to: '/patient' },
    { label: 'My Reports', icon: FileText, to: '/patient/reports' },
    { label: 'Test Status', icon: Activity, to: '/patient/status' },
    { label: 'Book Test', icon: CalendarDays, to: '/patient/book' },
    { label: 'Payments', icon: Wallet, to: '/patient/payments' },
    { label: 'AI Summary', icon: Bot, to: '/patient/ai' },
  ],
}

const roleLabels = {
  superadmin: 'Super Admin',
  labadmin:   'Lab Admin',
  technician: 'Technician',
  reception:  'Reception',
  doctor:     'Doctor Portal',
  patient:    'Patient Portal',
}

export default function Layout({ role, children, title, subtitle }) {
  const { theme, toggleTheme, sidebarOpen, toggleSidebar, logout, user } = useStore()
  const navigate = useNavigate()
  const navItems = navConfigs[role] || []
  const [backendDown, setBackendDown] = useState(false)

  useEffect(() => {
    let cancelled = false
    const ping = () => {
      const base = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/api$/, '')
      fetch(`${base}/api/health`, { signal: AbortSignal.timeout(4000) })
        .then(res => { if (!cancelled) setBackendDown(!res.ok) })
        .catch(() => { if (!cancelled) setBackendDown(true) })
    }
    ping()
    const interval = setInterval(ping, 15000)
    return () => { cancelled = true; clearInterval(interval) }
  }, [])

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="flex h-screen overflow-hidden bg-surface-950 text-slate-100">
      {/* Sidebar */}
      <aside
        className="flex flex-col bg-surface-900 border-r border-surface-700 transition-all duration-300 flex-shrink-0"
        style={{ width: sidebarOpen ? 264 : 64 }}
      >
        {/* Logo */}
        <div className={`flex items-center gap-3 px-4 py-4 border-b border-surface-700 ${!sidebarOpen ? 'justify-center' : ''}`}>
          <div className="w-10 h-10 rounded-2xl border border-brand-500/30 bg-surface-850 flex items-center justify-center flex-shrink-0 shadow-glow">
            <Microscope size={18} className="text-brand-400" />
          </div>
          {sidebarOpen && (
            <div className="overflow-hidden">
              <p className="font-display font-semibold text-sm leading-tight whitespace-nowrap">
                MediFlow <span className="text-brand-400">Pro AI</span>
              </p>
              <p className="text-xs text-slate-500">Laboratory Information System</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to.split('/').length <= 2}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer
                ${!sidebarOpen ? 'justify-center px-0' : ''}
                ${isActive
                  ? 'bg-brand-500/10 text-brand-300 border border-brand-500/20 shadow-inner-glow'
                  : 'text-slate-400 hover:bg-surface-800 hover:text-slate-200 border border-transparent'}`
              }
            >
              <item.icon size={18} className="flex-shrink-0" />
              {sidebarOpen && <span className="truncate">{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* AI Assistant promo (lab admin) */}
        {sidebarOpen && role === 'labadmin' && (
          <div className="px-3 pb-3">
            <div className="rounded-2xl border border-brand-500/20 bg-gradient-to-br from-brand-500/10 to-transparent p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-7 h-7 rounded-lg bg-brand-500/15 border border-brand-500/25 flex items-center justify-center">
                  <Sparkles size={14} className="text-brand-400" />
                </div>
                <p className="text-sm font-semibold text-slate-200">MediFlow AI Assistant</p>
              </div>
              <p className="text-xs text-slate-400 mb-3 leading-relaxed">
                Ask anything about your lab data and get AI powered insights instantly.
              </p>
              <NavLink to="/labadmin/ai"
                className="flex items-center justify-center gap-1.5 w-full bg-brand-500/15 hover:bg-brand-500/25 text-brand-300 text-xs font-semibold py-2 rounded-xl border border-brand-500/25 transition-colors">
                Ask AI Assistant →
              </NavLink>
            </div>
          </div>
        )}

        {/* Logout */}
        <div className="border-t border-surface-700 p-3">
          <button
            onClick={handleLogout}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 transition-all w-full ${!sidebarOpen ? 'justify-center' : ''}`}
          >
            <LogOut size={18} className="flex-shrink-0" />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="flex items-center justify-between gap-4 px-6 py-3 bg-surface-900 border-b border-surface-700">
          <div className="flex items-center gap-4 min-w-0">
            <button onClick={toggleSidebar} className="p-2 rounded-lg hover:bg-surface-800 text-slate-400 transition-colors flex-shrink-0">
              <Menu size={18} />
            </button>
            {title && (
              <div className="min-w-0">
                <h1 className="font-display text-lg font-semibold text-slate-100 truncate">{title}</h1>
                {subtitle && <p className="text-xs text-slate-500 truncate">{subtitle}</p>}
              </div>
            )}
          </div>

          {/* Search */}
          <div className="hidden md:flex flex-1 max-w-md relative">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              placeholder="Search patients, tests, reports..."
              className="w-full bg-surface-850 border border-surface-700 rounded-xl pl-9 pr-12 py-2 text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500/40 transition-all"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 border border-surface-700 rounded px-1.5 py-0.5">Ctrl+K</span>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button className="p-2 rounded-lg hover:bg-surface-800 text-slate-400 transition-colors relative">
              <Bell size={18} />
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-brand-500 text-surface-950 text-[10px] font-bold rounded-full flex items-center justify-center">8</span>
            </button>
            <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-surface-800 text-slate-400 transition-colors">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <div className="flex items-center gap-2 ml-1 pl-3 border-l border-surface-700 cursor-pointer group">
              <div className="w-9 h-9 rounded-full bg-surface-850 border border-brand-500/25 flex items-center justify-center text-brand-400 text-sm font-semibold">
                {roleLabels[role][0]}
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-medium text-slate-200 leading-tight">{user?.name || roleLabels[role]}</p>
                <p className="text-xs text-slate-500">{roleLabels[role]}</p>
              </div>
              <ChevronDown size={14} className="text-slate-500 group-hover:text-slate-300 transition-colors hidden sm:block" />
            </div>
          </div>
        </header>

        {/* Backend connectivity banner */}
        {backendDown && (
          <div className="flex items-center gap-2 px-6 py-2 bg-red-500/10 border-b border-red-500/20 text-red-300 text-xs">
            <WifiOff size={14} />
            Cannot reach the backend API at <code className="font-mono-num">{import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}</code>.
            Make sure the backend server is running (<code className="font-mono-num">cd backend && npm run dev</code>) — until then, data won't load or save.
          </div>
        )}

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6 bg-surface-950">
          <div className="fade-in">{children}</div>
        </main>
      </div>
    </div>
  )
}
