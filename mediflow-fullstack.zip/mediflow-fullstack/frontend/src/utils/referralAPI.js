import api from './api'

export const referralAPI = {
  // Partners
  getPartners:   (params) => api.get('/referral/partners', { params }),
  createPartner: (data)   => api.post('/referral/partners', data),
  getPartner:    (id)     => api.get(`/referral/partners/${id}`),
  updatePartner: (id, data) => api.put(`/referral/partners/${id}`, data),
  deletePartner: (id)     => api.delete(`/referral/partners/${id}`),

  // Verify code (public)
  verifyCode: (code) => api.get(`/referral/verify/${code}`),

  // Logs
  getLogs:    (params) => api.get('/referral/logs', { params }),
  verify:     (id)     => api.patch(`/referral/logs/${id}/verify`),
  approve:    (id, data) => api.patch(`/referral/logs/${id}/approve`, data),
  reject:     (id, data) => api.patch(`/referral/logs/${id}/reject`, data),
  pay:        (id, data) => api.patch(`/referral/logs/${id}/pay`, data),

  // Stats
  getStats: () => api.get('/referral/stats'),
}
