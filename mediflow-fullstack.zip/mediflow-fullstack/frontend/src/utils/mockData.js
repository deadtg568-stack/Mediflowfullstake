export const mockPatients = [
  { id: 'P001', name: 'Rahul Sharma', age: 34, gender: 'Male', phone: '9876543210', tests: ['CBC', 'LFT'], status: 'completed', date: '2026-06-12', amount: 1200 },
  { id: 'P002', name: 'Priya Verma', age: 28, gender: 'Female', phone: '9123456780', tests: ['Thyroid Profile'], status: 'pending', date: '2026-06-13', amount: 850 },
  { id: 'P003', name: 'Anil Kumar', age: 52, gender: 'Male', phone: '9988776655', tests: ['Lipid Profile', 'HbA1c'], status: 'processing', date: '2026-06-13', amount: 1600 },
  { id: 'P004', name: 'Sunita Patel', age: 45, gender: 'Female', phone: '8877665544', tests: ['Urine Routine'], status: 'completed', date: '2026-06-11', amount: 300 },
  { id: 'P005', name: 'Vikram Singh', age: 38, gender: 'Male', phone: '7766554433', tests: ['CBC', 'CRP', 'ESR'], status: 'pending', date: '2026-06-13', amount: 950 },
]

export const mockTests = [
  { id: 'T001', name: 'Complete Blood Count (CBC)', category: 'Haematology', price: 350, tat: '4 hrs', status: 'active' },
  { id: 'T002', name: 'Lipid Profile', category: 'Biochemistry', price: 600, tat: '6 hrs', status: 'active' },
  { id: 'T003', name: 'Thyroid Profile (T3,T4,TSH)', category: 'Immunology', price: 850, tat: '8 hrs', status: 'active' },
  { id: 'T004', name: 'Liver Function Test (LFT)', category: 'Biochemistry', price: 700, tat: '6 hrs', status: 'active' },
  { id: 'T005', name: 'HbA1c', category: 'Biochemistry', price: 500, tat: '4 hrs', status: 'active' },
  { id: 'T006', name: 'Urine Routine & Microscopy', category: 'Urine', price: 250, tat: '2 hrs', status: 'active' },
]

export const mockDoctors = [
  { id: 'D001', name: 'Dr. Rajesh Mehta', speciality: 'General Physician', phone: '9800000001', referrals: 45, commission: 10 },
  { id: 'D002', name: 'Dr. Anita Gupta', speciality: 'Gynaecologist', phone: '9800000002', referrals: 32, commission: 10 },
  { id: 'D003', name: 'Dr. Suresh Nair', speciality: 'Cardiologist', phone: '9800000003', referrals: 28, commission: 8 },
  { id: 'D004', name: 'Dr. Kavya Rao', speciality: 'Diabetologist', phone: '9800000004', referrals: 19, commission: 10 },
]

export const mockLabs = [
  { id: 'L001', name: 'City Diagnostics', owner: 'Ramesh Gupta', plan: 'Professional', status: 'active', expiry: '2027-01-15', patients: 234, revenue: 48000 },
  { id: 'L002', name: 'Sharma Lab & Path', owner: 'Vikram Sharma', plan: 'Starter', status: 'active', expiry: '2026-09-30', patients: 98, revenue: 18000 },
  { id: 'L003', name: 'LifeCare Diagnostics', owner: 'Priya Nair', plan: 'Enterprise AI', status: 'active', expiry: '2027-03-20', patients: 512, revenue: 112000 },
  { id: 'L004', name: 'Arogya Pathology', owner: 'Suresh Patel', plan: 'Professional', status: 'expired', expiry: '2026-05-10', patients: 145, revenue: 32000 },
  { id: 'L005', name: 'MedPoint Lab', owner: 'Anjali Singh', plan: 'Starter', status: 'active', expiry: '2026-08-22', patients: 67, revenue: 12000 },
]

export const revenueData = [
  { month: 'Jan', revenue: 32000, patients: 120 },
  { month: 'Feb', revenue: 38000, patients: 145 },
  { month: 'Mar', revenue: 35000, patients: 132 },
  { month: 'Apr', revenue: 42000, patients: 158 },
  { month: 'May', revenue: 48000, patients: 180 },
  { month: 'Jun', revenue: 52000, patients: 196 },
]

export const testPopularity = [
  { name: 'CBC', count: 245 },
  { name: 'LFT', count: 189 },
  { name: 'Thyroid', count: 167 },
  { name: 'Lipid', count: 143 },
  { name: 'HbA1c', count: 112 },
  { name: 'Urine', count: 98 },
]

export const inventoryItems = [
  { id: 'INV001', name: 'EDTA Vacutainer', category: 'Consumables', stock: 450, minStock: 100, unit: 'pcs', expiry: '2027-12-01', vendor: 'BD India' },
  { id: 'INV002', name: 'CBC Reagent Kit', category: 'Reagents', stock: 8, minStock: 5, unit: 'kits', expiry: '2026-09-15', vendor: 'Sysmex India' },
  { id: 'INV003', name: 'Glucose Reagent', category: 'Reagents', stock: 3, minStock: 5, unit: 'bottles', expiry: '2026-07-20', vendor: 'Transasia' },
  { id: 'INV004', name: 'Urine Strips', category: 'Consumables', stock: 200, minStock: 50, unit: 'pcs', expiry: '2026-11-30', vendor: 'Medi-Test' },
  { id: 'INV005', name: 'SST Vacutainer', category: 'Consumables', stock: 380, minStock: 100, unit: 'pcs', expiry: '2027-06-01', vendor: 'BD India' },
]

export const staffList = [
  { id: 'S001', name: 'Kavita Sharma', role: 'Technician', phone: '9700000001', shift: 'Morning', status: 'active' },
  { id: 'S002', name: 'Ravi Kumar', role: 'Receptionist', phone: '9700000002', shift: 'Morning', status: 'active' },
  { id: 'S003', name: 'Sunita Devi', role: 'Technician', phone: '9700000003', shift: 'Evening', status: 'active' },
  { id: 'S004', name: 'Amit Yadav', role: 'Lab Helper', phone: '9700000004', shift: 'Morning', status: 'inactive' },
]

export const pendingReports = [
  { id: 'R001', patient: 'Rahul Sharma', test: 'CBC', collected: '08:30 AM', status: 'processing', tech: 'Kavita Sharma' },
  { id: 'R002', patient: 'Priya Verma', test: 'Thyroid Profile', collected: '09:15 AM', status: 'pending', tech: 'Ravi Kumar' },
  { id: 'R003', patient: 'Anil Kumar', test: 'Lipid Profile', collected: '09:45 AM', status: 'verification', tech: 'Kavita Sharma' },
  { id: 'R004', patient: 'Neha Singh', test: 'LFT', collected: '10:00 AM', status: 'pending', tech: 'Sunita Devi' },
]
