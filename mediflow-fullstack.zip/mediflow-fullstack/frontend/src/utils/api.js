import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

// Extract an array from a variety of API response shapes.
// Checks: response itself, response.data, response.data[fallbackKey]
export function extractArray(resData, fallbackKey) {
  if (Array.isArray(resData)) return resData
  if (Array.isArray(resData.data)) return resData.data
  if (fallbackKey && Array.isArray(resData[fallbackKey])) return resData[fallbackKey]
  return []
}

const api = axios.create({
  baseURL: API_BASE,
  timeout: 15000,
})

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('mf_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Handle 401 globally + log errors for easier debugging
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response) {
      // Server responded with an error status
      console.error(`[API ${err.response.status}] ${err.config?.method?.toUpperCase()} ${err.config?.url}`, err.response.data)
      if (err.response.status === 401) {
        localStorage.removeItem('mf_token')
        localStorage.removeItem('mf_user')
        window.location.href = '/login'
      }
    } else if (err.request) {
      // Request was made but no response received — backend unreachable
      console.error(`[API NETWORK ERROR] ${err.config?.method?.toUpperCase()} ${err.config?.baseURL}${err.config?.url} — is the backend running?`, err.message)
    } else {
      console.error('[API ERROR]', err.message)
    }
    return Promise.reject(err)
  }
)

// Returns a human-readable message for any API error — use this in toast.error()
export const apiErrorMessage = (err, fallback = 'Something went wrong') => {
  if (err.response?.data?.message) return err.response.data.message
  if (err.request) return `Cannot reach server (${API_BASE}). Is the backend running?`
  return err.message || fallback
}

// ─── AUTH ─────────────────────────────────────────────────────────────────────
export const authAPI = {
  login:          (phone, password, role) => api.post('/auth/login', { phone, password, role }),
  getMe:          () => api.get('/auth/me'),
  logout:         () => api.post('/auth/logout'),
  changePassword: (currentPassword, newPassword) => api.post('/auth/change-password', { currentPassword, newPassword }),
}

// ─── PATIENTS ─────────────────────────────────────────────────────────────────
export const patientAPI = {
  getAll:   (params) => api.get('/patients', { params }),
  getOne:   (id)     => api.get(`/patients/${id}`),
  create:   (data)   => api.post('/patients', data),
  update:   (id, data) => api.put(`/patients/${id}`, data),
  delete:   (id)     => api.delete(`/patients/${id}`),
}

// ─── BILLING ──────────────────────────────────────────────────────────────────
export const billingAPI = {
  getAll:        (params) => api.get('/billing', { params }),
  getOne:        (id)     => api.get(`/billing/${id}`),
  create:        (data)   => api.post('/billing', data),
  updatePayment: (id, data) => api.patch(`/billing/${id}/payment`, data),
  voidBill:      (id)     => api.patch(`/billing/${id}/void`),
  todaySummary:  ()       => api.get('/billing/today/summary'),
}

// ─── REPORTS ──────────────────────────────────────────────────────────────────
export const reportAPI = {
  getAll:  (params)   => api.get('/reports', { params }),
  update:  (id, data) => api.put(`/reports/${id}`, data),
  delete:  (id)       => api.delete(`/reports/${id}`),
}

// ─── DOCTORS ──────────────────────────────────────────────────────────────────
export const doctorAPI = {
  getAll:  (params)   => api.get('/doctors', { params }),
  create:  (data)     => api.post('/doctors', data),
  update:  (id, data) => api.put(`/doctors/${id}`, data),
  delete:  (id)       => api.delete(`/doctors/${id}`),
}

// ─── TESTS ────────────────────────────────────────────────────────────────────
export const testAPI = {
  getAll:  (params)   => api.get('/tests', { params }),
  create:  (data)     => api.post('/tests', data),
  update:  (id, data) => api.put(`/tests/${id}`, data),
  delete:  (id)       => api.delete(`/tests/${id}`),
}

// ─── STAFF ────────────────────────────────────────────────────────────────────
export const staffAPI = {
  getAll:  ()         => api.get('/staff'),
  create:  (data)     => api.post('/staff', data),
  update:  (id, data) => api.put(`/staff/${id}`, data),
}

// ─── INVENTORY ────────────────────────────────────────────────────────────────
export const inventoryAPI = {
  getAll:      ()         => api.get('/inventory'),
  create:      (data)     => api.post('/inventory', data),
  update:      (id, data) => api.put(`/inventory/${id}`, data),
  delete:      (id)       => api.delete(`/inventory/${id}`),
  adjustStock: (id, data) => api.patch(`/inventory/${id}/stock`, data),
}

// ─── APPOINTMENTS ─────────────────────────────────────────────────────────────
export const appointmentAPI = {
  getAll:  (params)   => api.get('/appointments', { params }),
  create:  (data)     => api.post('/appointments', data),
  update:  (id, data) => api.put(`/appointments/${id}`, data),
  delete:  (id)       => api.delete(`/appointments/${id}`),
}

// ─── ANALYTICS ────────────────────────────────────────────────────────────────
export const analyticsAPI = {
  dashboard:      () => api.get('/analytics/dashboard'),
  monthlyRevenue: () => api.get('/analytics/monthly-revenue'),
  topTests:       () => api.get('/analytics/top-tests'),
  topDoctors:     () => api.get('/analytics/top-doctors'),
}

// ─── SUPER ADMIN ──────────────────────────────────────────────────────────────
export const superAdminAPI = {
  dashboard:     ()         => api.get('/superadmin/dashboard'),
  getAllLabs:     ()         => api.get('/superadmin/labs'),
  createLab:     (data)     => api.post('/superadmin/labs', data),
  updateStatus:  (id, status) => api.patch(`/superadmin/labs/${id}/status`, { status }),
  renewSub:      (id, months) => api.post(`/superadmin/labs/${id}/renew`, { months }),
  revenue:       ()         => api.get('/superadmin/revenue'),
  getAllUsers:    ()         => api.get('/superadmin/users'),
}

// ─── LAB ──────────────────────────────────────────────────────────────────────
export const labAPI = {
  getMy:              ()     => api.get('/labs/my'),
  update:             (data) => api.put('/labs/my', data),
  getPrintSettings:   ()     => api.get('/labs/my/print-settings'),
  savePrintSettings:  (data) => api.put('/labs/my/print-settings', data),
}

// ─── SUPER ADMIN LAB PRINT SETTINGS ──────────────────────────────────────────
export const superAdminPrintAPI = {
  getPrintSettings:  (labId) => api.get(`/superadmin/labs/${labId}/print-settings`),
  savePrintSettings: (labId, data) => api.put(`/superadmin/labs/${labId}/print-settings`, data),
}

// ─── SUBSCRIPTION ─────────────────────────────────────────────────────────────
export const subscriptionAPI = {
  getPlans: () => api.get('/subscriptions/plans'),
  getMy:    () => api.get('/subscriptions/my'),
}

// ─── CAMERAS / CCTV ───────────────────────────────────────────────────────────
export const cameraAPI = {
  // CRUD
  getAll:   ()         => api.get('/cameras'),
  getOne:   (id)       => api.get(`/cameras/${id}`),
  create:   (data)     => api.post('/cameras', data),
  update:   (id, data) => api.put(`/cameras/${id}`, data),
  delete:   (id)       => api.delete(`/cameras/${id}`),

  // ONVIF auto-discovery
  discover:        (timeout) => api.get('/cameras/discover', { params: { timeout } }),
  discoverConnect: (data)    => api.post('/cameras/discover/connect', data),
  discoverAdd:     (data)    => api.post('/cameras/discover/add', data),

  // Live streaming (RTSP -> HLS)
  startStream:    (id) => api.post(`/cameras/${id}/stream/start`),
  stopStream:     (id) => api.post(`/cameras/${id}/stream/stop`),
  activeStreams:  ()   => api.get('/cameras/streams/active'),
  snapshotUrl:    (id) => `${API_BASE}/cameras/${id}/snapshot?t=${Date.now()}`,

  // Recording & playback
  startRecording: (id, segmentMinutes) => api.post(`/cameras/${id}/recording/start`, { segmentMinutes }),
  stopRecording:  (id) => api.post(`/cameras/${id}/recording/stop`),
  getRecordings:  (id) => api.get(`/cameras/${id}/recordings`),

  // AI motion detection
  startMotion: (id, data) => api.post(`/cameras/${id}/motion/start`, data),
  stopMotion:  (id)       => api.post(`/cameras/${id}/motion/stop`),
  testMotion:  (id)       => api.post(`/cameras/${id}/motion/test`),
  getMotionEvents: (params) => api.get('/cameras/motion-events', { params }),
  reviewMotionEvent: (id) => api.patch(`/cameras/motion-events/${id}/review`),
}

// ─── OUTBREAK RADAR ───────────────────────────────────────────────────────────
export const outbreakAPI = {
  getTrends:   (days) => api.get('/outbreak/trends', { params: { days } }),
  getAlerts:   () => api.get('/outbreak/alerts'),
  getNational: () => api.get('/outbreak/national'),
  triggerDetection: () => api.post('/outbreak/detect'),
  resolveAlert: (id) => api.patch(`/outbreak/alerts/${id}/resolve`),
}

// ─── GPS TRACKING ────────────────────────────────────────────────────────────
export const gpsAPI = {
  startTracking:   (data) => api.post('/gps/start', data),
  updateLocation:  (data) => api.post('/gps/location', data),
  updateStatus:    (id, data) => api.patch(`/gps/${id}/status`, data),
  stopTracking:    (id)   => api.post(`/gps/${id}/stop`),
  getActive:       ()     => api.get('/gps/active'),
  getHistory:      (id)   => api.get(`/gps/history/${id}`),
  getAll:          (params) => api.get('/gps', { params }),
}

// Base URL for static assets (HLS streams, recordings, snapshots)
// e.g. `${STATIC_BASE}${camera.streamingUrl}` -> http://localhost:5000/streams/cam_xxx/index.m3u8
export const STATIC_BASE = API_BASE.replace(/\/api$/, '')

export default api
