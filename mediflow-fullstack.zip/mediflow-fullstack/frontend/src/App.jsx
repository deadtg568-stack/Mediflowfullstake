import React, { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useStore } from './store'
import Layout from './layouts/Layout'
import ErrorBoundary from './components/ErrorBoundary'

import Login from './pages/Login'
import Settings from './pages/Settings'

import SuperAdminDashboard from './pages/superadmin/Dashboard'
import LabManagement from './pages/superadmin/LabManagement'
import UserManagement from './pages/superadmin/UserManagement'
import { Subscriptions, Revenue, ServerHealth, AIAnalytics, Support } from './pages/superadmin/Others'

import LabDashboard from './pages/labadmin/Dashboard'
import { Patients, Doctors, Tests } from './pages/labadmin/PatientsDoctorsTests'
import { Billing, Reports, Staff, Inventory, Finance, Analytics } from './pages/labadmin/BillingEtc'
import { AIAssistant } from './pages/labadmin/AIAndCCTV'
import { Appointments, LabSettings } from './pages/labadmin/AppointmentsSettings'

// CCTV Module
import CameraManagement from './pages/labadmin/cctv/CameraManagement'
import LiveView from './pages/labadmin/cctv/LiveView'
import Recordings from './pages/labadmin/cctv/Recordings'
import MotionEvents from './pages/labadmin/cctv/MotionEvents'
import CctvSettings from './pages/labadmin/cctv/CctvSettings'

// Outbreak Radar Module
import OutbreakRadar from './pages/labadmin/outbreak/OutbreakRadar'
import OutbreakMap from './pages/superadmin/outbreak/OutbreakMap'
import PrintPageEditor from './pages/superadmin/print/PrintPageEditor'
import Partners from './pages/superadmin/referral/Partners'
import ReferralLogs from './pages/superadmin/referral/ReferralLogs'

import { TechnicianDashboard, SampleCollection, PendingReports } from './pages/technician/TechnicianPages'
import GpsTracker from './pages/technician/GpsTracker'
import GpsTrackingDashboard from './pages/labadmin/GpsTracking'
import { ReceptionDashboard, PatientRegistration, TokenSystem, HomeCollection } from './pages/reception/ReceptionPages'
import { DoctorDashboard, PatientReports, PatientHistory, TrendAnalysis, Referrals } from './pages/doctor/DoctorPages'
import { PatientDashboard, MyReports, TestStatus, BookTest, Payments, PatientAISummary } from './pages/patient/PatientPages'

function W({ role, children }) {
  return <Layout role={role}>{children}</Layout>
}

export default function App() {
  const { theme } = useStore()

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  return (
    <BrowserRouter>
      <ErrorBoundary>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />

        <Route path="/superadmin" element={<W role="superadmin"><SuperAdminDashboard /></W>} />
        <Route path="/superadmin/labs" element={<W role="superadmin"><LabManagement /></W>} />
        <Route path="/superadmin/subscriptions" element={<W role="superadmin"><Subscriptions /></W>} />
        <Route path="/superadmin/revenue" element={<W role="superadmin"><Revenue /></W>} />
        <Route path="/superadmin/users" element={<W role="superadmin"><UserManagement /></W>} />
        <Route path="/superadmin/ai" element={<W role="superadmin"><AIAnalytics /></W>} />
        <Route path="/superadmin/support" element={<W role="superadmin"><Support /></W>} />
        <Route path="/superadmin/server" element={<W role="superadmin"><ServerHealth /></W>} />
        <Route path="/superadmin/settings" element={<W role="superadmin"><Settings /></W>} />
        <Route path="/superadmin/outbreak" element={<W role="superadmin"><OutbreakMap /></W>} />
        <Route path="/superadmin/print-editor" element={<W role="superadmin"><PrintPageEditor /></W>} />
        <Route path="/superadmin/referral/partners" element={<W role="superadmin"><Partners /></W>} />
        <Route path="/superadmin/referral/logs" element={<W role="superadmin"><ReferralLogs /></W>} />

        <Route path="/labadmin" element={<W role="labadmin"><LabDashboard /></W>} />
        <Route path="/labadmin/patients" element={<W role="labadmin"><Patients /></W>} />
        <Route path="/labadmin/doctors" element={<W role="labadmin"><Doctors /></W>} />
        <Route path="/labadmin/tests" element={<W role="labadmin"><Tests /></W>} />
        <Route path="/labadmin/appointments" element={<W role="labadmin"><Appointments /></W>} />
        <Route path="/labadmin/billing" element={<W role="labadmin"><Billing /></W>} />
        <Route path="/labadmin/reports" element={<W role="labadmin"><Reports /></W>} />
        <Route path="/labadmin/staff" element={<W role="labadmin"><Staff /></W>} />
        <Route path="/labadmin/inventory" element={<W role="labadmin"><Inventory /></W>} />
        <Route path="/labadmin/finance" element={<W role="labadmin"><Finance /></W>} />
        <Route path="/labadmin/analytics" element={<W role="labadmin"><Analytics /></W>} />
        <Route path="/labadmin/ai" element={<W role="labadmin"><AIAssistant /></W>} />
        <Route path="/labadmin/cctv" element={<W role="labadmin"><LiveView /></W>} />
        <Route path="/labadmin/cctv/cameras" element={<W role="labadmin"><CameraManagement /></W>} />
        <Route path="/labadmin/cctv/recordings" element={<W role="labadmin"><Recordings /></W>} />
        <Route path="/labadmin/cctv/motion" element={<W role="labadmin"><MotionEvents /></W>} />
        <Route path="/labadmin/cctv/settings" element={<W role="labadmin"><CctvSettings /></W>} />
        <Route path="/labadmin/outbreak" element={<W role="labadmin"><OutbreakRadar /></W>} />
        <Route path="/labadmin/gps" element={<W role="labadmin"><GpsTrackingDashboard /></W>} />
        <Route path="/labadmin/settings" element={<W role="labadmin"><LabSettings /></W>} />

        <Route path="/technician" element={<W role="technician"><TechnicianDashboard /></W>} />
        <Route path="/technician/samples" element={<W role="technician"><SampleCollection /></W>} />
        <Route path="/technician/tests" element={<W role="technician"><TechnicianDashboard /></W>} />
        <Route path="/technician/pending" element={<W role="technician"><PendingReports /></W>} />
        <Route path="/technician/upload" element={<W role="technician"><PendingReports /></W>} />
        <Route path="/technician/gps" element={<W role="technician"><GpsTracker /></W>} />

        <Route path="/reception" element={<W role="reception"><ReceptionDashboard /></W>} />
        <Route path="/reception/register" element={<W role="reception"><PatientRegistration /></W>} />
        <Route path="/reception/tokens" element={<W role="reception"><TokenSystem /></W>} />
        <Route path="/reception/appointments" element={<W role="reception"><Appointments /></W>} />
        <Route path="/reception/billing" element={<W role="reception"><Billing /></W>} />
        <Route path="/reception/homecollection" element={<W role="reception"><HomeCollection /></W>} />

        <Route path="/doctor" element={<W role="doctor"><DoctorDashboard /></W>} />
        <Route path="/doctor/reports" element={<W role="doctor"><PatientReports /></W>} />
        <Route path="/doctor/history" element={<W role="doctor"><PatientHistory /></W>} />
        <Route path="/doctor/trends" element={<W role="doctor"><TrendAnalysis /></W>} />
        <Route path="/doctor/referrals" element={<W role="doctor"><Referrals /></W>} />

        <Route path="/patient" element={<W role="patient"><PatientDashboard /></W>} />
        <Route path="/patient/reports" element={<W role="patient"><MyReports /></W>} />
        <Route path="/patient/status" element={<W role="patient"><TestStatus /></W>} />
        <Route path="/patient/book" element={<W role="patient"><BookTest /></W>} />
        <Route path="/patient/payments" element={<W role="patient"><Payments /></W>} />
        <Route path="/patient/ai" element={<W role="patient"><PatientAISummary /></W>} />

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
      </ErrorBoundary>
    </BrowserRouter>
  )
}
