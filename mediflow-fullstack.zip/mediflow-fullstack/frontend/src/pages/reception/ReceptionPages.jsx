import React, { useState } from 'react'
import { PageHeader, Badge, StatCard, Modal } from '../../components/UI'
import { Users, Clock, Receipt, Home, Plus, Navigation } from 'lucide-react'
import toast from 'react-hot-toast'

export function ReceptionDashboard() {
  const [showRegModal, setShowRegModal] = useState(false)
  const [showBillingModal, setShowBillingModal] = useState(false)
  const [showHomeModal, setShowHomeModal] = useState(false)

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-100">Reception Desk</h1>
        <p className="text-sm text-slate-500">Ravi Kumar · Morning Shift · {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="Patients Today" value="24" color="blue" />
        <StatCard icon={Clock} label="Current Token" value="#18" color="amber" />
        <StatCard icon={Receipt} label="Billing Done" value="₹18,400" color="green" />
        <StatCard icon={Home} label="Home Collection" value="3 booked" color="purple" />
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'New Registration', desc: 'Register walk-in patient', color: 'from-blue-500 to-cyan-600', icon: Users, action: () => setShowRegModal(true) },
          { label: 'Quick Billing', desc: 'Generate invoice', color: 'from-emerald-500 to-teal-600', icon: Receipt, action: () => setShowBillingModal(true) },
          { label: 'Book Home Collection', desc: 'Schedule home visit', color: 'from-purple-500 to-indigo-600', icon: Home, action: () => setShowHomeModal(true) },
        ].map(a => (
          <button key={a.label} onClick={a.action} className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-left hover:shadow-md hover:border-brand-500/30 transition-all cursor-pointer">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${a.color} flex items-center justify-center mb-3`}>
              <a.icon size={20} className="text-white" />
            </div>
            <p className="font-medium text-slate-300">{a.label}</p>
            <p className="text-xs text-slate-500 mt-0.5">{a.desc}</p>
          </button>
        ))}
      </div>

      {/* New Registration Modal */}
      <Modal open={showRegModal} onClose={() => setShowRegModal(false)} title="Register New Patient" size="lg">
        <ReceptionRegistrationForm onClose={() => setShowRegModal(false)} />
      </Modal>

      {/* Quick Billing Modal */}
      <Modal open={showBillingModal} onClose={() => setShowBillingModal(false)} title="Quick Billing" size="lg">
        <QuickBillingForm onClose={() => setShowBillingModal(false)} />
      </Modal>

      {/* Home Collection Modal */}
      <Modal open={showHomeModal} onClose={() => setShowHomeModal(false)} title="Book Home Collection" size="lg">
        <HomeCollectionForm onClose={() => setShowHomeModal(false)} />
      </Modal>
    </div>
  )
}

function ReceptionRegistrationForm({ onClose }) {
  const [form, setForm] = useState({ name: '', age: '', gender: 'Male', phone: '', dob: '', referredBy: 'Self', address: '' })
  const handleSubmit = (e) => {
    e.preventDefault()
    toast.success('Patient registered successfully!')
    onClose()
  }
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Full name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Age *</label><input required type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Age" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} /></div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Gender *</label>
          <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}><option>Male</option><option>Female</option><option>Other</option></select>
        </div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Phone *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Mobile number" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Date of Birth</label><input type="date" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form.dob} onChange={e => setForm({ ...form, dob: e.target.value })} /></div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Referred By</label>
          <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form.referredBy} onChange={e => setForm({ ...form, referredBy: e.target.value })}><option>Self</option><option>Dr. Rajesh Mehta</option><option>Dr. Anita Gupta</option></select>
        </div>
      </div>
      <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Address</label><textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all h-16 resize-none" placeholder="Full address" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
      <div className="flex gap-2">
        <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Register & Add Tests</button>
        <button type="button" onClick={onClose} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Cancel</button>
      </div>
    </form>
  )
}

function QuickBillingForm({ onClose }) {
  const [form, setForm] = useState({ patient: '', tests: '', amount: '', paymentMode: 'cash' })
  const handleSubmit = (e) => {
    e.preventDefault()
    toast.success('Invoice generated!')
    onClose()
  }
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Patient name" value={form.patient} onChange={e => setForm({ ...form, patient: e.target.value })} /></div>
      <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Tests (comma separated) *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. CBC, LFT" value={form.tests} onChange={e => setForm({ ...form, tests: e.target.value })} /></div>
      <div className="grid grid-cols-2 gap-4">
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Amount (₹) *</label><input required type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="0" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} /></div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Payment Mode</label>
          <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.paymentMode} onChange={e => setForm({ ...form, paymentMode: e.target.value })}><option value="cash">Cash</option><option value="upi">UPI</option><option value="card">Card</option></select>
        </div>
      </div>
      <div className="flex gap-2">
        <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Generate Invoice</button>
        <button type="button" onClick={onClose} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Cancel</button>
      </div>
    </form>
  )
}

function HomeCollectionForm({ onClose }) {
  const [form, setForm] = useState({ patient: '', phone: '', address: '', tests: '', date: '', time: '' })
  const handleSubmit = (e) => {
    e.preventDefault()
    toast.success('Home collection booked!')
    onClose()
  }
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Name" value={form.patient} onChange={e => setForm({ ...form, patient: e.target.value })} /></div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Phone *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Mobile" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
      </div>
      <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Address *</label><textarea required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-16 resize-none" placeholder="Full address" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
      <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Tests *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. CBC, LFT" value={form.tests} onChange={e => setForm({ ...form, tests: e.target.value })} /></div>
      <div className="grid grid-cols-2 gap-4">
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Date *</label><input required type="date" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></div>
        <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Preferred Time *</label><input required type="time" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} /></div>
      </div>
      <div className="flex gap-2">
        <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Book Visit</button>
        <button type="button" onClick={onClose} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Cancel</button>
      </div>
    </form>
  )
}

export function PatientRegistration() {
  const [form, setForm] = useState({ name: '', age: '', gender: 'Male', phone: '', dob: '', referredBy: 'Self', address: '' })
  const handleSubmit = (e) => {
    e.preventDefault()
    toast.success('Patient registered successfully!')
    setForm({ name: '', age: '', gender: 'Male', phone: '', dob: '', referredBy: 'Self', address: '' })
  }
  return (
    <div>
      <PageHeader title="Patient Registration" subtitle="Register new or existing patient" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 max-w-2xl">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Full name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Age *</label><input required type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Age" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Gender *</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}><option>Male</option><option>Female</option><option>Other</option></select>
            </div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Phone *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Mobile number" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Date of Birth</label><input type="date" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form.dob} onChange={e => setForm({ ...form, dob: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Referred By</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form.referredBy} onChange={e => setForm({ ...form, referredBy: e.target.value })}><option>Self</option><option>Dr. Rajesh Mehta</option><option>Dr. Anita Gupta</option></select>
            </div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Address</label>
            <textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all h-16 resize-none" placeholder="Full address" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} />
          </div>
          <div className="flex gap-2">
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Register & Add Tests</button>
            <button type="button" onClick={() => setForm({ name: '', age: '', gender: 'Male', phone: '', dob: '', referredBy: 'Self', address: '' })} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Reset</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export function TokenSystem() {
  const [tokens, setTokens] = useState([
    { num: 16, patient: 'Anil Kumar', status: 'serving' },
    { num: 17, patient: 'Priya Verma', status: 'waiting' },
    { num: 18, patient: 'Rahul Singh', status: 'waiting' },
    { num: 19, patient: 'Meena Devi', status: 'waiting' },
  ])

  const callNext = () => {
    setTokens(prev => {
      const updated = [...prev]
      const servingIdx = updated.findIndex(t => t.status === 'serving')
      if (servingIdx !== -1) updated[servingIdx].status = 'completed'
      const nextIdx = updated.findIndex(t => t.status === 'waiting')
      if (nextIdx !== -1) {
        updated[nextIdx].status = 'serving'
        toast.success(`Now serving: ${updated[nextIdx].patient} (Token #${updated[nextIdx].num})`)
      } else {
        toast.success('All patients served!')
      }
      return updated
    })
  }

  const currentServing = tokens.find(t => t.status === 'serving')
  const nextWaiting = tokens.find(t => t.status === 'waiting')

  return (
    <div>
      <PageHeader title="Token System" subtitle="Queue management" />
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 text-center">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Now Serving</p>
          <div className="text-6xl font-bold text-brand-400">#{currentServing?.num || '—'}</div>
          <p className="text-slate-500 mt-1">{currentServing?.patient || 'None'}</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 text-center">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Next Token</p>
          <div className="text-6xl font-bold text-slate-300">#{nextWaiting?.num || '—'}</div>
          <p className="text-slate-500 mt-1">{nextWaiting?.patient || 'No one waiting'}</p>
        </div>
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700 flex items-center justify-between">
          <p className="font-semibold text-slate-300">Queue ({tokens.filter(t => t.status !== 'completed').length})</p>
          <button onClick={callNext} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs">Call Next</button>
        </div>
        <div className="divide-y divide-surface-800">
          {tokens.map(t => (
            <div key={t.num} className="flex items-center gap-3 p-3">
              <span className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold ${t.status === 'serving' ? 'bg-brand-500 text-surface-950' : t.status === 'completed' ? 'bg-surface-700 text-slate-600' : 'bg-surface-800 text-slate-500'}`}>
                {t.num}
              </span>
              <span className={`flex-1 text-sm font-medium ${t.status === 'completed' ? 'text-slate-600 line-through' : 'text-slate-400'}`}>{t.patient}</span>
              <Badge status={t.status === 'serving' ? 'active' : t.status === 'completed' ? 'completed' : 'pending'} />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function HomeCollection() {
  const [showModal, setShowModal] = useState(false)
  const [trips, setTrips] = useState([
    { id: 'HC001', patient: 'Mrs. Sunita Agrawal', address: 'Shankar Nagar, Raipur', time: '08:00 AM', tests: 'CBC, LFT', tech: 'Kavita Sharma', status: 'completed' },
    { id: 'HC002', patient: 'Mr. Dinesh Patel', address: 'Telibandha, Raipur', time: '09:30 AM', tests: 'Thyroid Profile', tech: 'Ravi Kumar', status: 'pending' },
    { id: 'HC003', patient: 'Mrs. Geeta Verma', address: 'Pandri, Raipur', time: '11:00 AM', tests: 'HbA1c, Glucose', tech: 'Kavita Sharma', status: 'pending' },
  ])
  const [form, setForm] = useState({ patient: '', phone: '', address: '', tests: '', date: '', time: '' })

  const handleBook = (e) => {
    e.preventDefault()
    const newTrip = { id: `HC${String(trips.length + 1).padStart(3, '0')}`, patient: form.patient, address: form.address, time: form.time || '—', tests: form.tests, tech: '—', status: 'pending' }
    setTrips(prev => [newTrip, ...prev])
    setShowModal(false)
    setForm({ patient: '', phone: '', address: '', tests: '', date: '', time: '' })
    toast.success('Home collection booked!')
  }

  const handleTrack = (trip) => {
    toast.success(`Tracking ${trip.patient} — ETA: 15 mins`)
  }

  return (
    <div>
      <PageHeader title="Home Collection" subtitle="Schedule and track home sample collection" actions={
        <button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} />Book Visit</button>
      }/>
      <div className="grid grid-cols-1 gap-3">
        {trips.map(h => (
          <div key={h.id} className="bg-surface-900 rounded-2xl border border-surface-700 p-4 flex gap-4">
            <div className="w-10 h-10 bg-purple-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
              <Home size={18} className="text-purple-400" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-slate-300">{h.patient}</p>
                <Badge status={h.status} />
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{h.address}</p>
              <p className="text-xs text-slate-500 mt-0.5">{h.tests} · {h.time} · {h.tech}</p>
            </div>
            <button onClick={() => handleTrack(h)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium self-start flex items-center gap-1 transition-all">
              <Navigation size={12} /> Track
            </button>
          </div>
        ))}
      </div>

      <Modal open={showModal} onClose={() => setShowModal(false)} title="Book Home Collection">
        <form onSubmit={handleBook} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Name" value={form.patient} onChange={e => setForm({ ...form, patient: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Phone *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Mobile" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Address *</label><textarea required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-16 resize-none" placeholder="Full address" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Tests *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. CBC, LFT" value={form.tests} onChange={e => setForm({ ...form, tests: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Date *</label><input required type="date" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Time *</label><input required type="time" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} /></div>
          </div>
          <div className="flex gap-2">
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Book Visit</button>
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Cancel</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
