import React, { useState } from 'react'
import { PageHeader, Badge, StatCard } from '../../components/UI'
import { Users, Clock, Receipt, Home, Plus } from 'lucide-react'

export function ReceptionDashboard() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-100">Reception Desk</h1>
        <p className="text-sm text-slate-500">Ravi Kumar · Morning Shift · June 13, 2026</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="Patients Today" value="24" color="blue" />
        <StatCard icon={Clock} label="Current Token" value="#18" color="amber" />
        <StatCard icon={Receipt} label="Billing Done" value="₹18,400" color="green" />
        <StatCard icon={Home} label="Home Collection" value="3 booked" color="purple" />
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'New Registration', desc: 'Register walk-in patient', color: 'from-blue-500 to-cyan-600', icon: Users },
          { label: 'Quick Billing', desc: 'Generate invoice', color: 'from-emerald-500 to-teal-600', icon: Receipt },
          { label: 'Book Home Collection', desc: 'Schedule home visit', color: 'from-purple-500 to-indigo-600', icon: Home },
        ].map(a => (
          <button key={a.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-left hover:shadow-md transition-shadow">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${a.color} flex items-center justify-center mb-3`}>
              <a.icon size={20} className="text-white" />
            </div>
            <p className="font-medium text-slate-300">{a.label}</p>
            <p className="text-xs text-slate-500 mt-0.5">{a.desc}</p>
          </button>
        ))}
      </div>
    </div>
  )
}

export function PatientRegistration() {
  return (
    <div>
      <PageHeader title="Patient Registration" subtitle="Register new or existing patient" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 max-w-2xl">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Patient Name *</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Full name" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Age *</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" type="number" placeholder="Age" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Gender *</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all"><option>Male</option><option>Female</option><option>Other</option></select>
            </div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Phone *</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Mobile number" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Date of Birth</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" type="date" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Referred By</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all"><option>Self</option><option>Dr. Rajesh Mehta</option><option>Dr. Anita Gupta</option></select>
            </div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Address</label>
            <textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all h-16 resize-none" placeholder="Full address" />
          </div>
          <div className="flex gap-2">
            <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Register & Add Tests</button>
            <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Reset</button>
          </div>
        </div>
      </div>
    </div>
  )
}

export function TokenSystem() {
  const tokens = [
    { num: 16, patient: 'Anil Kumar', status: 'serving' },
    { num: 17, patient: 'Priya Verma', status: 'waiting' },
    { num: 18, patient: 'Rahul Singh', status: 'waiting' },
    { num: 19, patient: 'Meena Devi', status: 'waiting' },
  ]
  return (
    <div>
      <PageHeader title="Token System" subtitle="Queue management" />
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 text-center">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Now Serving</p>
          <div className="text-6xl font-bold text-brand-400">#16</div>
          <p className="text-slate-500 mt-1">Anil Kumar</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 text-center">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Next Token</p>
          <div className="text-6xl font-bold text-slate-300">#17</div>
          <p className="text-slate-500 mt-1">Priya Verma</p>
        </div>
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700 flex items-center justify-between">
          <p className="font-semibold text-slate-300">Queue ({tokens.length})</p>
          <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs">Call Next</button>
        </div>
        <div className="divide-y divide-surface-800">
          {tokens.map(t => (
            <div key={t.num} className="flex items-center gap-3 p-3">
              <span className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold ${t.status === 'serving' ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-500'}`}>
                {t.num}
              </span>
              <span className="flex-1 text-sm font-medium text-slate-400">{t.patient}</span>
              <Badge status={t.status === 'serving' ? 'active' : 'pending'} />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function HomeCollection() {
  return (
    <div>
      <PageHeader title="Home Collection" subtitle="Schedule and track home sample collection" actions={
        <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} />Book Visit</button>
      }/>
      <div className="grid grid-cols-1 gap-3">
        {[
          { id: 'HC001', patient: 'Mrs. Sunita Agrawal', address: 'Shankar Nagar, Raipur', time: '08:00 AM', tests: 'CBC, LFT', tech: 'Kavita Sharma', status: 'completed' },
          { id: 'HC002', patient: 'Mr. Dinesh Patel', address: 'Telibandha, Raipur', time: '09:30 AM', tests: 'Thyroid Profile', tech: 'Ravi Kumar', status: 'pending' },
          { id: 'HC003', patient: 'Mrs. Geeta Verma', address: 'Pandri, Raipur', time: '11:00 AM', tests: 'HbA1c, Glucose', tech: 'Kavita Sharma', status: 'pending' },
        ].map(h => (
          <div key={h.id} className="bg-surface-900 rounded-2xl border border-surface-700 p-4 flex gap-4">
            <div className="w-10 h-10 bg-purple-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
              <Home size={18} className="text-purple-400" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-slate-300">{h.patient}</p>
                <Badge status={h.status} />
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{h.address}</p>
              <p className="text-xs text-slate-500 mt-0.5">{h.tests} · {h.time} · {h.tech}</p>
            </div>
            <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1 self-start">Track</button>
          </div>
        ))}
      </div>
    </div>
  )
}
