import React, { useState } from 'react'
import { PageHeader } from '../components/UI'
import toast from 'react-hot-toast'

export default function Settings() {
  const [form, setForm] = useState({
    name: 'Admin User',
    email: 'admin@mediflow.in',
    phone: '+91 98765 43210'
  })
  const [notifications, setNotifications] = useState({
    email: true, whatsapp: true, sms: false, push: true, lowStock: true, reportReady: true
  })

  const handleSave = () => {
    toast.success('Settings saved successfully!')
  }

  const handleToggle = (key) => {
    setNotifications(prev => ({ ...prev, [key]: !prev[key] }))
    toast.success('Notification setting updated!')
  }

  return (
    <div>
      <PageHeader title="Settings" subtitle="Manage your preferences" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Account Settings</p>
          <div className="space-y-3">
            {[
              { label: 'Name', key: 'name' },
              { label: 'Email', key: 'email' },
              { label: 'Phone', key: 'phone' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form[f.key]} onChange={e => setForm({ ...form, [f.key]: e.target.value })} />
              </div>
            ))}
            <button onClick={handleSave} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all mt-2">Save Changes</button>
          </div>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Notifications</p>
          <div className="space-y-3">
            {[
              { key: 'email', label: 'Email notifications' },
              { key: 'whatsapp', label: 'WhatsApp alerts' },
              { key: 'sms', label: 'SMS reminders' },
              { key: 'push', label: 'Push notifications' },
              { key: 'lowStock', label: 'Low stock alerts' },
              { key: 'reportReady', label: 'Report ready alerts' },
            ].map(opt => (
              <button key={opt.key} onClick={() => handleToggle(opt.key)} className="flex items-center justify-between w-full cursor-pointer py-1">
                <span className="text-sm text-slate-400">{opt.label}</span>
                <div className={`w-10 h-5 rounded-full flex items-center px-0.5 transition-colors ${notifications[opt.key] ? 'bg-brand-500' : 'bg-surface-700'}`}>
                  <div className={`w-4 h-4 rounded-full transition-transform ${notifications[opt.key] ? 'bg-white ml-auto' : 'bg-slate-400'}`} />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
