import React from 'react'
import { PageHeader } from '../components/UI'

export default function Settings() {
  return (
    <div>
      <PageHeader title="Settings" subtitle="Manage your preferences" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Account Settings</p>
          <div className="space-y-3">
            {[
              { label: 'Name', val: 'Admin User' },
              { label: 'Email', val: 'admin@mediflow.in' },
              { label: 'Phone', val: '+91 98765 43210' },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" defaultValue={f.val} />
              </div>
            ))}
            <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all mt-2">Save Changes</button>
          </div>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Notifications</p>
          <div className="space-y-3">
            {['Email notifications', 'WhatsApp alerts', 'SMS reminders', 'Push notifications', 'Low stock alerts', 'Report ready alerts'].map(opt => (
              <label key={opt} className="flex items-center justify-between cursor-pointer">
                <span className="text-sm text-slate-400">{opt}</span>
                <div className="w-10 h-5 bg-brand-500 rounded-full flex items-center px-0.5 cursor-pointer">
                  <div className="w-4 h-4 bg-surface-900 rounded-full ml-auto" />
                </div>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
