import React, { useState, useEffect, useCallback, useRef } from 'react'
import { PageHeader, Badge, Modal } from '../../components/UI'
import { gpsAPI } from '../../utils/api'
import {
  Navigation, MapPin, Play, Square, Clock, Home, Phone,
  ChevronRight, CheckCircle, AlertCircle, Crosshair,
} from 'lucide-react'
import toast from 'react-hot-toast'

const STATUS_BADGE = {
  en_route:    'active',
  at_location: 'pending',
  collecting:  'processing',
  completed:   'completed',
  cancelled:   'inactive',
}

const STATUS_LABELS = {
  en_route:    '🟢 En Route',
  at_location: '🟡 At Location',
  collecting:  '🟣 Collecting Sample',
  completed:   '✅ Completed',
  cancelled:   '❌ Cancelled',
}

const STATUS_ACTIONS = [
  { from: 'en_route',    to: 'at_location', label: 'Arrived at Location',    icon: MapPin },
  { from: 'at_location', to: 'collecting',  label: 'Started Sample Collection', icon: Home },
  { from: 'collecting',  to: 'completed',   label: 'Collection Complete',       icon: CheckCircle },
]

// ═══════════════════════════════════════════════════════════════════════════════
//  TECHNICIAN GPS TRACKER
// ═══════════════════════════════════════════════════════════════════════════════
export default function GpsTracker() {
  const [isTracking, setIsTracking] = useState(false)
  const [trackingId, setTrackingId] = useState(null)
  const [currentSession, setCurrentSession] = useState(null)
  const [location, setLocation] = useState(null)
  const [error, setError] = useState(null)
  const [watchId, setWatchId] = useState(null)
  const [showStartModal, setShowStartModal] = useState(false)
  const [form, setForm] = useState({
    patientName: '',
    patientPhone: '',
    patientAddress: '',
    destLat: '',
    destLng: '',
  })
  const [history, setHistory] = useState([])
  const [loadingHistory, setLoadingHistory] = useState(false)
  const locationIntervalRef = useRef(null)
  const historyFetchedRef = useRef(false)

  // Load today's completed trackings on mount
  useEffect(() => {
    const fetchHistory = async () => {
      setLoadingHistory(true)
      try {
        const res = await gpsAPI.getAll({ date: new Date().toISOString().split('T')[0] })
        const data = res.data?.data || []
        setHistory(data)
        // Check if there's an active session
        const active = data.find(t => !['completed', 'cancelled'].includes(t.status))
        if (active) {
          setIsTracking(true)
          setTrackingId(active._id)
          setCurrentSession(active)
          if (active.currentLocation) {
            setLocation({
              lat: active.currentLocation.lat,
              lng: active.currentLocation.lng,
            })
          }
        }
        historyFetchedRef.current = true
      } catch (err) {
        console.error('Failed to fetch GPS history:', err)
      } finally {
        setLoadingHistory(false)
      }
    }
    fetchHistory()
  }, [])

  // ── Start GPS watch ──────────────────────────────────────────────────────
  const startGpsWatch = useCallback(() => {
    if (!navigator.geolocation) {
      setError('GPS not available on this device')
      return
    }

    const id = navigator.geolocation.watchPosition(
      (pos) => {
        const loc = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          heading: pos.coords.heading,
          speed: pos.coords.speed,
        }
        setLocation(loc)
        setError(null)
      },
      (err) => {
        setError(`GPS error: ${err.message}`)
        console.error('GPS error:', err)
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 3000 }
    )
    setWatchId(id)
  }, [])

  // ── Stop GPS watch ───────────────────────────────────────────────────────
  const stopGpsWatch = useCallback(() => {
    if (watchId != null) {
      navigator.geolocation.clearWatch(watchId)
      setWatchId(null)
    }
    if (locationIntervalRef.current) {
      clearInterval(locationIntervalRef.current)
      locationIntervalRef.current = null
    }
  }, [watchId])

  // ── Start tracking session ───────────────────────────────────────────────
  const handleStartTracking = async (e) => {
    e.preventDefault()
    if (!form.patientName || !form.patientAddress) {
      toast.error('Patient name and address are required')
      return
    }

    try {
      const res = await gpsAPI.startTracking({
        patientName: form.patientName,
        patientPhone: form.patientPhone,
        patientAddress: form.patientAddress,
        destLat: form.destLat ? parseFloat(form.destLat) : undefined,
        destLng: form.destLng ? parseFloat(form.destLng) : undefined,
      })
      const session = res.data?.data
      setTrackingId(session._id)
      setCurrentSession(session)
      setIsTracking(true)
      startGpsWatch()
      setShowStartModal(false)
      setForm({ patientName: '', patientPhone: '', patientAddress: '', destLat: '', destLng: '' })
      toast.success('GPS tracking started!')
    } catch (err) {
      toast.error('Failed to start tracking')
    }
  }

  // ── Send location to server every 8 seconds ──────────────────────────────
  useEffect(() => {
    if (!isTracking || !trackingId || !location) return

    const sendLocation = async () => {
      try {
        await gpsAPI.updateLocation({
          trackingId,
          lat: location.lat,
          lng: location.lng,
          accuracy: location.accuracy,
          heading: location.heading,
          speed: location.speed,
        })
      } catch (err) {
        // Silent fail — location pings are best-effort
        console.error('Location update failed:', err)
      }
    }

    // Send immediately, then every 8 seconds
    sendLocation()
    locationIntervalRef.current = setInterval(sendLocation, 8000)

    return () => {
      if (locationIntervalRef.current) clearInterval(locationIntervalRef.current)
    }
  }, [isTracking, trackingId, location])

  // ── Update tracking status ───────────────────────────────────────────────
  const handleUpdateStatus = async (newStatus) => {
    if (!trackingId) return
    try {
      const res = await gpsAPI.updateStatus(trackingId, { status: newStatus })
      setCurrentSession(res.data?.data)
      toast.success(STATUS_LABELS[newStatus])

      if (newStatus === 'completed' || newStatus === 'cancelled') {
        stopGpsWatch()
        setIsTracking(false)
      }
    } catch (err) {
      toast.error('Failed to update status')
    }
  }

  // ── Stop tracking manually ───────────────────────────────────────────────
  const handleStopTracking = async () => {
    if (!trackingId) return
    try {
      await gpsAPI.stopTracking(trackingId)
      stopGpsWatch()
      setIsTracking(false)
      setCurrentSession(null)
      toast.success('Tracking ended')
    } catch (err) {
      toast.error('Failed to stop tracking')
    }
  }

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopGpsWatch()
    }
  }, [stopGpsWatch])

  return (
    <div>
      <PageHeader
        title="Home Collection GPS"
        subtitle="Track your location while doing home sample collections"
        actions={
          !isTracking && (
            <button
              onClick={() => setShowStartModal(true)}
              className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-2 transition-all"
            >
              <Play size={16} /> Start New Trip
            </button>
          )
        }
      />

      {/* GPS Status Bar */}
      {!navigator.geolocation && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 mb-4 flex items-center gap-3">
          <AlertCircle size={18} className="text-red-400 flex-shrink-0" />
          <p className="text-sm text-red-400">GPS is not available on this device. Location tracking won't work.</p>
        </div>
      )}

      {error && (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-3 mb-4 flex items-center gap-2 text-sm text-amber-400">
          <AlertCircle size={16} className="flex-shrink-0" />
          {error}
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Main: Active Tracking */}
        <div className="lg:col-span-2 space-y-4">
          {isTracking && currentSession ? (
            <>
              {/* Live Status Card */}
              <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                    <p className="font-semibold text-slate-200">Live Tracking Active</p>
                  </div>
                  <Badge status={STATUS_BADGE[currentSession.status]} />
                </div>

                {/* Patient Info */}
                <div className="bg-surface-850 rounded-xl p-4 mb-4">
                  <p className="text-xs font-semibold text-slate-500 mb-2">PATIENT DETAILS</p>
                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Patient</span>
                      <span className="text-slate-200 font-medium">{currentSession.patientName}</span>
                    </div>
                    {currentSession.patientPhone && (
                      <div className="flex justify-between">
                        <span className="text-slate-500">Phone</span>
                        <a href={`tel:${currentSession.patientPhone}`} className="text-brand-400 hover:text-brand-300">{currentSession.patientPhone}</a>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-slate-500">Address</span>
                      <span className="text-slate-200 text-right max-w-[200px]">{currentSession.patientAddress}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Started</span>
                      <span className="text-slate-200">{new Date(currentSession.startedAt).toLocaleTimeString()}</span>
                    </div>
                  </div>
                </div>

                {/* Location Data */}
                {location && (
                  <div className="bg-surface-850 rounded-xl p-4 mb-4">
                    <p className="text-xs font-semibold text-slate-500 mb-2">YOUR POSITION</p>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Latitude</span>
                        <span className="text-slate-200 font-mono">{location.lat.toFixed(6)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Longitude</span>
                        <span className="text-slate-200 font-mono">{location.lng.toFixed(6)}</span>
                      </div>
                      {location.accuracy && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Accuracy</span>
                          <span className="text-slate-200">{location.accuracy.toFixed(0)}m</span>
                        </div>
                      )}
                      {location.heading != null && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Heading</span>
                          <span className="text-slate-200">{location.heading.toFixed(0)}°</span>
                        </div>
                      )}
                      {location.speed != null && (
                        <div className="flex justify-between">
                          <span className="text-slate-500">Speed</span>
                          <span className="text-slate-200">{(location.speed * 3.6).toFixed(1)} km/h</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Status Transitions */}
                <p className="text-xs font-semibold text-slate-500 mb-2">UPDATE STATUS</p>
                <div className="flex flex-wrap gap-2">
                  {STATUS_ACTIONS
                    .filter(a => a.from === currentSession.status)
                    .map(a => (
                      <button
                        key={a.to}
                        onClick={() => handleUpdateStatus(a.to)}
                        className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all"
                      >
                        <a.icon size={14} /> {a.label}
                      </button>
                    ))}
                  {currentSession.status !== 'completed' && currentSession.status !== 'cancelled' && (
                    <button
                      onClick={() => handleUpdateStatus('cancelled')}
                      className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all"
                    >
                      <Square size={12} /> Cancel Trip
                    </button>
                  )}
                </div>
              </div>

              {/* Status Timeline */}
              <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
                <p className="font-semibold text-slate-300 mb-3 flex items-center gap-2">
                  <Clock size={16} className="text-brand-400" /> Trip Timeline
                </p>
                <div className="space-y-3">
                  {[
                    { status: 'en_route', label: 'Departed', time: currentSession.startedAt },
                    currentSession.status === 'at_location' || currentSession.status === 'collecting' || currentSession.status === 'completed'
                      ? { status: 'at_location', label: 'Arrived at Location', time: currentSession.updatedAt }
                      : null,
                    currentSession.status === 'collecting' || currentSession.status === 'completed'
                      ? { status: 'collecting', label: 'Started Collection', time: currentSession.updatedAt }
                      : null,
                    currentSession.status === 'completed'
                      ? { status: 'completed', label: 'Collection Complete', time: currentSession.completedAt }
                      : null,
                  ].filter(Boolean).map((step, i, arr) => (
                    <div key={step.status} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full border-2 ${
                          step.status === 'en_route' ? 'border-blue-500 bg-blue-500/20' :
                          step.status === 'at_location' ? 'border-amber-500 bg-amber-500/20' :
                          step.status === 'collecting' ? 'border-purple-500 bg-purple-500/20' :
                          'border-green-500 bg-green-500/20'
                        }`} />
                        {i < arr.length - 1 && <div className="w-0.5 flex-1 bg-surface-700 mt-1" />}
                      </div>
                      <div className="pb-3">
                        <p className="text-sm text-slate-300">{step.label}</p>
                        <p className="text-xs text-slate-500">{step.time ? new Date(step.time).toLocaleTimeString() : '—'}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-surface-900 rounded-2xl border border-surface-700 p-8 text-center">
              <Navigation size={40} className="mx-auto mb-3 text-slate-600" />
              <p className="text-slate-400 font-medium mb-1">No Active Tracking</p>
              <p className="text-sm text-slate-500 mb-4">Start a new home collection trip to begin GPS tracking</p>
              <button
                onClick={() => setShowStartModal(true)}
                className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-5 py-2.5 rounded-xl text-sm transition-all inline-flex items-center gap-2"
              >
                <Play size={16} /> Start New Trip
              </button>
            </div>
          )}
        </div>

        {/* Sidebar: Today's History */}
        <div className="space-y-4">
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Today's Trips</p>
            {loadingHistory ? (
              <div className="text-center py-8 text-slate-500 text-sm">Loading...</div>
            ) : history.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-sm">No trips today</div>
            ) : (
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {history.map(h => (
                  <div key={h._id} className="bg-surface-850 rounded-xl p-3">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-medium text-slate-300 truncate">{h.patientName}</p>
                      <Badge status={STATUS_BADGE[h.status]} />
                    </div>
                    <p className="text-[10px] text-slate-500 truncate">{h.patientAddress}</p>
                    <p className="text-[10px] text-slate-600 mt-1">
                      Started: {new Date(h.startedAt).toLocaleTimeString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* GPS Tips */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4">
            <p className="text-xs font-semibold text-slate-500 mb-2">GPS TIPS</p>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li className="flex items-start gap-1.5"><Crosshair size={11} className="mt-0.5 flex-shrink-0 text-brand-400" /> Enable high-accuracy GPS for best results</li>
              <li className="flex items-start gap-1.5"><MapPin size={11} className="mt-0.5 flex-shrink-0 text-brand-400" /> Location updates every 8 seconds</li>
              <li className="flex items-start gap-1.5"><Clock size={11} className="mt-0.5 flex-shrink-0 text-brand-400" /> Lab admin can see your live location</li>
              <li className="flex items-start gap-1.5"><CheckCircle size={11} className="mt-0.5 flex-shrink-0 text-brand-400" /> End tracking when collection is complete</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Start Tracking Modal */}
      <Modal open={showStartModal} onClose={() => setShowStartModal(false)} title="Start Home Collection Trip" size="md">
        <form onSubmit={handleStartTracking} className="space-y-4">
          <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Patient Name *</label>
            <input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Full name" value={form.patientName} onChange={e => setForm({ ...form, patientName: e.target.value })} />
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Phone</label>
            <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Patient phone" value={form.patientPhone} onChange={e => setForm({ ...form, patientPhone: e.target.value })} />
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Address *</label>
            <textarea required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-20 resize-none" placeholder="Full address" value={form.patientAddress} onChange={e => setForm({ ...form, patientAddress: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Latitude (optional)</label>
              <input type="number" step="any" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. 21.2513" value={form.destLat} onChange={e => setForm({ ...form, destLat: e.target.value })} />
            </div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1.5">Longitude (optional)</label>
              <input type="number" step="any" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. 81.6296" value={form.destLng} onChange={e => setForm({ ...form, destLng: e.target.value })} />
            </div>
          </div>
          <div className="flex gap-2">
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-2 transition-all">
              <Navigation size={16} /> Start GPS Tracking
            </button>
            <button type="button" onClick={() => setShowStartModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm transition-all">Cancel</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
