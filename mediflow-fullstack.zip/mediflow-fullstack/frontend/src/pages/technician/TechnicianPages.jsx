import React, { useState } from 'react'
import { PageHeader, Badge } from '../../components/UI'
import { StatCard } from '../../components/UI'
import { FlaskConical, FileText, Clock, CheckCircle, AlertCircle } from 'lucide-react'
import { pendingReports } from '../../utils/mockData'

export function TechnicianDashboard() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-100">Technician Panel</h1>
        <p className="text-sm text-slate-500">Kavita Sharma · Morning Shift · June 13, 2026</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={FlaskConical} label="Samples Today" value="24" color="blue" />
        <StatCard icon={Clock} label="Pending" value="4" color="amber" />
        <StatCard icon={CheckCircle} label="Completed" value="18" color="green" />
        <StatCard icon={AlertCircle} label="Verification" value="2" color="purple" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700">
          <p className="font-semibold text-slate-300">Pending Work</p>
        </div>
        <div className="divide-y divide-surface-800">
          {pendingReports.map(r => (
            <div key={r.id} className="flex items-center gap-4 p-4">
              <div className="w-10 h-10 bg-teal-50 rounded-xl flex items-center justify-center">
                <FlaskConical size={18} className="text-teal-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-slate-300">{r.patient}</p>
                <p className="text-sm text-slate-500">{r.test} · Collected {r.collected}</p>
              </div>
              <Badge status={r.status} />
              <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1.5">
                {r.status === 'verification' ? 'Verify' : r.status === 'processing' ? 'Enter Result' : 'Start'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function SampleCollection() {
  const [barcode, setBarcode] = useState('')
  return (
    <div>
      <PageHeader title="Sample Collection" subtitle="Scan barcode or enter patient ID" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Scan / Search Patient</p>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Barcode / Sample ID</label>
              <div className="flex gap-2">
                <input value={barcode} onChange={e => setBarcode(e.target.value)} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all flex-1" placeholder="Scan or type barcode..." />
                <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all px-4">Search</button>
              </div>
            </div>
            <p className="text-center text-xs text-slate-500">or scan physical barcode with scanner</p>
          </div>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-3">Collection Status Today</p>
          <div className="space-y-2">
            {[
              { stage: 'Collection', count: 24, color: 'bg-blue-500' },
              { stage: 'Processing', count: 18, color: 'bg-amber-500' },
              { stage: 'Verification', count: 4, color: 'bg-purple-500' },
              { stage: 'Completed', count: 18, color: 'bg-brand-500' },
            ].map(s => (
              <div key={s.stage} className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${s.color}`} />
                <span className="text-sm text-slate-400 flex-1">{s.stage}</span>
                <span className="font-semibold text-slate-300">{s.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export function PendingReports() {
  return (
    <div>
      <PageHeader title="Pending Reports" subtitle="Tests awaiting result entry or verification" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="divide-y divide-surface-800">
          {pendingReports.map(r => (
            <div key={r.id} className="flex items-center gap-4 p-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="font-medium text-slate-300">{r.patient}</p>
                  <Badge status={r.status} />
                </div>
                <p className="text-sm text-slate-500">{r.test} · Collected at {r.collected} · {r.tech}</p>
              </div>
              <div className="flex gap-2">
                <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">View</button>
                <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">
                  {r.status === 'verification' ? 'Approve' : 'Enter Result'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
