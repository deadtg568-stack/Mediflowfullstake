import React, { useState, useMemo, useRef } from 'react'
import { PageHeader, Badge, Modal, StatCard, Tooltip, useKeyboardShortcuts } from '../../components/UI'
import { FlaskConical, Clock, CheckCircle, AlertCircle, Eye, Search, Droplets, TestTube, Activity, FileText, User } from 'lucide-react'
import toast from 'react-hot-toast'

// ─── Shared mock data ────────────────────────────────────────────────────────
const TECHNICIAN = { name: 'Kavita Sharma', role: 'Senior Technician', shift: 'Morning', phone: '+91 97000 00001' }

const TODAY_SAMPLES = [
  { id: 'SMP-2026-001', barcode: 'BC-4501', patient: 'Rahul Sharma', patientId: 'P0001', age: 34, gender: 'Male', phone: '9111000001', test: 'CBC', sampleType: 'Blood-EDTA', collectedAt: '08:15 AM', status: 'completed', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '3 mL', condition: 'Hemolyzed: No' },
  { id: 'SMP-2026-002', barcode: 'BC-4502', patient: 'Anil Kumar', patientId: 'P0003', age: 52, gender: 'Male', phone: '9111000003', test: 'Lipid Profile', sampleType: 'Blood-SST', collectedAt: '08:15 AM', status: 'completed', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '5 mL', condition: 'Fasting: Yes' },
  { id: 'SMP-2026-003', barcode: 'BC-4503', patient: 'Meena Devi', patientId: 'P0007', age: 45, gender: 'Female', phone: '9111000007', test: 'Thyroid Profile', sampleType: 'Blood-SST', collectedAt: '08:20 AM', status: 'completed', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '5 mL', condition: 'Fasting: No' },
  { id: 'SMP-2026-004', barcode: 'BC-4504', patient: 'Suresh Babu', patientId: 'P0012', age: 58, gender: 'Male', phone: '9111000012', test: 'Cardiac Risk Profile', sampleType: 'Blood-SST', collectedAt: '08:25 AM', status: 'completed', priority: 'urgent', assignedBy: 'Dr. Suresh Nair', volume: '5 mL', condition: 'Fasting: Yes' },
  { id: 'SMP-2026-005', barcode: 'BC-4505', patient: 'Priyanka Singh', patientId: 'P0015', age: 28, gender: 'Female', phone: '9111000015', test: 'CBC + Iron Studies', sampleType: 'Blood-EDTA', collectedAt: '08:30 AM', status: 'processing', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '4 mL', condition: 'Hemolyzed: No' },
  { id: 'SMP-2026-006', barcode: 'BC-4506', patient: 'Ravi Shankar', patientId: 'P0019', age: 61, gender: 'Male', phone: '9111000019', test: 'HbA1c + KFT', sampleType: 'Blood-EDTA', collectedAt: '08:35 AM', status: 'processing', priority: 'urgent', assignedBy: 'Dr. Rajesh Mehta', volume: '3 mL', condition: 'Hemolyzed: No' },
  { id: 'SMP-2026-007', barcode: 'BC-4507', patient: 'Geeta Bai', patientId: 'P0022', age: 40, gender: 'Female', phone: '9111000022', test: 'LFT + Hepatitis B', sampleType: 'Blood-SST', collectedAt: '08:40 AM', status: 'processing', priority: 'normal', assignedBy: 'Dr. Anita Gupta', volume: '5 mL', condition: 'Fasting: Yes' },
  { id: 'SMP-2026-008', barcode: 'BC-4508', patient: 'Mohd. Irfan', patientId: 'P0025', age: 35, gender: 'Male', phone: '9111000025', test: 'Dengue NS1 + CBC + CRP', sampleType: 'Blood-SST + EDTA', collectedAt: '08:45 AM', status: 'processing', priority: 'urgent', assignedBy: 'Dr. Rajesh Mehta', volume: '5+3 mL', condition: 'Acute sample' },
  { id: 'SMP-2026-009', barcode: 'BC-4509', patient: 'Sunita Verma', patientId: 'P0028', age: 55, gender: 'Female', phone: '9111000028', test: 'Thyroid + HbA1c + Lipid', sampleType: 'Blood-SST + EDTA', collectedAt: '09:00 AM', status: 'verification', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '5+3 mL', condition: 'Fasting: Yes' },
  { id: 'SMP-2026-010', barcode: 'BC-4510', patient: 'Kamal Nath', patientId: 'P0031', age: 48, gender: 'Male', phone: '9111000031', test: 'PSA + CBC', sampleType: 'Blood-SST + EDTA', collectedAt: '09:05 AM', status: 'verification', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '5+3 mL', condition: 'Fasting: No' },
  { id: 'SMP-2026-011', barcode: 'BC-4511', patient: 'Anjali Patel', patientId: 'P0034', age: 32, gender: 'Female', phone: '9111000034', test: 'CBC + Thyroid + Iron', sampleType: 'Blood-EDTA', collectedAt: '09:15 AM', status: 'pending', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '4 mL', condition: 'Hemolyzed: No' },
  { id: 'SMP-2026-012', barcode: 'BC-4512', patient: 'Vikram Joshi', patientId: 'P0037', age: 67, gender: 'Male', phone: '9111000037', test: 'Blood Sugar Fasting + Lipid', sampleType: 'Blood-Fluoride + SST', collectedAt: '09:20 AM', status: 'pending', priority: 'normal', assignedBy: 'Dr. Suresh Nair', volume: '3+5 mL', condition: 'Fasting: Yes' },
  { id: 'SMP-2026-013', barcode: 'BC-4513', patient: 'Neha Gupta', patientId: 'P0040', age: 25, gender: 'Female', phone: '9111000040', test: 'Urine Routine', sampleType: 'Urine', collectedAt: '09:25 AM', status: 'pending', priority: 'normal', assignedBy: 'Dr. Anita Gupta', volume: '30 mL', condition: 'Midstream: Yes' },
  { id: 'SMP-2026-014', barcode: 'BC-4514', patient: 'Ramesh Yadav', patientId: 'P0043', age: 50, gender: 'Male', phone: '9111000043', test: 'Vitamin D + B12 + Calcium', sampleType: 'Blood-SST', collectedAt: '09:30 AM', status: 'pending', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '5 mL', condition: 'Fasting: No' },
  { id: 'SMP-2026-015', barcode: 'BC-4515', patient: 'Priya Deshmukh', patientId: 'P0046', age: 38, gender: 'Female', phone: '9111000046', test: 'HbA1c', sampleType: 'Blood-EDTA', collectedAt: '09:35 AM', status: 'pending', priority: 'normal', assignedBy: 'Dr. Rajesh Mehta', volume: '3 mL', condition: 'Hemolyzed: No' },
]

const COMPLETED_TODAY = [
  { patient: 'Rahul Sharma', test: 'CBC', time: '09:15 AM', result: 'Normal — Hb 13.2, WBC 7200' },
  { patient: 'Anil Kumar', test: 'Lipid Profile', time: '09:45 AM', result: 'LDL elevated — 142 mg/dL' },
  { patient: 'Meena Devi', test: 'Thyroid Profile', time: '10:00 AM', result: 'TSH normal — 2.8 μIU/mL' },
  { patient: 'Suresh Babu', test: 'Cardiac Risk Profile', time: '10:15 AM', result: 'hs-CRP 3.1 — elevated' },
]

// ─── Patient history lookup (mock) ───────────────────────────────────────────
const PATIENT_HISTORY_LOOKUP = {
  'P0001': [
    { date: 'Jun 10, 2026', test: 'CBC + ESR', result: 'Hb 13.0, WBC 7100, ESR 12', flag: 'normal' },
    { date: 'May 25, 2026', test: 'Lipid Profile', result: 'Chol 182, LDL 110, HDL 48', flag: 'normal' },
    { date: 'Apr 15, 2026', test: 'HbA1c', result: '5.4% — Normal', flag: 'normal' },
    { date: 'Mar 02, 2026', test: 'CBC', result: 'Hb 12.8, WBC 6900', flag: 'normal' },
  ],
  'P0003': [
    { date: 'Jun 12, 2026', test: 'HbA1c + KFT', result: 'HbA1c 6.8%, Creat 0.9', flag: 'high' },
    { date: 'May 10, 2026', test: 'Lipid Profile', result: 'Chol 215, LDL 148, HDL 44', flag: 'high' },
    { date: 'Apr 05, 2026', test: 'CBC + HbA1c', result: 'Hb 12.9, HbA1c 7.0%', flag: 'high' },
    { date: 'Feb 18, 2026', test: 'LFT + KFT', result: 'ALT 32, AST 28, Creat 0.8', flag: 'normal' },
  ],
  'P0007': [
    { date: 'Jun 08, 2026', test: 'Thyroid Profile', result: 'TSH 2.8, FT3 3.1, FT4 1.2', flag: 'normal' },
    { date: 'Apr 20, 2026', test: 'Vitamin D + B12', result: 'Vit D 28 ng/mL, B12 320', flag: 'normal' },
    { date: 'Mar 12, 2026', test: 'CBC + Thyroid', result: 'Hb 11.5, TSH 3.2', flag: 'normal' },
  ],
  'P0012': [
    { date: 'Jun 10, 2026', test: 'Cardiac Risk Profile', result: 'hs-CRP 2.8, LDH 185', flag: 'high' },
    { date: 'Apr 28, 2026', test: 'Lipid Profile + Hs-CRP', result: 'Chol 235, LDL 162, CRP 3.1', flag: 'high' },
    { date: 'Mar 05, 2026', test: 'ECG + Echo Report', result: 'LVEF 55%, Mild LVH', flag: 'abnormal' },
  ],
  'P0015': [
    { date: 'Jun 05, 2026', test: 'CBC + Iron Studies', result: 'Hb 10.2, Ferritin 15, TIBC 480', flag: 'low' },
    { date: 'Apr 22, 2026', test: 'CBC + Vitamin B12', result: 'Hb 9.8, MCV 72, B12 180', flag: 'low' },
  ],
}

const REPORT_PARAMS = {
  'CBC': [
    { name: 'Hemoglobin', ref: '12.0–16.0 g/dL', unit: 'g/dL' },
    { name: 'WBC Count', ref: '4,000–11,000 /μL', unit: '/μL' },
    { name: 'Platelet Count', ref: '1,50,000–4,00,000 /μL', unit: '/μL' },
    { name: 'RBC Count', ref: '4.5–5.5 M/μL', unit: 'M/μL' },
    { name: 'Hematocrit', ref: '36–46 %', unit: '%' },
    { name: 'MCV', ref: '80–100 fL', unit: 'fL' },
  ],
  'Lipid Profile': [
    { name: 'Total Cholesterol', ref: '<200 mg/dL', unit: 'mg/dL' },
    { name: 'LDL Cholesterol', ref: '<130 mg/dL', unit: 'mg/dL' },
    { name: 'HDL Cholesterol', ref: '>40 mg/dL', unit: 'mg/dL' },
    { name: 'Triglycerides', ref: '<150 mg/dL', unit: 'mg/dL' },
  ],
  'Thyroid Profile': [
    { name: 'TSH', ref: '0.4–4.0 μIU/mL', unit: 'μIU/mL' },
    { name: 'Free T3', ref: '2.3–4.2 pg/mL', unit: 'pg/mL' },
    { name: 'Free T4', ref: '0.9–1.7 ng/dL', unit: 'ng/dL' },
  ],
  'HbA1c': [
    { name: 'HbA1c', ref: '<5.7 %', unit: '%' },
    { name: 'Est. Avg Glucose', ref: '70–105 mg/dL', unit: 'mg/dL' },
  ],
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TECHNICIAN DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════════
export function TechnicianDashboard() {
  const [showResultModal, setShowResultModal] = useState(false)
  const [selectedReport, setSelectedReport] = useState(null)
  const [resultForm, setResultForm] = useState({ value: '', unit: '', flag: 'normal', notes: '' })
  const [filter, setFilter] = useState('all')
  const [showPatientModal, setShowPatientModal] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState(null)

  const stats = useMemo(() => ({
    total: TODAY_SAMPLES.length,
    pending: TODAY_SAMPLES.filter(s => s.status === 'pending').length,
    processing: TODAY_SAMPLES.filter(s => s.status === 'processing').length,
    verification: TODAY_SAMPLES.filter(s => s.status === 'verification').length,
    completed: TODAY_SAMPLES.filter(s => s.status === 'completed').length,
    urgent: TODAY_SAMPLES.filter(s => s.priority === 'urgent').length,
  }), [])

  const filtered = useMemo(() => {
    if (filter === 'all') return TODAY_SAMPLES
    return TODAY_SAMPLES.filter(s => s.status === filter)
  }, [filter])

  const handleAction = (report) => {
    setSelectedReport(report)
    setResultForm({ value: '', unit: '', flag: 'normal', notes: '' })
    setShowResultModal(true)
  }

  const handleSubmitResult = (e) => {
    e.preventDefault()
    toast.success(`✅ Result submitted for ${selectedReport?.patient}! ${selectedReport?.test}`)
    setShowResultModal(false)
  }

  const handleQuickComplete = (sample) => {
    toast.success(`✅ ${sample.test} completed for ${sample.patient}`)
  }

  const handleViewPatient = (sample) => {
    setSelectedPatient(sample)
    setShowPatientModal(true)
  }

  // ── Keyboard shortcuts ────────────────────────────────────────────────────────
  const filteredRef = useRef(filtered)
  filteredRef.current = filtered

  useKeyboardShortcuts({
    'p': () => { const list = filteredRef.current; if (list.length > 0) handleViewPatient(list[0]) },
    's': () => { const list = filteredRef.current; const p = list.find(s => s.status === 'pending'); if (p) handleAction(p) },
    'e': () => { const list = filteredRef.current; const p = list.find(s => s.status === 'processing'); if (p) handleAction(p) },
    'v': () => { const list = filteredRef.current; const p = list.find(s => s.status === 'verification'); if (p) handleAction(p) },
    'shift+v': () => { const list = filteredRef.current; const p = list.find(s => s.status === 'completed'); if (p) handleQuickComplete(p) },
  }, { disabled: showPatientModal || showResultModal }, [handleViewPatient, handleAction, handleQuickComplete])

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-teal-500 to-teal-700 flex items-center justify-center text-white font-bold text-lg shadow-glow">KS</div>
          <div>
            <h1 className="text-xl font-semibold text-slate-100">Technician Panel — {TECHNICIAN.name}</h1>
            <p className="text-sm text-slate-500">{TECHNICIAN.role} · {TECHNICIAN.shift} Shift · {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <StatCard icon={FlaskConical} label="Total Samples" value={stats.total} color="blue" />
        <StatCard icon={Clock} label="Pending" value={stats.pending} color="amber" />
        <StatCard icon={Activity} label="Processing" value={stats.processing} color="purple" />
        <StatCard icon={AlertCircle} label="Verification" value={stats.verification} color="green" />
        <StatCard icon={CheckCircle} label="Completed" value={stats.completed} color="green" />
      </div>

      {/* Urgent banner */}
      {stats.urgent > 0 && (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 mb-4 flex items-center gap-3">
          <AlertCircle size={20} className="text-amber-400 flex-shrink-0" />
          <div>
            <p className="text-sm font-semibold text-amber-400">{stats.urgent} URGENT samples require priority processing</p>
            <p className="text-xs text-amber-400/70">Patient outcomes depend on fast turnaround</p>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Main: Pending Work */}
        <div className="lg:col-span-2 bg-surface-900 rounded-2xl border border-surface-700">
          <div className="p-4 border-b border-surface-700 flex items-center justify-between">
            <p className="font-semibold text-slate-300">Today's Samples</p>
            <div className="flex gap-1.5">
              {[{ k: 'all', l: 'All' }, { k: 'pending', l: 'Pending' }, { k: 'processing', l: 'Processing' }, { k: 'verification', l: 'Verify' }].map(f => (
                <button key={f.k} onClick={() => setFilter(f.k)} className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${filter === f.k ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-500 hover:text-slate-300'}`}>{f.l} ({f.k === 'all' ? stats.total : TODAY_SAMPLES.filter(s => s.status === f.k).length})</button>
              ))}
            </div>
          </div>
          <div className="divide-y divide-surface-800 max-h-[500px] overflow-y-auto">
            {filtered.map(s => (
              <div key={s.id} className={`flex items-center gap-3 p-4 hover:bg-surface-850 transition-colors ${s.priority === 'urgent' ? 'border-l-2 border-l-amber-500' : ''}`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${s.status === 'completed' ? 'bg-green-500/10' : s.status === 'verification' ? 'bg-purple-500/10' : s.status === 'processing' ? 'bg-amber-500/10' : 'bg-blue-500/10'}`}>
                  {s.status === 'completed' ? <CheckCircle size={18} className="text-green-400" /> : <FlaskConical size={18} className={s.status === 'verification' ? 'text-purple-400' : s.status === 'processing' ? 'text-amber-400' : 'text-blue-400'} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm text-slate-300 truncate">{s.patient}</p>
                    {s.priority === 'urgent' && <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/20 font-semibold">URGENT</span>}
                  </div>
                  <p className="text-xs text-slate-500 truncate">{s.test} · {s.sampleType} · {s.collectedAt}</p>
                  <p className="text-[10px] text-slate-600">Barcode: {s.barcode} · Vol: {s.volume}</p>
                </div>
                <Badge status={s.status} />
                <Tooltip label="View Patient" shortcut="⌘P">
                  <button onClick={() => handleViewPatient(s)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 p-1.5 rounded-xl transition-all flex-shrink-0">
                    <User size={15} />
                  </button>
                </Tooltip>
                {s.status !== 'completed' && (
                  <Tooltip label={s.status === 'verification' ? 'Verify Result' : s.status === 'processing' ? 'Enter Result' : 'Start Processing'} shortcut={`⌘${s.status === 'verification' ? 'V' : s.status === 'processing' ? 'E' : 'S'}`}>
                    <button onClick={() => handleAction(s)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-3 py-1.5 rounded-xl text-xs transition-all flex-shrink-0">
                      {s.status === 'verification' ? 'Verify' : s.status === 'processing' ? 'Enter Result' : 'Start'}
                    </button>
                  </Tooltip>
                )}
                {s.status === 'completed' && (
                  <Tooltip label="View Result" shortcut="⌘⇧V">
                    <button onClick={() => handleQuickComplete(s)} className="bg-green-500/10 hover:bg-green-500/20 text-green-400 border border-green-500/20 px-3 py-1.5 rounded-xl text-xs font-medium transition-all flex-shrink-0">
                      View
                    </button>
                  </Tooltip>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">
          {/* Today's Completed */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3 flex items-center gap-2"><CheckCircle size={16} className="text-green-400" /> Completed Today</p>
            <div className="space-y-2">
              {COMPLETED_TODAY.map((c, i) => (
                <div key={i} className="p-3 bg-surface-850 rounded-xl">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-slate-300">{c.patient}</p>
                    <span className="text-[10px] text-slate-600">{c.time}</span>
                  </div>
                  <p className="text-xs text-slate-500">{c.test}</p>
                  <p className="text-xs text-green-400/80 mt-0.5">{c.result}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Collection Pipeline */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Pipeline</p>
            <div className="space-y-3">
              {[
                { stage: 'Pending Collection', count: stats.pending, color: 'bg-blue-500', items: ['Anjali Patel', 'Vikram Joshi', 'Neha Gupta', 'Ramesh Yadav', 'Priya Deshmukh'] },
                { stage: 'Processing', count: stats.processing, color: 'bg-amber-500', items: ['Priyanka Singh', 'Ravi Shankar', 'Geeta Bai', 'Mohd. Irfan'] },
                { stage: 'Verification', count: stats.verification, color: 'bg-purple-500', items: ['Sunita Verma', 'Kamal Nath'] },
                { stage: 'Completed', count: stats.completed, color: 'bg-green-500', items: ['Rahul Sharma', 'Anil Kumar', 'Meena Devi', 'Suresh Babu'] },
              ].map(p => (
                <div key={p.stage}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${p.color}`} />
                      <span className="text-xs text-slate-400">{p.stage}</span>
                    </div>
                    <span className="text-xs font-bold text-slate-300">{p.count}</span>
                  </div>
                  <div className="w-full bg-surface-800 rounded-full h-1.5 mb-1">
                    <div className={`${p.color} h-1.5 rounded-full transition-all`} style={{ width: `${(p.count / stats.total) * 100}%` }} />
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {p.items.map(item => <span key={item} className="text-[10px] text-slate-600 bg-surface-850 px-1.5 py-0.5 rounded">{item.split(' ')[0]}</span>)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Shift Info */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4">
            <p className="text-xs font-semibold text-slate-500 mb-2">SHIFT INFO</p>
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Shift</span><span className="text-slate-200">{TECHNICIAN.shift} (8 AM – 2 PM)</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Samples/hour</span><span className="text-brand-400 font-medium">{(stats.total / 1.5).toFixed(1)}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Avg turnaround</span><span className="text-slate-200">45 min</span></div>
            </div>
          </div>
        </div>
      </div>

      {/* Patient Detail Modal */}
      <Modal open={showPatientModal} onClose={() => setShowPatientModal(false)} title={`Patient Details — ${selectedPatient?.patient || ''}`} size="lg">
        {selectedPatient && (
          <div className="space-y-4">
            {/* Patient Identity */}
            <div className="flex items-center gap-4 p-4 bg-surface-850 rounded-xl">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-brand-500 to-blue-600 flex items-center justify-center text-white font-bold text-lg shadow-glow">
                {selectedPatient.patient.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-100">{selectedPatient.patient}</h3>
                <p className="text-sm text-slate-400">{selectedPatient.patientId} · {selectedPatient.age} yrs · {selectedPatient.gender}</p>
                <p className="text-xs text-slate-500">📞 {selectedPatient.phone}</p>
              </div>
            </div>

            {/* Sample / Test Details */}
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 uppercase tracking-wide">Test & Sample Info</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Test</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.test}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Sample Type</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.sampleType}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Barcode</p>
                  <p className="text-sm text-slate-200 font-mono font-medium">{selectedPatient.barcode}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Collected At</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.collectedAt}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Volume</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.volume}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Condition</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.condition}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Assigned By</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.assignedBy}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Status</p>
                  <p className="text-sm"><Badge status={selectedPatient.status} /></p>
                </div>
              </div>
            </div>

            {/* Priority flag */}
            {selectedPatient.priority === 'urgent' && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 flex items-center gap-2">
                <AlertCircle size={16} className="text-amber-400" />
                <p className="text-sm text-amber-400 font-medium">URGENT — Priority processing required</p>
              </div>
            )}

            {/* Patient History */}
            {PATIENT_HISTORY_LOOKUP[selectedPatient.patientId] && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                    <Activity size={13} className="text-brand-400" /> Patient History
                  </p>
                  <span className="text-[10px] text-slate-600">{PATIENT_HISTORY_LOOKUP[selectedPatient.patientId].length} previous records</span>
                </div>
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {PATIENT_HISTORY_LOOKUP[selectedPatient.patientId].map((h, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-surface-850 rounded-xl hover:bg-surface-800 transition-colors">
                      {/* Timeline dot */}
                      <div className="relative flex flex-col items-center pt-1">
                        <div className={`w-2.5 h-2.5 rounded-full border-2 ${h.flag === 'normal' ? 'border-green-500 bg-green-500/20' : h.flag === 'high' ? 'border-amber-500 bg-amber-500/20' : h.flag === 'low' ? 'border-blue-500 bg-blue-500/20' : 'border-red-500 bg-red-500/20'}`} />
                        {i < PATIENT_HISTORY_LOOKUP[selectedPatient.patientId].length - 1 && <div className="w-0.5 flex-1 bg-surface-700 mt-1" />}
                      </div>
                      <div className="flex-1 min-w-0 pb-3">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-xs font-medium text-slate-300">{h.date}</p>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                            h.flag === 'normal' ? 'bg-green-500/10 text-green-400' :
                            h.flag === 'high' ? 'bg-amber-500/10 text-amber-400' :
                            h.flag === 'low' ? 'bg-blue-500/10 text-blue-400' :
                            'bg-red-500/10 text-red-400'
                          }`}>{h.flag}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{h.test}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">{h.result}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {!PATIENT_HISTORY_LOOKUP[selectedPatient.patientId] && (
              <div className="bg-surface-850 rounded-xl p-4 text-center">
                <p className="text-xs text-slate-500">No previous history available for this patient</p>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Result Entry Modal */}
      <Modal open={showResultModal} onClose={() => setShowResultModal(false)} title={`${selectedReport?.status === 'verification' ? 'Verify Result' : 'Enter Result'} — ${selectedReport?.patient || ''}`} size="lg">
        <form onSubmit={handleSubmitResult} className="space-y-4">
          <div className="grid grid-cols-2 gap-3 bg-surface-850 rounded-xl p-4 text-sm">
            <div><span className="text-slate-500 block">Patient</span><span className="text-slate-200 font-medium">{selectedReport?.patient}</span></div>
            <div><span className="text-slate-500 block">Patient ID</span><span className="text-slate-200 font-medium">{selectedReport?.patientId}</span></div>
            <div><span className="text-slate-500 block">Test</span><span className="text-slate-200 font-medium">{selectedReport?.test}</span></div>
            <div><span className="text-slate-500 block">Sample Type</span><span className="text-slate-200 font-medium">{selectedReport?.sampleType}</span></div>
            <div><span className="text-slate-500 block">Barcode</span><span className="text-slate-200 font-medium font-mono">{selectedReport?.barcode}</span></div>
            <div><span className="text-slate-500 block">Collected</span><span className="text-slate-200 font-medium">{selectedReport?.collectedAt}</span></div>
          </div>

          {/* Parameter results */}
          {selectedReport && REPORT_PARAMS[selectedReport.test?.split(' ')[0]] && (
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2">PARAMETER RESULTS</p>
              <div className="space-y-2">
                {REPORT_PARAMS[selectedReport.test.split(' ')[0]].map((p, i) => (
                  <div key={i} className="flex items-center gap-3 bg-surface-850 rounded-xl p-3">
                    <div className="flex-1">
                      <p className="text-sm text-slate-300 font-medium">{p.name}</p>
                      <p className="text-[10px] text-slate-600">Ref: {p.ref}</p>
                    </div>
                    <input className="w-24 bg-surface-900 border border-surface-700 rounded-lg px-2 py-1.5 text-sm text-center focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Value" />
                    <span className="text-xs text-slate-600 w-12">{p.unit}</span>
                    <select className="bg-surface-900 border border-surface-700 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand-500/40">
                      <option value="normal">Normal</option>
                      <option value="high">High</option>
                      <option value="low">Low</option>
                      <option value="critical">Critical</option>
                    </select>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Notes / Remarks</label>
            <textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-20 resize-none" placeholder="Any observations, hemolysis, lipemia, icterus index..." value={resultForm.notes} onChange={e => setResultForm({ ...resultForm, notes: e.target.value })} />
          </div>

          <div className="flex gap-2 justify-end">
            <button type="button" onClick={() => setShowResultModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-5 py-2 rounded-xl text-sm font-medium">
              {selectedReport?.status === 'verification' ? '✓ Approve & Release' : 'Submit Result'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  SAMPLE COLLECTION
// ═══════════════════════════════════════════════════════════════════════════════
const SAMPLE_QUEUE = [
  { patient: 'Neha Gupta', patientId: 'P0040', test: 'Urine Routine', sampleType: 'Urine', priority: 'normal', referredBy: 'Dr. Anita Gupta', fasting: 'No', time: '09:25 AM' },
  { patient: 'Ramesh Yadav', patientId: 'P0043', test: 'Vitamin D + B12 + Calcium', sampleType: 'Blood-SST', priority: 'normal', referredBy: 'Dr. Rajesh Mehta', fasting: 'No', time: '09:30 AM' },
  { patient: 'Priya Deshmukh', patientId: 'P0046', test: 'HbA1c', sampleType: 'Blood-EDTA', priority: 'normal', referredBy: 'Dr. Rajesh Mehta', fasting: 'Yes', time: '09:35 AM' },
  { patient: 'Ashok Menon', patientId: 'P0049', test: 'LFT + KFT', sampleType: 'Blood-SST', priority: 'normal', referredBy: 'Dr. Suresh Nair', fasting: 'Yes', time: '09:40 AM' },
  { patient: 'Fatima Begum', patientId: 'P0052', test: 'CBC + ESR + CRP', sampleType: 'Blood-EDTA', priority: 'urgent', referredBy: 'Dr. Rajesh Mehta', fasting: 'No', time: '09:45 AM' },
]

const RECENT_COLLECTED = [
  { patient: 'Rahul Sharma', barcode: 'BC-4501', test: 'CBC', time: '08:15 AM', status: 'labelled' },
  { patient: 'Anil Kumar', barcode: 'BC-4502', test: 'Lipid Profile', time: '08:15 AM', status: 'labelled' },
  { patient: 'Meena Devi', barcode: 'BC-4503', test: 'Thyroid Profile', time: '08:20 AM', status: 'labelled' },
  { patient: 'Suresh Babu', barcode: 'BC-4504', test: 'Cardiac Risk Profile', time: '08:25 AM', status: 'labelled' },
  { patient: 'Priyanka Singh', barcode: 'BC-4505', test: 'CBC + Iron Studies', time: '08:30 AM', status: 'labelled' },
  { patient: 'Ravi Shankar', barcode: 'BC-4506', test: 'HbA1c + KFT', time: '08:35 AM', status: 'labelled' },
  { patient: 'Geeta Bai', barcode: 'BC-4507', test: 'LFT + Hepatitis B', time: '08:40 AM', status: 'labelled' },
  { patient: 'Mohd. Irfan', barcode: 'BC-4508', test: 'Dengue NS1 + CBC + CRP', time: '08:45 AM', status: 'labelled' },
]

// ═══════════════════════════════════════════════════════════════════════════════
//  SAMPLE COLLECTION (continued)
// ═══════════════════════════════════════════════════════════════════════════════
export function SampleCollection() {
  const [barcode, setBarcode] = useState('')
  const [searchResult, setSearchResult] = useState(null)
  const [searched, setSearched] = useState(false)
  const [queueIndex, setQueueIndex] = useState(0)
  const searchRef = useRef(null)

  const handleSearch = () => {
    setSearched(true)
    if (!barcode.trim()) { toast.error('Please enter a barcode or patient ID'); return }
    // Search in queue
    const found = SAMPLE_QUEUE.find(s => s.patientId.toLowerCase() === barcode.toLowerCase() || s.patient.toLowerCase().includes(barcode.toLowerCase()))
    // Search in already collected
    const foundCollected = RECENT_COLLECTED.find(s => s.barcode === barcode || s.patient.toLowerCase().includes(barcode.toLowerCase()))

    if (found) {
      setSearchResult({ ...found, barcode: `BC-${Date.now().toString().slice(-4)}`, status: 'pending' })
      toast.success(`Patient found: ${found.patient}`)
    } else if (foundCollected) {
      setSearchResult({ ...foundCollected, status: 'already_collected' })
      toast.success(`Already collected: ${foundCollected.patient}`)
    } else {
      setSearchResult(null)
      toast.error('No patient found with this ID')
    }
  }

  const handleQueueSelect = (patient, idx) => {
    setQueueIndex(idx)
    setBarcode(patient.patientId)
    setSearched(true)
    setSearchResult({ ...patient, barcode: `BC-${Date.now().toString().slice(-4)}`, status: 'pending' })
    toast.success(`Pre-filled: ${patient.patient}`)
  }

  const handleCollect = () => {
    toast.success(`✅ Sample collected and labelled for ${searchResult?.patient}!`)
    setSearchResult(null)
    setBarcode('')
    setSearched(false)
  }

  // ── Keyboard shortcuts ────────────────────────────────────────────────────────
  useKeyboardShortcuts({
    'f': () => searchRef.current?.focus(),
    'n': () => {
      const next = (queueIndex + 1) % SAMPLE_QUEUE.length
      handleQueueSelect(SAMPLE_QUEUE[next], next)
    },
    'enter': () => { if (searchResult && searchResult.status !== 'already_collected') handleCollect() },
  }, { allowWhenTyping: ['f'] }, [searchResult, handleCollect, queueIndex])

  return (
    <div>
      <PageHeader title="Sample Collection" subtitle="Scan barcode or search patient for sample collection" />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Left: Search & Collection (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          {/* Search */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-4 flex items-center gap-2"><Search size={16} className="text-brand-400" /> Scan / Search Patient</p>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input ref={searchRef} value={barcode} onChange={e => setBarcode(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()} className="w-full bg-surface-850 border border-surface-700 rounded-xl pl-4 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 font-mono" placeholder="Barcode / Patient ID / Name..." />
              </div>
              <Tooltip label="Search Patient" shortcut="⌘F">
                <button onClick={handleSearch} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-5 py-2 rounded-xl text-sm">Search</button>
              </Tooltip>
            </div>
            <p className="text-center text-xs text-slate-500/60 mt-2">⌘N to cycle queue items · or scan physical barcode with scanner</p>
          </div>

          {/* Search Result */}
          {searched && searchResult && (
            <div className={`bg-surface-900 rounded-2xl border p-5 ${searchResult.status === 'already_collected' ? 'border-green-500/30' : 'border-brand-500/30'}`}>
              {searchResult.status === 'already_collected' ? (
                <>
                  <p className="text-xs font-semibold text-green-400 uppercase tracking-wide mb-2">✓ Already Collected</p>
                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between"><span className="text-slate-500">Patient:</span><span className="text-slate-200">{searchResult.patient}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Test:</span><span className="text-slate-200">{searchResult.test}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Barcode:</span><span className="text-slate-200 font-mono">{searchResult.barcode}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Collected at:</span><span className="text-slate-200">{searchResult.time}</span></div>
                  </div>
                </>
              ) : (
                <>
                  <p className="text-xs font-semibold text-brand-400 uppercase tracking-wide mb-2">Patient Found — Ready to Collect</p>
                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between"><span className="text-slate-500">Patient:</span><span className="text-slate-200">{searchResult.patient} ({searchResult.patientId})</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Test:</span><span className="text-slate-200">{searchResult.test}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Sample Type:</span><span className="text-slate-200">{searchResult.sampleType}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Referred by:</span><span className="text-slate-200">{searchResult.referredBy}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Fasting:</span><span className={searchResult.fasting === 'Yes' ? 'text-amber-400 font-medium' : 'text-slate-200'}>{searchResult.fasting}</span></div>
                    {searchResult.priority === 'urgent' && <div className="flex justify-between"><span className="text-slate-500">Priority:</span><span className="text-amber-400 font-bold">URGENT</span></div>}
                  </div>
                  <Tooltip label="Collect Sample" shortcut="⌘↵">
                    <button onClick={handleCollect} className="mt-4 w-full bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2.5 rounded-xl text-sm transition-all">✓ Collect Sample & Print Label</button>
                  </Tooltip>
                </>
              )}
            </div>
          )}
          {searched && !searchResult && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-5 text-center">
              <p className="text-sm text-red-400">No patient found with "{barcode}"</p>
              <p className="text-xs text-red-400/60 mt-1">Try a different barcode or patient ID</p>
            </div>
          )}

          {/* Quick Tips */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4">
            <p className="text-xs font-semibold text-slate-500 mb-2">QUICK TIPS</p>
            <div className="space-y-1.5 text-xs text-slate-400">
              <p>• Scan barcode label on the vacutainer</p>
              <p>• Verify patient name before collecting</p>
              <p>• Check fasting status — critical for Lipid, Glucose</p>
              <p>• URGENT samples: process within 30 minutes</p>
            </div>
          </div>
        </div>

        {/* Right: Queue & Status (3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          {/* Collection Queue */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <div className="flex items-center justify-between mb-3">
              <p className="font-semibold text-slate-300">Collection Queue — Waiting ({SAMPLE_QUEUE.length})</p>
              <span className="text-xs text-slate-500">Sorted by priority & time</span>
            </div>
            <div className="space-y-2">
              {SAMPLE_QUEUE.map((s, i) => (
                <Tooltip key={i} label="Quick Select" position="left">
                  <div onClick={() => handleQueueSelect(s, i)} className={`flex items-center gap-3 p-3 rounded-xl transition-colors cursor-pointer ${i === queueIndex ? 'ring-2 ring-brand-500/40 bg-brand-500/5' : ''} ${s.priority === 'urgent' ? 'bg-amber-500/5 border border-amber-500/20' : 'bg-surface-850 hover:bg-surface-800'}`}>
                    <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                      <User size={14} className="text-blue-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-slate-300 truncate">{s.patient}</p>
                        {s.priority === 'urgent' && <span className="text-[10px] px-1 py-0.5 rounded bg-amber-500/15 text-amber-400 font-bold">URGENT</span>}
                      </div>
                      <p className="text-xs text-slate-500">{s.test} · {s.sampleType} · {s.referredBy}</p>
                    </div>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded ${s.fasting === 'Yes' ? 'bg-amber-500/10 text-amber-400' : 'bg-green-500/10 text-green-400'}`}>{s.fasting === 'Yes' ? 'Fasting' : 'Non-fasting'}</span>
                  </div>
                </Tooltip>
              ))}
            </div>
          </div>

          {/* Today's Collection Status */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Today's Collection Status</p>
            <div className="grid grid-cols-2 gap-3 mb-4">
              {[
                { label: 'Total Collected', value: '8', color: 'text-blue-400', bg: 'bg-blue-500/10' },
                { label: 'In Queue', value: '5', color: 'text-amber-400', bg: 'bg-amber-500/10' },
                { label: 'Processing', value: '4', color: 'text-purple-400', bg: 'bg-purple-500/10' },
                { label: 'Completed', value: '4', color: 'text-green-400', bg: 'bg-green-500/10' },
              ].map(s => (
                <div key={s.label} className={`${s.bg} rounded-xl p-3 text-center`}>
                  <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                  <p className="text-xs text-slate-500">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Sample type breakdown */}
            <p className="text-xs font-semibold text-slate-500 mb-2">SAMPLE TYPES TODAY</p>
            <div className="space-y-1.5">
              {[
                { type: 'Blood-EDTA', count: 6, icon: Droplets, color: 'text-red-400' },
                { type: 'Blood-SST', count: 5, icon: Droplets, color: 'text-rose-400' },
                { type: 'Urine', count: 1, icon: TestTube, color: 'text-yellow-400' },
                { type: 'Blood-Fluoride', count: 1, icon: Droplets, color: 'text-orange-400' },
              ].map(t => (
                <div key={t.type} className="flex items-center gap-2 text-sm">
                  <t.icon size={14} className={t.color} />
                  <span className="text-slate-400 flex-1">{t.type}</span>
                  <span className="font-medium text-slate-300">{t.count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Recently Collected */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3 flex items-center gap-2"><CheckCircle size={16} className="text-green-400" /> Recently Collected</p>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {RECENT_COLLECTED.map((r, i) => (
                <div key={i} className="flex items-center gap-2 p-2 bg-surface-850 rounded-lg text-sm">
                  <CheckCircle size={12} className="text-green-400 flex-shrink-0" />
                  <span className="text-slate-300 flex-1 truncate">{r.patient}</span>
                  <span className="text-xs text-slate-500">{r.test.split('+')[0].trim()}</span>
                  <span className="text-[10px] text-slate-600 font-mono">{r.barcode}</span>
                  <span className="text-[10px] text-slate-600">{r.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PENDING REPORTS
// ═══════════════════════════════════════════════════════════════════════════════
export function PendingReports() {
  const [showModal, setShowModal] = useState(false)
  const [selectedReport, setSelectedReport] = useState(null)
  const [resultForm, setResultForm] = useState({ value: '', notes: '' })
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [showPatientModal, setShowPatientModal] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState(null)

  const REPORTS = [
    ...TODAY_SAMPLES.filter(s => s.status !== 'completed'),
  ]

  const filtered = useMemo(() => {
    return REPORTS.filter(r => {
      const matchSearch = r.patient.toLowerCase().includes(search.toLowerCase()) || r.test.toLowerCase().includes(search.toLowerCase())
      const matchFilter = filter === 'all' || r.status === filter
      return matchSearch && matchFilter
    })
  }, [search, filter])

  const handleView = (report) => {
    setSelectedReport(report)
    setShowModal(true)
  }

  const handleApprove = (report) => {
    toast.success(`✅ Report approved & released for ${report.patient} — ${report.test}`)
  }

  const handleSubmitResult = (e) => {
    e.preventDefault()
    toast.success(`✅ Result submitted for ${selectedReport?.patient}! Awaiting verification.`)
    setShowModal(false)
  }

  const handleViewPatient = (sample) => {
    setSelectedPatient(sample)
    setShowPatientModal(true)
  }

  // ── Keyboard shortcuts ────────────────────────────────────────────────────────
  const filteredRef = useRef(filtered)
  filteredRef.current = filtered

  useKeyboardShortcuts({
    'p': () => { const list = filteredRef.current; if (list.length > 0) handleViewPatient(list[0]) },
    'd': () => { const list = filteredRef.current; if (list.length > 0) handleView(list[0]) },
    'a': () => { const list = filteredRef.current; const p = list.find(r => r.status === 'verification'); if (p) handleApprove(p) },
    'r': () => { const list = filteredRef.current; const p = list.find(r => r.status !== 'verification'); if (p) { setSelectedReport(p); setResultForm({ value: '', notes: '' }); setShowModal(true) } },
  }, { disabled: showPatientModal || showModal }, [handleViewPatient, handleView, handleApprove])

  return (
    <div>
      <PageHeader title="Pending Reports" subtitle={`${REPORTS.length} tests awaiting result entry or verification`} />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1 max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by patient name or test..." className="w-full bg-surface-900 border border-surface-700 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" />
        </div>
        <div className="flex gap-2">
          {[{ k: 'all', l: 'All' }, { k: 'pending', l: 'Pending' }, { k: 'processing', l: 'Processing' }, { k: 'verification', l: 'Verify' }].map(f => (
            <button key={f.k} onClick={() => setFilter(f.k)} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${filter === f.k ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700'}`}>{f.l} ({f.k === 'all' ? REPORTS.length : REPORTS.filter(r => r.status === f.k).length})</button>
          ))}
        </div>
      </div>

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="divide-y divide-surface-800">
          {filtered.map(r => (
            <div key={r.id} className={`flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors ${r.priority === 'urgent' ? 'border-l-2 border-l-amber-500' : ''}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${r.status === 'verification' ? 'bg-purple-500/10' : r.status === 'processing' ? 'bg-amber-500/10' : 'bg-blue-500/10'}`}>
                <FileText size={18} className={r.status === 'verification' ? 'text-purple-400' : r.status === 'processing' ? 'text-amber-400' : 'text-blue-400'} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="font-medium text-sm text-slate-300">{r.patient}</p>
                  <span className="text-xs text-slate-600">({r.patientId})</span>
                  {r.priority === 'urgent' && <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/20 font-semibold">URGENT</span>}
                </div>
                <p className="text-xs text-slate-500">{r.test} · {r.sampleType} · Collected {r.collectedAt}</p>
                <p className="text-[10px] text-slate-600">Barcode: {r.barcode} · Vol: {r.volume} · {r.condition}</p>
              </div>
              <Badge status={r.status} />
              <Tooltip label="View Patient" shortcut="⌘P">
                <button onClick={() => handleViewPatient(r)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 p-1.5 rounded-xl transition-all flex-shrink-0">
                  <User size={15} />
                </button>
              </Tooltip>
              <div className="flex gap-2 flex-shrink-0">
                <Tooltip label="View Details" shortcut="⌘D">
                  <button onClick={() => handleView(r)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-2.5 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={11} /> View</button>
                </Tooltip>
                {r.status === 'verification' ? (
                  <Tooltip label="Approve & Release" shortcut="⌘A">
                    <button onClick={() => handleApprove(r)} className="bg-green-500 hover:bg-green-600 text-white font-semibold px-3 py-1 rounded-xl text-xs transition-all">Approve</button>
                  </Tooltip>
                ) : (
                  <Tooltip label="Enter Result" shortcut="⌘R">
                    <button onClick={() => { setSelectedReport(r); setResultForm({ value: '', notes: '' }); setShowModal(true) }} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-3 py-1 rounded-xl text-xs transition-all">Enter Result</button>
                  </Tooltip>
                )}
              </div>
            </div>
          ))}
          {filtered.length === 0 && <div className="p-8 text-center text-slate-500 text-sm">No reports match your search.</div>}
        </div>
      </div>

      {/* Patient Detail Modal */}
      <Modal open={showPatientModal} onClose={() => setShowPatientModal(false)} title={`Patient Details — ${selectedPatient?.patient || ''}`} size="lg">
        {selectedPatient && (
          <div className="space-y-4">
            {/* Patient Identity */}
            <div className="flex items-center gap-4 p-4 bg-surface-850 rounded-xl">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-brand-500 to-blue-600 flex items-center justify-center text-white font-bold text-lg shadow-glow">
                {selectedPatient.patient.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-100">{selectedPatient.patient}</h3>
                <p className="text-sm text-slate-400">{selectedPatient.patientId} · {selectedPatient.age} yrs · {selectedPatient.gender}</p>
                <p className="text-xs text-slate-500">📞 {selectedPatient.phone}</p>
              </div>
            </div>

            {/* Sample / Test Details */}
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 uppercase tracking-wide">Test & Sample Info</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Test</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.test}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Sample Type</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.sampleType}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Barcode</p>
                  <p className="text-sm text-slate-200 font-mono font-medium">{selectedPatient.barcode}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Collected At</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.collectedAt}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Volume</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.volume}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Condition</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.condition}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Assigned By</p>
                  <p className="text-sm text-slate-200 font-medium">{selectedPatient.assignedBy}</p>
                </div>
                <div className="bg-surface-850 rounded-xl p-3">
                  <p className="text-[10px] text-slate-500 uppercase">Status</p>
                  <p className="text-sm"><Badge status={selectedPatient.status} /></p>
                </div>
              </div>
            </div>

            {/* Priority flag */}
            {selectedPatient.priority === 'urgent' && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 flex items-center gap-2">
                <AlertCircle size={16} className="text-amber-400" />
                <p className="text-sm text-amber-400 font-medium">URGENT — Priority processing required</p>
              </div>
            )}

            {/* Patient History */}
            {PATIENT_HISTORY_LOOKUP[selectedPatient.patientId] && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                    <Activity size={13} className="text-brand-400" /> Patient History
                  </p>
                  <span className="text-[10px] text-slate-600">{PATIENT_HISTORY_LOOKUP[selectedPatient.patientId].length} previous records</span>
                </div>
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {PATIENT_HISTORY_LOOKUP[selectedPatient.patientId].map((h, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-surface-850 rounded-xl hover:bg-surface-800 transition-colors">
                      {/* Timeline dot */}
                      <div className="relative flex flex-col items-center pt-1">
                        <div className={`w-2.5 h-2.5 rounded-full border-2 ${h.flag === 'normal' ? 'border-green-500 bg-green-500/20' : h.flag === 'high' ? 'border-amber-500 bg-amber-500/20' : h.flag === 'low' ? 'border-blue-500 bg-blue-500/20' : 'border-red-500 bg-red-500/20'}`} />
                        {i < PATIENT_HISTORY_LOOKUP[selectedPatient.patientId].length - 1 && <div className="w-0.5 flex-1 bg-surface-700 mt-1" />}
                      </div>
                      <div className="flex-1 min-w-0 pb-3">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-xs font-medium text-slate-300">{h.date}</p>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                            h.flag === 'normal' ? 'bg-green-500/10 text-green-400' :
                            h.flag === 'high' ? 'bg-amber-500/10 text-amber-400' :
                            h.flag === 'low' ? 'bg-blue-500/10 text-blue-400' :
                            'bg-red-500/10 text-red-400'
                          }`}>{h.flag}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{h.test}</p>
                        <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">{h.result}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {!PATIENT_HISTORY_LOOKUP[selectedPatient.patientId] && (
              <div className="bg-surface-850 rounded-xl p-4 text-center">
                <p className="text-xs text-slate-500">No previous history available for this patient</p>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Result Entry Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title={`Enter Result — ${selectedReport?.patient || ''}`} size="lg">
        <form onSubmit={handleSubmitResult} className="space-y-4">
          <div className="grid grid-cols-2 gap-3 bg-surface-850 rounded-xl p-4 text-sm">
            <div><span className="text-slate-500 block text-xs">Patient</span><span className="text-slate-200 font-medium">{selectedReport?.patient}</span></div>
            <div><span className="text-slate-500 block text-xs">Patient ID</span><span className="text-slate-200 font-medium">{selectedReport?.patientId}</span></div>
            <div><span className="text-slate-500 block text-xs">Test</span><span className="text-slate-200 font-medium">{selectedReport?.test}</span></div>
            <div><span className="text-slate-500 block text-xs">Sample</span><span className="text-slate-200 font-medium">{selectedReport?.sampleType}</span></div>
          </div>

          {/* Quick parameter entry */}
          {selectedReport && REPORT_PARAMS[selectedReport.test?.split(' ')[0]] && (
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2">PARAMETERS</p>
              <div className="space-y-2">
                {REPORT_PARAMS[selectedReport.test.split(' ')[0]].map((p, i) => (
                  <div key={i} className="flex items-center gap-3 bg-surface-850 rounded-xl p-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-slate-300 font-medium">{p.name}</p>
                      <p className="text-[10px] text-slate-600">Ref: {p.ref}</p>
                    </div>
                    <input className="w-24 bg-surface-900 border border-surface-700 rounded-lg px-2 py-1.5 text-sm text-center focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Value" />
                    <span className="text-[10px] text-slate-600 w-10 text-right">{p.unit}</span>
                    <select className="bg-surface-900 border border-surface-700 rounded-lg px-2 py-1.5 text-[10px] focus:outline-none focus:ring-2 focus:ring-brand-500/40">
                      <option value="normal">Normal</option>
                      <option value="high">High ↑</option>
                      <option value="low">Low ↓</option>
                      <option value="critical">Critical ⚠</option>
                    </select>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Notes / Remarks</label>
            <textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-20 resize-none" placeholder="Hemolysis index, lipemia, icterus, any observations..." value={resultForm.notes} onChange={e => setResultForm({ ...resultForm, notes: e.target.value })} />
          </div>

          <div className="flex gap-2 justify-end">
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-5 py-2 rounded-xl text-sm font-medium">Submit Result</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
