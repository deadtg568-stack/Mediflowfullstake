import React, { useState } from 'react'
import { PageHeader, Badge } from '../../components/UI'
import { CalendarDays, Clock, Plus } from 'lucide-react'

export function Appointments() {
  const appts = [
    { id: 'A001', patient: 'Rahul Sharma', phone: '9876543210', tests: ['CBC', 'LFT'], time: '09:00 AM', type: 'Walk-in', status: 'completed' },
    { id: 'A002', patient: 'Priya Verma', phone: '9123456780', tests: ['Thyroid'], time: '10:30 AM', type: 'Appointment', status: 'pending' },
    { id: 'A003', patient: 'Anil Kumar', phone: '9988776655', tests: ['Lipid', 'HbA1c'], time: '11:00 AM', type: 'Home Collection', status: 'processing' },
    { id: 'A004', patient: 'Sunita Patel', phone: '8877665544', tests: ['Urine'], time: '11:30 AM', type: 'Walk-in', status: 'pending' },
  ]
  return (
    <div>
      <PageHeader
        title="Appointments"
        subtitle="Today's schedule and bookings"
        actions={<button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} />Book Appointment</button>}
      />
      <div className="grid grid-cols-1 gap-3">
        {appts.map(a => (
          <div key={a.id} className="bg-surface-900 rounded-2xl border border-surface-700 p-4 flex items-center gap-4">
            <div className="w-12 h-12 bg-brand-500/10 rounded-xl flex flex-col items-center justify-center flex-shrink-0">
              <Clock size={14} className="text-brand-400 mb-0.5" />
              <span className="text-xs font-bold text-primary-700">{a.time.split(' ')[0]}</span>
              <span className="text-xs text-brand-400">{a.time.split(' ')[1]}</span>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-slate-300">{a.patient}</p>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium bg-blue-500/10 text-blue-400 text-xs">{a.type}</span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{a.phone} · {a.tests.join(', ')}</p>
            </div>
            <Badge status={a.status} />
            <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">View</button>
          </div>
        ))}
      </div>
    </div>
  )
}

export function LabSettings() {
  return (
    <div>
      <PageHeader title="Settings" subtitle="Lab configuration and preferences" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Lab Information</p>
          <div className="space-y-3">
            {[
              { label: 'Lab Name', val: 'City Diagnostics' },
              { label: 'Registration No.', val: 'LAB/CG/2024/001' },
              { label: 'Address', val: 'Raipur, Chhattisgarh' },
              { label: 'Phone', val: '+91 98765 43210' },
              { label: 'Email', val: 'citydiag@email.com' },
              { label: 'GST Number', val: '22XXXXX1234X1Z5' },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" defaultValue={f.val} />
              </div>
            ))}
            <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all mt-2">Save Changes</button>
          </div>
        </div>
        <div className="space-y-4">
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Report Settings</p>
            <div className="space-y-2">
              {['Show doctor signature on report', 'Include lab logo in PDF', 'Enable QR code verification', 'Auto-send report on WhatsApp'].map(opt => (
                <label key={opt} className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded" />
                  {opt}
                </label>
              ))}
            </div>
          </div>
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Current Plan</p>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-blue-400 text-lg">Professional</p>
                <p className="text-sm text-slate-500">₹1,999/month · Renews Jan 15, 2027</p>
              </div>
              <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs">Upgrade</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
