import React, { useState, useEffect } from 'react'
import { PageHeader, Badge, Modal } from '../../components/UI'
import { Clock, Plus, Eye } from 'lucide-react'
import { labAPI, appointmentAPI, apiErrorMessage } from '../../utils/api'
import toast from 'react-hot-toast'

export function Appointments() {
  const [appts, setAppts] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedAppt, setSelectedAppt] = useState(null)
  const [form, setForm] = useState({ patient: '', phone: '', tests: '', time: '', date: '', type: 'Appointment', notes: '' })

  // ── Helper: map backend status to UI badge status ─────────────────────────
  const mapStatus = (s) => {
    const map = { scheduled: 'pending', confirmed: 'processing', completed: 'completed', cancelled: 'cancelled' }
    return map[s] || 'pending'
  }

  // ── Helper: format scheduledAt to time string ─────────────────────────────
  const formatTime = (date) => {
    if (!date) return '—'
    const d = new Date(date)
    return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
  }

  // ── Helper: map backend appointment to UI shape ───────────────────────────
  const mapAppt = (a) => ({
    _id: a._id,
    id: a._id,
    patient: a.patient?.name || 'N/A',
    phone: a.patient?.phone || '—',
    tests: (a.tests || []).map(t => t.name || t),
    time: formatTime(a.scheduledAt),
    type: a.type === 'appointment' ? 'Appointment' : a.type === 'walkin' ? 'Walk-in' : a.type === 'home' ? 'Home Collection' : a.type,
    status: mapStatus(a.status),
    notes: a.notes,
  })

  const load = async () => {
    setLoading(true)
    try {
      const res = await appointmentAPI.getAll()
      const data = Array.isArray(res.data) ? res.data : res.data.data || []
      setAppts(data.map(mapAppt))
    } catch {
      // Fallback to mock data
      setAppts([
        { id: 'demo-1', patient: 'Rahul Sharma', phone: '9876543210', tests: ['CBC', 'LFT'], time: '09:00 AM', type: 'Walk-in', status: 'completed' },
        { id: 'demo-2', patient: 'Priya Verma', phone: '9123456780', tests: ['Thyroid'], time: '10:30 AM', type: 'Appointment', status: 'pending' },
        { id: 'demo-3', patient: 'Anil Kumar', phone: '9988776655', tests: ['Lipid', 'HbA1c'], time: '11:00 AM', type: 'Home Collection', status: 'processing' },
        { id: 'demo-4', patient: 'Sunita Patel', phone: '8877665544', tests: ['Urine'], time: '11:30 AM', type: 'Walk-in', status: 'pending' },
      ])
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleCreate = async (e) => {
    e.preventDefault()
    const tests = form.tests.split(',').map(t => t.trim()).filter(Boolean)
    const scheduledAt = form.date && form.time ? new Date(`${form.date}T${form.time}`) : new Date()
    try {
      await appointmentAPI.create({
        patient: form.patient,
        phone: form.phone,
        tests,
        scheduledAt,
        type: form.type === 'Home Collection' ? 'home' : form.type === 'Walk-in' ? 'walkin' : 'appointment',
        notes: form.notes || undefined,
      })
      toast.success('Appointment booked!')
      setShowModal(false)
      setForm({ patient: '', phone: '', tests: '', time: '', date: '', type: 'Appointment', notes: '' })
      load()
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not save to server'))
      // Fallback: add locally
      const newAppt = {
        id: `demo-${Date.now()}`,
        patient: form.patient,
        phone: form.phone,
        tests,
        time: form.time ? formatTime(new Date(`2026-01-01T${form.time}`)) : '—',
        type: form.type,
        status: 'pending',
      }
      setAppts(prev => [newAppt, ...prev])
      setShowModal(false)
      setForm({ patient: '', phone: '', tests: '', time: '', date: '', type: 'Appointment', notes: '' })
      toast.success('Appointment booked! (offline)')
    }
  }

  const handleView = (appt) => {
    setSelectedAppt(appt)
    setShowViewModal(true)
  }

  const handleCancel = async (appt) => {
    if (!window.confirm(`Cancel appointment for ${appt.patient}?`)) return
    try {
      if (appt._id && !appt._id.startsWith('demo-')) {
        await appointmentAPI.update(appt._id, { status: 'cancelled' })
      }
      setAppts(prev => prev.map(a => (a.id === appt.id ? { ...a, status: 'cancelled' } : a)))
      toast.success('Appointment cancelled!')
    } catch { toast.error('Failed to cancel') }
  }

  const handleDelete = async (appt) => {
    if (!window.confirm(`Delete appointment for ${appt.patient}? This cannot be undone.`)) return
    try {
      if (appt._id && !appt._id.startsWith('demo-')) {
        await appointmentAPI.delete(appt._id)
      }
      setAppts(prev => prev.filter(a => a.id !== appt.id))
      toast.success('Appointment deleted!')
    } catch { toast.error('Failed to delete') }
  }

  const handleStart = async (appt) => {
    try {
      if (appt._id && !appt._id.startsWith('demo-')) {
        await appointmentAPI.update(appt._id, { status: 'confirmed' })
      }
      setAppts(prev => prev.map(a => (a.id === appt.id ? { ...a, status: 'processing' } : a)))
      toast.success(`Started serving ${appt.patient}`)
    } catch { toast.error('Failed to update') }
  }

  return (
    <div>
      <PageHeader
        title="Appointments"
        subtitle="Today's schedule and bookings"
        actions={<button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} />Book Appointment</button>}
      />
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 text-center">
          <p className="text-2xl font-bold text-brand-400">{appts.filter(a => a.status === 'completed').length}</p>
          <p className="text-xs text-slate-500 mt-0.5">Completed</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 text-center">
          <p className="text-2xl font-bold text-amber-400">{appts.filter(a => a.status === 'pending').length}</p>
          <p className="text-xs text-slate-500 mt-0.5">Pending</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 text-center">
          <p className="text-2xl font-bold text-blue-400">{appts.filter(a => a.status === 'processing').length}</p>
          <p className="text-xs text-slate-500 mt-0.5">In Progress</p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-3">
        {appts.map(a => (
          <div key={a.id} className="bg-surface-900 rounded-2xl border border-surface-700 p-4 flex items-center gap-4">
            <div className="w-12 h-12 bg-brand-500/10 rounded-xl flex flex-col items-center justify-center flex-shrink-0">
              <Clock size={14} className="text-brand-400 mb-0.5" />
              <span className="text-xs font-bold text-primary-700">{a.time.split(' ')[0]}</span>
              <span className="text-xs text-brand-400">{a.time.split(' ')[1]}</span>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-medium text-slate-300">{a.patient}</p>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium bg-blue-500/10 text-blue-400">{a.type}</span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{a.phone} · {a.tests.join(', ')}</p>
            </div>
            <Badge status={a.status} />
            <div className="flex gap-2">
              <button onClick={() => handleView(a)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={12} /> View</button>
              {a.status === 'pending' && <button onClick={() => handleStart(a)} className="bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all">Start</button>}
              {a.status !== 'completed' && a.status !== 'cancelled' && <button onClick={() => handleCancel(a)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all">Cancel</button>}
              {a.status === 'cancelled' && <button onClick={() => handleDelete(a)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all">Delete</button>}
            </div>
          </div>
        ))}
      </div>

      {/* Book Appointment Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Book New Appointment">
        <form onSubmit={handleCreate} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Patient name" value={form.patient} onChange={e => setForm({ ...form, patient: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Phone *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Mobile" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Tests (comma separated) *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. CBC, LFT" value={form.tests} onChange={e => setForm({ ...form, tests: e.target.value })} /></div>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Date *</label><input required type="date" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Time *</label><input required type="time" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Type</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
                <option>Appointment</option><option>Walk-in</option><option>Home Collection</option>
              </select>
            </div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Notes</label><textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-16 resize-none" placeholder="Optional..." value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Book Appointment</button>
          </div>
        </form>
      </Modal>

      {/* View Appointment Modal */}
      <Modal open={showViewModal} onClose={() => setShowViewModal(false)} title="Appointment Details">
        {selectedAppt && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-slate-500">Patient:</span><p className="text-slate-200 font-medium">{selectedAppt.patient}</p></div>
              <div><span className="text-slate-500">Phone:</span><p className="text-slate-200">{selectedAppt.phone}</p></div>
              <div><span className="text-slate-500">Date & Time:</span><p className="text-slate-200">{selectedAppt.time}</p></div>
              <div><span className="text-slate-500">Type:</span><p className="text-slate-200">{selectedAppt.type}</p></div>
              <div><span className="text-slate-500">Status:</span><p><Badge status={selectedAppt.status} /></p></div>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Tests</p>
              <div className="bg-surface-850 rounded-xl p-3">
                <p className="text-sm text-slate-300">{selectedAppt.tests.join(', ')}</p>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

export function LabSettings() {
  const [form, setForm] = useState({
    labName: 'City Diagnostics', regNo: 'LAB/CG/2024/001', address: 'Raipur, Chhattisgarh',
    phone: '+91 98765 43210', email: 'citydiag@email.com', gst: '22XXXXX1234X1Z5'
  })
  const [reportSettings, setReportSettings] = useState({
    doctorSignature: true, labLogo: true, qrCode: true, autoWhatsApp: false
  })

  const handleSave = async () => {
    try { await labAPI.update(form); toast.success('Settings saved!') } catch { toast.success('Settings saved! (demo)') }
  }

  const handleToggle = (key) => {
    setReportSettings(prev => ({ ...prev, [key]: !prev[key] }))
    toast.success('Setting updated!')
  }

  return (
    <div>
      <PageHeader title="Settings" subtitle="Lab configuration and preferences" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Lab Information</p>
          <div className="space-y-3">
            {[
              { label: 'Lab Name', key: 'labName' },
              { label: 'Registration No.', key: 'regNo' },
              { label: 'Address', key: 'address' },
              { label: 'Phone', key: 'phone' },
              { label: 'Email', key: 'email' },
              { label: 'GST Number', key: 'gst' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" value={form[f.key]} onChange={e => setForm({ ...form, [f.key]: e.target.value })} />
              </div>
            ))}
            <button onClick={handleSave} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all mt-2">Save Changes</button>
          </div>
        </div>
        <div className="space-y-4">
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Report Settings</p>
            <div className="space-y-2">
              {[
                { key: 'doctorSignature', label: 'Show doctor signature on report' },
                { key: 'labLogo', label: 'Include lab logo in PDF' },
                { key: 'qrCode', label: 'Enable QR code verification' },
                { key: 'autoWhatsApp', label: 'Auto-send report on WhatsApp' },
              ].map(opt => (
                <button key={opt.key} onClick={() => handleToggle(opt.key)} className="flex items-center justify-between w-full text-sm text-slate-400 cursor-pointer py-1">
                  <span>{opt.label}</span>
                  <div className={`w-10 h-5 rounded-full flex items-center px-0.5 transition-colors ${reportSettings[opt.key] ? 'bg-brand-500' : 'bg-surface-700'}`}>
                    <div className={`w-4 h-4 rounded-full transition-transform ${reportSettings[opt.key] ? 'bg-white ml-auto' : 'bg-slate-400'}`} />
                  </div>
                </button>
              ))}
            </div>
          </div>
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Current Plan</p>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-blue-400 text-lg">Professional</p>
                <p className="text-sm text-slate-500">₹1,999/month · Renews Jan 15, 2027</p>
              </div>
              <button onClick={() => toast.success('Upgrade flow coming soon!')} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs">Upgrade</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
