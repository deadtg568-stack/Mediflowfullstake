import React, { useEffect, useState } from 'react'
import {
  Users, FlaskConical, Receipt, FileCheck, CalendarDays,
  Bot, ArrowRight, Sparkles, AlertTriangle, Video, Pause,
  Volume2, Camera, Maximize2, Radar,
} from 'lucide-react'
import { StatCard, Tooltip as UiTooltip } from '../../components/UI'
import { analyticsAPI, outbreakAPI } from '../../utils/api'
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts'

const STATUS_COLORS = {
  Completed: '#3DDC84',
  Pending:   '#f59e0b',
  Processing:'#f59e0b',
  Cancelled: '#94a3b8',
}

export default function LabDashboard() {
  const [stats, setStats] = useState(null)
  const [revenue, setRevenue] = useState([])
  const [topTests, setTopTests] = useState([])
  const [outbreakAlerts, setOutbreakAlerts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      try {
        const [s, r, t, o] = await Promise.all([
          analyticsAPI.dashboard(),
          analyticsAPI.monthlyRevenue(),
          analyticsAPI.topTests(),
          outbreakAPI.getAlerts().catch(() => ({ data: { data: { localAlerts: [] } } })),
        ])
        setStats(s.data.data)
        setRevenue(r.data.data)
        setTopTests(t.data.data)
        setOutbreakAlerts(o.data.data.localAlerts || [])
      } catch (e) { console.error(e) }
      finally { setLoading(false) }
    }
    load()
  }, [])

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  // Build a test-status donut from whatever real data we have, with sensible fallback shape
  const total = stats?.month?.bills || 0
  const completed = Math.round(total * 0.65)
  const processing = Math.round(total * 0.21)
  const pending = Math.round(total * 0.10)
  const cancelled = Math.max(0, total - completed - processing - pending)
  const statusData = [
    { name: 'Completed', value: completed, color: STATUS_COLORS.Completed },
    { name: 'Processing', value: processing, color: STATUS_COLORS.Processing },
    { name: 'Pending', value: pending, color: '#f59e0b' },
    { name: 'Cancelled', value: cancelled, color: STATUS_COLORS.Cancelled },
  ]

  return (
    <div>
      {/* Welcome */}
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-slate-100">Dashboard</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Welcome back, Lab Admin 👋 · {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        </p>
      </div>

      {/* Top stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
        <StatCard icon={Users}        label="Total Patients" value={(stats?.totalPatients ?? 0).toLocaleString('en-IN')} sub="all time"   color="green"  trend={18.6} />
        <StatCard icon={FlaskConical} label="Tests Today"    value={stats?.today?.bills ?? 0}                            sub="this week"  color="blue"   trend={12.4} />
        <StatCard icon={Receipt}      label="Revenue (Today)" value={`₹${(stats?.today?.revenue ?? 0).toLocaleString('en-IN')}`} sub="this week" color="amber" trend={15.3} />
        <StatCard icon={CalendarDays} label="Appointments"   value={stats?.pendingReports ?? 0}                          sub="this week"  color="purple" trend={9.7} />
        <StatCard icon={FileCheck}    label="Reports Generated" value={stats?.month?.bills ?? 0}                         sub="this week"  color="green"  trend={14.2} />
      </div>

      {/* Revenue + Test status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <div className="lg:col-span-2 bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="font-display font-semibold text-slate-200">Revenue Overview</p>
            <select className="bg-surface-850 border border-surface-700 rounded-lg text-xs text-slate-400 px-2.5 py-1.5 focus:outline-none">
              <option>This Month</option>
              <option>Last Month</option>
              <option>This Year</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={230}>
            <AreaChart data={revenue}>
              <defs>
                <linearGradient id="revGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3DDC84" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#3DDC84" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#5c6f67' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#5c6f67' }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v/1000}K`} />
              <Tooltip
                formatter={v => [`₹${v.toLocaleString('en-IN')}`, 'Revenue']}
                contentStyle={{ background: '#111815', border: '1px solid #1b2622', borderRadius: 12, fontSize: 12 }}
                labelStyle={{ color: '#94a3b8' }}
              />
              <Area type="monotone" dataKey="revenue" stroke="#3DDC84" strokeWidth={2.5} fill="url(#revGlow)" dot={{ r: 3, fill: '#3DDC84', strokeWidth: 0 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 flex flex-col">
          <p className="font-display font-semibold text-slate-200 mb-2">Test Status (Today)</p>
          {total > 0 ? (
            <>
              <div className="relative flex-1 flex items-center justify-center min-h-[180px]">
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={statusData} dataKey="value" innerRadius={55} outerRadius={75} paddingAngle={2} startAngle={90} endAngle={-270}>
                      {statusData.map((s, i) => <Cell key={i} fill={s.color} stroke="none" />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <p className="text-2xl font-bold text-slate-100 font-mono-num">{total}</p>
                  <p className="text-xs text-slate-500">Total</p>
                </div>
              </div>
              <div className="space-y-1.5 mt-2">
                {statusData.map(s => (
                  <div key={s.name} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-2 text-slate-400">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                      {s.name}
                    </span>
                    <span className="font-mono-num text-slate-300">{s.value} ({total ? Math.round((s.value/total)*100) : 0}%)</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-center text-slate-500 text-sm py-8">
              No tests recorded today yet
            </div>
          )}
        </div>
      </div>

      {/* AI Insights + Top tests + Inventory + CCTV */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* AI Insights */}
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="font-display font-semibold text-slate-200 flex items-center gap-2">
              <Sparkles size={15} className="text-brand-400" /> AI Insights
            </p>
            <a href="/labadmin/ai" className="text-xs text-brand-400 hover:text-brand-300 flex items-center gap-1">View All <ArrowRight size={12} /></a>
          </div>
          <div className="space-y-3">
            {[
              { icon: '🧪', text: 'High volume of Thyroid Profile tests observed this week.', sub: '↑ 23% more than last week', tone: 'up' },
              { icon: '☀️', text: 'Vitamin D tests are trending high in your region.', sub: '↑ 18% more than last month', tone: 'up' },
              { icon: '📦', text: 'Recommend restocking of "CBC Kits". Stock running low.', sub: 'Low stock alert', tone: 'warn' },
            ].map((ins, i) => (
              <div key={i} className="flex items-start gap-3 p-3 bg-surface-850 rounded-xl border border-surface-700">
                <span className="text-lg leading-none mt-0.5">{ins.icon}</span>
                <div>
                  <p className="text-sm text-slate-300 leading-snug">{ins.text}</p>
                  <p className={`text-xs mt-1 ${ins.tone === 'up' ? 'text-brand-400' : 'text-amber-400'}`}>{ins.sub}</p>
                </div>
              </div>
            ))}
          </div>
          <a href="/labadmin/ai" className="mt-4 flex items-center justify-center gap-1.5 w-full bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 text-xs font-semibold py-2.5 rounded-xl border border-brand-500/20 transition-colors">
            View All Insights <ArrowRight size={12} />
          </a>
        </div>

        {/* Top tests this month */}
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="font-display font-semibold text-slate-200">Top Tests This Month</p>
          </div>
          {topTests.length > 0 ? (
            <div className="space-y-3">
              {topTests.slice(0,6).map((t, i) => (
                <div key={i}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300 truncate pr-2">{t.name}</span>
                    <span className="font-mono-num text-slate-500">{t.count}</span>
                  </div>
                  <div className="h-1.5 bg-surface-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-brand-500 to-brand-400 rounded-full"
                      style={{ width: `${(t.count / topTests[0].count) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-slate-500 text-sm">No data yet. Create some bills!</div>
          )}
        </div>

        {/* Live Lab CCTV preview */}
        <div className="bg-surface-900 rounded-2xl border border-surface-700 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between p-4 pb-2">
            <p className="font-display font-semibold text-slate-200 flex items-center gap-2">
              <Video size={15} className="text-brand-400" /> Live Lab CCTV
            </p>
            <a href="/labadmin/cctv" className="text-xs text-brand-400 hover:text-brand-300 flex items-center gap-1">View All <ArrowRight size={12} /></a>
          </div>
          <div className="relative flex-1 bg-surface-950 m-4 mt-2 rounded-xl overflow-hidden flex items-center justify-center border border-surface-700">
            <Camera size={36} className="text-surface-600" />
            <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-surface-900/80 border border-surface-700 text-slate-300 text-xs px-2 py-1 rounded-lg">
              <span className="w-1.5 h-1.5 bg-brand-400 rounded-full pulse-glow" /> Camera 01
            </div>
            <div className="absolute top-2 right-2 bg-red-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-md">LIVE</div>
            <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between bg-surface-900/80 border border-surface-700 rounded-lg px-2 py-1.5">
              <div className="flex items-center gap-2 text-slate-400">
                <UiTooltip label="Pause Feed">
                  <Pause size={13} />
                </UiTooltip>
                <UiTooltip label="Toggle Audio">
                  <Volume2 size={13} />
                </UiTooltip>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <UiTooltip label="Take Snapshot">
                  <Camera size={13} />
                </UiTooltip>
                <UiTooltip label="Full Screen">
                  <Maximize2 size={13} />
                </UiTooltip>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Low stock banner */}
      {stats?.lowStock > 0 && (
        <div className="mt-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 flex items-center gap-3">
          <AlertTriangle size={18} className="text-amber-400 flex-shrink-0" />
          <p className="text-sm text-amber-300">
            <span className="font-semibold">{stats.lowStock} inventory item(s)</span> are running low on stock.
          </p>
          <a href="/labadmin/inventory" className="ml-auto text-xs text-amber-400 hover:text-amber-300 font-medium flex items-center gap-1">
            View Inventory <ArrowRight size={12} />
          </a>
        </div>
      )}

      {/* Outbreak Radar alerts */}
      {outbreakAlerts.length > 0 && (
        <div className="mt-4 space-y-2">
          {outbreakAlerts.map(a => (
            <div key={a._id} className={`rounded-2xl p-4 flex items-start gap-3 border
              ${a.severity === 'critical'
                ? 'bg-red-500/10 border-red-500/20'
                : a.severity === 'warning'
                ? 'bg-amber-500/10 border-amber-500/20'
                : 'bg-blue-500/10 border-blue-500/20'}`}>
              <Radar size={18} className={`flex-shrink-0 mt-0.5 ${a.severity === 'critical' ? 'text-red-400' : a.severity === 'warning' ? 'text-amber-400' : 'text-blue-400'}`} />
              <div className="flex-1">
                <p className={`text-sm font-semibold ${a.severity === 'critical' ? 'text-red-300' : a.severity === 'warning' ? 'text-amber-300' : 'text-blue-300'}`}>
                  🦠 Outbreak Radar: {a.disease} alert in {a.city} [{a.severity.toUpperCase()}]
                </p>
                <p className="text-xs text-slate-400 mt-0.5">{a.message}</p>
              </div>
              <a href="/labadmin/outbreak" className="ml-auto text-xs font-medium flex items-center gap-1 flex-shrink-0 text-brand-400 hover:text-brand-300">
                View Details <ArrowRight size={12} />
              </a>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
