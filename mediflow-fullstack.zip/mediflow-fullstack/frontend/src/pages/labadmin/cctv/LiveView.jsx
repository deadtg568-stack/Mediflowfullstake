import React, { useEffect, useState, useCallback } from 'react'
import { Play, Square, Circle, Video, Maximize2, RefreshCw, Camera as CameraIcon } from 'lucide-react'
import { PageHeader } from '../../../components/UI'
import { cameraAPI, STATIC_BASE, apiErrorMessage } from '../../../utils/api'
import HlsPlayer from '../../../components/HlsPlayer'
import toast from 'react-hot-toast'

export default function LiveView() {
  const [cameras, setCameras] = useState([])
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState({}) // cameraId -> action in progress
  const [fullscreen, setFullscreen] = useState(null) // cameraId

  const load = useCallback(async () => {
    try {
      const res = await cameraAPI.getAll()
      setCameras(res.data.data)
    } catch { toast.error('Failed to load cameras') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => {
    load()
    const interval = setInterval(load, 10000) // refresh status every 10s
    return () => clearInterval(interval)
  }, [load])

  const setBusyFor = (id, val) => setBusy(b => ({ ...b, [id]: val }))

  const toggleStream = async (cam) => {
    setBusyFor(cam._id, 'stream')
    try {
      if (cam.streaming) {
        await cameraAPI.stopStream(cam._id)
        toast.success(`Stopped stream: ${cam.name}`)
      } else {
        await cameraAPI.startStream(cam._id)
        toast.success(`Starting stream: ${cam.name}... (takes a few seconds)`)
      }
      await load()
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Stream operation failed'))
    } finally { setBusyFor(cam._id, null) }
  }

  const toggleRecording = async (cam) => {
    setBusyFor(cam._id, 'recording')
    try {
      if (cam.recording) {
        await cameraAPI.stopRecording(cam._id)
        toast.success(`Recording stopped: ${cam.name}`)
      } else {
        await cameraAPI.startRecording(cam._id, 15)
        toast.success(`Recording started: ${cam.name}`)
      }
      await load()
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Recording operation failed'))
    } finally { setBusyFor(cam._id, null) }
  }

  const toggleMotion = async (cam) => {
    setBusyFor(cam._id, 'motion')
    try {
      if (cam.motionWatch) {
        await cameraAPI.stopMotion(cam._id)
        toast.success(`AI motion detection stopped: ${cam.name}`)
      } else {
        await cameraAPI.startMotion(cam._id, { intervalMs: 5000 })
        toast.success(`AI motion detection started: ${cam.name}`)
      }
      await load()
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Motion detection toggle failed'))
    } finally { setBusyFor(cam._id, null) }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  if (cameras.length === 0) return (
    <div>
      <PageHeader title="Live View" subtitle="Multi-camera monitoring" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-16 text-center">
        <CameraIcon size={36} className="text-slate-200 mx-auto mb-3" />
        <p className="text-slate-500 font-medium">No cameras configured</p>
        <p className="text-slate-500 text-sm mt-1">Go to Camera Management to add cameras first</p>
        <a href="/labadmin/cctv/cameras" className="inline-block mt-4 bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">
          Manage Cameras
        </a>
      </div>
    </div>
  )

  const focused = fullscreen ? cameras.find(c => c._id === fullscreen) : null

  return (
    <div>
      <PageHeader
        title="Live View"
        subtitle={`${cameras.length} camera(s) · ${cameras.filter(c => c.streaming).length} streaming`}
        actions={
          <button onClick={load} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2">
            <RefreshCw size={16} /> Refresh
          </button>
        }
      />

      {/* Fullscreen single camera view */}
      {focused && (
        <div className="bg-surface-900 rounded-2xl border border-surface-700 mb-4 p-3">
          <div className="aspect-video rounded-xl overflow-hidden">
            <HlsPlayer
              src={focused.streaming ? `${STATIC_BASE}/streams/${focused.streamKey}/index.m3u8` : null}
              label={focused.name}
              controls
              autoPlay
            />
          </div>
          <div className="flex items-center justify-between mt-3">
            <div>
              <p className="font-medium text-slate-300">{focused.name}</p>
              <p className="text-xs text-slate-500">{focused.location} · {focused.ip}</p>
            </div>
            <button onClick={() => setFullscreen(null)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">
              Back to Grid
            </button>
          </div>
        </div>
      )}

      {/* Camera grid */}
      <div className={`grid gap-4 ${cameras.length === 1 ? 'grid-cols-1' : cameras.length <= 2 ? 'grid-cols-2' : 'grid-cols-2 lg:grid-cols-3'}`}>
        {cameras.map(cam => (
          <div key={cam._id} className="bg-surface-900 rounded-2xl border border-surface-700 overflow-hidden">
            <div className="aspect-video relative cursor-pointer" onClick={() => setFullscreen(cam._id)}>
              <HlsPlayer
                src={cam.streaming ? `${STATIC_BASE}/streams/${cam.streamKey}/index.m3u8` : null}
                label={cam.name}
                muted
                autoPlay={cam.streaming}
              />
              <button className="absolute top-3 right-3 bg-black/40 hover:bg-black/60 text-white p-1.5 rounded-lg transition-colors">
                <Maximize2 size={14} />
              </button>
              {cam.recording && (
                <div className="absolute bottom-12 left-3 flex items-center gap-1.5 bg-black/50 text-white text-xs px-2 py-1 rounded-full">
                  <Circle size={8} className="fill-red-500 text-red-500" /> REC
                </div>
              )}
              {cam.motionWatch && (
                <div className="absolute bottom-12 right-3 flex items-center gap-1.5 bg-black/50 text-emerald-300 text-xs px-2 py-1 rounded-full">
                  AI Motion
                </div>
              )}
            </div>

            <div className="p-3 flex items-center justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-300 truncate">{cam.name}</p>
                <p className="text-xs text-slate-500 truncate">{cam.location || cam.ip}</p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => toggleStream(cam)}
                  disabled={busy[cam._id] === 'stream'}
                  title={cam.streaming ? 'Stop stream' : 'Start stream'}
                  className={`p-2 rounded-lg transition-colors ${cam.streaming ? 'bg-red-500/10 text-red-400 hover:bg-red-500/15' : 'bg-brand-500/10 text-brand-400 hover:bg-brand-500/15'} disabled:opacity-50`}>
                  {cam.streaming ? <Square size={14} /> : <Play size={14} />}
                </button>
                <button
                  onClick={() => toggleRecording(cam)}
                  disabled={busy[cam._id] === 'recording'}
                  title={cam.recording ? 'Stop recording' : 'Start recording'}
                  className={`p-2 rounded-lg transition-colors ${cam.recording ? 'bg-red-500/10 text-red-400 hover:bg-red-500/15' : 'bg-surface-850 text-slate-500 hover:bg-surface-700'} disabled:opacity-50`}>
                  <Circle size={14} className={cam.recording ? 'fill-current' : ''} />
                </button>
                <button
                  onClick={() => toggleMotion(cam)}
                  disabled={busy[cam._id] === 'motion'}
                  title={cam.motionWatch ? 'Stop AI motion detection' : 'Start AI motion detection'}
                  className={`px-2 py-2 rounded-lg text-xs font-bold transition-colors ${cam.motionWatch ? 'bg-brand-500/10 text-brand-400 hover:bg-brand-500/15' : 'bg-surface-850 text-slate-500 hover:bg-surface-700'} disabled:opacity-50`}>
                  AI
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-blue-500/10 border border-blue-100 rounded-2xl p-4 mt-4">
        <p className="text-xs text-blue-400 leading-relaxed">
          <strong>Tip:</strong> Click the green Play button to start an RTSP→HLS stream for a camera. The first
          load takes a few seconds while ffmpeg connects to the camera and generates stream segments.
          Recording saves rolling 15-minute MP4 clips to the server's <code>/recordings</code> folder.
          AI Motion detection runs frame-difference analysis every 5 seconds and logs events under Motion Events.
        </p>
      </div>
    </div>
  )
}
