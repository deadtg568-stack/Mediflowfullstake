import React, { useEffect, useState } from 'react'
import { AlertTriangle, CheckCircle, Camera as CameraIcon, Eye } from 'lucide-react'
import { PageHeader, Badge, Modal } from '../../../components/UI'
import { cameraAPI, STATIC_BASE } from '../../../utils/api'
import toast from 'react-hot-toast'

export default function MotionEvents() {
  const [events, setEvents] = useState([])
  const [cameras, setCameras] = useState([])
  const [cameraFilter, setCameraFilter] = useState('')
  const [loading, setLoading] = useState(true)
  const [preview, setPreview] = useState(null)

  const load = async () => {
    setLoading(true)
    try {
      const [evRes, camRes] = await Promise.all([
        cameraAPI.getMotionEvents({ cameraId: cameraFilter || undefined, limit: 50 }),
        cameraAPI.getAll(),
      ])
      setEvents(evRes.data.data.events)
      setCameras(camRes.data.data)
    } catch { toast.error('Failed to load motion events') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [cameraFilter])

  const markReviewed = async (id) => {
    try {
      await cameraAPI.reviewMotionEvent(id)
      setEvents(ev => ev.map(e => e._id === id ? { ...e, reviewed: true } : e))
    } catch { toast.error('Failed to update') }
  }

  const watchingCameras = cameras.filter(c => c.motionWatch)

  return (
    <div>
      <PageHeader
        title="AI Motion Detection"
        subtitle={`${events.filter(e => !e.reviewed).length} unreviewed event(s)`}
        actions={
          <select value={cameraFilter} onChange={e => setCameraFilter(e.target.value)}
            className="bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40">
            <option value="">All Cameras</option>
            {cameras.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}
          </select>
        }
      />

      {/* Active watchers status */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 mb-4">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">AI Monitoring Status</p>
        {watchingCameras.length === 0 ? (
          <p className="text-sm text-slate-500">No cameras currently being monitored. Enable AI Motion from Live View.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {watchingCameras.map(c => (
              <span key={c._id} className="inline-flex items-center gap-1.5 bg-brand-500/10 text-brand-400 text-xs font-medium px-3 py-1.5 rounded-lg">
                <span className="w-1.5 h-1.5 bg-brand-500 rounded-full animate-pulse" />
                {c.name} · sensitivity {c.motionSensitivity}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Events list */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700">
          <p className="font-semibold text-slate-300">Event Log</p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-500 text-sm">Loading...</div>
        ) : events.length === 0 ? (
          <div className="text-center py-16">
            <CameraIcon size={36} className="text-slate-200 mx-auto mb-3" />
            <p className="text-slate-500 font-medium">No motion events yet</p>
            <p className="text-slate-500 text-sm mt-1">Events will appear here once AI motion detection is running</p>
          </div>
        ) : (
          <div className="divide-y divide-surface-800">
            {events.map(ev => (
              <div key={ev._id} className="flex items-center gap-4 p-4">
                <button onClick={() => setPreview(ev)} className="w-16 h-12 rounded-lg bg-surface-800 flex-shrink-0 overflow-hidden hover:opacity-80 transition-opacity">
                  {ev.snapshot ? (
                    <img src={`${STATIC_BASE}${ev.snapshot}`} alt="snapshot" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-300"><AlertTriangle size={16} /></div>
                  )}
                </button>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-slate-300">{ev.camera?.name || 'Unknown Camera'}</p>
                    {!ev.reviewed && <Badge status="pending" />}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {new Date(ev.detectedAt).toLocaleString('en-IN')} · {ev.zone || 'No zone'} · Confidence {ev.confidence}%
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setPreview(ev)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5">
                    <Eye size={14} /> View
                  </button>
                  {!ev.reviewed && (
                    <button onClick={() => markReviewed(ev._id)} className="bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/20 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5">
                      <CheckCircle size={14} /> Mark Reviewed
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Snapshot preview modal */}
      <Modal open={!!preview} onClose={() => setPreview(null)} title="Motion Event Snapshot" size="lg">
        {preview && (
          <div>
            {preview.snapshot && (
              <img src={`${STATIC_BASE}${preview.snapshot}`} alt="snapshot" className="w-full rounded-xl mb-3" />
            )}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><p className="text-slate-500 text-xs">Camera</p><p className="font-medium text-slate-300">{preview.camera?.name}</p></div>
              <div><p className="text-slate-500 text-xs">Zone</p><p className="font-medium text-slate-300">{preview.zone || '—'}</p></div>
              <div><p className="text-slate-500 text-xs">Detected At</p><p className="font-medium text-slate-300">{new Date(preview.detectedAt).toLocaleString('en-IN')}</p></div>
              <div><p className="text-slate-500 text-xs">Confidence</p><p className="font-medium text-slate-300">{preview.confidence}%</p></div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
