import React, { useEffect, useState } from 'react'
import { Plus, Search, Wifi, WifiOff, Trash2, Settings, Camera as CameraIcon, RefreshCw } from 'lucide-react'
import { PageHeader, Table, Badge, Modal, SearchBar } from '../../../components/UI'
import { cameraAPI, apiErrorMessage } from '../../../utils/api'
import toast from 'react-hot-toast'

const initialForm = {
  name: '', location: '', ip: '', port: 554, onvifPort: 80,
  username: 'admin', password: '', rtspPath: '/Streaming/Channels/101',
  brand: '', model: '',
}

export default function CameraManagement() {
  const [cameras, setCameras] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  const [showAddModal, setShowAddModal] = useState(false)
  const [form, setForm] = useState(initialForm)
  const [saving, setSaving] = useState(false)

  const [showDiscoverModal, setShowDiscoverModal] = useState(false)
  const [discovering, setDiscovering] = useState(false)
  const [discovered, setDiscovered] = useState([])
  const [connecting, setConnecting] = useState(null)
  const [discoverCreds, setDiscoverCreds] = useState({ username: 'admin', password: '' })

  const load = async () => {
    setLoading(true)
    try {
      const res = await cameraAPI.getAll()
      setCameras(res.data.data)
    } catch (e) {
      toast.error('Failed to load cameras')
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleAdd = async (e) => {
    e.preventDefault()
    if (!form.name || !form.ip) return toast.error('Name and IP are required')
    setSaving(true)
    try {
      await cameraAPI.create(form)
      toast.success('Camera added')
      setShowAddModal(false)
      setForm(initialForm)
      load()
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Failed to add camera'))
    } finally { setSaving(false) }
  }

  const handleDelete = async (cam) => {
    if (!window.confirm(`Remove camera "${cam.name}"? This stops any active stream/recording.`)) return
    try {
      await cameraAPI.delete(cam._id)
      toast.success('Camera removed')
      setCameras(c => c.filter(x => x._id !== cam._id))
    } catch { toast.error('Failed to remove camera') }
  }

  const runDiscovery = async () => {
    setDiscovering(true)
    setDiscovered([])
    try {
      const res = await cameraAPI.discover(5000)
      setDiscovered(res.data.data)
      if (res.data.data.length === 0) {
        toast('No ONVIF devices found on this network', { icon: 'ℹ️' })
      }
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Discovery failed'))
    } finally { setDiscovering(false) }
  }

  const handleConnectDevice = async (device) => {
    setConnecting(device.ip)
    try {
      const res = await cameraAPI.discoverConnect({
        ip: device.ip,
        username: discoverCreds.username,
        password: discoverCreds.password,
      })
      const details = res.data.data
      if (!details.rtspUri) {
        toast.error('Connected but could not retrieve RTSP stream URI')
        return
      }
      await cameraAPI.discoverAdd({
        name: `${details.manufacturer || 'Camera'} ${details.model || ''}`.trim() || device.ip,
        location: '',
        ip: device.ip,
        username: discoverCreds.username,
        password: discoverCreds.password,
        rtspUri: details.rtspUri,
        manufacturer: details.manufacturer,
        model: details.model,
      })
      toast.success('Camera added via ONVIF!')
      setShowDiscoverModal(false)
      setDiscovered([])
      load()
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not connect to device. Check credentials.'))
    } finally { setConnecting(null) }
  }

  const filtered = cameras.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.ip.includes(search) ||
    (c.location || '').toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <PageHeader
        title="Camera Management"
        subtitle={`${cameras.length} camera(s) configured`}
        actions={<>
          <SearchBar value={search} onChange={setSearch} placeholder="Search cameras..." />
          <button onClick={() => { setShowDiscoverModal(true); setDiscovered([]) }}
            className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all">
            <Search size={16} /> ONVIF Discover
          </button>
          <button onClick={() => setShowAddModal(true)}
            className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all">
            <Plus size={16} /> Add Camera
          </button>
        </>}
      />

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-500 text-sm">Loading cameras...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <CameraIcon size={36} className="text-slate-200 mx-auto mb-3" />
            <p className="text-slate-500 font-medium">No cameras configured yet</p>
            <p className="text-slate-500 text-sm mt-1">Add manually or run ONVIF discovery to find cameras on your network</p>
          </div>
        ) : (
          <Table
            columns={[
              { key: 'name', label: 'Camera', render: (v, row) => (
                <div>
                  <p className="font-medium text-slate-300">{v}</p>
                  <p className="text-xs text-slate-500">{row.location || 'No location set'}</p>
                </div>
              )},
              { key: 'ip', label: 'IP Address', render: (v, row) => (
                <div>
                  <p className="text-slate-400">{v}</p>
                  <p className="text-xs text-slate-500">Port {row.port} {row.addedVia === 'onvif' && '· ONVIF'}</p>
                </div>
              )},
              { key: 'manufacturer', label: 'Brand', render: (v, row) => v || row.brand || '—' },
              { key: 'status', label: 'Status', render: v => (
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-xs font-medium ${v === 'online' ? 'bg-brand-500/10 text-brand-400' : 'bg-surface-800 text-slate-500'}`}>
                  {v === 'online' ? <Wifi size={12} /> : <WifiOff size={12} />}
                  {v}
                </span>
              )},
              { key: 'streaming', label: 'Live', render: v => v
                  ? <span className="inline-flex items-center gap-1 text-xs text-red-500 font-medium"><span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />Streaming</span>
                  : <span className="text-xs text-slate-500">Idle</span>
              },
              { key: 'recording', label: 'Recording', render: v => v
                  ? <Badge status="active" />
                  : <span className="text-xs text-slate-500">Off</span>
              },
              { key: 'motionWatch', label: 'AI Motion', render: v => v
                  ? <Badge status="active" />
                  : <span className="text-xs text-slate-500">Off</span>
              },
            ]}
            data={filtered}
            actions={row => (
              <>
                <a href="/labadmin/cctv" className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium flex items-center gap-1">
                  <Settings size={12} /> View
                </a>
                <button onClick={() => handleDelete(row)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium flex items-center gap-1">
                  <Trash2 size={12} />
                </button>
              </>
            )}
          />
        )}
      </div>

      <Modal open={showAddModal} onClose={() => setShowAddModal(false)} title="Add Camera Manually" size="lg">
        <form onSubmit={handleAdd} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Camera Name*</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                placeholder="e.g. Reception Area" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Location / Zone</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                placeholder="e.g. Sample Collection Room" value={form.location} onChange={e => setForm({...form, location: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">IP Address*</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                placeholder="192.168.1.64" value={form.ip} onChange={e => setForm({...form, ip: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">RTSP Port</label>
              <input type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={form.port} onChange={e => setForm({...form, port: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Username</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={form.username} onChange={e => setForm({...form, username: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Password</label>
              <input type="password" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-medium text-slate-500 mb-1">RTSP Path</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                placeholder="/Streaming/Channels/101" value={form.rtspPath} onChange={e => setForm({...form, rtspPath: e.target.value})} />
              <p className="text-xs text-slate-500 mt-1">
                Common paths: Hikvision <code>/Streaming/Channels/101</code> · Dahua <code>/cam/realmonitor?channel=1&subtype=0</code> · Generic <code>/stream1</code>
              </p>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Brand</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                placeholder="Hikvision, Dahua, CP Plus..." value={form.brand} onChange={e => setForm({...form, brand: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Model</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                placeholder="Model number" value={form.model} onChange={e => setForm({...form, model: e.target.value})} />
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowAddModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" disabled={saving} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium disabled:opacity-60">
              {saving ? 'Adding...' : 'Add Camera'}
            </button>
          </div>
        </form>
      </Modal>

      <Modal open={showDiscoverModal} onClose={() => setShowDiscoverModal(false)} title="ONVIF Auto Discovery" size="lg">
        <div className="space-y-4">
          <p className="text-sm text-slate-500">
            Scans your local network (WS-Discovery / UDP multicast) for ONVIF-compliant IP cameras.
            Make sure cameras and this server are on the same LAN.
          </p>

          <div className="grid grid-cols-2 gap-3 bg-surface-850 rounded-xl p-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Camera Username (used to connect)</label>
              <input className="w-full bg-surface-900 border border-surface-700 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={discoverCreds.username} onChange={e => setDiscoverCreds({...discoverCreds, username: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Camera Password</label>
              <input type="password" className="w-full bg-surface-900 border border-surface-700 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={discoverCreds.password} onChange={e => setDiscoverCreds({...discoverCreds, password: e.target.value})} />
            </div>
          </div>

          <button onClick={runDiscovery} disabled={discovering}
            className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2.5 rounded-xl text-sm font-medium flex items-center gap-2 disabled:opacity-60">
            {discovering ? <RefreshCw size={16} className="animate-spin" /> : <Search size={16} />}
            {discovering ? 'Scanning network (5s)...' : 'Start Scan'}
          </button>

          {discovered.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Found {discovered.length} device(s)</p>
              {discovered.map((d, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-surface-850 rounded-xl">
                  <div className="w-9 h-9 bg-brand-500/15 text-brand-400 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CameraIcon size={16} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-300">{d.ip}</p>
                    <p className="text-xs text-slate-500 truncate">{d.xaddr || 'ONVIF device'}</p>
                  </div>
                  <button onClick={() => handleConnectDevice(d)} disabled={connecting === d.ip}
                    className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-3 py-1.5 rounded-xl text-xs font-medium disabled:opacity-60">
                    {connecting === d.ip ? 'Connecting...' : 'Connect & Add'}
                  </button>
                </div>
              ))}
            </div>
          )}

          {!discovering && discovered.length === 0 && (
            <div className="text-center py-6 text-slate-500 text-sm">
              No devices found yet. Click "Start Scan" to begin.
              <p className="text-xs mt-2 text-slate-300">
                Note: discovery requires UDP multicast access — if running in Docker, use <code>--network host</code>.
              </p>
            </div>
          )}
        </div>
      </Modal>
    </div>
  )
}
