import React, { useEffect, useState } from 'react'
import { Save, Camera as CameraIcon } from 'lucide-react'
import { PageHeader } from '../../../components/UI'
import { cameraAPI, apiErrorMessage } from '../../../utils/api'
import toast from 'react-hot-toast'

export default function CctvSettings() {
  const [cameras, setCameras] = useState([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(null)

  const load = async () => {
    try {
      const res = await cameraAPI.getAll()
      setCameras(res.data.data)
    } catch { toast.error('Failed to load cameras') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const updateField = (id, field, value) => {
    setCameras(cs => cs.map(c => c._id === id ? { ...c, [field]: value } : c))
  }

  const save = async (cam) => {
    setSaving(cam._id)
    try {
      await cameraAPI.update(cam._id, {
        name: cam.name,
        location: cam.location,
        motionSensitivity: Number(cam.motionSensitivity),
        recordingEnabled: cam.recordingEnabled,
        motionDetectionEnabled: cam.motionDetectionEnabled,
      })
      toast.success(`Saved settings for ${cam.name}`)
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Failed to save'))
    } finally { setSaving(null) }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  return (
    <div>
      <PageHeader title="CCTV Settings" subtitle="Configure motion sensitivity and recording per camera" />

      {cameras.length === 0 ? (
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-16 text-center">
          <CameraIcon size={36} className="text-slate-200 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No cameras configured</p>
        </div>
      ) : (
        <div className="space-y-4">
          {cameras.map(cam => (
            <div key={cam._id} className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Camera Name</label>
                  <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                    value={cam.name} onChange={e => updateField(cam._id, 'name', e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Location / Zone</label>
                  <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                    value={cam.location || ''} onChange={e => updateField(cam._id, 'location', e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    AI Motion Sensitivity: {cam.motionSensitivity}
                    <span className="text-slate-500 ml-1">(lower = more sensitive)</span>
                  </label>
                  <input type="range" min="5" max="80" value={cam.motionSensitivity}
                    onChange={e => updateField(cam._id, 'motionSensitivity', e.target.value)}
                    className="w-full accent-brand-500 mt-2.5" />
                </div>
                <div className="flex items-end gap-2">
                  <button onClick={() => save(cam)} disabled={saving === cam._id}
                    className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2.5 rounded-xl text-sm font-medium flex items-center gap-2 disabled:opacity-60 w-full justify-center">
                    <Save size={14} /> {saving === cam._id ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-6 mt-4 pt-4 border-t border-surface-700">
                <label className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer">
                  <input type="checkbox" checked={cam.motionDetectionEnabled}
                    onChange={e => updateField(cam._id, 'motionDetectionEnabled', e.target.checked)}
                    className="rounded accent-brand-500" />
                  AI Motion Detection Enabled
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer">
                  <input type="checkbox" checked={cam.recordingEnabled}
                    onChange={e => updateField(cam._id, 'recordingEnabled', e.target.checked)}
                    className="rounded accent-brand-500" />
                  Continuous Recording Enabled
                </label>
                <div className="text-xs text-slate-500 ml-auto">
                  RTSP: <code className="bg-surface-850 px-1.5 py-0.5 rounded">{cam.ip}:{cam.port}{cam.rtspPath}</code>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
