import React, { useEffect, useState } from 'react'
import { PlayCircle, Download, FileVideo, HardDrive, Camera as CameraIcon } from 'lucide-react'
import { PageHeader, Modal } from '../../../components/UI'
import { cameraAPI, STATIC_BASE } from '../../../utils/api'
import toast from 'react-hot-toast'

const formatBytes = (bytes) => {
  if (!bytes) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB']
  let i = 0; let val = bytes
  while (val >= 1024 && i < units.length - 1) { val /= 1024; i++ }
  return `${val.toFixed(1)} ${units[i]}`
}

export default function Recordings() {
  const [cameras, setCameras] = useState([])
  const [selected, setSelected] = useState(null)
  const [recordings, setRecordings] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadingRecs, setLoadingRecs] = useState(false)
  const [playUrl, setPlayUrl] = useState(null)

  useEffect(() => {
    cameraAPI.getAll().then(res => {
      setCameras(res.data.data)
      if (res.data.data.length > 0) setSelected(res.data.data[0]._id)
    }).catch(() => toast.error('Failed to load cameras'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (!selected) return
    setLoadingRecs(true)
    cameraAPI.getRecordings(selected).then(res => setRecordings(res.data.data))
      .catch(() => toast.error('Failed to load recordings'))
      .finally(() => setLoadingRecs(false))
  }, [selected])

  const currentCamera = cameras.find(c => c._id === selected)

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  return (
    <div>
      <PageHeader title="Recording & Playback" subtitle="Browse recorded clips per camera" />

      {cameras.length === 0 ? (
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-16 text-center">
          <CameraIcon size={36} className="text-slate-200 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No cameras configured</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-3">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide px-2 mb-2">Cameras</p>
            <div className="space-y-1">
              {cameras.map(cam => (
                <button key={cam._id} onClick={() => setSelected(cam._id)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-sm transition-colors ${selected === cam._id ? 'bg-brand-500/10 text-brand-400 font-medium' : 'text-slate-400 hover:bg-surface-850'}`}>
                  <div className="flex items-center justify-between">
                    <span className="truncate">{cam.name}</span>
                    {cam.recording && <span className="w-2 h-2 bg-red-500 rounded-full flex-shrink-0" />}
                  </div>
                  <p className="text-xs text-slate-500 truncate">{cam.location || cam.ip}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3 bg-surface-900 rounded-2xl border border-surface-700">
            <div className="p-4 border-b border-surface-700 flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-300">{currentCamera?.name}</p>
                <p className="text-xs text-slate-500">{recordings.length} recording(s)</p>
              </div>
              {currentCamera?.recording && (
                <span className="inline-flex items-center gap-1.5 bg-red-500/10 text-red-400 text-xs font-medium px-2.5 py-1 rounded-lg">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" /> Recording now
                </span>
              )}
            </div>

            {loadingRecs ? (
              <div className="text-center py-12 text-slate-500 text-sm">Loading recordings...</div>
            ) : recordings.length === 0 ? (
              <div className="text-center py-16">
                <FileVideo size={36} className="text-slate-200 mx-auto mb-3" />
                <p className="text-slate-500 font-medium">No recordings yet</p>
                <p className="text-slate-500 text-sm mt-1">Start recording from Live View to see clips here</p>
              </div>
            ) : (
              <div className="divide-y divide-surface-800">
                {recordings.map((rec, i) => (
                  <div key={i} className="flex items-center gap-4 p-4">
                    <div className="w-10 h-10 bg-brand-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <FileVideo size={18} className="text-brand-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-300 truncate">{rec.filename}</p>
                      <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5">
                        <span>{new Date(rec.createdAt).toLocaleString('en-IN')}</span>
                        <span className="flex items-center gap-1"><HardDrive size={11} />{formatBytes(rec.size)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setPlayUrl(`${STATIC_BASE}${rec.url}`)}
                        className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5">
                        <PlayCircle size={14} /> Play
                      </button>
                      <a href={`${STATIC_BASE}${rec.url}`} download
                        className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5">
                        <Download size={14} />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <Modal open={!!playUrl} onClose={() => setPlayUrl(null)} title="Playback" size="xl">
        {playUrl && (
          <video src={playUrl} controls autoPlay className="w-full rounded-xl bg-black" style={{ maxHeight: '70vh' }} />
        )}
      </Modal>
    </div>
  )
}
