import React, { useState, useEffect } from 'react'
import { PageHeader, Badge, Modal } from '../../components/UI'
import { Gift, Copy, Check, Share2, Link2, Users, TrendingUp, Bot, ExternalLink } from 'lucide-react'
import toast from 'react-hot-toast'

export default function ReferralPage() {
  const [myCode, setMyCode] = useState(null)
  const [referralData, setReferralData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const [showGenerateModal, setShowGenerateModal] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const { referralAPI } = await import('../../utils/api')
      const [codeRes, refRes] = await Promise.all([
        referralAPI.getMyCode().catch(() => null),
        referralAPI.getMy().catch(() => null),
      ])
      if (codeRes?.data?.data) setMyCode(codeRes.data.data)
      if (refRes?.data?.data) setReferralData(refRes.data.data)
    } catch {
      setMyCode({
        referralCode: 'CG-ABC1',
        name: 'City Diagnostics',
        labName: 'City Diagnostics',
        referralLink: 'https://mediflowproai.com/signup?ref=CG-ABC1',
        stats: { total: 1, converted: 0, commissionApplied: 0, totalCommission: 0 },
      })
      setReferralData({
        referrals: [
          { _id: 'R1', referralCode: 'CG-ABC1', referredLabName: 'New Health Lab', status: 'pending', discountPercent: 50, discountApplied: false, createdAt: '2026-06-15', referredLab: null },
        ],
        stats: { total: 1, converted: 0, commissionApplied: 0, totalCommission: 0 },
      })
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleGenerateCode = async () => {
    try {
      const { referralAPI } = await import('../../utils/api')
      const res = await referralAPI.generateCode()
      setMyCode(prev => ({ ...prev, ...res.data.data }))
      toast.success('Referral code generated!')
      setShowGenerateModal(false)
      load()
    } catch {
      toast.success('Referral code generated! (demo)')
      setShowGenerateModal(false)
    }
  }

  const handleCopy = (text) => {
    if (!text) return
    navigator.clipboard.writeText(text)
    toast.success('Copied!')
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShareWhatsApp = () => {
    const msg = `🏥 *MediFlow Pro AI - Diagnostic Lab Platform*\n\n🤝 Refer another lab to MediFlow and get 50% OFF your next subscription!\n\n🔗 Signup Link: ${myCode?.referralLink || ''}\n📌 Referral Code: ${myCode?.referralCode || ''}\n\nWhen the lab you refer subscribes, you get 50% discount on your next renewal!`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
  }

  const stats = referralData?.stats || myCode?.stats || { total: 0, converted: 0, commissionApplied: 0, totalCommission: 0 }
  const referrals = referralData?.referrals || []

  return (
    <div>
      <PageHeader
        title="Referral Program"
        subtitle="Refer other labs & earn 50% off your subscription renewal"
        actions={
          <button onClick={handleShareWhatsApp} className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2">
            <Share2 size={16} /> Share on WhatsApp
          </button>
        }
      />

      {/* Referral Code Card */}
      <div className="bg-surface-900 rounded-2xl border border-brand-500/20 p-6 mb-6 bg-gradient-to-br from-brand-500/5 via-transparent to-purple-500/5">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Gift size={18} className="text-brand-400" />
              <p className="text-sm font-semibold text-slate-300">Your Referral Code</p>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Share this code with other labs. When they subscribe, you get <span className="text-brand-400 font-semibold">50% OFF</span> your lab's next renewal!
            </p>
            {myCode?.referralCode ? (
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 bg-surface-850 rounded-xl border border-brand-500/30 px-5 py-3">
                  <span className="text-2xl font-bold font-mono tracking-wider text-brand-400">{myCode.referralCode}</span>
                  <button onClick={() => handleCopy(myCode.referralCode)} className="p-2 rounded-lg hover:bg-surface-700 text-slate-400 transition-all" title="Copy code">
                    {copied ? <Check size={16} className="text-brand-400" /> : <Copy size={16} />}
                  </button>
                </div>
                {myCode.referralLink && (
                  <button onClick={() => handleCopy(myCode.referralLink)} className="flex items-center gap-1.5 bg-surface-800 hover:bg-surface-700 border border-surface-700 px-4 py-3 rounded-xl text-xs text-slate-400 transition-all">
                    <Link2 size={14} />
                    <span className="max-w-[200px] truncate">{myCode.referralLink}</span>
                    <Copy size={12} />
                  </button>
                )}
              </div>
            ) : (
              <button onClick={() => setShowGenerateModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-5 py-2.5 rounded-xl text-sm transition-all">
                Generate Referral Code ✨
              </button>
            )}
          </div>
          <div className="hidden lg:flex flex-col items-center px-6 py-3 bg-surface-850 rounded-xl border border-surface-700">
            <p className="text-xs text-slate-500">Commission</p>
            <p className="text-2xl font-bold text-brand-400">50%</p>
            <p className="text-xs text-slate-500">OFF subscription</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-slate-100">{stats.total || 0}</p>
          <p className="text-sm text-slate-500 mt-1">Total Referred</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-brand-400">{stats.converted || 0}</p>
          <p className="text-sm text-slate-500 mt-1">Converted</p>
          <p className="text-xs text-green-400 mt-0.5">Subscribed ✓</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-blue-400">₹{stats.totalCommission?.toLocaleString() || 0}</p>
          <p className="text-sm text-slate-500 mt-1">Commission Value</p>
          <p className="text-xs text-slate-600 mt-0.5">At 50% off rate</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-purple-400">{stats.commissionApplied || 0}</p>
          <p className="text-sm text-slate-500 mt-1">Discounts Given</p>
          <p className="text-xs text-green-400 mt-0.5">Already used ✓</p>
        </div>
      </div>

      {/* How it works */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-6">
        <p className="font-semibold text-slate-300 mb-4 flex items-center gap-2"><Bot size={16} className="text-brand-400" /> How It Works</p>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { step: '1', title: 'Generate Code', desc: 'Get your unique referral code above. Share it with other lab owners or doctors.' },
            { step: '2', title: 'Refer a Lab', desc: 'When a new lab signs up using your code, they mention it during registration.' },
            { step: '3', title: 'Get 50% OFF', desc: 'Once the referred lab subscribes, you get 50% off your lab\'s next renewal!' },
          ].map(s => (
            <div key={s.step} className="flex items-start gap-3 p-4 bg-surface-850 rounded-xl">
              <div className="w-8 h-8 rounded-full bg-brand-500/15 text-brand-400 flex items-center justify-center text-sm font-bold flex-shrink-0">{s.step}</div>
              <div>
                <p className="text-sm font-semibold text-slate-300">{s.title}</p>
                <p className="text-xs text-slate-500 mt-0.5">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Referred Labs Table */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700 flex items-center justify-between">
          <div>
            <p className="font-semibold text-slate-300 text-sm">Referred Labs</p>
            <p className="text-xs text-slate-500 mt-0.5">Labs that signed up using your referral code</p>
          </div>
        </div>
        {loading ? (
          <div className="text-center py-8 text-slate-500 text-sm">Loading...</div>
        ) : referrals.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <Users size={32} className="mx-auto mb-2 text-slate-600" />
            <p className="text-sm">No referrals yet</p>
            <p className="text-xs mt-1">Share your referral code to start earning discounts</p>
          </div>
        ) : (
          <div className="divide-y divide-surface-800">
            {referrals.map(ref => (
              <div key={ref._id} className="flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors">
                <div className="w-10 h-10 rounded-full bg-brand-500/15 text-brand-400 flex items-center justify-center flex-shrink-0">
                  <Gift size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-slate-300 truncate">{ref.referredLabName || 'Pending lab'}</p>
                  <p className="text-xs text-slate-500">Code: {ref.referralCode} · {ref.createdAt ? new Date(ref.createdAt).toLocaleDateString('en-IN') : ''}</p>
                </div>
                <Badge status={ref.status === 'commission_applied' ? 'active' : ref.status === 'converted' ? 'completed' : ref.status} />
                <div className="text-xs text-slate-400">
                  {ref.status === 'converted' && !ref.discountApplied && '🔄 Ready for discount'}
                  {ref.discountApplied && '✅ Discount applied'}
                  {ref.status === 'pending' && '⏳ Awaiting subscription'}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Generate Code Modal */}
      <Modal open={showGenerateModal} onClose={() => setShowGenerateModal(false)} title="Generate Referral Code">
        <div className="space-y-4">
          <div className="bg-surface-850 rounded-xl p-4 text-center">
            <p className="text-sm text-slate-400">Click below to generate your unique referral code.</p>
            <p className="text-xs text-slate-500 mt-2">Share this code with other labs and doctors to invite them to MediFlow and earn rewards.</p>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button onClick={() => setShowGenerateModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button onClick={handleGenerateCode} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Generate Code</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
