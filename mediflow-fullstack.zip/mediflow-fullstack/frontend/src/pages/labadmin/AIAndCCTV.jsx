import React, { useState, useRef, useEffect } from 'react'
import { PageHeader } from '../../components/UI'
import { Send, Mic, Bot, User, Video, Wifi, WifiOff } from 'lucide-react'

const quickCommands = [
  'Aaj kitni billing hui?',
  'Pending reports dikhao',
  'Low stock items batao',
  'Aaj ke patients kitne hain?',
  'Top referring doctor kaun hai?',
]

const aiResponses = {
  'Aaj kitni billing hui?': 'Aaj June 13, 2026 ki total billing ₹18,400 hai. 24 patients aaye, jisme se 6 ka payment pending hai (₹4,200). Home collection se ₹2,400 extra mila.',
  'Pending reports dikhao': '4 reports abhi pending hain:\n1. Rahul Sharma – CBC (Processing)\n2. Priya Verma – Thyroid Profile (Pending)\n3. Anil Kumar – Lipid Profile (Verification)\n4. Neha Singh – LFT (Pending)',
  'Low stock items batao': '2 items low stock par hain:\n⚠️ CBC Reagent Kit – 8 kits bache hain (min: 5)\n🚨 Glucose Reagent – sirf 3 bottles hain (min: 5) — URGENT reorder karein!',
  'Aaj ke patients kitne hain?': 'Aaj 24 patients aaye. 18 walk-in, 3 home collection, 3 appointment ke through. Kal se 6% zyada hai.',
  'Top referring doctor kaun hai?': 'Is mahine ke top referring doctors:\n1. Dr. Rajesh Mehta – 45 referrals (₹54,000 revenue)\n2. Dr. Anita Gupta – 32 referrals (₹28,000 revenue)\n3. Dr. Suresh Nair – 28 referrals (₹22,400 revenue)',
}

export function AIAssistant() {
  const [messages, setMessages] = useState([
    { from: 'ai', text: 'Namaste! Main MediFlow AI Assistant hoon 🤖\nAap mujhse kuch bhi puch sakte hain — billing, reports, inventory, patients... Hindi ya English mein.' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef()

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const send = (text) => {
    const msg = text || input.trim()
    if (!msg) return
    setInput('')
    setMessages(m => [...m, { from: 'user', text: msg }])
    setLoading(true)
    setTimeout(() => {
      const reply = aiResponses[msg] || `Main "${msg}" ko process kar raha hoon... Is demo mein quick commands try karein!`
      setMessages(m => [...m, { from: 'ai', text: reply }])
      setLoading(false)
    }, 900)
  }

  return (
    <div>
      <PageHeader title="AI Assistant" subtitle="Voice & text commands for your lab" />
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Quick Commands</p>
          <div className="space-y-2">
            {quickCommands.map(cmd => (
              <button key={cmd} onClick={() => send(cmd)}
                className="w-full text-left text-xs bg-surface-850 hover:bg-brand-500/10 hover:text-brand-300 text-slate-400 px-3 py-2.5 rounded-xl transition-colors leading-relaxed">
                "{cmd}"
              </button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-3 card flex flex-col" style={{ height: 480 }}>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-3 ${m.from === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${m.from === 'ai' ? 'bg-brand-500/15 text-brand-400' : 'bg-surface-700 text-slate-400'}`}>
                  {m.from === 'ai' ? <Bot size={16} /> : <User size={16} />}
                </div>
                <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl text-sm whitespace-pre-line leading-relaxed ${
                  m.from === 'ai'
                    ? 'bg-surface-850 text-slate-300'
                    : 'bg-brand-500 text-surface-950'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-brand-500/15 text-brand-400 flex items-center justify-center"><Bot size={16} /></div>
                <div className="bg-surface-850 px-4 py-3 rounded-2xl flex gap-1 items-center">
                  <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
          <div className="border-t border-surface-700 p-3 flex gap-2">
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()}
              placeholder="Type a command or question..."
              className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all flex-1"
            />
            <button onClick={() => send()} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all px-3">
              <Send size={16} />
            </button>
            <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all px-3" title="Voice input">
              <Mic size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export function CCTV() {
  const cameras = [
    { id: 'CAM1', name: 'Reception Area', status: 'online' },
    { id: 'CAM2', name: 'Sample Collection', status: 'online' },
    { id: 'CAM3', name: 'Lab Area', status: 'online' },
    { id: 'CAM4', name: 'Waiting Area', status: 'offline' },
  ]
  return (
    <div>
      <PageHeader title="CCTV Monitoring" subtitle="Live camera feeds and event logs" />
      <div className="grid grid-cols-2 gap-4 mb-4">
        {cameras.map(cam => (
          <div key={cam.id} className="bg-surface-900 rounded-2xl border border-surface-700 overflow-hidden">
            <div className="bg-surface-950 aspect-video flex items-center justify-center relative">
              <div className="text-center">
                <Video size={40} className="text-slate-400 mx-auto mb-2" />
                <p className="text-slate-500 text-sm">{cam.status === 'online' ? 'Live Feed' : 'Camera Offline'}</p>
              </div>
              <div className={`absolute top-3 right-3 flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${cam.status === 'online' ? 'bg-brand-500/20 text-brand-400' : 'bg-red-500/20 text-red-400'}`}>
                {cam.status === 'online' ? <Wifi size={12} /> : <WifiOff size={12} />}
                {cam.status}
              </div>
              {cam.status === 'online' && (
                <div className="absolute top-3 left-3 flex items-center gap-1 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 bg-surface-900 rounded-full animate-pulse" />LIVE
                </div>
              )}
            </div>
            <div className="p-3 flex items-center justify-between">
              <p className="font-medium text-sm text-slate-300">{cam.name}</p>
              <p className="text-xs text-slate-500">{cam.id}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <p className="font-semibold text-slate-300 mb-3">Event Log</p>
        <div className="space-y-2">
          {[
            { time: '10:42 AM', cam: 'Reception Area', event: 'Motion detected', type: 'info' },
            { time: '10:15 AM', cam: 'Sample Collection', event: 'Motion detected', type: 'info' },
            { time: '09:30 AM', cam: 'Waiting Area', event: 'Camera went offline', type: 'error' },
            { time: '08:00 AM', cam: 'All Cameras', event: 'System started', type: 'success' },
          ].map((e, i) => (
            <div key={i} className="flex items-center gap-3 py-2 border-b border-surface-700 last:border-0 text-sm">
              <span className={`w-2 h-2 rounded-full flex-shrink-0 ${e.type === 'error' ? 'bg-red-500' : e.type === 'success' ? 'bg-brand-500' : 'bg-blue-500'}`} />
              <span className="text-slate-500 w-20 flex-shrink-0">{e.time}</span>
              <span className="text-slate-500 w-32 flex-shrink-0">{e.cam}</span>
              <span className="text-slate-400">{e.event}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
