import React, { useEffect, useState } from 'react'
import { Radar, AlertTriangle, TrendingUp, MapPin, Activity, ShieldAlert, Globe2, CheckCircle2, RefreshCw } from 'lucide-react'
import { PageHeader, Badge } from '../../../components/UI'
import { outbreakAPI, apiErrorMessage } from '../../../utils/api'
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from 'recharts'
import toast from 'react-hot-toast'

const DISEASE_COLORS = {
  Dengue:          '#ef4444',
  Malaria:         '#f59e0b',
  Typhoid:         '#3DDC84',
  Chikungunya:     '#a855f7',
  'COVID-19':      '#60a5fa',
  Influenza:       '#fb923c',
  Leptospirosis:   '#22d3ee',
  'Hepatitis A':   '#facc15',
  Gastroenteritis: '#f472b6',
}

const SEVERITY_STYLES = {
  critical: { badge: 'bg-red-500/10 text-red-400 border border-red-500/20', icon: 'text-red-400', bar: 'bg-red-500' },
  warning:  { badge: 'bg-amber-500/10 text-amber-400 border border-amber-500/20', icon: 'text-amber-400', bar: 'bg-amber-500' },
  watch:    { badge: 'bg-blue-500/10 text-blue-400 border border-blue-500/20', icon: 'text-blue-400', bar: 'bg-blue-500' },
}

export default function OutbreakRadar() {
  const [trendData, setTrendData] = useState({ city: null, trend: [], diseases: [], trackedDiseases: [] })
  const [alerts, setAlerts] = useState({ city: null, localAlerts: [], networkAlerts: [] })
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const load = async () => {
    try {
      const [t, a] = await Promise.all([outbreakAPI.getTrends(30), outbreakAPI.getAlerts()])
      setTrendData(t.data.data)
      setAlerts(a.data.data)
    } catch (e) {
      toast.error(apiErrorMessage(e, 'Failed to load outbreak data'))
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleRefresh = async () => {
    setRefreshing(true)
    try {
      await outbreakAPI.triggerDetection()
      await load()
      toast.success('Detection refreshed')
    } catch (e) {
      toast.error(apiErrorMessage(e, 'Detection failed'))
    } finally { setRefreshing(false) }
  }

  const handleResolve = async (id) => {
    try {
      await outbreakAPI.resolveAlert(id)
      setAlerts(a => ({ ...a, localAlerts: a.localAlerts.filter(x => x._id !== id) }))
      toast.success('Alert dismissed')
    } catch (e) { toast.error(apiErrorMessage(e, 'Failed to dismiss')) }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  const diseasesInTrend = trendData.diseases.length > 0 ? trendData.diseases : trendData.trackedDiseases.slice(0, 4)

  return (
    <div>
      <PageHeader
        title="Outbreak Radar"
        subtitle={trendData.city
          ? <span className="flex items-center gap-1.5"><MapPin size={13} className="text-brand-400" />{trendData.city} · anonymized, network-wide disease intelligence</span>
          : 'Set your lab city in Settings to enable local outbreak tracking'}
        actions={
          <button onClick={handleRefresh} disabled={refreshing}
            className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 disabled:opacity-60">
            <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} /> Refresh Detection
          </button>
        }
      />

      {/* How it works banner */}
      <div className="bg-gradient-to-r from-brand-500/10 to-transparent border border-brand-500/20 rounded-2xl p-4 mb-4 flex items-start gap-3">
        <Globe2 size={20} className="text-brand-400 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-slate-300 leading-relaxed">
          <span className="font-semibold text-brand-400">Network Effect:</span> every lab on MediFlow anonymously
          contributes daily counts of disease-indicating tests (Dengue, Malaria, Typhoid, etc.) by city.
          The system compares your city's current week against its own 5-week baseline — if a disease
          spikes <span className="text-brand-400 font-medium">50%+</span>, an alert appears here automatically,
          often days before clinical reports catch the trend.
        </p>
      </div>

      {/* Local alerts */}
      {alerts.localAlerts.length > 0 ? (
        <div className="space-y-3 mb-4">
          {alerts.localAlerts.map(a => {
            const style = SEVERITY_STYLES[a.severity]
            return (
              <div key={a._id} className="bg-surface-900 border border-surface-700 rounded-2xl p-5 relative overflow-hidden">
                <div className={`absolute left-0 top-0 bottom-0 w-1 ${style.bar}`} />
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${style.badge}`}>
                      <AlertTriangle size={18} className={style.icon} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-display font-semibold text-slate-100">{a.disease} — {a.city}</p>
                        <span className={`px-2 py-0.5 rounded-lg text-xs font-medium uppercase ${style.badge}`}>{a.severity}</span>
                      </div>
                      <p className="text-sm text-slate-400 leading-relaxed">{a.message}</p>
                      <p className="text-sm text-brand-300 mt-2 flex items-start gap-1.5">
                        <ShieldAlert size={14} className="mt-0.5 flex-shrink-0" />
                        {a.recommendation}
                      </p>
                      <p className="text-xs text-slate-500 mt-2">
                        {a.currentCount} tests this week · {a.labCount} lab(s) reporting · baseline ~{Math.round(a.baselineAvg)}/week
                      </p>
                    </div>
                  </div>
                  <button onClick={() => handleResolve(a._id)}
                    className="bg-surface-800 hover:bg-surface-700 text-slate-400 border border-surface-700 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 flex-shrink-0">
                    <CheckCircle2 size={13} /> Dismiss
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className="bg-surface-900 border border-surface-700 rounded-2xl p-5 mb-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center flex-shrink-0">
            <CheckCircle2 size={18} className="text-brand-400" />
          </div>
          <div>
            <p className="font-medium text-slate-200">No active alerts for {trendData.city || 'your city'}</p>
            <p className="text-xs text-slate-500 mt-0.5">Disease-test volumes are within normal range vs the 5-week baseline.</p>
          </div>
        </div>
      )}

      {/* Trend chart */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-4">
        <div className="flex items-center justify-between mb-4">
          <p className="font-display font-semibold text-slate-200 flex items-center gap-2">
            <Activity size={15} className="text-brand-400" /> 30-Day Disease-Test Trend — {trendData.city || '—'}
          </p>
        </div>
        {trendData.trend.length > 0 ? (
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={trendData.trend}>
              <CartesianGrid stroke="#1b2622" strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#5c6f67' }} axisLine={false} tickLine={false}
                tickFormatter={d => d?.slice(5)} />
              <YAxis tick={{ fontSize: 12, fill: '#5c6f67' }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ background: '#111815', border: '1px solid #1b2622', borderRadius: 12, fontSize: 12 }} labelStyle={{ color: '#94a3b8' }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              {diseasesInTrend.map(d => (
                <Line key={d} type="monotone" dataKey={d} stroke={DISEASE_COLORS[d] || '#3DDC84'} strokeWidth={2} dot={false} connectNulls />
              ))}
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="text-center py-16 text-slate-500 text-sm">
            <Radar size={32} className="mx-auto mb-3 text-surface-600" />
            No disease-test signals recorded yet for {trendData.city || 'your city'}.<br />
            <span className="text-xs">Signals are recorded automatically when bills include tests like Dengue NS1, Malaria MP Smear, Typhoid Widal, etc.</span>
          </div>
        )}
      </div>

      {/* Network alerts from other cities */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <div className="flex items-center justify-between mb-4">
          <p className="font-display font-semibold text-slate-200 flex items-center gap-2">
            <Globe2 size={15} className="text-brand-400" /> Regional Network Alerts
          </p>
          <span className="text-xs text-slate-500">From other cities on the MediFlow network</span>
        </div>
        {alerts.networkAlerts.length > 0 ? (
          <div className="space-y-2">
            {alerts.networkAlerts.map(a => {
              const style = SEVERITY_STYLES[a.severity]
              return (
                <div key={a._id} className="flex items-center gap-3 p-3 bg-surface-850 rounded-xl border border-surface-700">
                  <span className={`w-2 h-2 rounded-full flex-shrink-0 ${style.bar}`} />
                  <div className="flex-1">
                    <p className="text-sm text-slate-300">
                      <span className="font-medium text-slate-100">{a.disease}</span> trending up in <span className="font-medium text-slate-100">{a.city}</span>
                    </p>
                    <p className="text-xs text-slate-500">+{a.percentChange}% vs baseline · {a.labCount} lab(s) reporting</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded-lg text-xs font-medium uppercase ${style.badge}`}>{a.severity}</span>
                </div>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-slate-500 text-sm">No active alerts elsewhere on the network right now.</div>
        )}
      </div>
    </div>
  )
}
