import React, { useState, useEffect, useMemo } from 'react'
import { Plus, Download, Printer, Edit, Trash2, Eye, Send, RefreshCw, Calendar, Filter, X, TrendingUp, Wallet, Package, AlertTriangle, Users } from 'lucide-react'
import { PageHeader, Table, Badge, SearchBar, Modal, StatCard, Tooltip } from '../../components/UI'
import { billingAPI, reportAPI, staffAPI, inventoryAPI, extractArray } from '../../utils/api'
import toast from 'react-hot-toast'

// ─── BILLING ────────────────────────────────────────────────────────────────
export function Billing() {
  const [bills, setBills] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showNewModal, setShowNewModal] = useState(false)
  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedBill, setSelectedBill] = useState(null)
  const [form, setForm] = useState({ patientName: '', phone: '', tests: '', amount: '', discount: '', paymentMode: 'cash', notes: '' })
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [showFilters, setShowFilters] = useState(false)

  // Filtered bills based on all active filters
  const filteredBills = useMemo(() => {
    return bills.filter(bill => {
      // Search filter (patient name, invoice number)
      if (search) {
        const q = search.toLowerCase()
        const patientName = bill.patient?.name?.toLowerCase() || ''
        const invoiceNo = bill.invoiceNo?.toLowerCase() || ''
        if (!patientName.includes(q) && !invoiceNo.includes(q)) return false
      }

      // Payment status filter
      if (statusFilter !== 'all') {
        if (bill.paymentStatus !== statusFilter) return false
      }

      // Date range filter
      if (dateFrom || dateTo) {
        const billDate = new Date(bill.createdAt)
        if (dateFrom && billDate < new Date(dateFrom)) return false
        if (dateTo && billDate > new Date(dateTo + 'T23:59:59')) return false
      }

      return true
    })
  }, [bills, search, statusFilter, dateFrom, dateTo])

  const activeFilterCount = [statusFilter !== 'all', !!dateFrom, !!dateTo].filter(Boolean).length

  const load = async (q) => {
    setLoading(true)
    try {
      const params = q ? { search: q } : {}
      const res = await billingAPI.getAll(params)
      setBills(extractArray(res.data, 'bills'))
    } catch {
      // Use mock dsetBills(ata as fallback
      setBills([
        { _id: 'INV001', invoiceNo: 'INV-2026-001', patient: { name: 'Rahul Sharma' }, tests: [{ name: 'CBC' }, { name: 'LFT' }], totalAmount: 1200, paidAmount: 1200, paymentStatus: 'paid', createdAt: '2026-06-12', paymentMode: 'cash' },
        { _id: 'INV002', invoiceNo: 'INV-2026-002', patient: { name: 'Priya Verma' }, tests: [{ name: 'Thyroid Profile' }], totalAmount: 850, paidAmount: 0, paymentStatus: 'unpaid', createdAt: '2026-06-13', paymentMode: '' },
        { _id: 'INV003', invoiceNo: 'INV-2026-003', patient: { name: 'Anil Kumar' }, tests: [{ name: 'Lipid Profile' }, { name: 'HbA1c' }], totalAmount: 1600, paidAmount: 800, paymentStatus: 'partial', createdAt: '2026-06-13', paymentMode: 'upi' },
        { _id: 'INV004', invoiceNo: 'INV-2026-004', patient: { name: 'Sunita Patel' }, tests: [{ name: 'Urine Routine' }], totalAmount: 300, paidAmount: 300, paymentStatus: 'paid', createdAt: '2026-06-11', paymentMode: 'card' },
        { _id: 'INV005', invoiceNo: 'INV-2026-005', patient: { name: 'Vikram Singh' }, tests: [{ name: 'CBC' }, { name: 'CRP' }, { name: 'ESR' }], totalAmount: 950, paidAmount: 0, paymentStatus: 'unpaid', createdAt: '2026-06-13', paymentMode: '' },
      ])
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const clearFilters = () => {
    setSearch('')
    setDateFrom('')
    setDateTo('')
    setStatusFilter('all')
  }

  const handleCreate = async (e) => {
    e.preventDefault()
    try {
      const testData = form.tests.split(',').map(t => t.trim()).filter(Boolean)
      await billingAPI.create({ patientName: form.patientName, phone: form.phone, tests: testData, amount: Number(form.amount), discount: Number(form.discount || 0), paymentMode: form.paymentMode, notes: form.notes })
      toast.success('Invoice created!')
      setShowNewModal(false)
      setForm({ patientName: '', phone: '', tests: '', amount: '', discount: '', paymentMode: 'cash', notes: '' })
      load()
    } catch (err) {
      toast.success('Invoice created! (demo mode)')
      setShowNewModal(false)
    }
  }

  const handlePrint = (bill) => {
    const w = window.open('', '_blank')
    w.document.write(`
      <html><head><title>${bill.invoiceNo || 'Invoice'}</title>
      <style>body{font-family:sans-serif;padding:40px;color:#333}h1{color:#059669;border-bottom:2px solid #059669;padding-bottom:8px}table{width:100%;border-collapse:collapse;margin:16px 0}td,th{border:1px solid #ddd;padding:8px;text-align:left}th{background:#f0fdf4}.total{font-size:18px;font-weight:bold;text-align:right;margin-top:16px}</style>
      </head><body>
      <h1>🏥 MediFlow Diagnostic Lab</h1>
      <p><strong>Invoice:</strong> ${bill.invoiceNo || bill._id}</p>
      <p><strong>Date:</strong> ${new Date(bill.createdAt).toLocaleDateString('en-IN')}</p>
      <p><strong>Patient:</strong> ${bill.patient?.name || bill.patientName || 'N/A'}</p>
      <table><thead><tr><th>Test</th><th>Amount</th></tr></thead><tbody>
      ${(bill.tests || []).map(t => `<tr><td>${t.name || t}</td><td>₹${t.price || ''}</td></tr>`).join('')}
      </tbody></table>
      <p><strong>Discount:</strong> ₹${bill.discount || 0}</p>
      <p class="total">Total: ₹${bill.totalAmount || bill.amount || 0}</p>
      <p><strong>Payment Status:</strong> ${bill.paymentStatus}</p>
      <p><strong>Mode:</strong> ${bill.paymentMode || 'N/A'}</p>
      <hr><p style="font-size:12px;color:#888">Generated by MediFlow Pro AI · Thank you!</p>
      </body></html>`)
    w.document.close()
    w.print()
  }

  const handleVoid = async (bill) => {
    if (!window.confirm(`Void invoice ${bill.invoiceNo || bill._id}? This marks it as voided and resets payment.`)) return
    try {
      await billingAPI.voidBill(bill._id)
      toast.success('Invoice voided!')
      load()
    } catch { toast.success('Invoice voided! (offline)') }
    setBills(prev => prev.map(b => b._id === bill._id ? { ...b, paymentStatus: 'voided', paidAmount: 0 } : b))
  }

  const handleWhatsApp = (bill) => {
    const msg = `🏥 *MediFlow Diagnostic Lab*\n\n📋 Invoice: ${bill.invoiceNo || bill._id}\n👤 Patient: ${bill.patient?.name || 'N/A'}\n🧪 Tests: ${(bill.tests || []).map(t => t.name || t).join(', ')}\n💰 Amount: ₹${bill.totalAmount || 0}\n✅ Status: ${bill.paymentStatus}\n\nThank you for choosing MediFlow!`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
    toast.success('Opening WhatsApp...')
  }

  const handleExport = () => {
    const csv = [['Invoice', 'Patient', 'Tests', 'Amount', 'Paid', 'Status', 'Date'].join(',')]
    filteredBills.forEach(b => {
      csv.push([b.invoiceNo, b.patient?.name || '', (b.tests || []).map(t => t.name).join('; '), b.totalAmount, b.paidAmount, b.paymentStatus, new Date(b.createdAt).toLocaleDateString('en-IN')].join(','))
    })
    const blob = new Blob([csv.join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `invoices_${Date.now()}.csv`; a.click()
    URL.revokeObjectURL(url)
    toast.success('Exported to CSV!')
  }

  return (
    <div>
      <PageHeader
        title="Billing"
        subtitle="GST invoices and payment management"
        actions={<>
          <button onClick={handleExport} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Download size={16} /> Export</button>
          <button onClick={() => setShowNewModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} /> New Invoice</button>
        </>}
      />
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={Wallet} label="Today's Collection" value={`₹${bills.filter(b => b.paymentStatus === 'paid').reduce((s, b) => s + (b.paidAmount || 0), 0).toLocaleString()}`} color="green" trend={12} />
        <StatCard icon={TrendingUp} label="Total Invoices" value={bills.length} color="blue" trend={8} />
        <StatCard icon={AlertTriangle} label="Pending Dues" value={`₹${bills.filter(b => b.paymentStatus !== 'paid').reduce((s, b) => s + ((b.totalAmount || 0) - (b.paidAmount || 0)), 0).toLocaleString()}`} color="red" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <SearchBar value={search} onChange={setSearch} placeholder="Search by patient name or invoice..." />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all border ${showFilters || activeFilterCount > 0 ? 'bg-brand-500/15 border-brand-500/30 text-brand-300' : 'bg-surface-850 border-surface-700 text-slate-400 hover:border-surface-600'}`}
            >
              <Filter size={15} />
              Filters
              {activeFilterCount > 0 && (
                <span className="w-5 h-5 bg-brand-500 text-surface-950 text-xs font-bold rounded-full flex items-center justify-center">
                  {activeFilterCount}
                </span>
              )}
            </button>
            {activeFilterCount > 0 && (
              <button onClick={clearFilters} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-red-400 hover:bg-red-500/10 transition-all">
                <X size={14} /> Clear
              </button>
            )}
          </div>

          {/* Expanded Filter Panel */}
          {showFilters && (
            <div className="mt-4 p-4 bg-surface-850 rounded-xl border border-surface-700 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Payment Status Filter */}
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-2">Payment Status</label>
                  <div className="flex flex-wrap gap-2">
                    {[{ value: 'all', label: 'All' }, { value: 'paid', label: 'Paid' }, { value: 'unpaid', label: 'Unpaid' }, { value: 'partial', label: 'Partial' }].map(opt => (
                      <button
                        key={opt.value}
                        onClick={() => setStatusFilter(opt.value)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${statusFilter === opt.value ? 'bg-brand-500/15 border-brand-500/30 text-brand-300' : 'bg-surface-800 border-surface-700 text-slate-400 hover:border-surface-500'}`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Date From */}
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-2">From Date</label>
                  <div className="relative">
                    <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="date"
                      value={dateFrom}
                      onChange={e => setDateFrom(e.target.value)}
                      className="w-full bg-surface-800 border border-surface-700 rounded-xl pl-9 pr-4 py-2 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/30 transition-all"
                    />
                  </div>
                </div>

                {/* Date To */}
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-2">To Date</label>
                  <div className="relative">
                    <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="date"
                      value={dateTo}
                      onChange={e => setDateTo(e.target.value)}
                      className="w-full bg-surface-800 border border-surface-700 rounded-xl pl-9 pr-4 py-2 text-sm text-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/30 transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Active Filters Summary */}
              {activeFilterCount > 0 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-slate-500">Active:</span>
                  {statusFilter !== 'all' && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-brand-500/10 text-brand-300 rounded-lg text-xs">
                      Status: {statusFilter} <button onClick={() => setStatusFilter('all')} className="hover:text-white"><X size={12} /></button>
                    </span>
                  )}
                  {dateFrom && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-500/10 text-blue-300 rounded-lg text-xs">
                      From: {dateFrom} <button onClick={() => setDateFrom('')} className="hover:text-white"><X size={12} /></button>
                    </span>
                  )}
                  {dateTo && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-500/10 text-purple-300 rounded-lg text-xs">
                      To: {dateTo} <button onClick={() => setDateTo('')} className="hover:text-white"><X size={12} /></button>
                    </span>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading...</div>
        ) : (
          <Table
            columns={[
              { key: 'invoiceNo', label: 'Invoice', render: v => v || 'INV-NEW' },
              { key: 'patient', label: 'Patient', render: v => v?.name || 'N/A' },
              { key: 'tests', label: 'Tests', render: v => (v || []).map(t => t.name || t).join(', ') || '—' },
              { key: 'totalAmount', label: 'Amount', render: v => `₹${(v || 0).toLocaleString()}` },
              { key: 'paymentStatus', label: 'Payment', render: v => <Badge status={v === 'paid' ? 'paid' : v === 'partial' ? 'pending' : v === 'voided' ? 'voided' : 'unpaid'} /> },
              { key: 'createdAt', label: 'Date', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '—' },
            ]}
            data={filteredBills}
            actions={(row) => (
              <>
                <Tooltip label="View Invoice">
                  <button onClick={() => { setSelectedBill(row); setShowViewModal(true) }} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={12} /> View</button>
                </Tooltip>
                <Tooltip label="Print Invoice">
                  <button onClick={() => handlePrint(row)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Printer size={12} /> Print</button>
                </Tooltip>
                <Tooltip label="Share on WhatsApp">
                  <button onClick={() => handleWhatsApp(row)} className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all">WhatsApp</button>
                </Tooltip>
                {row.paymentStatus !== 'voided' && (
                  <Tooltip label="Void Invoice">
                    <button onClick={() => handleVoid(row)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all">Void</button>
                  </Tooltip>
                )}
              </>
            )}
          />
        )}
      </div>

      {/* New Invoice Modal */}
      <Modal open={showNewModal} onClose={() => setShowNewModal(false)} title="Create New Invoice" size="lg">
        <form onSubmit={handleCreate} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Patient name" value={form.patientName} onChange={e => setForm({ ...form, patientName: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Phone</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Mobile number" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Tests (comma separated) *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. CBC, LFT, Lipid Profile" value={form.tests} onChange={e => setForm({ ...form, tests: e.target.value })} /></div>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Amount (₹) *</label><input required type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="0" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Discount (₹)</label><input type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="0" value={form.discount} onChange={e => setForm({ ...form, discount: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Payment Mode</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.paymentMode} onChange={e => setForm({ ...form, paymentMode: e.target.value })}>
                <option value="cash">Cash</option><option value="upi">UPI</option><option value="card">Card</option><option value="bank">Bank Transfer</option>
              </select>
            </div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Notes</label><textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-16 resize-none" placeholder="Optional notes..." value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
          {form.amount > 0 && (
            <div className="bg-surface-850 rounded-xl p-3 text-sm text-slate-300">
              <span>Subtotal: ₹{Number(form.amount || 0)} </span>
              <span className="text-slate-500">| Discount: -₹{Number(form.discount || 0)} </span>
              <span className="font-semibold text-brand-400">= ₹{Number(form.amount || 0) - Number(form.discount || 0)}</span>
            </div>
          )}
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowNewModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Create Invoice</button>
          </div>
        </form>
      </Modal>

      {/* View Invoice Modal */}
      <Modal open={showViewModal} onClose={() => setShowViewModal(false)} title={`Invoice: ${selectedBill?.invoiceNo || ''}`} size="lg">
        {selectedBill && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-slate-500">Patient:</span><p className="text-slate-200 font-medium">{selectedBill.patient?.name || 'N/A'}</p></div>
              <div><span className="text-slate-500">Date:</span><p className="text-slate-200">{selectedBill.createdAt ? new Date(selectedBill.createdAt).toLocaleDateString('en-IN') : '—'}</p></div>
              <div><span className="text-slate-500">Payment Status:</span><p><Badge status={selectedBill.paymentStatus === 'paid' ? 'paid' : selectedBill.paymentStatus === 'voided' ? 'voided' : 'unpaid'} /></p></div>
              <div><span className="text-slate-500">Payment Mode:</span><p className="text-slate-200">{selectedBill.paymentMode || 'N/A'}</p></div>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Tests</p>
              <div className="bg-surface-850 rounded-xl p-3 space-y-1">
                {(selectedBill.tests || []).map((t, i) => (
                  <div key={i} className="flex justify-between text-sm"><span className="text-slate-300">{t.name || t}</span><span className="text-slate-400">{t.price ? `₹${t.price}` : ''}</span></div>
                ))}
              </div>
            </div>
            {selectedBill.discount > 0 && <p className="text-sm text-slate-400">Discount: -₹{selectedBill.discount}</p>}
            <div className="flex justify-between items-center pt-2 border-t border-surface-700">
              <span className="text-lg font-semibold text-slate-100">Total: ₹{(selectedBill.totalAmount || 0).toLocaleString()}</span>
              <span className="text-sm text-slate-400">Paid: ₹{(selectedBill.paidAmount || 0).toLocaleString()}</span>
            </div>
            <div className="flex gap-2 justify-end">
              <Tooltip label="Print Invoice">
                <button onClick={() => handlePrint(selectedBill)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"><Printer size={14} /> Print</button>
              </Tooltip>
              <Tooltip label="Share on WhatsApp">
                <button onClick={() => handleWhatsApp(selectedBill)} className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"><Send size={14} /> Share on WhatsApp</button>
              </Tooltip>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

// ─── REPORTS ────────────────────────────────────────────────────────────────
export function Reports() {
  const [reports, setReports] = useState([])
  const [loading, setLoading] = useState(true)
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [form, setForm] = useState({ patientName: '', test: '', notes: '' })

  const load = async () => {
    setLoading(true)
    try {
      const res = await reportAPI.getAll()
      setReports(extractArray(res.data, 'reports'))
    } catch {
      setReports([
        { _id: 'R001', patient: { name: 'Rahul Sharma' }, tests: [{ name: 'CBC' }], status: 'completed', createdAt: '2026-06-12' },
        { _id: 'R002', patient: { name: 'Priya Verma' }, tests: [{ name: 'Thyroid Profile' }], status: 'pending', createdAt: '2026-06-13' },
        { _id: 'R003', patient: { name: 'Anil Kumar' }, tests: [{ name: 'Lipid Profile' }, { name: 'HbA1c' }], status: 'processing', createdAt: '2026-06-13' },
        { _id: 'R004', patient: { name: 'Sunita Patel' }, tests: [{ name: 'Urine Routine' }], status: 'completed', createdAt: '2026-06-11' },
      ])
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleUpload = async (e) => {
    e.preventDefault()
    try {
      await reportAPI.update('new', form)
      toast.success('Report uploaded!')
    } catch { toast.success('Report uploaded! (demo)') }
    setShowUploadModal(false)
    setForm({ patientName: '', test: '', notes: '' })
    load()
  }

  const handleViewPDF = (report) => {
    const w = window.open('', '_blank')
    w.document.write(`
      <html><head><title>Report - ${report.patient?.name || 'Patient'}</title>
      <style>body{font-family:sans-serif;padding:40px;color:#333}h1{color:#059669;border-bottom:2px solid #059669;padding-bottom:8px}table{width:100%;border-collapse:collapse;margin:16px 0}td,th{border:1px solid #ddd;padding:8px;text-align:left}th{background:#f0fdf4}.normal{color:green}.abnormal{color:red;font-weight:bold}</style>
      </head><body>
      <h1>🏥 MediFlow Diagnostic Lab — Lab Report</h1>
      <p><strong>Report ID:</strong> ${report._id}</p>
      <p><strong>Date:</strong> ${new Date(report.createdAt).toLocaleDateString('en-IN')}</p>
      <p><strong>Patient:</strong> ${report.patient?.name || 'N/A'}</p>
      <p><strong>Tests:</strong> ${(report.tests || []).map(t => t.name || t).join(', ')}</p>
      <table><thead><tr><th>Parameter</th><th>Result</th><th>Unit</th><th>Reference Range</th><th>Status</th></tr></thead><tbody>
      <tr><td>Hemoglobin</td><td class="normal">13.2</td><td>g/dL</td><td>12.0 - 16.0</td><td class="normal">Normal</td></tr>
      <tr><td>WBC Count</td><td class="normal">7,200</td><td>/μL</td><td>4,000 - 11,000</td><td class="normal">Normal</td></tr>
      <tr><td>Platelet Count</td><td class="normal">2,45,000</td><td>/μL</td><td>1,50,000 - 4,00,000</td><td class="normal">Normal</td></tr>
      <tr><td>RBC Count</td><td class="normal">4.8</td><td>million/μL</td><td>4.5 - 5.5</td><td class="normal">Normal</td></tr>
      <tr><td>Hematocrit</td><td class="normal">41.2</td><td>%</td><td>36.0 - 46.0</td><td class="normal">Normal</td></tr>
      </tbody></table>
      <p style="font-size:12px;color:#888;margin-top:24px">⚕️ This report is generated by MediFlow Pro AI. For medical consultation, please visit your doctor.</p>
      <hr><p style="font-size:11px;color:#aaa">MediFlow Diagnostic Lab · Raipur, Chhattisgarh</p>
      </body></html>`)
    w.document.close()
  }

  const handleShare = (report) => {
    const msg = `🏥 *MediFlow Diagnostic Lab*\n\n📋 Report ID: ${report._id}\n👤 Patient: ${report.patient?.name || 'N/A'}\n🧪 Tests: ${(report.tests || []).map(t => t.name || t).join(', ')}\n📊 Status: ${report.status}\n\nYour report is ready! Please collect from the lab.`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
    toast.success('Opening WhatsApp...')
  }

  const handleDeleteReport = async (report) => {
    if (!window.confirm(`Delete report for ${report.patient?.name || report._id}? This cannot be undone.`)) return
    try {
      await reportAPI.delete(report._id)
      toast.success('Report deleted!')
    } catch { toast.success('Report deleted! (offline)') }
    setReports(prev => prev.filter(r => r._id !== report._id))
  }

  return (
    <div>
      <PageHeader title="Reports" subtitle="Patient diagnostic reports"
        actions={<button onClick={() => setShowUploadModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} /> Upload Report</button>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? <div className="text-center py-12 text-slate-500">Loading...</div> : (
          <Table
            columns={[
              { key: '_id', label: 'Report ID', render: v => `RPT-${v?.slice(-3) || '000'}` },
              { key: 'patient', label: 'Patient', render: v => v?.name || 'N/A' },
              { key: 'tests', label: 'Tests', render: v => (v || []).map(t => t.name || t).join(', ') },
              { key: 'createdAt', label: 'Date', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '—' },
              { key: 'status', label: 'Status', render: v => <Badge status={v || 'pending'} /> },
            ]}
            data={reports}
            actions={(row) => (
              <>
                <Tooltip label="View PDF Report">
                  <button onClick={() => handleViewPDF(row)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={12} /> View PDF</button>
                </Tooltip>
                <Tooltip label="Share Report">
                  <button onClick={() => handleShare(row)} className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Send size={12} /> Share</button>
                </Tooltip>
                <Tooltip label="Delete Report">
                  <button onClick={() => handleDeleteReport(row)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Trash2 size={12} /> Delete</button>
                </Tooltip>
              </>
            )}
          />
        )}
      </div>

      <Modal open={showUploadModal} onClose={() => setShowUploadModal(false)} title="Upload Report">
        <form onSubmit={handleUpload} className="space-y-3">
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Patient Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Patient name" value={form.patientName} onChange={e => setForm({ ...form, patientName: e.target.value })} /></div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Test *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. CBC" value={form.test} onChange={e => setForm({ ...form, test: e.target.value })} /></div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Report File</label><input type="file" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" accept=".pdf,.jpg,.png" /></div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Notes</label><textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-16 resize-none" placeholder="Optional..." value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowUploadModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Upload Report</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

// ─── STAFF ──────────────────────────────────────────────────────────────────
export function Staff() {
  const [staff, setStaff] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editItem, setEditItem] = useState(null)
  const [form, setForm] = useState({ name: '', role: 'Technician', phone: '', shift: 'Morning' })

  const load = async () => {
    setLoading(true)
    try {
      const res = await staffAPI.getAll()
      setStaff(extractArray(res.data, 'staff'))
    } catch {
      setStaff([
        { _id: 'S001', name: 'Kavita Sharma', role: 'Technician', phone: '9700000001', shift: 'Morning', status: 'active' },
        { _id: 'S002', name: 'Ravi Kumar', role: 'Receptionist', phone: '9700000002', shift: 'Morning', status: 'active' },
        { _id: 'S003', name: 'Sunita Devi', role: 'Technician', phone: '9700000003', shift: 'Evening', status: 'active' },
        { _id: 'S004', name: 'Amit Yadav', role: 'Lab Helper', phone: '9700000004', shift: 'Morning', status: 'inactive' },
      ])
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      if (editItem) {
        await staffAPI.update(editItem._id, form)
        toast.success('Staff updated!')
      } else {
        await staffAPI.create(form)
        toast.success('Staff added!')
      }
    } catch { toast.success(editItem ? 'Staff updated! (demo)' : 'Staff added! (demo)') }
    setShowModal(false)
    setEditItem(null)
    setForm({ name: '', role: 'Technician', phone: '', shift: 'Morning' })
    load()
  }

  const handleEdit = (item) => {
    setEditItem(item)
    setForm({ name: item.name, role: item.role, phone: item.phone, shift: item.shift })
    setShowModal(true)
  }

  const handleRemove = async (item) => {
    if (!window.confirm(`Remove ${item.name}?`)) return
    setStaff(s => s.filter(x => x._id !== item._id))
    toast.success(`${item.name} removed!`)
  }

  return (
    <div>
      <PageHeader title="Staff Management" subtitle="Manage lab staff and roles"
        actions={<button onClick={() => { setEditItem(null); setForm({ name: '', role: 'Technician', phone: '', shift: 'Morning' }); setShowModal(true) }} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} /> Add Staff</button>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? <div className="text-center py-12 text-slate-500">Loading...</div> : (
          <Table
            columns={[
              { key: '_id', label: 'ID', render: v => v?.slice(-3) || '—' },
              { key: 'name', label: 'Name', render: (v) => (
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-teal-500/15 text-teal-400 flex items-center justify-center text-xs font-semibold">{v?.split(' ').map(n => n[0]).join('')}</div>
                  <span className="font-medium text-slate-300">{v}</span>
                </div>
              )},
              { key: 'role', label: 'Role' },
              { key: 'phone', label: 'Phone' },
              { key: 'shift', label: 'Shift' },
              { key: 'status', label: 'Status', render: v => <Badge status={v || 'active'} /> },
            ]}
            data={staff}
            actions={(row) => (
              <>
                <Tooltip label="Edit Staff">
                  <button onClick={() => handleEdit(row)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Edit size={12} /> Edit</button>
                </Tooltip>
                <Tooltip label="Remove Staff">
                  <button onClick={() => handleRemove(row)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Trash2 size={12} /> Remove</button>
                </Tooltip>
              </>
            )}
          />
        )}
      </div>
      <Modal open={showModal} onClose={() => setShowModal(false)} title={editItem ? 'Edit Staff Member' : 'Add Staff Member'}>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Full name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Role</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
                <option>Technician</option><option>Receptionist</option><option>Lab Helper</option><option>Accountant</option>
              </select>
            </div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Phone *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Mobile" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Shift</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.shift} onChange={e => setForm({ ...form, shift: e.target.value })}>
                <option>Morning</option><option>Evening</option><option>Night</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">{editItem ? 'Update' : 'Add Staff'}</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

// ─── INVENTORY ──────────────────────────────────────────────────────────────
export function Inventory() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showStockModal, setShowStockModal] = useState(false)
  const [editItem, setEditItem] = useState(null)
  const [form, setForm] = useState({ name: '', category: 'Reagents', stock: '', minStock: '', unit: 'pcs', expiry: '', vendor: '' })
  const [stockAdj, setStockAdj] = useState({ type: 'add', quantity: '' })

  const load = async () => {
    setLoading(true)
    try {
      const res = await inventoryAPI.getAll()
      setItems(extractArray(res.data, 'items'))
    } catch {
      setItems([
        { _id: 'INV001', name: 'EDTA Vacutainer', category: 'Consumables', stock: 450, minStock: 100, unit: 'pcs', expiry: '2027-12-01', vendor: 'BD India' },
        { _id: 'INV002', name: 'CBC Reagent Kit', category: 'Reagents', stock: 8, minStock: 5, unit: 'kits', expiry: '2026-09-15', vendor: 'Sysmex India' },
        { _id: 'INV003', name: 'Glucose Reagent', category: 'Reagents', stock: 3, minStock: 5, unit: 'bottles', expiry: '2026-07-20', vendor: 'Transasia' },
        { _id: 'INV004', name: 'Urine Strips', category: 'Consumables', stock: 200, minStock: 50, unit: 'pcs', expiry: '2026-11-30', vendor: 'Medi-Test' },
        { _id: 'INV005', name: 'SST Vacutainer', category: 'Consumables', stock: 380, minStock: 100, unit: 'pcs', expiry: '2027-06-01', vendor: 'BD India' },
      ])
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleAddItem = async (e) => {
    e.preventDefault()
    try { await inventoryAPI.create(form); toast.success('Item added!') } catch { toast.success('Item added! (demo)') }
    setShowAddModal(false)
    setForm({ name: '', category: 'Reagents', stock: '', minStock: '', unit: 'pcs', expiry: '', vendor: '' })
    load()
  }

  const handleUpdateStock = async (e) => {
    e.preventDefault()
    const qty = Number(stockAdj.quantity)
    if (!qty) return
    setItems(prev => prev.map(item => {
      if (item._id !== editItem._id) return item
      const newStock = stockAdj.type === 'add' ? item.stock + qty : Math.max(0, item.stock - qty)
      return { ...item, stock: newStock }
    }))
    try { await inventoryAPI.adjustStock(editItem._id, stockAdj) } catch {}
    toast.success(`Stock ${stockAdj.type === 'add' ? 'added' : 'reduced'}!`)
    setShowStockModal(false)
  }

  const handleDeleteItem = async (item) => {
    if (!window.confirm(`Delete ${item.name}? This permanently removes it from inventory.`)) return
    try {
      await inventoryAPI.delete(item._id)
      toast.success(`${item.name} deleted!`)
    } catch { toast.success(`${item.name} deleted! (offline)`) }
    setItems(prev => prev.filter(i => i._id !== item._id))
  }

  const handleOrder = (item) => {
    const msg = `📦 *Inventory Restock Request*\n\nItem: ${item.name}\nCurrent Stock: ${item.stock} ${item.unit}\nMin Required: ${item.minStock} ${item.unit}\nVendor: ${item.vendor}\n\nPlease arrange reorder.`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
    toast.success('Opening WhatsApp for order request...')
  }

  const handleExport = () => {
    const csv = [['ID', 'Name', 'Category', 'Stock', 'Unit', 'Min Stock', 'Expiry', 'Vendor'].join(',')]
    items.forEach(item => {
      csv.push([item._id, item.name, item.category, item.stock, item.unit, item.minStock, item.expiry, item.vendor].join(','))
    })
    const blob = new Blob([csv.join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `inventory_${Date.now()}.csv`; a.click()
    URL.revokeObjectURL(url)
    toast.success('Inventory exported!')
  }

  return (
    <div>
      <PageHeader title="Inventory" subtitle="Reagents, consumables and stock management"
        actions={<>
          <button onClick={handleExport} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Download size={16} /> Export</button>
          <button onClick={() => setShowAddModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} /> Add Item</button>
        </>}
      />
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={Package} label="Total Items" value={items.length} color="blue" />
        <StatCard icon={AlertTriangle} label="Low Stock" value={items.filter(i => i.stock <= i.minStock).length} color="red" />
        <StatCard icon={Package} label="Expiring Soon" value={items.filter(i => { const d = new Date(i.expiry); return d <= new Date(Date.now() + 90*86400000) }).length} color="amber" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? <div className="text-center py-12 text-slate-500">Loading...</div> : (
          <Table
            columns={[
              { key: '_id', label: 'ID', render: v => v?.slice(-3) || '—' },
              { key: 'name', label: 'Item Name' },
              { key: 'category', label: 'Category' },
              { key: 'stock', label: 'Stock', render: (v, row) => (
                <span className={v <= row.minStock ? 'text-red-400 font-semibold' : 'text-slate-300'}>
                  {v} {row.unit}
                  {v <= row.minStock && <span className="inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-medium bg-red-500/10 text-red-400 ml-2">Low</span>}
                </span>
              )},
              { key: 'expiry', label: 'Expiry' },
              { key: 'vendor', label: 'Vendor' },
            ]}
            data={items}
            actions={(row) => (
              <>
                <Tooltip label="Adjust Stock Level">
                  <button onClick={() => { setEditItem(row); setStockAdj({ type: 'add', quantity: '' }); setShowStockModal(true) }} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><RefreshCw size={12} /> Update Stock</button>
                </Tooltip>
                <Tooltip label="Order from Vendor">
                  <button onClick={() => handleOrder(row)} className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Send size={12} /> Order</button>
                </Tooltip>
                <Tooltip label="Delete Item">
                  <button onClick={() => handleDeleteItem(row)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Trash2 size={12} /> Delete</button>
                </Tooltip>
              </>
            )}
          />
        )}
      </div>

      {/* Add Item Modal */}
      <Modal open={showAddModal} onClose={() => setShowAddModal(false)} title="Add Inventory Item">
        <form onSubmit={handleAddItem} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Item Name *</label><input required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Item name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Category</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                <option>Reagents</option><option>Consumables</option><option>Equipment</option><option>Kits</option>
              </select>
            </div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Stock *</label><input required type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="0" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Min Stock</label><input type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Min required" value={form.minStock} onChange={e => setForm({ ...form, minStock: e.target.value })} /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Unit</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })}>
                <option>pcs</option><option>kits</option><option>bottles</option><option>boxes</option><option>rolls</option>
              </select>
            </div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Expiry Date</label><input type="date" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.expiry} onChange={e => setForm({ ...form, expiry: e.target.value })} /></div>
          </div>
          <div><label className="block text-xs font-medium text-slate-500 mb-1">Vendor</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Vendor name" value={form.vendor} onChange={e => setForm({ ...form, vendor: e.target.value })} /></div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowAddModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Add Item</button>
          </div>
        </form>
      </Modal>

      {/* Update Stock Modal */}
      <Modal open={showStockModal} onClose={() => setShowStockModal(false)} title={`Update Stock: ${editItem?.name || ''}`}>
        <form onSubmit={handleUpdateStock} className="space-y-3">
          <div className="bg-surface-850 rounded-xl p-3 text-sm text-slate-300">
            Current Stock: <span className="font-semibold">{editItem?.stock} {editItem?.unit}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Action</label>
              <div className="flex gap-2">
                <button type="button" onClick={() => setStockAdj({ ...stockAdj, type: 'add' })} className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all border ${stockAdj.type === 'add' ? 'bg-brand-500/15 border-brand-500/30 text-brand-300' : 'bg-surface-800 border-surface-700 text-slate-400'}`}>+ Add</button>
                <button type="button" onClick={() => setStockAdj({ ...stockAdj, type: 'reduce' })} className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all border ${stockAdj.type === 'reduce' ? 'bg-red-500/15 border-red-500/30 text-red-300' : 'bg-surface-800 border-surface-700 text-slate-400'}`}>− Reduce</button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Quantity *</label>
              <input required type="number" min="1" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="0" value={stockAdj.quantity} onChange={e => setStockAdj({ ...stockAdj, quantity: e.target.value })} />
            </div>
          </div>
          <div className="bg-surface-850 rounded-xl p-3 text-sm">
            <span className="text-slate-500">New Stock: </span>
            <span className="font-semibold text-brand-400">
              {stockAdj.type === 'add'
                ? (editItem?.stock || 0) + Number(stockAdj.quantity || 0)
                : Math.max(0, (editItem?.stock || 0) - Number(stockAdj.quantity || 0))
              } {editItem?.unit}
            </span>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowStockModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Update Stock</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

// ─── FINANCE ────────────────────────────────────────────────────────────────
export function Finance() {
  const [entries] = useState([
    { type: 'Income', description: 'Patient billing collections', amount: 18400, date: '2026-06-13', category: 'Revenue' },
    { type: 'Income', description: 'Home collection charges', amount: 2400, date: '2026-06-13', category: 'Revenue' },
    { type: 'Expense', description: 'Reagent purchase – Transasia', amount: -8500, date: '2026-06-12', category: 'Inventory' },
    { type: 'Expense', description: 'Staff salary advance', amount: -5000, date: '2026-06-11', category: 'HR' },
    { type: 'Expense', description: 'Electricity bill', amount: -2800, date: '2026-06-10', category: 'Utilities' },
  ])

  const handleExport = () => {
    const csv = [['Date', 'Description', 'Category', 'Type', 'Amount'].join(',')]
    entries.forEach(e => csv.push([e.date, `"${e.description}"`, e.category, e.type, e.amount].join(',')))
    const blob = new Blob([csv.join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `finance_${Date.now()}.csv`; a.click()
    URL.revokeObjectURL(url)
    toast.success('Finance data exported!')
  }

  const totalIncome = entries.filter(e => e.amount > 0).reduce((s, e) => s + e.amount, 0)
  const totalExpense = entries.filter(e => e.amount < 0).reduce((s, e) => s + Math.abs(e.amount), 0)

  return (
    <div>
      <PageHeader title="Finance" subtitle="Income, expenses and P&L overview" actions={
        <button onClick={handleExport} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Download size={16} /> Export</button>
      }/>
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={TrendingUp} label="Total Income" value={`₹${totalIncome.toLocaleString()}`} color="green" sub="This month" />
        <StatCard icon={Wallet} label="Total Expenses" value={`₹${totalExpense.toLocaleString()}`} color="red" sub="This month" />
        <StatCard icon={TrendingUp} label="Net Profit" value={`₹${(totalIncome - totalExpense).toLocaleString()}`} color="blue" sub="This month" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'date', label: 'Date' },
            { key: 'description', label: 'Description' },
            { key: 'category', label: 'Category' },
            { key: 'type', label: 'Type', render: v => (
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium ${v === 'Income' ? 'bg-brand-500/10 text-brand-400 border border-brand-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>{v}</span>
            )},
            { key: 'amount', label: 'Amount', render: v => (
              <span className={v < 0 ? 'text-red-400 font-medium' : 'text-brand-400 font-medium'}>
                {v < 0 ? '-' : '+'}₹{Math.abs(v).toLocaleString()}
              </span>
            )},
          ]}
          data={entries}
        />
      </div>
    </div>
  )
}

// ─── ANALYTICS ──────────────────────────────────────────────────────────────
export function Analytics() {
  return (
    <div>
      <PageHeader title="Analytics" subtitle="Lab performance and growth insights" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="Total Patients" value="1,234" color="blue" trend={12} />
        <StatCard icon={TrendingUp} label="Revenue Growth" value="18%" color="green" />
        <StatCard icon={Package} label="Tests Done" value="4,567" color="purple" trend={9} />
        <StatCard icon={Wallet} label="Avg Invoice" value="₹892" color="amber" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-8 text-center">
        <div className="w-16 h-16 bg-brand-500/15 rounded-2xl mx-auto flex items-center justify-center mb-3">
          <TrendingUp className="text-brand-400" size={28} />
        </div>
        <p className="font-semibold text-slate-300">Full analytics available in Pro plan</p>
        <p className="text-sm text-slate-500 mt-1">Detailed growth charts, doctor referral analysis, test trends and more</p>
      </div>
    </div>
  )
}
