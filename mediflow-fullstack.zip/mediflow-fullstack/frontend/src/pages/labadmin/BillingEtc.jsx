import React, { useState } from 'react'
import { Plus, Download, Printer } from 'lucide-react'
import { PageHeader, Table, Badge, SearchBar, Modal, StatCard } from '../../components/UI'
import { mockPatients, inventoryItems, staffList } from '../../utils/mockData'
import { TrendingUp, Wallet, Package, AlertTriangle, Users } from 'lucide-react'

export function Billing() {
  return (
    <div>
      <PageHeader
        title="Billing"
        subtitle="GST invoices and payment management"
        actions={
          <>
            <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Download size={16} /> Export</button>
            <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} /> New Invoice</button>
          </>
        }
      />
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={Wallet} label="Today's Collection" value="₹18,400" color="green" trend={12} />
        <StatCard icon={TrendingUp} label="This Month" value="₹3,24,000" color="blue" trend={8} />
        <StatCard icon={AlertTriangle} label="Pending Dues" value="₹12,600" color="red" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'Invoice', render: (v) => `INV-2026-${v.replace('P', '')}` },
            { key: 'name', label: 'Patient' },
            { key: 'tests', label: 'Tests', render: v => v.join(', ') },
            { key: 'amount', label: 'Amount', render: v => `₹${v.toLocaleString()}` },
            { key: 'status', label: 'Payment', render: v => (
              <Badge status={v === 'completed' ? 'paid' : 'unpaid'} />
            )},
            { key: 'date', label: 'Date' },
          ]}
          data={mockPatients}
          actions={() => (
            <>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1 flex items-center gap-1"><Printer size={12} />Print</button>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">WhatsApp</button>
            </>
          )}
        />
      </div>
    </div>
  )
}

export function Reports() {
  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle="Patient diagnostic reports"
        actions={<button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} /> Upload Report</button>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'Report ID', render: v => `RPT-${v.replace('P', '')}` },
            { key: 'name', label: 'Patient' },
            { key: 'tests', label: 'Tests', render: v => v.join(', ') },
            { key: 'date', label: 'Date' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={mockPatients}
          actions={() => (
            <>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">View PDF</button>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Share</button>
            </>
          )}
        />
      </div>
    </div>
  )
}

export function Staff() {
  const [showModal, setShowModal] = useState(false)
  return (
    <div>
      <PageHeader
        title="Staff Management"
        subtitle="Manage lab staff and roles"
        actions={
          <button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2">
            <Plus size={16} /> Add Staff
          </button>
        }
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'ID' },
            { key: 'name', label: 'Name', render: (v, row) => (
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-teal-500/15 text-teal-400 flex items-center justify-center text-xs font-semibold">
                  {v.split(' ').map(n => n[0]).join('')}
                </div>
                <span className="font-medium text-slate-300">{v}</span>
              </div>
            )},
            { key: 'role', label: 'Role' },
            { key: 'phone', label: 'Phone' },
            { key: 'shift', label: 'Shift' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={staffList}
          actions={() => (
            <>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Edit</button>
              <button className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Remove</button>
            </>
          )}
        />
      </div>
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Add Staff Member">
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Name</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Full name" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Role</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all"><option>Technician</option><option>Receptionist</option><option>Lab Helper</option><option>Accountant</option></select>
            </div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Phone</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Mobile" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Shift</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all"><option>Morning</option><option>Evening</option><option>Night</option></select>
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Cancel</button>
            <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Add Staff</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export function Inventory() {
  return (
    <div>
      <PageHeader
        title="Inventory"
        subtitle="Reagents, consumables and stock management"
        actions={<button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Plus size={16} /> Add Item</button>}
      />
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={Package} label="Total Items" value={inventoryItems.length} color="blue" />
        <StatCard icon={AlertTriangle} label="Low Stock" value={inventoryItems.filter(i => i.stock <= i.minStock).length} color="red" />
        <StatCard icon={Package} label="Expiring Soon" value="1 item" color="amber" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'ID' },
            { key: 'name', label: 'Item Name' },
            { key: 'category', label: 'Category' },
            { key: 'stock', label: 'Stock', render: (v, row) => (
              <span className={v <= row.minStock ? 'text-red-400 font-semibold' : 'text-slate-300'}>
                {v} {row.unit}
                {v <= row.minStock && <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium bg-red-500/10 text-red-400 ml-2">Low</span>}
              </span>
            )},
            { key: 'expiry', label: 'Expiry' },
            { key: 'vendor', label: 'Vendor' },
          ]}
          data={inventoryItems}
          actions={() => (
            <>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Update Stock</button>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Order</button>
            </>
          )}
        />
      </div>
    </div>
  )
}

export function Finance() {
  const entries = [
    { type: 'Income', description: 'Patient billing collections', amount: 18400, date: '2026-06-13', category: 'Revenue' },
    { type: 'Income', description: 'Home collection charges', amount: 2400, date: '2026-06-13', category: 'Revenue' },
    { type: 'Expense', description: 'Reagent purchase – Transasia', amount: -8500, date: '2026-06-12', category: 'Inventory' },
    { type: 'Expense', description: 'Staff salary advance', amount: -5000, date: '2026-06-11', category: 'HR' },
    { type: 'Expense', description: 'Electricity bill', amount: -2800, date: '2026-06-10', category: 'Utilities' },
  ]
  return (
    <div>
      <PageHeader title="Finance" subtitle="Income, expenses and P&L overview" actions={
        <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2"><Download size={16} /> Export</button>
      }/>
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={TrendingUp} label="Total Income" value="₹3,24,000" color="green" sub="This month" />
        <StatCard icon={Wallet} label="Total Expenses" value="₹98,500" color="red" sub="This month" />
        <StatCard icon={TrendingUp} label="Net Profit" value="₹2,25,500" color="blue" sub="This month" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'date', label: 'Date' },
            { key: 'description', label: 'Description' },
            { key: 'category', label: 'Category' },
            { key: 'type', label: 'Type', render: v => (
              <span className={`badge ${v === 'Income' ? 'badge-green' : 'badge-red'}`}>{v}</span>
            )},
            { key: 'amount', label: 'Amount', render: v => (
              <span className={v < 0 ? 'text-red-400 font-medium' : 'text-brand-400 font-medium'}>
                {v < 0 ? '-' : '+'}₹{Math.abs(v).toLocaleString()}
              </span>
            )},
          ]}
          data={entries}
        />
      </div>
    </div>
  )
}

export function Analytics() {
  return (
    <div>
      <PageHeader title="Analytics" subtitle="Lab performance and growth insights" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="Total Patients" value="1,234" color="blue" trend={12} />
        <StatCard icon={TrendingUp} label="Revenue Growth" value="18%" color="green" />
        <StatCard icon={Package} label="Tests Done" value="4,567" color="purple" trend={9} />
        <StatCard icon={Wallet} label="Avg Invoice" value="₹892" color="amber" />
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-8 text-center">
        <div className="w-16 h-16 bg-brand-500/15 rounded-2xl mx-auto flex items-center justify-center mb-3">
          <TrendingUp className="text-brand-400" size={28} />
        </div>
        <p className="font-semibold text-slate-300">Full analytics available in Pro plan</p>
        <p className="text-sm text-slate-500 mt-1">Detailed growth charts, doctor referral analysis, test trends and more</p>
      </div>
    </div>
  )
}
