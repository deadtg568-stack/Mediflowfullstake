import React, { useState, useEffect, useCallback, useRef } from 'react'
import { PageHeader, Badge } from '../../components/UI'
import { gpsAPI } from '../../utils/api'
import { Navigation, MapPin, Clock, Phone, Home, ChevronRight, Play, Square, RefreshCw } from 'lucide-react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import toast from 'react-hot-toast'

// ─── Fix Leaflet default icon issue ────────────────────────────────────────────
// Webpack/vite bundling breaks the default marker icon paths
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

const TECHNICIAN_ICON = new L.Icon({
  iconUrl:     'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#16a34a" stroke="none"><circle cx="12" cy="12" r="10"/><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" /><circle cx="12" cy="9" r="3" fill="white"/></svg>'),
  iconSize:     [32, 32],
  iconAnchor:   [16, 32],
  popupAnchor:  [0, -32],
})

const DEST_ICON = new L.Icon({
  iconUrl:     'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#ef4444" stroke="none"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" /><circle cx="12" cy="9" r="3" fill="white"/></svg>'),
  iconSize:     [28, 28],
  iconAnchor:   [14, 28],
  popupAnchor:  [0, -28],
})

const STATUS_COLORS = {
  en_route:    'text-blue-400 bg-blue-500/10 border-blue-500/20',
  at_location: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  collecting:  'text-purple-400 bg-purple-500/10 border-purple-500/20',
  completed:   'text-green-400 bg-green-500/10 border-green-500/20',
  cancelled:   'text-red-400 bg-red-500/10 border-red-500/20',
}

const STATUS_LABELS = {
  en_route:    'En Route',
  at_location: 'At Location',
  collecting:  'Collecting',
  completed:   'Completed',
  cancelled:   'Cancelled',
}

function LiveMap({ trackings }) {
  const mapRef = useRef(null)
  const mapInstance = useRef(null)
  const markersRef = useRef({})

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return
    mapInstance.current = L.map(mapRef.current, {
      center: [21.25, 81.63], // Default: Raipur, Chhattisgarh
      zoom: 13,
      zoomControl: true,
    })

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(mapInstance.current)

    // Cleanup on unmount
    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove()
        mapInstance.current = null
      }
    }
  }, [])

  // Update markers when trackings change
  useEffect(() => {
    const map = mapInstance.current
    if (!map) return

    const newMarkers = {}
    const bounds = []

    trackings.forEach(t => {
      const techLoc = t.currentLocation
      const dest = t.destination
      const key = t._id

      // Clear old markers for this tracking
      if (markersRef.current[key]) {
        markersRef.current[key].forEach(m => map.removeLayer(m))
      }

      const markers = []

      // Technician marker
      if (techLoc?.lat && techLoc?.lng) {
        const popupContent = `
          <div style="font-family:sans-serif;font-size:13px;min-width:180px">
            <strong>${t.technician?.name || 'Technician'}</strong><br/>
            <span style="color:#666">${t.patientName || 'Unknown patient'}</span><br/>
            <span style="color:#999;font-size:11px">${STATUS_LABELS[t.status]}</span>
          </div>`
        const m = L.marker([techLoc.lat, techLoc.lng], { icon: TECHNICIAN_ICON })
          .bindPopup(popupContent)
          .addTo(map)
        markers.push(m)
        bounds.push([techLoc.lat, techLoc.lng])
      }

      // Destination marker
      if (dest?.lat && dest?.lng) {
        const popupContent = `
          <div style="font-family:sans-serif;font-size:13px;min-width:180px">
            <strong>📍 ${t.patientName || 'Destination'}</strong><br/>
            <span style="color:#666">${t.patientAddress || ''}</span>
          </div>`
        const m = L.marker([dest.lat, dest.lng], { icon: DEST_ICON })
          .bindPopup(popupContent)
          .addTo(map)
        markers.push(m)
        bounds.push([dest.lat, dest.lng])
      }

      // Draw route line if both points exist
      if (techLoc?.lat && techLoc?.lng && dest?.lat && dest?.lng) {
        const line = L.polyline(
          [[techLoc.lat, techLoc.lng], [dest.lat, dest.lng]],
          { color: '#16a34a', weight: 2, dashArray: '8, 8', opacity: 0.5 }
        ).addTo(map)
        markers.push(line)
      }

      newMarkers[key] = markers
    })

    // Remove markers for trackings that no longer exist
    Object.keys(markersRef.current).forEach(key => {
      if (!newMarkers[key]) {
        markersRef.current[key].forEach(m => map.removeLayer(m))
      }
    })

    markersRef.current = newMarkers

    // Fit bounds if we have markers
    if (bounds.length > 0) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 })
    }
  }, [trackings])

  return <div ref={mapRef} className="w-full h-full min-h-[400px] rounded-xl" />
}

// ═══════════════════════════════════════════════════════════════════════════════
//  GPS TRACKING DASHBOARD (Lab Admin)
// ═══════════════════════════════════════════════════════════════════════════════
export default function GpsTrackingDashboard() {
  const [trackings, setTrackings] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedTech, setSelectedTech] = useState(null)
  const [showHistory, setShowHistory] = useState(false)
  const [historyData, setHistoryData] = useState(null)
  const [autoRefresh, setAutoRefresh] = useState(true)
  const intervalRef = useRef(null)

  const fetchTrackings = useCallback(async () => {
    try {
      const res = await gpsAPI.getActive()
      const data = res.data?.data || []
      setTrackings(data)
    } catch (err) {
      console.error('Failed to fetch GPS trackings:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchTrackings()
  }, [fetchTrackings])

  // Auto-refresh every 5 seconds
  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(fetchTrackings, 5000)
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [autoRefresh, fetchTrackings])

  const handleRefresh = () => {
    setLoading(true)
    fetchTrackings()
    toast.success('Locations refreshed')
  }

  const handleViewHistory = async (tracking) => {
    try {
      const res = await gpsAPI.getHistory(tracking._id)
      setHistoryData(res.data?.data || null)
      setShowHistory(true)
    } catch (err) {
      toast.error('Failed to load tracking history')
    }
  }

  const activeCount = trackings.filter(t => !['completed', 'cancelled'].includes(t.status)).length
  const completedToday = trackings.filter(t => t.status === 'completed').length

  return (
    <div>
      <PageHeader
        title="GPS Tracking"
        subtitle="Real-time location of field staff doing home collections"
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 ${
                autoRefresh ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-surface-800 text-slate-400 border border-surface-700'
              }`}
            >
              <Play size={12} /> Auto-refresh
            </button>
            <button onClick={handleRefresh} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all">
              <RefreshCw size={12} /> Refresh
            </button>
          </div>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Active Trackings', value: activeCount, icon: Navigation, color: 'text-green-400 bg-green-500/10' },
          { label: 'En Route', value: trackings.filter(t => t.status === 'en_route').length, icon: MapPin, color: 'text-blue-400 bg-blue-500/10' },
          { label: 'Collecting', value: trackings.filter(t => t.status === 'collecting').length, icon: Home, color: 'text-purple-400 bg-purple-500/10' },
          { label: 'Completed Today', value: completedToday, icon: Clock, color: 'text-amber-400 bg-amber-500/10' },
        ].map(s => (
          <div key={s.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-4 flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl ${s.color.split(' ')[1]} flex items-center justify-center`}>
              <s.icon size={18} className={s.color.split(' ')[0]} />
            </div>
            <div>
              <p className="text-xl font-bold text-slate-100">{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main grid: Map + List */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Map */}
        <div className="lg:col-span-2 bg-surface-900 rounded-2xl border border-surface-700 overflow-hidden">
          <div className="p-4 border-b border-surface-700 flex items-center justify-between">
            <p className="font-semibold text-slate-300 flex items-center gap-2">
              <MapPin size={16} className="text-brand-400" /> Live Map
            </p>
            {loading && <span className="text-xs text-slate-500 animate-pulse">Loading...</span>}
          </div>
          <div className="h-[500px]">
            {loading && trackings.length === 0 ? (
              <div className="flex items-center justify-center h-full text-slate-500 text-sm">Loading map...</div>
            ) : (
              <LiveMap trackings={trackings} />
            )}
          </div>
        </div>

        {/* Sidebar: Active Trackings List */}
        <div className="space-y-4">
          <div className="bg-surface-900 rounded-2xl border border-surface-700">
            <div className="p-4 border-b border-surface-700 flex items-center justify-between">
              <p className="font-semibold text-slate-300">Active Staff ({activeCount})</p>
            </div>
            <div className="divide-y divide-surface-800 max-h-[500px] overflow-y-auto">
              {trackings.length === 0 && !loading && (
                <div className="p-6 text-center text-slate-500 text-sm">
                  <Navigation size={24} className="mx-auto mb-2 text-slate-600" />
                  No active field staff
                </div>
              )}
              {trackings.map(t => (
                <div
                  key={t._id}
                  onClick={() => setSelectedTech(selectedTech?._id === t._id ? null : t)}
                  className={`p-4 transition-colors cursor-pointer ${
                    selectedTech?._id === t._id ? 'bg-brand-500/5 ring-1 ring-brand-500/20' : 'hover:bg-surface-850'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <p className="font-medium text-sm text-slate-200">{t.technician?.name || 'Unknown'}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${STATUS_COLORS[t.status] || ''}`}>
                      {STATUS_LABELS[t.status] || t.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 flex items-center gap-1">
                    <Home size={11} /> {t.patientName || 'No patient'}
                  </p>
                  {t.currentLocation?.updatedAt && (
                    <p className="text-[10px] text-slate-600 mt-1 flex items-center gap-1">
                      <Clock size={10} /> Updated {new Date(t.currentLocation.updatedAt).toLocaleTimeString()}
                    </p>
                  )}
                  <div className="flex gap-1.5 mt-2">
                    <button
                      onClick={(e) => { e.stopPropagation(); handleViewHistory(t) }}
                      className="text-[10px] bg-surface-800 hover:bg-surface-700 text-slate-400 px-2 py-1 rounded-lg flex items-center gap-1 transition-all"
                    >
                      <Clock size={10} /> History
                    </button>
                    {t.patientPhone && (
                      <a
                        href={`tel:${t.patientPhone}`}
                        onClick={(e) => e.stopPropagation()}
                        className="text-[10px] bg-green-500/10 hover:bg-green-500/20 text-green-400 px-2 py-1 rounded-lg flex items-center gap-1 transition-all"
                      >
                        <Phone size={10} /> Call
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Selected tech details */}
          {selectedTech && (
            <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4">
              <p className="font-semibold text-slate-300 mb-3 text-sm">Trip Details</p>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between"><span className="text-slate-500">Technician</span><span className="text-slate-200">{selectedTech.technician?.name}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Patient</span><span className="text-slate-200">{selectedTech.patientName}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Address</span><span className="text-slate-200 text-right max-w-[180px]">{selectedTech.patientAddress}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Started</span><span className="text-slate-200">{new Date(selectedTech.startedAt).toLocaleTimeString()}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Status</span><Badge status={selectedTech.status} /></div>
                {selectedTech.currentLocation && (
                  <>
                    <div className="border-t border-surface-700 pt-2 mt-2">
                      <p className="text-[10px] text-slate-500 uppercase tracking-wide mb-1">Live Position</p>
                      <p className="text-slate-300">Lat: {selectedTech.currentLocation.lat?.toFixed(5)}</p>
                      <p className="text-slate-300">Lng: {selectedTech.currentLocation.lng?.toFixed(5)}</p>
                      {selectedTech.currentLocation.speed != null && (
                        <p className="text-slate-300">Speed: {selectedTech.currentLocation.speed.toFixed(1)} m/s</p>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* History Modal */}
      {showHistory && historyData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={() => setShowHistory(false)}>
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 max-w-lg w-full mx-4 max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <p className="font-semibold text-slate-300">Route History — {historyData.tracking?.technician?.name}</p>
              <button onClick={() => setShowHistory(false)} className="text-slate-500 hover:text-slate-300 text-xl leading-none">&times;</button>
            </div>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between"><span className="text-slate-500">Patient</span><span className="text-slate-200">{historyData.tracking?.patientName}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Status</span><Badge status={historyData.tracking?.status} /></div>
              <div className="flex justify-between"><span className="text-slate-500">Started</span><span className="text-slate-200">{new Date(historyData.tracking?.startedAt).toLocaleString()}</span></div>
              {historyData.tracking?.completedAt && (
                <div className="flex justify-between"><span className="text-slate-500">Completed</span><span className="text-slate-200">{new Date(historyData.tracking.completedAt).toLocaleString()}</span></div>
              )}
            </div>
            <div className="mt-4 border-t border-surface-700 pt-3">
              <p className="text-xs font-semibold text-slate-500 mb-2">Location Pings ({historyData.locationLogs?.length || 0})</p>
              <div className="max-h-40 overflow-y-auto space-y-1">
                {historyData.locationLogs?.slice(-20).reverse().map((log, i) => (
                  <div key={i} className="text-[10px] text-slate-500 flex justify-between bg-surface-850 rounded-lg px-2 py-1">
                    <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                    <span>{log.lat.toFixed(5)}, {log.lng.toFixed(5)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
