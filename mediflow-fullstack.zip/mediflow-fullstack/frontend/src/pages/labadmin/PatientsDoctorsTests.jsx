import React, { useState, useEffect, useMemo } from 'react'
import { Plus, Eye, Phone, MapPin, User, Calendar, Search, CheckCircle, FileText, Check } from 'lucide-react'
import { PageHeader, Table, Badge, SearchBar, Modal, Tooltip } from '../../components/UI'
import { patientAPI, doctorAPI, testAPI, billingAPI, apiErrorMessage } from '../../utils/api'
import toast from 'react-hot-toast'

// ═══════════════════════════════════════════════════════════════════════════════
//  PATIENTS — with "Register & Bill" workflow
// ═══════════════════════════════════════════════════════════════════════════════
export function Patients() {
  const [patients, setPatients] = useState([])
  const [search, setSearch]     = useState('')
  const [loading, setLoading]   = useState(true)
  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState(null)

  // ── Edit patient state ────────────────────────────────────────────────────
  const [showEditModal, setShowEditModal] = useState(false)
  const [editForm, setEditForm] = useState({ name:'', phone:'', age:'', gender:'male', address:'', referredBy:'' })
  const [editingPatientId, setEditingPatientId] = useState(null)
  const [saving, setSaving] = useState(false)

  // ── Register & Bill state ──────────────────────────────────────────────────
  const [showBillModal, setShowBillModal] = useState(false)
  const [billStep, setBillStep] = useState(1) // 1=patient, 2=tests, 3=invoice

  // Step 1: patient info
  const [patientForm, setPatientForm] = useState({ name:'', phone:'', age:'', gender:'male', address:'', referredBy:'' })

  // Step 2: test selection
  const [allTests, setAllTests] = useState([])
  const [testSearch, setTestSearch] = useState('')
  const [testCategory, setTestCategory] = useState('All')
  const [selectedTests, setSelectedTests] = useState([])

  // Step 3: invoice
  const [discount, setDiscount] = useState(0)
  const [gstPercent, setGstPercent] = useState(0)
  const [paymentMode, setPaymentMode] = useState('cash')
  const [paidAmount, setPaidAmount] = useState(0)
  const [notes, setNotes] = useState('')
  const [creating, setCreating] = useState(false)
  const [createdBill, setCreatedBill] = useState(null)

  const loadPatients = async (q = '') => {
    setLoading(true)
    try {
      const res = await patientAPI.getAll({ search: q, limit: 50 })
      setPatients(res.data.data.patients)
    } catch { toast.error('Failed to load patients') }
    finally { setLoading(false) }
  }

  useEffect(() => { loadPatients() }, [])
  useEffect(() => { const t = setTimeout(() => loadPatients(search), 400); return () => clearTimeout(t) }, [search])

  // Load tests when bill modal opens, or doctors when edit modal opens
  useEffect(() => {
    if (showBillModal) {
      testAPI.getAll().then(r => setAllTests(r.data.data || [])).catch(() => {})
      doctorAPI.getAll().then(r => setDoctorList(r.data.data || [])).catch(() => {})
    }
  }, [showBillModal])

  // Load doctors when edit modal opens
  useEffect(() => {
    if (showEditModal) {
      doctorAPI.getAll().then(r => setDoctorList(r.data.data || [])).catch(() => {})
    }
  }, [showEditModal])

  const [doctorList, setDoctorList] = useState([])

  // ── Test catalog filtering ─────────────────────────────────────────────────
  const testCategories = useMemo(() => ['All', ...new Set(allTests.map(t => t.category))], [allTests])

  const filteredTests = useMemo(() => {
    return allTests.filter(t => {
      const matchSearch = t.name.toLowerCase().includes(testSearch.toLowerCase()) || (t.code || '').toLowerCase().includes(testSearch.toLowerCase())
      const matchCat = testCategory === 'All' || t.category === testCategory
      return matchSearch && matchCat && t.isActive !== false
    })
  }, [allTests, testSearch, testCategory])

  // ── Toggle test selection ──────────────────────────────────────────────────
  const toggleTest = (test) => {
    setSelectedTests(prev => {
      const exists = prev.find(t => t._id === test._id)
      if (exists) return prev.filter(t => t._id !== test._id)
      return [...prev, { testId: test._id, name: test.name, price: test.price, category: test.category, code: test.code }]
    })
  }

  const removeTest = (testId) => {
    setSelectedTests(prev => prev.filter(t => t.testId !== testId))
  }

  // ── Invoice calculations ───────────────────────────────────────────────────
  const subtotal = selectedTests.reduce((s, t) => s + t.price, 0)
  const discountAmount = (subtotal * discount) / 100
  const taxableAmount = subtotal - discountAmount
  const gstAmount = (taxableAmount * gstPercent) / 100
  const totalAmount = taxableAmount + gstAmount

  // ── Reset bill modal ───────────────────────────────────────────────────────
  const resetBillModal = () => {
    setShowBillModal(false)
    setBillStep(1)
    setPatientForm({ name:'', phone:'', age:'', gender:'male', address:'', referredBy:'' })
    setSelectedTests([])
    setTestSearch('')
    setTestCategory('All')
    setDiscount(0)
    setGstPercent(0)
    setPaymentMode('cash')
    setPaidAmount(0)
    setNotes('')
    setCreatedBill(null)
  }

  // ── Step 1: Validate & proceed to tests ────────────────────────────────────
  const handleStep1Next = () => {
    if (!patientForm.name.trim()) return toast.error('Patient name is required')
    if (!patientForm.phone.trim() || patientForm.phone.length < 10) return toast.error('Valid phone number is required')
    setBillStep(2)
  }

  // ── Step 2: Proceed to invoice ─────────────────────────────────────────────
  const handleStep2Next = () => {
    if (selectedTests.length === 0) return toast.error('Select at least one test')
    setPaidAmount(totalAmount) // default full payment
    setBillStep(3)
  }

  // ── Step 3: Create patient + bill ──────────────────────────────────────────
  const handleCreateBill = async () => {
    setCreating(true)
    try {
      // 1. Create patient
      const patRes = await patientAPI.create({
        name: patientForm.name.trim(),
        phone: patientForm.phone.trim(),
        age: patientForm.age ? Number(patientForm.age) : undefined,
        gender: patientForm.gender,
        address: patientForm.address.trim() || undefined,
        referredBy: patientForm.referredBy || undefined,
      })
      const newPatient = patRes.data.data

      // 2. Create bill
      const billRes = await billingAPI.create({
        patientId: newPatient._id,
        tests: selectedTests.map(t => ({ testId: t.testId, price: t.price })),
        discount: discountAmount,
        gstPercent,
        paidAmount,
        paymentMode,
        referredBy: patientForm.referredBy || undefined,
        collectionType: 'walkin',
        notes: notes || undefined,
      })
      const bill = billRes.data.data
      setCreatedBill(bill)
      setPatients(prev => [newPatient, ...prev])
      toast.success(`✅ Patient registered & bill ${bill.invoiceNo} created!`)
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Failed to create bill'))
    } finally {
      setCreating(false)
    }
  }

  // ── Edit patient ───────────────────────────────────────────────────────────
  const handleEdit = (row) => {
    setEditingPatientId(row._id)
    setEditForm({
      name: row.name || '',
      phone: row.phone || '',
      age: row.age ? String(row.age) : '',
      gender: row.gender || 'male',
      address: row.address || '',
      referredBy: row.referredBy?._id || row.referredBy || '',
    })
    setShowEditModal(true)
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    if (!editForm.name.trim()) return toast.error('Patient name is required')
    if (!editForm.phone.trim() || editForm.phone.length < 10) return toast.error('Valid phone number is required')
    setSaving(true)
    try {
      const payload = {
        name: editForm.name.trim(),
        phone: editForm.phone.trim(),
        age: editForm.age ? Number(editForm.age) : undefined,
        gender: editForm.gender,
        address: editForm.address.trim() || undefined,
        referredBy: editForm.referredBy || undefined,
      }
      const res = await patientAPI.update(editingPatientId, payload)
      setPatients(prev => prev.map(p => p._id === editingPatientId ? res.data.data : p))
      toast.success('Patient updated!')
      setShowEditModal(false)
    } catch (err) { toast.error(apiErrorMessage(err, 'Failed to update patient')) }
    finally { setSaving(false) }
  }

  // ── View patient ───────────────────────────────────────────────────────────
  const handleView = async (row) => {
    try {
      const res = await patientAPI.getOne(row._id)
      // Backend sends: { success: true, data: { patient: {...}, bills: [...], reports: [...] } }
      setSelectedPatient(res.data.data.patient)
    } catch {
      setSelectedPatient(row)
    }
    setShowViewModal(true)
  }

  return (
    <div>
      <PageHeader title="Patient Management" subtitle={`${patients.length} patients`}
        actions={<>
          <SearchBar value={search} onChange={setSearch} placeholder="Search patients..." />
          <button onClick={() => { resetBillModal(); setShowBillModal(true) }} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all">
            <Plus size={16} /> Register & Bill
          </button>
        </>}
      />

      {/* Patient Table */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading...</div>
        ) : (
          <Table
            columns={[
              { key: 'patientId', label: 'ID' },
              { key: 'name', label: 'Patient', render: (v, row) => (
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-brand-500/15 text-brand-400 flex items-center justify-center text-xs font-semibold">
                    {v.split(' ').map(n=>n[0]).join('')}
                  </div>
                  <div><p className="font-medium text-slate-300">{v}</p><p className="text-xs text-slate-500">{row.phone}</p></div>
                </div>
              )},
              { key: 'age', label: 'Age/Gender', render: (v, row) => `${v||'?'}y · ${row.gender}` },
              { key: 'referredBy', label: 'Referred By', render: v => v?.name || '—' },
              { key: 'totalVisits', label: 'Visits' },
              { key: 'createdAt', label: 'Registered', render: v => new Date(v).toLocaleDateString('en-IN') },
            ]}
            data={patients}
            actions={(row) => (
              <div className="flex items-center gap-2">
                <Tooltip label="View Patient Details">
                  <button onClick={() => handleView(row)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={12} /> View</button>
                </Tooltip>
                <Tooltip label="Edit Patient">
                  <button onClick={() => handleEdit(row)} className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><span className="text-base leading-none">✏️</span> Edit</button>
                </Tooltip>
                <Tooltip label="Delete Patient">
                  <button onClick={async () => {
                    if (!window.confirm('Delete patient ' + row.name + '? This action cannot be undone.')) return
                    try {
                      await patientAPI.delete(row._id)
                      setPatients(prev => prev.filter(p => p._id !== row._id))
                      toast.success('Patient ' + row.name + ' deleted')
                    } catch (err) { toast.error(apiErrorMessage(err, 'Failed to delete patient')) }
                  }} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><span className="text-base leading-none">🗑️</span> Delete</button>
                </Tooltip>
              </div>
            )}
          />
        )}
      </div>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  REGISTER & BILL MODAL — 3-STEP WIZARD                               */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <Modal open={showBillModal} onClose={resetBillModal} title={createdBill ? 'Bill Created!' : `Register & Bill — Step ${billStep} of 3`} size="lg">
        {createdBill ? (
          /* ── SUCCESS ─────────────────────────────────────────────── */
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-green-500/15 flex items-center justify-center mx-auto">
              <CheckCircle size={32} className="text-green-400" />
            </div>
            <div>
              <p className="text-lg font-semibold text-slate-100">Registration & Billing Complete!</p>
              <p className="text-sm text-slate-500 mt-1">Patient: <strong className="text-slate-300">{patientForm.name}</strong> · Invoice: <strong className="text-brand-400">{createdBill.invoiceNo}</strong></p>
            </div>
            <div className="bg-surface-850 rounded-xl p-4 text-sm max-w-sm mx-auto">
              <div className="flex justify-between py-1"><span className="text-slate-500">Tests:</span><span className="text-slate-200">{selectedTests.length} selected</span></div>
              <div className="flex justify-between py-1"><span className="text-slate-500">Total:</span><span className="text-brand-400 font-bold">₹{totalAmount.toLocaleString()}</span></div>
              <div className="flex justify-between py-1"><span className="text-slate-500">Paid:</span><span className="text-green-400 font-bold">₹{paidAmount.toLocaleString()}</span></div>
              {totalAmount - paidAmount > 0 && <div className="flex justify-between py-1"><span className="text-slate-500">Due:</span><span className="text-amber-400 font-bold">₹{(totalAmount - paidAmount).toLocaleString()}</span></div>}
            </div>
            <div className="flex gap-2 justify-center">
              <button onClick={resetBillModal} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-6 py-2 rounded-xl text-sm">Done</button>
              <button onClick={() => { resetBillModal(); setTimeout(() => setShowBillModal(true), 100) }} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-6 py-2 rounded-xl text-sm font-medium">Add Another</button>
            </div>
          </div>
        ) : (
          <>
            {/* ── Step indicator ─────────────────────────────────────── */}
            <div className="flex items-center gap-2 mb-6">
              {[1,2,3].map(s => (
                <React.Fragment key={s}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${billStep >= s ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-500'}`}>
                    {billStep > s ? '✓' : s}
                  </div>
                  <span className={`text-xs font-medium ${billStep >= s ? 'text-brand-400' : 'text-slate-500'}`}>{s === 1 ? 'Patient' : s === 2 ? 'Tests' : 'Invoice'}</span>
                  {s < 3 && <div className={`flex-1 h-0.5 ${billStep > s ? 'bg-brand-500' : 'bg-surface-700'}`} />}
                </React.Fragment>
              ))}
            </div>

            {/* ── STEP 1: Patient Details ────────────────────────────── */}
            {billStep === 1 && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Full Name *</label>
                    <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. Rahul Sharma" value={patientForm.name} onChange={e => setPatientForm({...patientForm, name: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Phone Number *</label>
                    <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="10-digit mobile" maxLength={10} value={patientForm.phone} onChange={e => setPatientForm({...patientForm, phone: e.target.value.replace(/\D/g,'').slice(0,10)})} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Age</label>
                    <input type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Age" value={patientForm.age} onChange={e => setPatientForm({...patientForm, age: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Gender</label>
                    <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={patientForm.gender} onChange={e => setPatientForm({...patientForm, gender: e.target.value})}>
                      <option value="male">Male</option><option value="female">Female</option><option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Address</label>
                  <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Full address (optional)" value={patientForm.address} onChange={e => setPatientForm({...patientForm, address: e.target.value})} />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Referred By</label>
                  <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={patientForm.referredBy} onChange={e => setPatientForm({...patientForm, referredBy: e.target.value})}>
                    <option value="">Self (No referral)</option>
                    {doctorList.map(d => <option key={d._id} value={d._id}>{d.name} — {d.speciality}</option>)}
                  </select>
                </div>
                <div className="flex justify-end pt-2">
                  <button onClick={handleStep1Next} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-6 py-2 rounded-xl text-sm">Next — Select Tests →</button>
                </div>
              </div>
            )}

            {/* ── STEP 2: Test Selection ─────────────────────────────── */}
            {billStep === 2 && (
              <div className="space-y-3">
                {/* Search & category filter */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="relative flex-1">
                    <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input className="w-full bg-surface-850 border border-surface-700 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Search 150+ tests by name or code..." value={testSearch} onChange={e => setTestSearch(e.target.value)} />
                  </div>
                  <select className="bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={testCategory} onChange={e => setTestCategory(e.target.value)}>
                    {testCategories.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>

                {/* Selected tests summary */}
                {selectedTests.length > 0 && (
                  <div className="bg-brand-500/10 border border-brand-500/20 rounded-xl p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-brand-400">{selectedTests.length} test(s) selected — ₹{subtotal.toLocaleString()}</span>
                      <button onClick={() => setSelectedTests([])} className="text-xs text-red-400 hover:text-red-300">Clear all</button>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedTests.map(t => (
                        <span key={t.testId} className="inline-flex items-center gap-1 bg-brand-500/15 text-brand-300 text-xs px-2 py-1 rounded-lg">
                          {t.name} — ₹{t.price}
                          <button onClick={() => removeTest(t.testId)} className="ml-0.5 hover:text-red-400">×</button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Test catalog */}
                <div className="border border-surface-700 rounded-xl max-h-[45vh] overflow-y-auto">
                  {filteredTests.length === 0 ? (
                    <div className="p-8 text-center text-slate-500 text-sm">No tests found matching "{testSearch}"</div>
                  ) : (
                    <div className="divide-y divide-surface-800">
                      {filteredTests.map(t => {
                        const isSelected = selectedTests.some(s => s.testId === t._id)
                        return (
                          <button key={t._id} onClick={() => toggleTest(t)} className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all ${isSelected ? 'bg-brand-500/10' : 'hover:bg-surface-850'}`}>
                            <div className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${isSelected ? 'border-brand-500 bg-brand-500' : 'border-surface-600'}`}>
                              {isSelected && <Check size={12} className="text-surface-950" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <p className={`text-sm font-medium truncate ${isSelected ? 'text-brand-300' : 'text-slate-300'}`}>{t.name}</p>
                                {t.code && <span className="text-[10px] text-slate-500 bg-surface-800 px-1.5 py-0.5 rounded font-mono">{t.code}</span>}
                              </div>
                              <p className="text-xs text-slate-500">{t.category} · {t.tat} · {t.sampleType}</p>
                            </div>
                            <span className={`text-sm font-bold flex-shrink-0 ${isSelected ? 'text-brand-400' : 'text-slate-400'}`}>₹{t.price}</span>
                          </button>
                        )
                      })}
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-2">
                  <button onClick={() => setBillStep(1)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">← Back</button>
                  <button onClick={handleStep2Next} disabled={selectedTests.length === 0} className={`px-6 py-2 rounded-xl text-sm font-semibold transition-all ${selectedTests.length > 0 ? 'bg-brand-500 hover:bg-brand-600 text-surface-950' : 'bg-surface-800 text-slate-500 cursor-not-allowed'}`}>
                    Next — Generate Invoice →
                  </button>
                </div>
              </div>
            )}

            {/* ── STEP 3: Invoice Preview & Payment ──────────────────── */}
            {billStep === 3 && (
              <div className="grid md:grid-cols-5 gap-4">
                {/* Left: Invoice */}
                <div className="md:col-span-3 space-y-3">
                  <div className="bg-surface-850 rounded-xl p-4 border border-surface-700">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-semibold text-slate-200">{patientForm.name}</p>
                        <p className="text-xs text-slate-500">{patientForm.phone} · {patientForm.age || '?'}y · {patientForm.gender}</p>
                      </div>
                      <span className="text-xs bg-brand-500/10 text-brand-400 px-2 py-1 rounded-lg font-medium">NEW PATIENT</span>
                    </div>
                    <div className="border-t border-surface-700 pt-3">
                      <p className="text-xs font-semibold text-slate-500 mb-2">TESTS ({selectedTests.length})</p>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto">
                        {selectedTests.map((t, i) => (
                          <div key={i} className="flex items-center justify-between text-sm">
                            <span className="text-slate-400 truncate mr-2">{i+1}. {t.name}</span>
                            <span className="text-slate-200 font-medium flex-shrink-0">₹{t.price}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Discount / GST */}
                  <div className="bg-surface-850 rounded-xl p-4 border border-surface-700 space-y-3">
                    <p className="text-xs font-semibold text-slate-500">ADJUSTMENTS</p>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-slate-500 mb-1">Discount (%)</label>
                        <input type="number" min={0} max={100} className="w-full bg-surface-900 border border-surface-700 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={discount} onChange={e => setDiscount(Math.min(100, Math.max(0, Number(e.target.value))))} />
                      </div>
                      <div>
                        <label className="block text-xs text-slate-500 mb-1">GST (%)</label>
                        <input type="number" min={0} max={28} className="w-full bg-surface-900 border border-surface-700 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={gstPercent} onChange={e => setGstPercent(Math.min(28, Math.max(0, Number(e.target.value))))} />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs text-slate-500 mb-1">Notes (optional)</label>
                      <input className="w-full bg-surface-900 border border-surface-700 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Any special instructions..." value={notes} onChange={e => setNotes(e.target.value)} />
                    </div>
                  </div>
                </div>

                {/* Right: Payment summary */}
                <div className="md:col-span-2 space-y-3">
                  <div className="bg-surface-850 rounded-xl p-4 border border-surface-700 sticky top-6">
                    <p className="text-xs font-semibold text-slate-500 mb-3">INVOICE SUMMARY</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-slate-500">Subtotal ({selectedTests.length} tests)</span><span className="text-slate-200">₹{subtotal.toLocaleString()}</span></div>
                      {discount > 0 && <div className="flex justify-between text-green-400"><span>Discount ({discount}%)</span><span>-₹{discountAmount.toLocaleString()}</span></div>}
                      {gstPercent > 0 && <div className="flex justify-between"><span className="text-slate-500">GST ({gstPercent}%)</span><span className="text-slate-200">₹{gstAmount.toLocaleString()}</span></div>}
                      <div className="border-t border-surface-700 pt-2 flex justify-between font-bold"><span className="text-slate-200">Total</span><span className="text-brand-400 text-xl">₹{totalAmount.toLocaleString()}</span></div>
                    </div>

                    {/* Payment mode */}
                    <div className="mt-4 space-y-3">
                      <p className="text-xs font-semibold text-slate-500">PAYMENT</p>
                      <div className="grid grid-cols-4 gap-1.5">
                        {['cash','upi','card','credit'].map(m => (
                          <button key={m} onClick={() => setPaymentMode(m)} className={`py-1.5 rounded-lg text-xs font-medium transition-all ${paymentMode === m ? 'bg-brand-500 text-surface-950' : 'bg-surface-900 text-slate-500 border border-surface-700 hover:text-slate-300'}`}>{m.charAt(0).toUpperCase()+m.slice(1)}</button>
                        ))}
                      </div>
                      <div>
                        <label className="block text-xs text-slate-500 mb-1">Paid Amount</label>
                        <input type="number" min={0} max={totalAmount} className="w-full bg-surface-900 border border-surface-700 rounded-xl px-3 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={paidAmount} onChange={e => setPaidAmount(Math.min(totalAmount, Math.max(0, Number(e.target.value))))} />
                      </div>
                      {paidAmount < totalAmount && (
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-500">Due Amount</span>
                          <span className="text-amber-400 font-bold">₹{(totalAmount - paidAmount).toLocaleString()}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 mt-4">
                      <button onClick={() => setBillStep(2)} className="flex-1 bg-surface-900 hover:bg-surface-800 text-slate-300 border border-surface-700 py-2.5 rounded-xl text-sm font-medium">Back</button>
                      <button onClick={handleCreateBill} disabled={creating} className="flex-1 bg-brand-500 hover:bg-brand-600 text-surface-950 font-bold py-2.5 rounded-xl text-sm transition-all disabled:opacity-60 flex items-center justify-center gap-1">
                        {creating ? 'Creating...' : <><FileText size={14} /> Create & Print</>}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </Modal>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  EDIT PATIENT MODAL                                                   */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <Modal open={showEditModal} onClose={() => setShowEditModal(false)} title="Edit Patient" size="md">
        <form onSubmit={handleEditSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Full Name *</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="e.g. Rahul Sharma" value={editForm.name} onChange={e => setEditForm({...editForm, name: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Phone Number *</label>
              <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="10-digit mobile" maxLength={10} value={editForm.phone} onChange={e => setEditForm({...editForm, phone: e.target.value.replace(/\D/g,'').slice(0,10)})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Age</label>
              <input type="number" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Age" value={editForm.age} onChange={e => setEditForm({...editForm, age: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Gender</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={editForm.gender} onChange={e => setEditForm({...editForm, gender: e.target.value})}>
                <option value="male">Male</option><option value="female">Female</option><option value="other">Other</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Address</label>
            <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Full address (optional)" value={editForm.address} onChange={e => setEditForm({...editForm, address: e.target.value})} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Referred By</label>
            <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={editForm.referredBy} onChange={e => setEditForm({...editForm, referredBy: e.target.value})}>
              <option value="">Self (No referral)</option>
              {doctorList.map(d => <option key={d._id} value={d._id}>{d.name} — {d.speciality}</option>)}
            </select>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowEditModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" disabled={saving} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-6 py-2 rounded-xl text-sm transition-all disabled:opacity-60 flex items-center gap-1">{saving ? 'Saving...' : <><span className="text-base leading-none">💾</span> Save Changes</>}</button>
          </div>
        </form>
      </Modal>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/*  VIEW PATIENT MODAL                                                   */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <Modal open={showViewModal} onClose={() => setShowViewModal(false)} title="Patient Details" size="lg">
        {selectedPatient && (
          <div className="space-y-4">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-full bg-brand-500/15 text-brand-400 flex items-center justify-center text-xl font-bold">
                {selectedPatient.name?.split(' ').map(n=>n[0]).join('')}
              </div>
              <div>
                <p className="text-lg font-semibold text-slate-100">{selectedPatient.name}</p>
                <p className="text-sm text-slate-500">ID: {selectedPatient.patientId || selectedPatient._id}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="bg-surface-850 rounded-xl p-3">
                <div className="flex items-center gap-2 text-slate-500 mb-1"><Phone size={14} /> Phone</div>
                <p className="text-slate-200 font-medium">{selectedPatient.phone || '—'}</p>
              </div>
              <div className="bg-surface-850 rounded-xl p-3">
                <div className="flex items-center gap-2 text-slate-500 mb-1"><User size={14} /> Age / Gender</div>
                <p className="text-slate-200 font-medium">{selectedPatient.age || '?'} years · {selectedPatient.gender}</p>
              </div>
              <div className="bg-surface-850 rounded-xl p-3">
                <div className="flex items-center gap-2 text-slate-500 mb-1"><Calendar size={14} /> Registered</div>
                <p className="text-slate-200 font-medium">{selectedPatient.createdAt ? new Date(selectedPatient.createdAt).toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' }) : '—'}</p>
              </div>
              <div className="bg-surface-850 rounded-xl p-3">
                <div className="flex items-center gap-2 text-slate-500 mb-1"><User size={14} /> Referred By</div>
                <p className="text-slate-200 font-medium">{selectedPatient.referredBy?.name || 'Self'}</p>
              </div>
            </div>
            {selectedPatient.address && (
              <div className="bg-surface-850 rounded-xl p-3">
                <div className="flex items-center gap-2 text-slate-500 mb-1"><MapPin size={14} /> Address</div>
                <p className="text-slate-200 font-medium">{selectedPatient.address}</p>
              </div>
            )}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-surface-850 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-brand-400">{selectedPatient.totalVisits || 0}</p>
                <p className="text-xs text-slate-500">Total Visits</p>
              </div>
              <div className="bg-surface-850 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-blue-400">{selectedPatient.totalTests || 0}</p>
                <p className="text-xs text-slate-500">Tests Done</p>
              </div>
              <div className="bg-surface-850 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-green-400">₹{(selectedPatient.totalPaid || 0).toLocaleString()}</p>
                <p className="text-xs text-slate-500">Total Paid</p>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  DOCTORS
// ═══════════════════════════════════════════════════════════════════════════════
export function Doctors() {
  const [doctors, setDoctors] = useState([])
  const [showModal, setShowModal] = useState(false)
  const [editingDoctor, setEditingDoctor] = useState(null) // null = add mode, object = edit mode
  const [form, setForm] = useState({ name:'', phone:'', speciality:'', commission:10 })

  useEffect(() => {
    doctorAPI.getAll().then(r => setDoctors(r.data.data)).catch(()=>{})
  }, [])

  const resetForm = () => {
    setForm({ name:'', phone:'', speciality:'', commission:10 })
    setEditingDoctor(null)
  }

  const handleOpenAdd = () => {
    resetForm()
    setShowModal(true)
  }

  const handleEdit = (doctor) => {
    setEditingDoctor(doctor)
    setForm({
      name: doctor.name || '',
      phone: doctor.phone || '',
      speciality: doctor.speciality || '',
      commission: doctor.commission ?? 10,
    })
    setShowModal(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.name.trim() || !form.phone.trim()) return toast.error('Name and phone are required')
    // Ensure commission is sent as a number
    const payload = { ...form, commission: Number(form.commission) }
    try {
      if (editingDoctor) {
        const res = await doctorAPI.update(editingDoctor._id, payload)
        setDoctors(d => d.map(doc => doc._id === editingDoctor._id ? res.data.data : doc))
        toast.success('Doctor updated!')
      } else {
        const res = await doctorAPI.create(payload)
        setDoctors(d => [...d, res.data.data])
        toast.success('Doctor added!')
      }
      setShowModal(false)
      resetForm()
    } catch (err) { toast.error(apiErrorMessage(err, 'Error')) }
  }

  return (
    <div>
      <PageHeader title="Doctor Management" subtitle="Referring doctors & commissions"
        actions={<button onClick={handleOpenAdd} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all"><Plus size={16} />Add Doctor</button>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'name', label: 'Doctor' },
            { key: 'speciality', label: 'Speciality' },
            { key: 'phone', label: 'Phone' },
            { key: 'commission', label: 'Commission', render: v => `${v}%` },
          ]}
          data={doctors}
          actions={(row) => (
            <>
              <button onClick={() => handleEdit(row)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all">Edit</button>
              <button onClick={async () => {
                if (!window.confirm(`Deactivate ${row.name}? They will no longer appear as a referring doctor.`)) return
                try {
                  await doctorAPI.delete(row._id)
                  setDoctors(d => d.filter(doc => doc._id !== row._id))
                  toast.success(`${row.name} deactivated`)
                } catch (err) { toast.error(apiErrorMessage(err, 'Failed to deactivate')) }
              }} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all">Deactivate</button>
            </>
          )}
        />
      </div>
      <Modal open={showModal} onClose={() => { setShowModal(false); resetForm() }} title={editingDoctor ? 'Edit Doctor' : 'Add Doctor'}>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Name*', key:'name', placeholder:"Dr. Full Name" },
              { label:'Phone*', key:'phone', placeholder:'Mobile' },
              { label:'Speciality', key:'speciality', placeholder:'Speciality' },
              { label:'Commission %', key:'commission', placeholder:'10', type:'number' },
            ].map(f => (
              <div key={f.key}>
                <label htmlFor={`doctor-${f.key}`} className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input id={`doctor-${f.key}`} type={f.type||'text'} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder={f.placeholder}
                  value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => { setShowModal(false); resetForm() }} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">
              {editingDoctor ? 'Update Doctor' : 'Add Doctor'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TESTS
// ═══════════════════════════════════════════════════════════════════════════════
export function Tests() {
  const [tests, setTests] = useState([])
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name:'', code:'', category:'Biochemistry', price:'', tat:'', sampleType:'' })

  const load = async () => {
    try { const r = await testAPI.getAll(); setTests(r.data.data) } catch {}
  }
  useEffect(() => { load() }, [])

  const handleCreate = async (e) => {
    e.preventDefault()
    try {
      await testAPI.create(form); await load()
      setShowModal(false); setForm({ name:'', code:'', category:'Biochemistry', price:'', tat:'', sampleType:'' }); toast.success('Test created!')
    } catch (err) { toast.error(apiErrorMessage(err, 'Error')) }
  }

  const filtered = tests.filter(t => t.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div>
      <PageHeader title="Test Management" subtitle={`${tests.length} tests`}
        actions={<>
          <SearchBar value={search} onChange={setSearch} placeholder="Search tests..." />
          <button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all"><Plus size={16} />Add Test</button>
        </>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'code', label: 'Code' },
            { key: 'name', label: 'Test Name' },
            { key: 'category', label: 'Category' },
            { key: 'price', label: 'Price', render: v => `₹${v}` },
            { key: 'tat', label: 'TAT' },
            { key: 'sampleType', label: 'Sample' },
            { key: 'isActive', label: 'Status', render: v => <Badge status={v !== false ? 'active' : 'inactive'} /> },
          ]}
          data={filtered}
          actions={row => (
            <button onClick={async () => { if(window.confirm('Disable this test?')) { await testAPI.delete(row._id); load() } }}
              className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium">Disable</button>
          )}
        />
      </div>
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Add New Test">
        <form onSubmit={handleCreate} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Test Name*', key:'name', placeholder:'e.g. CBC' },
              { label:'Code', key:'code', placeholder:'e.g. CBC' },
              { label:'Price (₹)*', key:'price', placeholder:'350', type:'number' },
              { label:'TAT', key:'tat', placeholder:'4 hrs' },
              { label:'Sample Type', key:'sampleType', placeholder:'Blood-EDTA' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input type={f.type||'text'} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder={f.placeholder}
                  value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Category</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
                {['Haematology','Coagulation','Biochemistry','Lipid Profile','Cardiac Markers','Thyroid','Hormones','Liver','Kidney','Diabetes','Vitamins','Urine','Microbiology','Serology','Immunology','Autoimmune','Infectious Disease','Stool','Oncology Markers','Cardiac Risk','Nutrition','Panels'].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Create Test</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
