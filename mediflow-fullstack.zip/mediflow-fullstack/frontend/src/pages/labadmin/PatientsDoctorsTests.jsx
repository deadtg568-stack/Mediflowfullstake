import React, { useState, useEffect } from 'react'
import { Plus } from 'lucide-react'
import { PageHeader, Table, Badge, SearchBar, Modal } from '../../components/UI'
import { patientAPI, doctorAPI, testAPI, apiErrorMessage } from '../../utils/api'
import toast from 'react-hot-toast'

export function Patients() {
  const [patients, setPatients] = useState([])
  const [search, setSearch]     = useState('')
  const [loading, setLoading]   = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name:'', phone:'', age:'', gender:'male', address:'' })

  const load = async (q = '') => {
    setLoading(true)
    try {
      const res = await patientAPI.getAll({ search: q, limit: 50 })
      setPatients(res.data.data.patients)
    } catch { toast.error('Failed to load patients') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])
  useEffect(() => { const t = setTimeout(() => load(search), 400); return () => clearTimeout(t) }, [search])

  const handleCreate = async (e) => {
    e.preventDefault()
    try {
      const res = await patientAPI.create(form)
      setPatients(p => [res.data.data, ...p])
      setShowModal(false)
      setForm({ name:'', phone:'', age:'', gender:'male', address:'' })
      toast.success('Patient registered!')
    } catch (err) { toast.error(apiErrorMessage(err, 'Error')) }
  }

  return (
    <div>
      <PageHeader title="Patient Management" subtitle={`${patients.length} patients`}
        actions={<>
          <SearchBar value={search} onChange={setSearch} placeholder="Search patients..." />
          <button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all">
            <Plus size={16} /> Add Patient
          </button>
        </>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading...</div>
        ) : (
          <Table
            columns={[
              { key: 'patientId', label: 'ID' },
              { key: 'name', label: 'Patient', render: (v, row) => (
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-brand-500/15 text-brand-400 flex items-center justify-center text-xs font-semibold">
                    {v.split(' ').map(n=>n[0]).join('')}
                  </div>
                  <div><p className="font-medium text-slate-300">{v}</p><p className="text-xs text-slate-500">{row.phone}</p></div>
                </div>
              )},
              { key: 'age', label: 'Age/Gender', render: (v, row) => `${v||'?'}y · ${row.gender}` },
              { key: 'referredBy', label: 'Referred By', render: v => v?.name || '—' },
              { key: 'totalVisits', label: 'Visits' },
              { key: 'createdAt', label: 'Registered', render: v => new Date(v).toLocaleDateString('en-IN') },
            ]}
            data={patients}
            actions={() => (
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all">View</button>
            )}
          />
        )}
      </div>
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Register New Patient">
        <form onSubmit={handleCreate} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Full Name*', key:'name', placeholder:'Patient name' },
              { label:'Phone*', key:'phone', placeholder:'10-digit mobile' },
              { label:'Age', key:'age', placeholder:'Age', type:'number' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input type={f.type||'text'} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder={f.placeholder}
                  value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Gender</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={form.gender} onChange={e => setForm({...form, gender: e.target.value})}>
                <option value="male">Male</option><option value="female">Female</option><option value="other">Other</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Register</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

export function Doctors() {
  const [doctors, setDoctors] = useState([])
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name:'', phone:'', speciality:'', commission:10 })

  useEffect(() => {
    doctorAPI.getAll().then(r => setDoctors(r.data.data)).catch(()=>{})
  }, [])

  const handleCreate = async (e) => {
    e.preventDefault()
    try {
      const res = await doctorAPI.create(form)
      setDoctors(d => [...d, res.data.data])
      setShowModal(false)
      toast.success('Doctor added!')
    } catch (err) { toast.error(apiErrorMessage(err, 'Error')) }
  }

  return (
    <div>
      <PageHeader title="Doctor Management" subtitle="Referring doctors & commissions"
        actions={<button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all"><Plus size={16} />Add Doctor</button>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'name', label: 'Doctor' },
            { key: 'speciality', label: 'Speciality' },
            { key: 'phone', label: 'Phone' },
            { key: 'commission', label: 'Commission', render: v => `${v}%` },
          ]}
          data={doctors}
          actions={() => <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium">Edit</button>}
        />
      </div>
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Add Doctor">
        <form onSubmit={handleCreate} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Name*', key:'name', placeholder:"Dr. Full Name" },
              { label:'Phone*', key:'phone', placeholder:'Mobile' },
              { label:'Speciality', key:'speciality', placeholder:'Speciality' },
              { label:'Commission %', key:'commission', placeholder:'10', type:'number' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input type={f.type||'text'} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder={f.placeholder}
                  value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Add Doctor</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

export function Tests() {
  const [tests, setTests] = useState([])
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name:'', code:'', category:'Biochemistry', price:'', tat:'', sampleType:'' })

  const load = async () => {
    try { const r = await testAPI.getAll(); setTests(r.data.data) } catch {}
  }
  useEffect(() => { load() }, [])

  const handleCreate = async (e) => {
    e.preventDefault()
    try {
      await testAPI.create(form); await load()
      setShowModal(false); toast.success('Test created!')
    } catch (err) { toast.error(apiErrorMessage(err, 'Error')) }
  }

  const filtered = tests.filter(t => t.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div>
      <PageHeader title="Test Management" subtitle={`${tests.length} tests`}
        actions={<>
          <SearchBar value={search} onChange={setSearch} placeholder="Search tests..." />
          <button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition-all"><Plus size={16} />Add Test</button>
        </>}
      />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'code', label: 'Code' },
            { key: 'name', label: 'Test Name' },
            { key: 'category', label: 'Category' },
            { key: 'price', label: 'Price', render: v => `₹${v}` },
            { key: 'tat', label: 'TAT' },
            { key: 'sampleType', label: 'Sample' },
            { key: 'isActive', label: 'Status', render: v => <Badge status={v ? 'active' : 'inactive'} /> },
          ]}
          data={filtered}
          actions={row => (
            <button onClick={async () => { if(window.confirm('Disable this test?')) { await testAPI.delete(row._id); load() } }}
              className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs font-medium">Disable</button>
          )}
        />
      </div>
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Add New Test">
        <form onSubmit={handleCreate} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Test Name*', key:'name', placeholder:'e.g. CBC' },
              { label:'Code', key:'code', placeholder:'e.g. CBC' },
              { label:'Price (₹)*', key:'price', placeholder:'350', type:'number' },
              { label:'TAT', key:'tat', placeholder:'4 hrs' },
              { label:'Sample Type', key:'sampleType', placeholder:'Blood-EDTA' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                <input type={f.type||'text'} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder={f.placeholder}
                  value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Category</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40"
                value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
                {['Haematology','Biochemistry','Immunology','Urine','Microbiology','Serology','Hormones'].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Create Test</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
