import React, { useState } from 'react'
import { PageHeader, Badge, StatCard, Table } from '../../components/UI'
import { FileText, Users, TrendingUp, Heart, Activity } from 'lucide-react'
import { mockPatients, mockDoctors, revenueData } from '../../utils/mockData'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

export function DoctorDashboard() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-100">Doctor Portal</h1>
        <p className="text-sm text-slate-500">Dr. Rajesh Mehta · General Physician</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="My Patients" value="45" sub="referred this month" color="blue" trend={12} />
        <StatCard icon={FileText} label="Reports Ready" value="8" sub="awaiting review" color="green" />
        <StatCard icon={TrendingUp} label="Referral Revenue" value="₹54,000" sub="this month" color="purple" />
        <StatCard icon={Activity} label="Pending Reports" value="3" color="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 card p-5">
          <p className="font-semibold text-slate-300 mb-4">Recent Patient Reports</p>
          <div className="space-y-3">
            {mockPatients.slice(0,4).map(p => (
              <div key={p.id} className="flex items-center gap-3 p-3 bg-surface-850 rounded-xl">
                <div className="w-9 h-9 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center text-xs font-semibold">
                  {p.name.split(' ').map(n=>n[0]).join('')}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-sm text-slate-300">{p.name}</p>
                  <p className="text-xs text-slate-500">{p.tests.join(', ')} · {p.date}</p>
                </div>
                <Badge status={p.status} />
                <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">View</button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Referral Summary</p>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={revenueData}>
              <XAxis dataKey="month" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip />
              <Line type="monotone" dataKey="patients" stroke="#f43f5e" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-3 pt-3 border-t border-surface-700">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Commission rate</span>
              <span className="font-semibold text-slate-300">10%</span>
            </div>
            <div className="flex justify-between text-sm mt-1">
              <span className="text-slate-500">This month earned</span>
              <span className="font-semibold text-brand-400">₹5,400</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export function PatientReports() {
  const [search, setSearch] = useState('')
  const filtered = mockPatients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()))
  return (
    <div>
      <PageHeader title="Patient Reports" subtitle="All reports for your referred patients" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700">
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search patient name..."
            className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all w-64"
          />
        </div>
        <Table
          columns={[
            { key: 'id', label: 'ID' },
            { key: 'name', label: 'Patient', render: (v, row) => (
              <div>
                <p className="font-medium text-slate-300">{v}</p>
                <p className="text-xs text-slate-500">{row.age}y · {row.gender}</p>
              </div>
            )},
            { key: 'tests', label: 'Tests', render: v => v.join(', ') },
            { key: 'date', label: 'Date' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={filtered}
          actions={() => (
            <>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">View Report</button>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Download</button>
            </>
          )}
        />
      </div>
    </div>
  )
}

export function PatientHistory() {
  return (
    <div>
      <PageHeader title="Patient History" subtitle="Longitudinal patient test records" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <div className="mb-4">
          <label className="block text-xs font-medium text-slate-500 mb-1">Search Patient</label>
          <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all w-80" placeholder="Enter patient name or phone..." />
        </div>
        <div className="text-center py-12">
          <Heart size={40} className="text-slate-200 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Search for a patient to view their test history</p>
          <p className="text-slate-300 text-xs mt-1">Shows CBC trends, HbA1c progression, thyroid levels over time</p>
        </div>
      </div>
    </div>
  )
}

export function TrendAnalysis() {
  const trendData = [
    { month: 'Jan', hba1c: 8.2, tsh: 3.1 },
    { month: 'Feb', hba1c: 7.8, tsh: 2.9 },
    { month: 'Mar', hba1c: 7.5, tsh: 3.2 },
    { month: 'Apr', hba1c: 7.2, tsh: 2.8 },
    { month: 'May', hba1c: 6.9, tsh: 2.5 },
    { month: 'Jun', hba1c: 6.7, tsh: 2.4 },
  ]
  return (
    <div>
      <PageHeader title="Trend Analysis" subtitle="Parameter trends across referred patients" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <p className="font-semibold text-slate-300 mb-1">Sample: Anil Kumar — HbA1c & TSH Trend</p>
        <p className="text-xs text-slate-500 mb-4">6-month progression</p>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={trendData}>
            <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <Tooltip />
            <Line type="monotone" dataKey="hba1c" stroke="#3DDC84" strokeWidth={2} dot={{ r: 4 }} name="HbA1c %" />
            <Line type="monotone" dataKey="tsh" stroke="#60a5fa" strokeWidth={2} dot={{ r: 4 }} name="TSH mIU/L" />
          </LineChart>
        </ResponsiveContainer>
        <div className="flex gap-4 mt-2">
          <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="w-3 h-0.5 bg-brand-400 inline-block"></span>HbA1c %</span>
          <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="w-3 h-0.5 bg-blue-400 inline-block"></span>TSH mIU/L</span>
        </div>
      </div>
    </div>
  )
}

export function Referrals() {
  return (
    <div>
      <PageHeader title="Referral Tracking" subtitle="Track all your patient referrals and commissions" />
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-2xl font-bold text-slate-100">45</p>
          <p className="text-sm text-slate-500 mt-0.5">Total referrals this month</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-2xl font-bold text-brand-400">₹5,400</p>
          <p className="text-sm text-slate-500 mt-0.5">Commission earned</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-2xl font-bold text-blue-400">₹54,000</p>
          <p className="text-sm text-slate-500 mt-0.5">Revenue generated</p>
        </div>
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'Patient' },
            { key: 'name', label: 'Name' },
            { key: 'tests', label: 'Tests', render: v => v.join(', ') },
            { key: 'amount', label: 'Invoice', render: v => `₹${v.toLocaleString()}` },
            { key: 'date', label: 'Date' },
            { key: 'status', label: 'Report', render: v => <Badge status={v} /> },
          ]}
          data={mockPatients}
        />
      </div>
    </div>
  )
}
