import React, { useState } from 'react'
import { PageHeader, Badge, StatCard, Table, Modal, Tooltip as UiTooltip } from '../../components/UI'
import { FileText, Users, TrendingUp, Heart, Activity, Eye, Download, Share2, Calendar, Star, Bot, ChevronDown, Search } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from 'recharts'
import toast from 'react-hot-toast'

// ─── Shared mock data ────────────────────────────────────────────────────────
const DOCTOR = { name: 'Dr. Rajesh Mehta', speciality: 'General Physician', phone: '+91 98000 00001', commission: 10 }

const MY_PATIENTS = [
  { id: 'P0003', name: 'Anil Kumar', age: 52, gender: 'Male', phone: '9111000003', tests: ['CBC', 'Lipid Profile', 'HbA1c', 'LFT'], date: 'Jun 15, 2026', status: 'completed', amount: 2150, visitCount: 8, lastVisit: 'Jun 15, 2026', condition: 'Type 2 Diabetes, Hyperlipidemia' },
  { id: 'P0007', name: 'Meena Devi', age: 45, gender: 'Female', phone: '9111000007', tests: ['Thyroid Profile', 'Vitamin D', 'CBC'], date: 'Jun 12, 2026', status: 'completed', amount: 2400, visitCount: 5, lastVisit: 'Jun 12, 2026', condition: 'Hypothyroidism' },
  { id: 'P0012', name: 'Suresh Babu', age: 58, gender: 'Male', phone: '9111000012', tests: ['Cardiac Risk Profile', 'hs-CRP', 'Lipid Profile'], date: 'Jun 10, 2026', status: 'completed', amount: 4900, visitCount: 3, lastVisit: 'Jun 10, 2026', condition: 'Cardiac Risk - High' },
  { id: 'P0015', name: 'Priyanka Singh', age: 28, gender: 'Female', phone: '9111000015', tests: ['CBC', 'Iron Studies', 'Vitamin B12'], date: 'Jun 8, 2026', status: 'completed', amount: 1400, visitCount: 2, lastVisit: 'Jun 8, 2026', condition: 'Iron Deficiency Anaemia' },
  { id: 'P0019', name: 'Ravi Shankar', age: 61, gender: 'Male', phone: '9111000019', tests: ['HbA1c', 'KFT', 'Urine Albumin'], date: 'Jun 5, 2026', status: 'completed', amount: 1100, visitCount: 12, lastVisit: 'Jun 5, 2026', condition: 'Diabetic Nephropathy' },
  { id: 'P0022', name: 'Geeta Bai', age: 40, gender: 'Female', phone: '9111000022', tests: ['LFT', 'Hepatitis B', 'CBC'], date: 'Jun 3, 2026', status: 'processing', amount: 1550, visitCount: 4, lastVisit: 'Jun 3, 2026', condition: 'Hepatitis B Carrier' },
  { id: 'P0025', name: 'Mohd. Irfan', age: 35, gender: 'Male', phone: '9111000025', tests: ['Dengue NS1', 'CBC', 'CRP'], date: 'Jun 1, 2026', status: 'completed', amount: 1600, visitCount: 1, lastVisit: 'Jun 1, 2026', condition: 'Suspected Dengue' },
  { id: 'P0028', name: 'Sunita Verma', age: 55, gender: 'Female', phone: '9111000028', tests: ['Thyroid Profile', 'HbA1c', 'Lipid Profile', 'Vitamin D'], date: 'May 28, 2026', status: 'completed', amount: 3150, visitCount: 6, lastVisit: 'May 28, 2026', condition: 'Metabolic Syndrome' },
  { id: 'P0031', name: 'Kamal Nath', age: 48, gender: 'Male', phone: '9111000031', tests: ['PSA', 'CBC', 'KFT'], date: 'May 25, 2026', status: 'completed', amount: 1350, visitCount: 3, lastVisit: 'May 25, 2026', condition: 'Benign Prostatic Hyperplasia' },
  { id: 'P0034', name: 'Anjali Patel', age: 32, gender: 'Female', phone: '9111000034', tests: ['CBC', 'Thyroid Profile', 'Iron Studies'], date: 'May 20, 2026', status: 'completed', amount: 1600, visitCount: 2, lastVisit: 'May 20, 2026', condition: 'Fatigue workup' },
]

const PATIENT_HISTORY = {
  'P0003': {
    name: 'Anil Kumar', age: 52, gender: 'Male', phone: '9111000003',
    conditions: ['Type 2 Diabetes (diag. 2022)', 'Hyperlipidemia', 'Obesity (BMI 28.5)'],
    medications: ['Metformin 500mg BD', 'Atorvastatin 20mg HS', 'Amlodipine 5mg OD'],
    allergies: ['No known drug allergies'],
    records: [
      { date: 'Jun 15, 2026', tests: ['CBC', 'Lipid Profile', 'HbA1c', 'LFT'], results: { hba1c: '6.9%', ldl: '142', hdl: '52', tg: '148', hb: '13.2', wbc: '7200', plt: '245000', alt: '28', ast: '24' }, status: 'completed', notes: 'HbA1c improving. Continue current meds. Follow up in 3 months.' },
      { date: 'Mar 10, 2026', tests: ['HbA1c', 'KFT'], results: { hba1c: '7.2%', creatinine: '0.9', bun: '15' }, status: 'completed', notes: 'HbA1c slightly elevated. Increase Metformin to 500mg TDS if tolerated.' },
      { date: 'Dec 05, 2025', tests: ['CBC', 'Lipid Profile', 'HbA1c', 'Thyroid Profile'], results: { hba1c: '7.5%', ldl: '155', hdl: '48', tg: '165', hb: '12.8', tsh: '3.1' }, status: 'completed', notes: 'Poor glycemic control. Start Atorvastatin. Diet counseling advised.' },
      { date: 'Sep 12, 2025', tests: ['CBC', 'FBS', 'PPBS', 'LFT'], results: { fbs: '145', ppbs: '210', hb: '12.5', alt: '32' }, status: 'completed', notes: 'Fasting and PP both elevated. Start Metformin 500mg BD.' },
      { date: 'Jun 08, 2025', tests: ['Annual Checkup'], results: { fbs: '128', hb: '13.0', chol: '225' }, status: 'completed', notes: 'Pre-diabetic range. Lifestyle modifications advised. Recheck in 3 months.' },
    ],
    vitals: { height: '170 cm', weight: '82 kg', bmi: '28.5', bp: '132/84', pulse: '78' }
  },
  'P0007': {
    name: 'Meena Devi', age: 45, gender: 'Female', phone: '9111000007',
    conditions: ['Hypothyroidism (Hashimoto\'s)', 'Vitamin D deficiency'],
    medications: ['Levothyroxine 50mcg OD', 'Vitamin D3 6000 IU weekly'],
    allergies: ['Penicillin'],
    records: [
      { date: 'Jun 12, 2026', tests: ['Thyroid Profile', 'Vitamin D', 'CBC'], results: { tsh: '2.8', ft4: '1.1', vitd: '28', hb: '11.8' }, status: 'completed', notes: 'TSH normalizing. Vitamin D improving. Continue meds.' },
      { date: 'Mar 15, 2026', tests: ['Thyroid Profile', 'Vitamin D'], results: { tsh: '4.2', vitd: '22' }, status: 'completed', notes: 'TSH slightly elevated. Increase Levothyroxine to 50mcg.' },
      { date: 'Dec 10, 2025', tests: ['Thyroid Profile', 'CBC', 'Vitamin D'], results: { tsh: '5.8', hb: '11.2', vitd: '18' }, status: 'completed', notes: 'Diagnosed hypothyroidism. Started Levothyroxine 25mcg.' },
    ],
    vitals: { height: '158 cm', weight: '62 kg', bmi: '24.8', bp: '118/72', pulse: '72' }
  },
}

// ─── Report data for each test type ─────────────────────────────────────────
const REPORT_PARAMS = {
  'CBC': [
    { param: 'Hemoglobin', value: '13.2', unit: 'g/dL', ref: '12.0–16.0', flag: 'normal' },
    { param: 'WBC Count', value: '7,200', unit: '/μL', ref: '4,000–11,000', flag: 'normal' },
    { param: 'Platelet Count', value: '2,45,000', unit: '/μL', ref: '1,50,000–4,00,000', flag: 'normal' },
    { param: 'RBC Count', value: '4.8', unit: 'M/μL', ref: '4.5–5.5', flag: 'normal' },
    { param: 'Hematocrit', value: '42.3', unit: '%', ref: '36–46', flag: 'normal' },
    { param: 'MCV', value: '88.1', unit: 'fL', ref: '80–100', flag: 'normal' },
  ],
  'Lipid Profile': [
    { param: 'Total Cholesterol', value: '218', unit: 'mg/dL', ref: '<200', flag: 'high' },
    { param: 'LDL Cholesterol', value: '142', unit: 'mg/dL', ref: '<130', flag: 'high' },
    { param: 'HDL Cholesterol', value: '52', unit: 'mg/dL', ref: '>40', flag: 'normal' },
    { param: 'Triglycerides', value: '148', unit: 'mg/dL', ref: '<150', flag: 'normal' },
  ],
  'HbA1c': [
    { param: 'HbA1c', value: '6.9', unit: '%', ref: '<5.7', flag: 'high' },
    { param: 'Est. Avg Glucose', value: '149', unit: 'mg/dL', ref: '70–105', flag: 'high' },
  ],
  'Thyroid Profile': [
    { param: 'TSH', value: '2.8', unit: 'μIU/mL', ref: '0.4–4.0', flag: 'normal' },
    { param: 'Free T3', value: '3.2', unit: 'pg/mL', ref: '2.3–4.2', flag: 'normal' },
    { param: 'Free T4', value: '1.1', unit: 'ng/dL', ref: '0.9–1.7', flag: 'normal' },
  ],
  'LFT': [
    { param: 'ALT (SGPT)', value: '28', unit: 'U/L', ref: '<40', flag: 'normal' },
    { param: 'AST (SGOT)', value: '24', unit: 'U/L', ref: '<40', flag: 'normal' },
    { param: 'ALP', value: '78', unit: 'U/L', ref: '44–147', flag: 'normal' },
    { param: 'Bilirubin Total', value: '0.8', unit: 'mg/dL', ref: '0.1–1.2', flag: 'normal' },
  ],
  'KFT': [
    { param: 'Creatinine', value: '0.9', unit: 'mg/dL', ref: '0.7–1.3', flag: 'normal' },
    { param: 'BUN', value: '15', unit: 'mg/dL', ref: '7–20', flag: 'normal' },
    { param: 'Uric Acid', value: '5.8', unit: 'mg/dL', ref: '3.5–7.0', flag: 'normal' },
  ],
}

function buildReportHTML(patient, record) {
  const paramRows = record.tests.map(test => {
    const params = REPORT_PARAMS[test] || [{ param: test, value: '—', unit: '', ref: '', flag: 'normal' }]
    return params.map(p => `
      <tr><td>${p.param}</td><td class="${p.flag === 'high' ? 'abnormal' : 'normal'}">${p.value}</td><td>${p.unit}</td><td>${p.ref}</td><td class="${p.flag === 'high' ? 'abnormal' : 'normal'}">${p.flag === 'high' ? 'High' : 'Normal'}</td></tr>
    `).join('')
  }).join('')

  return `<html><head><title>Report — ${patient.name}</title>
    <style>
      body{font-family:'Segoe UI',sans-serif;padding:40px;max-width:800px;margin:0 auto;color:#333}
      h1{color:#059669;border-bottom:2px solid #059669;padding-bottom:8px;font-size:20px}
      table{width:100%;border-collapse:collapse;margin:16px 0;font-size:13px}
      td,th{border:1px solid #e2e8f0;padding:8px;text-align:left}th{background:#f0fdf4}
      .normal{color:#16a34a}.abnormal{color:#dc2626;font-weight:bold}
      .header{display:flex;justify-content:space-between;align-items:center}
      .patient-info{background:#f8fafc;padding:16px;border-radius:8px;margin:16px 0}
      .patient-info p{margin:4px 0;font-size:13px}
      .footer{margin-top:32px;font-size:11px;color:#94a3b8;border-top:1px solid #e2e8f0;padding-top:12px}
    </style></head><body>
    <div class="header">
      <h1>🏥 MediFlow Diagnostic Lab — Test Report</h1>
    </div>
    <div class="patient-info">
      <p><strong>Patient:</strong> ${patient.name} | <strong>ID:</strong> ${patient.id} | <strong>Age/Gender:</strong> ${patient.age} ${patient.gender}</p>
      <p><strong>Referred by:</strong> ${DOCTOR.name} | <strong>Date:</strong> ${record.date}</p>
    </div>
    <table>
      <thead><tr><th>Parameter</th><th>Result</th><th>Unit</th><th>Reference</th><th>Status</th></tr></thead>
      <tbody>${paramRows}</tbody>
    </table>
    <p style="font-size:13px;margin-top:16px"><strong>Doctor Notes:</strong> ${record.notes || 'No notes'}</p>
    <div class="footer">
      <p>MediFlow Diagnostic Lab · 27, Rajendra Nagar, Raipur, CG 492001</p>
      <p>Report digitally verified by ${DOCTOR.name}</p>
    </div></body></html>`
}

const MONTHLY_TREND = [
  { month: 'Jan', patients: 28, revenue: 32000, tests: 85 },
  { month: 'Feb', patients: 32, revenue: 38000, tests: 98 },
  { month: 'Mar', patients: 35, revenue: 41000, tests: 105 },
  { month: 'Apr', patients: 38, revenue: 45000, tests: 115 },
  { month: 'May', patients: 42, revenue: 52000, tests: 128 },
  { month: 'Jun', patients: 45, revenue: 54000, tests: 135 },
]

const UPCOMING_APPOINTMENTS = [
  { patient: 'Anil Kumar', time: 'Jun 28, 10:00 AM', reason: 'HbA1c follow-up', type: 'Follow-up' },
  { patient: 'Suresh Babu', time: 'Jun 22, 2:30 PM', reason: 'Cardiac risk reassessment', type: 'New' },
  { patient: 'Ravi Shankar', time: 'Jun 20, 11:00 AM', reason: 'Diabetic nephropathy review', type: 'Follow-up' },
]

// ═══════════════════════════════════════════════════════════════════════════════
//  DOCTOR DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════════
export function DoctorDashboard() {
  const [showReportModal, setShowReportModal] = useState(false)
  const [selectedReport, setSelectedReport] = useState(null)

  const handleView = (patient) => {
    setSelectedReport({ patient, record: MY_PATIENTS.find(p => p.id === patient.id) })
    setShowReportModal(true)
  }

  const handleDownloadPDF = (patient) => {
    const record = MY_PATIENTS.find(p => p.id === patient.id)
    const w = window.open('', '_blank')
    w.document.write(buildReportHTML(patient, { ...record, date: record.date, notes: record.notes || 'Reviewed by ' + DOCTOR.name }))
    w.document.close()
    toast.success('PDF opened in new tab!')
  }

  const handleShare = (patient) => {
    const msg = `🏥 *MediFlow Diagnostic Lab*\n\n📋 Patient: ${patient.name}\n🩺 Referred by: ${DOCTOR.name}\n📅 Date: ${patient.date}\n🧪 Tests: ${patient.tests.join(', ')}\n✅ Status: ${patient.status}`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
    toast.success('Opening WhatsApp...')
  }

  return (
    <div>
      {/* Doctor header */}
      <div className="mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-rose-500 to-rose-700 flex items-center justify-center text-white font-bold text-lg shadow-glow">RM</div>
          <div>
            <h1 className="text-xl font-semibold text-slate-100">Doctor Portal — {DOCTOR.name}</h1>
            <p className="text-sm text-slate-500">{DOCTOR.speciality} · {DOCTOR.phone} · Commission: {DOCTOR.commission}%</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} label="My Patients" value="45" sub="referred this month" color="blue" trend={12} />
        <StatCard icon={FileText} label="Reports Ready" value="8" sub="awaiting review" color="green" />
        <StatCard icon={TrendingUp} label="Referral Revenue" value="₹54,000" sub="this month" color="purple" />
        <StatCard icon={Activity} label="Pending Reports" value="3" color="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Recent Patient Reports */}
        <div className="lg:col-span-2 bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="font-semibold text-slate-300">Recent Patient Reports</p>
            <span className="text-xs text-slate-500">{MY_PATIENTS.length} patients</span>
          </div>
          <div className="space-y-2 max-h-[420px] overflow-y-auto">
            {MY_PATIENTS.slice(0, 8).map(p => (
              <div key={p.id} className="flex items-center gap-3 p-3 bg-surface-850 rounded-xl hover:bg-surface-800 transition-colors">
                <div className="w-9 h-9 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center text-xs font-semibold flex-shrink-0">
                  {p.name.split(' ').map(n=>n[0]).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm text-slate-300 truncate">{p.name}</p>
                    {p.visitCount > 5 && <Star size={10} className="text-amber-400 flex-shrink-0" />}
                  </div>
                  <p className="text-xs text-slate-500 truncate">{p.tests.slice(0,2).join(', ')}{p.tests.length > 2 ? ` +${p.tests.length-2}` : ''} · {p.date}</p>
                </div>
                <Badge status={p.status} />
                <div className="flex gap-1.5 flex-shrink-0">
                  <UiTooltip label="View Report">
                    <button onClick={() => handleView(p)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-2.5 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={11} /> View</button>
                  </UiTooltip>
                  <UiTooltip label="Download PDF">
                    <button onClick={() => handleDownloadPDF(p)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-2.5 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Download size={11} /></button>
                  </UiTooltip>
                  <UiTooltip label="Share on WhatsApp">
                    <button onClick={() => handleShare(p)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-2.5 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Share2 size={11} /></button>
                  </UiTooltip>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">
          {/* Upcoming Appointments */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3 flex items-center gap-2"><Calendar size={16} className="text-purple-400" /> Upcoming</p>
            <div className="space-y-2">
              {UPCOMING_APPOINTMENTS.map((a, i) => (
                <div key={i} className="p-3 bg-surface-850 rounded-xl">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-slate-300">{a.patient}</p>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${a.type === 'Follow-up' ? 'bg-blue-500/10 text-blue-400' : 'bg-green-500/10 text-green-400'}`}>{a.type}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{a.time}</p>
                  <p className="text-xs text-slate-500">{a.reason}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Referral Summary Chart */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-3">Referral Trend</p>
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={MONTHLY_TREND}>
                <XAxis dataKey="month" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip />
                <Line type="monotone" dataKey="patients" stroke="#f43f5e" strokeWidth={2} dot={{ r: 3 }} name="Patients" />
              </LineChart>
            </ResponsiveContainer>
            <div className="mt-3 pt-3 border-t border-surface-700 space-y-1">
              <div className="flex justify-between text-sm"><span className="text-slate-500">Commission rate</span><span className="font-semibold text-slate-300">{DOCTOR.commission}%</span></div>
              <div className="flex justify-between text-sm"><span className="text-slate-500">This month earned</span><span className="font-semibold text-brand-400">₹5,400</span></div>
              <div className="flex justify-between text-sm"><span className="text-slate-500">Total earned (FY)</span><span className="font-semibold text-green-400">₹28,800</span></div>
            </div>
          </div>

          {/* AI Insight */}
          <div className="bg-surface-900 rounded-2xl border border-brand-500/20 p-4 border-l-4 border-brand-500">
            <div className="flex items-center gap-2 mb-2">
              <Bot size={16} className="text-brand-400" />
              <p className="text-sm font-semibold text-slate-300">AI Insight</p>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">3 patients show improving HbA1c trends. 1 patient (Suresh Babu) has elevated cardiac risk — consider early intervention.</p>
          </div>
        </div>
      </div>

      {/* View Report Modal */}
      <Modal open={showReportModal} onClose={() => setShowReportModal(false)} title={selectedReport ? `Report — ${selectedReport.patient.name}` : 'Report'} size="lg">
        {selectedReport && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-surface-850 rounded-xl">
              <div className="w-10 h-10 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center text-sm font-bold">
                {selectedReport.patient.name.split(' ').map(n=>n[0]).join('')}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-200">{selectedReport.patient.name}</p>
                <p className="text-xs text-slate-500">{selectedReport.patient.id} · {selectedReport.patient.age}y · {selectedReport.patient.gender}</p>
              </div>
              <Badge status={selectedReport.patient.status} />
            </div>
            <div className="bg-surface-850 rounded-xl p-4">
              <p className="text-xs font-semibold text-slate-500 mb-2">TESTS</p>
              <div className="flex flex-wrap gap-1.5">
                {selectedReport.patient.tests.map(t => (
                  <span key={t} className="text-xs px-2 py-1 bg-brand-500/10 text-brand-400 border border-brand-500/20 rounded-lg">{t}</span>
                ))}
              </div>
              <p className="text-xs text-slate-500 mt-2">Amount: ₹{selectedReport.patient.amount.toLocaleString()} · Date: {selectedReport.patient.date}</p>
              {selectedReport.patient.condition && (
                <p className="text-xs text-amber-400 mt-1">Condition: {selectedReport.patient.condition}</p>
              )}
            </div>
            <div className="flex gap-2 justify-end">
              <UiTooltip label="Download PDF">
                <button onClick={() => { handleDownloadPDF(selectedReport.patient); setShowReportModal(false) }} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-1"><Download size={14} /> PDF</button>
              </UiTooltip>
              <UiTooltip label="Share on WhatsApp">
                <button onClick={() => { handleShare(selectedReport.patient); setShowReportModal(false) }} className="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-1"><Share2 size={14} /> WhatsApp</button>
              </UiTooltip>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PATIENT REPORTS
// ═══════════════════════════════════════════════════════════════════════════════
export function PatientReports() {
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState(null)

  const filtered = MY_PATIENTS.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.tests.some(t => t.toLowerCase().includes(search.toLowerCase()))
    const matchStatus = statusFilter === 'all' || p.status === statusFilter
    return matchSearch && matchStatus
  })

  const handleViewReport = (patient) => {
    const record = { ...patient, date: patient.date, notes: `Reviewed by ${DOCTOR.name}. ${patient.condition || ''}` }
    const w = window.open('', '_blank')
    w.document.write(buildReportHTML(patient, record))
    w.document.close()
    toast.success('Report opened!')
  }

  const handleDetail = (patient) => {
    setSelectedPatient(patient)
    setShowDetailModal(true)
  }

  const handleDownload = (patient) => {
    handleViewReport(patient)
    toast.success('Report opened for download!')
  }

  return (
    <div>
      <PageHeader title="Patient Reports" subtitle={`${filtered.length} reports from ${MY_PATIENTS.length} patients`} />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1 max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by patient name or test..." className="w-full bg-surface-900 border border-surface-700 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" />
        </div>
        <div className="flex gap-2">
          {[{ k: 'all', l: 'All' }, { k: 'completed', l: 'Completed' }, { k: 'processing', l: 'Processing' }].map(f => (
            <button key={f.k} onClick={() => setStatusFilter(f.k)} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${statusFilter === f.k ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700'}`}>{f.l}</button>
          ))}
        </div>
      </div>

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="divide-y divide-surface-800">
          {filtered.map(p => (
            <div key={p.id} className="flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors">
              <div className="w-10 h-10 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center text-xs font-semibold flex-shrink-0">
                {p.name.split(' ').map(n=>n[0]).join('')}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm text-slate-300 truncate">{p.name}</p>
                  <span className="text-xs text-slate-600">({p.id})</span>
                </div>
                <p className="text-xs text-slate-500 truncate">{p.tests.join(', ')} · {p.date}</p>
                {p.condition && <p className="text-xs text-amber-400/70 truncate">{p.condition}</p>}
              </div>
              <p className="font-semibold text-slate-300 text-sm flex-shrink-0">₹{p.amount.toLocaleString()}</p>
              <Badge status={p.status} />
              <div className="flex gap-1.5 flex-shrink-0">
                <UiTooltip label="View Details">
                  <button onClick={() => handleDetail(p)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-2.5 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={11} /> Detail</button>
                </UiTooltip>
                <UiTooltip label="View Full Report">
                  <button onClick={() => handleViewReport(p)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-2.5 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><FileText size={11} /> Report</button>
                </UiTooltip>
                <UiTooltip label="Download Report">
                  <button onClick={() => handleDownload(p)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-2.5 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Download size={11} /></button>
                </UiTooltip>
              </div>
            </div>
          ))}
          {filtered.length === 0 && <div className="p-8 text-center text-slate-500 text-sm">No reports match your search.</div>}
        </div>
      </div>

      {/* Detail Modal */}
      <Modal open={showDetailModal} onClose={() => setShowDetailModal(false)} title={selectedPatient ? `Patient Detail — ${selectedPatient.name}` : 'Detail'} size="lg">
        {selectedPatient && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-surface-850 rounded-xl">
              <div className="w-12 h-12 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center text-lg font-bold">{selectedPatient.name.split(' ').map(n=>n[0]).join('')}</div>
              <div className="flex-1">
                <p className="font-semibold text-slate-200">{selectedPatient.name}</p>
                <p className="text-xs text-slate-500">{selectedPatient.id} · {selectedPatient.age}y · {selectedPatient.gender} · {selectedPatient.phone}</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-surface-850 rounded-xl p-3 text-center"><p className="text-xl font-bold text-brand-400">{selectedPatient.visitCount}</p><p className="text-xs text-slate-500">Total Visits</p></div>
              <div className="bg-surface-850 rounded-xl p-3 text-center"><p className="text-xl font-bold text-blue-400">{selectedPatient.tests.length}</p><p className="text-xs text-slate-500">Tests Done</p></div>
              <div className="bg-surface-850 rounded-xl p-3 text-center"><p className="text-xl font-bold text-green-400">₹{selectedPatient.amount.toLocaleString()}</p><p className="text-xs text-slate-500">Total Amount</p></div>
            </div>
            <div className="bg-surface-850 rounded-xl p-4">
              <p className="text-xs font-semibold text-slate-500 mb-2">TESTS & RESULTS</p>
              <div className="flex flex-wrap gap-1.5">
                {selectedPatient.tests.map(t => (
                  <span key={t} className="text-xs px-2 py-1 bg-brand-500/10 text-brand-400 border border-brand-500/20 rounded-lg">{t}</span>
                ))}
              </div>
              {selectedPatient.condition && <p className="text-xs text-amber-400 mt-2">Condition: {selectedPatient.condition}</p>}
            </div>
            <div className="flex gap-2 justify-end">
              <UiTooltip label="Open Full Report">
                <button onClick={() => { handleViewReport(selectedPatient); setShowDetailModal(false) }} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-1"><FileText size={14} /> View Full Report</button>
              </UiTooltip>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PATIENT HISTORY
// ═══════════════════════════════════════════════════════════════════════════════
export function PatientHistory() {
  const [search, setSearch] = useState('')
  const [selectedKey, setSelectedKey] = useState(null)
  const [showAllRecords, setShowAllRecords] = useState(false)

  const history = selectedKey ? PATIENT_HISTORY[selectedKey] : null

  const handleSearch = () => {
    const match = Object.entries(PATIENT_HISTORY).find(([_, h]) => h.name.toLowerCase().includes(search.toLowerCase()) || h.phone.includes(search))
    if (match) { setSelectedKey(match[0]); toast.success(`Found: ${match[1].name}`) }
    else { toast.error('Patient not found. Try: Anil Kumar or Meena Devi') }
  }

  const displayRecords = history ? (showAllRecords ? history.records : history.records.slice(0, 3)) : []

  return (
    <div>
      <PageHeader title="Patient History" subtitle="Longitudinal patient test records & vitals" />

      {/* Search */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()} className="w-full bg-surface-850 border border-surface-700 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" placeholder="Search patient by name or phone (try: Anil Kumar, Meena Devi)" />
          </div>
          <UiTooltip label="Search Patient">
            <button onClick={handleSearch} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-5 py-2 rounded-xl text-sm">Search</button>
          </UiTooltip>
        </div>
      </div>

      {history ? (
        <div className="space-y-4">
          {/* Patient header card */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-14 h-14 rounded-full bg-rose-500/15 text-rose-400 flex items-center justify-center text-xl font-bold">{history.name.split(' ').map(n=>n[0]).join('')}</div>
              <div className="flex-1">
                <p className="text-lg font-semibold text-slate-100">{history.name}</p>
                <p className="text-sm text-slate-500">{history.age}y · {history.gender} · {history.phone}</p>
              </div>
            </div>

            {/* Vitals */}
            <div className="grid grid-cols-5 gap-2 mb-4">
              {Object.entries(history.vitals).map(([k, v]) => (
                <div key={k} className="bg-surface-850 rounded-lg p-2 text-center">
                  <p className="text-sm font-bold text-slate-200">{v}</p>
                  <p className="text-[10px] text-slate-500 uppercase">{k}</p>
                </div>
              ))}
            </div>

            {/* Conditions & Medications */}
            <div className="grid md:grid-cols-2 gap-3">
              <div className="bg-surface-850 rounded-xl p-3">
                <p className="text-xs font-semibold text-slate-500 mb-1.5">CONDITIONS</p>
                {history.conditions.map((c, i) => <p key={i} className="text-xs text-amber-400 mb-0.5">• {c}</p>)}
              </div>
              <div className="bg-surface-850 rounded-xl p-3">
                <p className="text-xs font-semibold text-slate-500 mb-1.5">MEDICATIONS</p>
                {history.medications.map((m, i) => <p key={i} className="text-xs text-blue-400 mb-0.5">• {m}</p>)}
              </div>
            </div>
            <div className="bg-surface-850 rounded-xl p-3 mt-2">
              <p className="text-xs font-semibold text-slate-500 mb-1">ALLERGIES</p>
              <p className="text-xs text-red-400">{history.allergies.join(', ')}</p>
            </div>
          </div>

          {/* Test history timeline */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="font-semibold text-slate-300 mb-4">Test History Timeline</p>
            <div className="space-y-3">
              {displayRecords.map((r, i) => (
                <div key={i} className="relative pl-8">
                  {/* Timeline dot & line */}
                  <div className={`absolute left-2.5 top-3 w-3 h-3 rounded-full ${i === 0 ? 'bg-brand-500' : 'bg-surface-600'}`} />
                  {i < displayRecords.length - 1 && <div className="absolute left-3.5 top-6 bottom-0 w-0.5 bg-surface-700" />}

                  <div className="bg-surface-850 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-sm text-slate-300">{r.date}</p>
                        <Badge status={r.status} />
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {r.tests.map(t => <span key={t} className="text-[11px] px-2 py-0.5 bg-brand-500/10 text-brand-400 rounded-lg">{t}</span>)}
                    </div>
                    {r.results && (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-1.5 mb-2">
                        {Object.entries(r.results).map(([k, v]) => (
                          <div key={k} className="bg-surface-900 rounded-lg px-2 py-1">
                            <p className="text-[10px] text-slate-500 uppercase">{k}</p>
                            <p className="text-xs font-medium text-slate-300">{v}</p>
                          </div>
                        ))}
                      </div>
                    )}
                    {r.notes && <p className="text-xs text-slate-400 italic">💬 {r.notes}</p>}
                  </div>
                </div>
              ))}
            </div>
            {history.records.length > 3 && (
              <button onClick={() => setShowAllRecords(!showAllRecords)} className="mt-3 text-xs text-brand-400 hover:text-brand-300 font-medium flex items-center gap-1 mx-auto">
                {showAllRecords ? 'Show less' : `Show all ${history.records.length} records`} <ChevronDown size={12} className={showAllRecords ? 'rotate-180' : ''} />
              </button>
            )}
          </div>

          {/* Lab Values Trend Chart */}
          {history.records.length >= 2 && (
            <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
              <p className="font-semibold text-slate-300 mb-3">Lab Values Trend</p>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={history.records.slice().reverse().map(r => ({ date: r.date.split(',')[0], hba1c: parseFloat(r.results?.hba1c) || null, tsh: parseFloat(r.results?.tsh) || null, hb: parseFloat(r.results?.hb) || null }))}>
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip />
                  <Line type="monotone" dataKey="hba1c" stroke="#3DDC84" strokeWidth={2} dot={{ r: 3 }} name="HbA1c %" connectNulls />
                  <Line type="monotone" dataKey="tsh" stroke="#60a5fa" strokeWidth={2} dot={{ r: 3 }} name="TSH" connectNulls />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-12 text-center">
          <Heart size={40} className="text-slate-600 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Search for a patient to view their test history</p>
          <p className="text-slate-600 text-xs mt-1">Shows CBC trends, HbA1c progression, thyroid levels over time</p>
          <p className="text-slate-600 text-xs mt-2">Try searching: <span className="text-brand-400">Anil Kumar</span> or <span className="text-brand-400">Meena Devi</span></p>
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TREND ANALYSIS
// ═══════════════════════════════════════════════════════════════════════════════
export function TrendAnalysis() {
  const [selectedPatient, setSelectedPatient] = useState('anil')

  const patientTrends = {
    anil: {
      name: 'Anil Kumar', data: [
        { month: 'Jun 25', hba1c: 8.2, ldl: 165, hb: 12.5, tsh: 3.1 },
        { month: 'Sep 25', hba1c: 7.8, ldl: 160, hb: 12.8, tsh: 3.0 },
        { month: 'Dec 25', hba1c: 7.5, ldl: 155, hb: 13.0, tsh: 3.1 },
        { month: 'Mar 26', hba1c: 7.2, ldl: 148, hb: 13.1, tsh: 2.9 },
        { month: 'Jun 26', hba1c: 6.9, ldl: 142, hb: 13.2, tsh: 2.8 },
      ],
      insight: 'HbA1c improved from 8.2% → 6.9% over 12 months. LDL trending down with Atorvastatin. Continue current management.'
    },
    meena: {
      name: 'Meena Devi', data: [
        { month: 'Dec 25', hba1c: null, ldl: null, hb: 11.2, tsh: 5.8 },
        { month: 'Mar 26', hba1c: null, ldl: null, hb: 11.5, tsh: 4.2 },
        { month: 'Jun 26', hba1c: null, ldl: null, hb: 11.8, tsh: 2.8 },
      ],
      insight: 'TSH normalized after Levothyroxine therapy (5.8 → 2.8). Hb improving. Vitamin D supplementation showing effect.'
    },
    suresh: {
      name: 'Suresh Babu', data: [
        { month: 'Mar 26', hba1c: 6.5, ldl: 158, hb: 14.0, tsh: 2.5 },
        { month: 'Jun 26', hba1c: 6.3, ldl: 145, hb: 14.2, tsh: 2.4 },
      ],
      insight: 'Cardiac risk elevated: LDL still above target (<100 for high risk). Consider statin dose escalation. hs-CRP trending down.'
    },
  }

  const current = patientTrends[selectedPatient]

  return (
    <div>
      <PageHeader title="Trend Analysis" subtitle="Parameter trends across referred patients" />

      {/* Patient selector */}
      <div className="flex gap-2 mb-4">
        {Object.entries(patientTrends).map(([k, v]) => (
          <button key={k} onClick={() => setSelectedPatient(k)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${selectedPatient === k ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700 hover:text-slate-200'}`}>{v.name}</button>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Chart */}
        <div className="lg:col-span-2 bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-1">{current.name} — Parameter Trends</p>
          <p className="text-xs text-slate-500 mb-4">{current.data.length}-visit progression</p>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={current.data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip />
              {current.data[0].hba1c !== null && <Line type="monotone" dataKey="hba1c" stroke="#3DDC84" strokeWidth={2} dot={{ r: 4 }} name="HbA1c %" connectNulls />}
              {current.data[0].ldl !== null && <Line type="monotone" dataKey="ldl" stroke="#f43f5e" strokeWidth={2} dot={{ r: 4 }} name="LDL mg/dL" connectNulls />}
              <Line type="monotone" dataKey="hb" stroke="#60a5fa" strokeWidth={2} dot={{ r: 4 }} name="Hb g/dL" connectNulls />
              {current.data[0].tsh !== null && <Line type="monotone" dataKey="tsh" stroke="#f59e0b" strokeWidth={2} dot={{ r: 4 }} name="TSH" connectNulls />}
            </LineChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2 flex-wrap">
            {current.data[0].hba1c !== null && <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="w-3 h-0.5 bg-green-400 inline-block" />HbA1c %</span>}
            {current.data[0].ldl !== null && <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="w-3 h-0.5 bg-rose-500 inline-block" />LDL mg/dL</span>}
            <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="w-3 h-0.5 bg-blue-400 inline-block" />Hb g/dL</span>
            {current.data[0].tsh !== null && <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="w-3 h-0.5 bg-amber-500 inline-block" />TSH</span>}
          </div>
        </div>

        {/* Insight */}
        <div className="space-y-4">
          <div className="bg-surface-900 rounded-2xl border border-brand-500/20 p-5 border-l-4 border-brand-500">
            <div className="flex items-center gap-2 mb-2"><Bot size={16} className="text-brand-400" /><p className="text-sm font-semibold text-slate-300">AI Analysis</p></div>
            <p className="text-sm text-slate-400 leading-relaxed">{current.insight}</p>
          </div>

          {/* Summary cards */}
          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 space-y-3">
            <p className="font-semibold text-slate-300 text-sm">Latest Values</p>
            {Object.entries(current.data[current.data.length - 1]).filter(([k]) => k !== 'month').map(([k, v]) => v !== null && (
              <div key={k} className="flex items-center justify-between">
                <span className="text-xs text-slate-500 uppercase">{k}</span>
                <span className="text-sm font-bold text-slate-200">{v}{k === 'hba1c' ? '%' : k === 'ldl' ? ' mg/dL' : k === 'hb' ? ' g/dL' : ''}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  REFERRALS
// ═══════════════════════════════════════════════════════════════════════════════
export function Referrals() {
  return (
    <div>
      <PageHeader title="Referral Tracking" subtitle="Track all your patient referrals and commissions" />

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-slate-100">45</p>
          <p className="text-sm text-slate-500 mt-1">Total Referrals</p>
          <p className="text-xs text-green-400 mt-0.5">↑ 12% from last month</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-brand-400">₹5,400</p>
          <p className="text-sm text-slate-500 mt-1">Commission Earned</p>
          <p className="text-xs text-slate-600 mt-0.5">{DOCTOR.commission}% rate</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-blue-400">₹54,000</p>
          <p className="text-sm text-slate-500 mt-1">Revenue Generated</p>
          <p className="text-xs text-slate-600 mt-0.5">This month</p>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
          <p className="text-3xl font-bold text-purple-400">₹28,800</p>
          <p className="text-sm text-slate-500 mt-1">Total FY Earnings</p>
          <p className="text-xs text-green-400 mt-0.5">↑ 18% vs last FY</p>
        </div>
      </div>

      {/* Revenue chart */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-4">
        <p className="font-semibold text-slate-300 mb-3">Monthly Revenue & Patient Trend</p>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={MONTHLY_TREND}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="month" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip />
            <Bar dataKey="patients" fill="#f43f5e" radius={[4,4,0,0]} name="Patients" />
            <Bar dataKey="tests" fill="#3b82f6" radius={[4,4,0,0]} name="Tests" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Referral table */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700">
          <p className="font-semibold text-slate-300 text-sm">Referral History</p>
        </div>
        <Table
          columns={[
            { key: 'id', label: 'Patient ID' },
            { key: 'name', label: 'Patient', render: (v, row) => (
              <div>
                <p className="font-medium text-slate-300">{v}</p>
                <p className="text-xs text-slate-500">{row.age}y · {row.gender}</p>
              </div>
            )},
            { key: 'tests', label: 'Tests', render: v => <span className="text-xs">{v.slice(0,2).join(', ')}{v.length > 2 ? ` +${v.length-2}` : ''}</span> },
            { key: 'amount', label: 'Invoice', render: v => `₹${v.toLocaleString()}` },
            { key: 'commission', label: 'Commission', render: (_, row) => <span className="text-brand-400 font-medium">₹{Math.round(row.amount * DOCTOR.commission / 100).toLocaleString()}</span> },
            { key: 'date', label: 'Date' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={MY_PATIENTS}
        />
      </div>
    </div>
  )
}
