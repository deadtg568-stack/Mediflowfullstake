import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { authAPI, apiErrorMessage } from '../utils/api'
import {
  Microscope, Eye, EyeOff, Phone, Lock, ShieldCheck, Cloud, Cpu, LineChart,
  Stethoscope, UserCog, FlaskConical, Users, ShieldAlert, Sun, Moon,
} from 'lucide-react'

const roles = [
  { key: 'labadmin',   label: 'Lab Admin',   icon: UserCog,     route: '/labadmin'   },
  { key: 'doctor',     label: 'Doctor',      icon: Stethoscope, route: '/doctor'     },
  { key: 'reception',  label: 'Reception',   icon: Users,       route: '/reception'  },
  { key: 'technician', label: 'Technician',  icon: FlaskConical,route: '/technician' },
  { key: 'patient',    label: 'Patient',     icon: Users,       route: '/patient'    },
  { key: 'superadmin', label: 'Super Admin', icon: ShieldAlert, route: '/superadmin' },
]

const demoCreds = {
  superadmin: { phone: '9999999999', password: 'admin123' },
  labadmin:   { phone: '9876543210', password: 'admin123' },
  technician: { phone: '9700000001', password: 'tech123' },
  reception:  { phone: '9700000002', password: 'recep123' },
  doctor:     { phone: '9800000001', password: 'doctor123' },
  patient:    { phone: '9111000001', password: 'patient123' },
}

export default function Login() {
  const [selected, setSelected] = useState('labadmin')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [remember, setRemember] = useState(true)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [isDark, setIsDark] = useState(true)
  const { setUser } = useStore()
  const navigate = useNavigate()
  const selectedRole = roles.find(r => r.key === selected)

  const toggleTheme = () => {
    const next = !isDark
    setIsDark(next)
    document.documentElement.classList.toggle('dark', next)
  }

  const handleLogin = async (e) => {
    e.preventDefault()
    setError('')
    if (phone.length < 10) return setError('Enter a valid 10-digit mobile number')
    if (!password) return setError('Enter your password')
    setLoading(true)
    try {
      const res = await authAPI.login(phone, password, selected)
      const { token, user } = res.data.data
      setUser(user, token)
      navigate(roles.find(r => r.key === user.role)?.route || '/labadmin')
    } catch (err) {
      setError(apiErrorMessage(err, 'Login failed'))
    } finally { setLoading(false) }
  }

  const fillDemo = () => {
    const c = demoCreds[selected]
    setPhone(c.phone)
    setPassword(c.password)
    setError('')
  }

  return (
    <div className="min-h-screen bg-surface-950 text-slate-100 lab-grid-bg relative overflow-hidden">
      {/* Ambient glow orbs */}
      <div className="glow-orb w-[28rem] h-[28rem] bg-brand-500/20 -top-32 -left-32" />
      <div className="glow-orb w-[24rem] h-[24rem] bg-brand-400/10 bottom-0 right-0" />

      <div className="relative grid grid-cols-1 lg:grid-cols-2 min-h-screen">

        {/* ── LEFT: Brand hero ───────────────────────────────────────────── */}
        <div className="hidden lg:flex flex-col p-12 relative">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-16">
            <div className="w-12 h-12 rounded-2xl border border-brand-500/30 bg-surface-900 flex items-center justify-center shadow-glow">
              <Microscope size={22} className="text-brand-400" />
            </div>
            <div>
              <h1 className="font-display text-xl font-semibold tracking-tight">
                MediFlow <span className="text-brand-400">Pro AI</span>
              </h1>
              <p className="text-xs text-slate-500 -mt-0.5">Laboratory Information System</p>
            </div>
          </div>

          {/* Headline */}
          <div className="mb-10">
            <h2 className="font-display text-5xl font-semibold leading-tight tracking-tight mb-4">
              Smart <span className="text-brand-400">Pathology.</span><br />
              Smarter <span className="text-brand-400">Workflow.</span>
            </h2>
            <div className="h-1 w-16 bg-gradient-to-r from-brand-400 to-brand-600 rounded-full mb-5" />
            <p className="text-sm font-medium text-brand-400/90 tracking-wide mb-3">
              AI POWERED &nbsp;•&nbsp; SECURE &nbsp;•&nbsp; ACCURATE
            </p>
            <p className="text-slate-500 text-sm leading-relaxed max-w-sm">
              Complete laboratory management in one intelligent platform —
              from sample collection to AI-verified reports.
            </p>
          </div>

          {/* Hero visual */}
          <div className="flex-1 flex items-center justify-center relative my-6">
            <div className="absolute w-72 h-72 rounded-full border border-brand-500/20" />
            <div className="absolute w-56 h-56 rounded-full border border-brand-500/15" />
            <div className="absolute w-72 h-72 rounded-full bg-brand-500/10 blur-2xl" />
            <div className="relative w-36 h-36 rounded-3xl bg-surface-900 border border-brand-500/30 shadow-glow-lg flex items-center justify-center">
              <Microscope size={64} className="text-brand-400" strokeWidth={1.4} />
            </div>
            {/* Floating data chips */}
            <div className="absolute top-4 right-6 px-3 py-1.5 rounded-xl bg-surface-900/80 border border-brand-500/20 backdrop-blur text-xs text-brand-300 font-mono-num">
              CBC ✓ Normal
            </div>
            <div className="absolute bottom-10 left-2 px-3 py-1.5 rounded-xl bg-surface-900/80 border border-brand-500/20 backdrop-blur text-xs text-brand-300 font-mono-num">
              98.6% Accuracy
            </div>
          </div>

          {/* Feature grid */}
          <div className="grid grid-cols-4 gap-3 mb-8">
            {[
              { icon: ShieldCheck, title: 'Secure & Reliable', sub: 'HIPAA Compliant' },
              { icon: Cloud,       title: 'Cloud Based',       sub: 'Access Anywhere' },
              { icon: Cpu,         title: 'AI Powered',        sub: 'Smart Analytics' },
              { icon: LineChart,   title: 'Real-time Reports', sub: 'Instant Insights' },
            ].map(f => (
              <div key={f.title} className="bg-surface-900/60 border border-surface-700 rounded-2xl p-3 backdrop-blur">
                <div className="w-8 h-8 rounded-xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center mb-2">
                  <f.icon size={15} className="text-brand-400" />
                </div>
                <p className="text-xs font-semibold text-slate-200 leading-tight">{f.title}</p>
                <p className="text-[11px] text-slate-500 mt-0.5">{f.sub}</p>
              </div>
            ))}
          </div>

          <div className="inline-flex items-center gap-2 self-start px-4 py-2 rounded-full border border-brand-500/20 bg-surface-900/60 backdrop-blur text-xs text-slate-300">
            <ShieldCheck size={14} className="text-brand-400" />
            Trusted by <span className="text-brand-400 font-semibold">1000+</span> Labs &amp; Diagnostic Centers
          </div>
        </div>

        {/* ── RIGHT: Login card ─────────────────────────────────────────── */}
        <div className="flex flex-col">
          {/* Top bar with theme toggle */}
          <div className="flex justify-end p-6 lg:p-8">
            <button onClick={toggleTheme}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-surface-700 bg-surface-900/60 text-xs text-slate-300 hover:border-brand-500/30 transition-colors">
              {isDark ? <Moon size={13} className="text-brand-400" /> : <Sun size={13} className="text-amber-400" />}
              {isDark ? 'Dark Mode' : 'Light Mode'}
            </button>
          </div>

          <div className="flex-1 flex items-center justify-center px-6 pb-10">
            <div className="w-full max-w-md">

              {/* Mobile logo (shown when left panel hidden) */}
              <div className="flex lg:hidden items-center gap-3 mb-8 justify-center">
                <div className="w-10 h-10 rounded-2xl border border-brand-500/30 bg-surface-900 flex items-center justify-center shadow-glow">
                  <Microscope size={18} className="text-brand-400" />
                </div>
                <h1 className="font-display text-lg font-semibold">MediFlow <span className="text-brand-400">Pro AI</span></h1>
              </div>

              <div className="bg-surface-900/80 backdrop-blur border border-surface-700 rounded-3xl p-7 shadow-glow-lg">
                {/* Icon + welcome */}
                <div className="flex flex-col items-center text-center mb-6">
                  <div className="relative mb-4">
                    <div className="absolute inset-0 rounded-full bg-brand-500/20 blur-xl" />
                    <div className="relative w-16 h-16 rounded-full border border-brand-500/30 bg-surface-850 flex items-center justify-center">
                      <Microscope size={28} className="text-brand-400" />
                    </div>
                  </div>
                  <h2 className="font-display text-2xl font-semibold">
                    Welcome <span className="text-brand-400">Back!</span>
                  </h2>
                  <p className="text-sm text-slate-500 mt-1">Sign in to your MediFlow Pro AI account</p>
                </div>

                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 text-red-300 text-sm rounded-xl px-4 py-2.5 mb-4">
                    {error}
                  </div>
                )}

                {/* Role selector */}
                <p className="text-xs font-semibold text-slate-500 tracking-wide mb-3">SELECT YOUR ROLE</p>
                <div className="grid grid-cols-3 sm:grid-cols-3 gap-2 mb-5">
                  {roles.map(r => {
                    const Icon = r.icon
                    const active = selected === r.key
                    return (
                      <button
                        key={r.key}
                        type="button"
                        onClick={() => { setSelected(r.key); setError(''); setPhone(''); setPassword('') }}
                        className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all text-xs font-medium
                          ${active
                            ? 'border-brand-500 bg-brand-500/10 text-brand-300 shadow-glow'
                            : 'border-surface-700 bg-surface-850 text-slate-500 hover:border-surface-600 hover:text-slate-300'}`}
                      >
                        <Icon size={18} />
                        {r.label}
                      </button>
                    )
                  })}
                </div>

                <div className="flex items-center gap-3 my-5">
                  <div className="flex-1 h-px bg-surface-700" />
                  <span className="text-xs text-slate-500">OR</span>
                  <div className="flex-1 h-px bg-surface-700" />
                </div>

                <form onSubmit={handleLogin} className="space-y-4">
                  {/* Phone */}
                  <div>
                    <label htmlFor="login-phone" className="block text-xs font-semibold text-slate-500 tracking-wide mb-1.5">MOBILE NUMBER</label>
                    <div className="relative">
                      <Phone size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                      <input
                        id="login-phone"
                        value={phone}
                        onChange={e => setPhone(e.target.value.replace(/\D/g,'').slice(0,10))}
                        placeholder="Enter your mobile number"
                        maxLength={10}
                        autoComplete="username"
                        className="w-full bg-surface-850 border border-surface-700 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500/50 transition-all"
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div>
                    <label htmlFor="login-password" className="block text-xs font-semibold text-slate-500 tracking-wide mb-1.5">PASSWORD</label>
                    <div className="relative">
                      <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                      <input
                        id="login-password"
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        placeholder="Enter your password"
                        autoComplete="current-password"
                        className="w-full bg-surface-850 border border-surface-700 rounded-xl pl-10 pr-10 py-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500/50 transition-all"
                      />
                      <button type="button" onClick={() => setShowPassword(s => !s)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  {/* Remember + forgot */}
                  <div className="flex items-center justify-between text-xs">
                    <label className="flex items-center gap-2 text-slate-500 cursor-pointer">
                      <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)}
                        className="rounded accent-brand-500 bg-surface-850 border-surface-700" />
                      Remember me
                    </label>
                    <button type="button" className="text-brand-400 hover:text-brand-300 font-medium">Forgot Password?</button>
                  </div>

                  {/* Submit */}
                  <button type="submit" disabled={loading}
                    className="w-full bg-gradient-to-r from-brand-500 to-brand-600 hover:from-brand-400 hover:to-brand-500 text-surface-950 font-semibold py-3 rounded-xl text-sm shadow-glow transition-all disabled:opacity-60 flex items-center justify-center gap-2">
                    <Lock size={15} />
                    {loading ? 'Signing in...' : 'SIGN IN'}
                  </button>

                  <p className="flex items-center justify-center gap-1.5 text-xs text-slate-500">
                    <ShieldCheck size={13} className="text-brand-400" />
                    Your data is <span className="text-brand-400 font-medium">100% secure</span> and encrypted
                  </p>
                </form>

                {/* Demo creds helper */}
                <div className="mt-5 bg-surface-850 border border-surface-700 rounded-xl p-3 text-xs text-slate-500">
                  <div className="flex items-center justify-between mb-1">
                    <p className="font-semibold text-slate-300">Demo credentials</p>
                    <button type="button" onClick={fillDemo} className="text-brand-400 hover:text-brand-300 font-medium underline">Autofill</button>
                  </div>
                  <p className="font-mono-num">Phone: {demoCreds[selected].phone}</p>
                  <p className="font-mono-num">Password: {demoCreds[selected].password}</p>
                </div>
              </div>

              {/* Compliance footer */}
              <div className="flex items-center justify-center gap-5 mt-6 text-[11px] text-slate-500">
                <span className="flex items-center gap-1"><ShieldCheck size={12} className="text-brand-400" /> HIPAA</span>
                <span className="flex items-center gap-1"><Cpu size={12} className="text-brand-400" /> ISO 27001</span>
                <span className="flex items-center gap-1"><Cloud size={12} className="text-brand-400" /> Cloud Secure</span>
                <span>© 2026 MediFlow Pro AI</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
