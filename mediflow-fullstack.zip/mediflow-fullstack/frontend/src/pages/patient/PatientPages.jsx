import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { PageHeader, Badge, StatCard, Modal } from '../../components/UI'
import { FileText, Activity, CalendarDays, Wallet, Bot, Download, Share2, CheckCircle, Eye, Printer, Clock, TrendingUp, Heart } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import toast from 'react-hot-toast'

// ─── Shared mock data ────────────────────────────────────────────────────────
const PATIENT = { name: 'Rahul Sharma', id: 'P001', phone: '+91 91110 00001', age: 34, gender: 'Male', dob: '15 Mar 1992' }

const RECENT_REPORTS = [
  { test: 'Complete Blood Count (CBC)', date: 'Jun 12, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Rajesh Mehta' },
  { test: 'Lipid Profile', date: 'May 28, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Anita Gupta' },
  { test: 'Thyroid Profile (T3,T4,TSH)', date: 'May 15, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Rajesh Mehta' },
  { test: 'HbA1c', date: 'Apr 20, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Rajesh Mehta' },
  { test: 'Liver Function Test (LFT)', date: 'Apr 05, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Suresh Nair' },
  { test: 'Blood Sugar Fasting', date: 'Mar 28, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Rajesh Mehta' },
  { test: 'Urine Routine & Microscopy', date: 'Mar 15, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Anita Gupta' },
  { test: 'CRP (C-Reactive Protein)', date: 'Mar 01, 2026', status: 'completed', lab: 'City Diagnostics', doctor: 'Dr. Rajesh Mehta' },
]

const ALL_REPORTS = [
  { test: 'Complete Blood Count (CBC)', date: 'Jun 12, 2026', id: 'RPT-2026-001', status: 'completed', category: 'Haematology' },
  { test: 'Lipid Profile', date: 'May 28, 2026', id: 'RPT-2026-002', status: 'completed', category: 'Biochemistry' },
  { test: 'Thyroid Profile (T3,T4,TSH)', date: 'May 15, 2026', id: 'RPT-2026-003', status: 'completed', category: 'Immunology' },
  { test: 'HbA1c', date: 'Apr 20, 2026', id: 'RPT-2026-004', status: 'completed', category: 'Biochemistry' },
  { test: 'Liver Function Test (LFT)', date: 'Apr 05, 2026', id: 'RPT-2026-005', status: 'completed', category: 'Biochemistry' },
  { test: 'Blood Sugar Fasting', date: 'Mar 28, 2026', id: 'RPT-2026-006', status: 'completed', category: 'Biochemistry' },
  { test: 'Urine Routine & Microscopy', date: 'Mar 15, 2026', id: 'RPT-2026-007', status: 'completed', category: 'Urine' },
  { test: 'CRP (C-Reactive Protein)', date: 'Mar 01, 2026', id: 'RPT-2026-008', status: 'completed', category: 'Immunology' },
  { test: 'Vitamin D (25-OH)', date: 'Feb 14, 2026', id: 'RPT-2026-009', status: 'completed', category: 'Immunology' },
  { test: 'Iron Studies', date: 'Jan 20, 2026', id: 'RPT-2026-010', status: 'completed', category: 'Haematology' },
  { test: 'HbA1c', date: 'Dec 10, 2025', id: 'RPT-2025-011', status: 'completed', category: 'Biochemistry' },
  { test: 'Complete Blood Count (CBC)', date: 'Nov 05, 2025', id: 'RPT-2025-012', status: 'completed', category: 'Haematology' },
]

const ACTIVE_TESTS = [
  { test: 'Dengue NS1 Antigen', collected: '08:15 AM', status: 'completed', eta: 'Done', orderId: 'ORD-2026-045', priority: 'urgent' },
  { test: 'CBC (Repeat)', collected: '08:15 AM', status: 'processing', eta: 'Ready by 1:30 PM', orderId: 'ORD-2026-046', priority: 'normal' },
  { test: 'Lipid Profile (Fasting)', collected: '08:15 AM', status: 'processing', eta: 'Ready by 2:30 PM', orderId: 'ORD-2026-047', priority: 'normal' },
  { test: 'HbA1c', collected: '08:15 AM', status: 'pending', eta: 'Ready by 4:00 PM', orderId: 'ORD-2026-048', priority: 'normal' },
  { test: 'CRP (C-Reactive Protein)', collected: '08:15 AM', status: 'pending', eta: 'Ready by 3:00 PM', orderId: 'ORD-2026-049', priority: 'urgent' },
]

const BOOKABLE_TESTS = [
  { name: 'Complete Blood Count (CBC)', price: 350, tat: '4 hrs', category: 'Haematology', sample: 'Blood-EDTA' },
  { name: 'Lipid Profile', price: 600, tat: '6 hrs', category: 'Biochemistry', sample: 'Blood-SST' },
  { name: 'Thyroid Profile (T3,T4,TSH)', price: 850, tat: '8 hrs', category: 'Immunology', sample: 'Blood-SST' },
  { name: 'Liver Function Test (LFT)', price: 700, tat: '6 hrs', category: 'Biochemistry', sample: 'Blood-SST' },
  { name: 'HbA1c', price: 500, tat: '4 hrs', category: 'Biochemistry', sample: 'Blood-EDTA' },
  { name: 'Blood Sugar Fasting', price: 120, tat: '2 hrs', category: 'Biochemistry', sample: 'Blood-Fluoride' },
  { name: 'Urine Routine & Microscopy', price: 250, tat: '2 hrs', category: 'Urine', sample: 'Urine' },
  { name: 'CRP (C-Reactive Protein)', price: 450, tat: '4 hrs', category: 'Immunology', sample: 'Blood-SST' },
  { name: 'Vitamin D (25-OH)', price: 1200, tat: '24 hrs', category: 'Immunology', sample: 'Blood-SST' },
  { name: 'Iron Studies', price: 400, tat: '6 hrs', category: 'Haematology', sample: 'Blood-SST' },
  { name: 'Dengue NS1 Antigen', price: 800, tat: '4 hrs', category: 'Serology', sample: 'Blood-SST' },
  { name: 'Dengue IgM/IgG', price: 900, tat: '6 hrs', category: 'Serology', sample: 'Blood-SST' },
]

const PAYMENTS_DATA = [
  { invoice: 'INV-2026-015', tests: 'Dengue NS1 + CBC + CRP', amount: 1600, date: 'Jun 15, 2026', status: 'paid', method: 'UPI' },
  { invoice: 'INV-2026-012', tests: 'CBC + Lipid Profile + HbA1c', amount: 1450, date: 'Jun 12, 2026', status: 'paid', method: 'Cash' },
  { invoice: 'INV-2026-009', tests: 'Thyroid Profile', amount: 850, date: 'May 15, 2026', status: 'paid', method: 'Card' },
  { invoice: 'INV-2026-007', tests: 'Lipid Profile', amount: 600, date: 'May 28, 2026', status: 'paid', method: 'UPI' },
  { invoice: 'INV-2026-005', tests: 'Liver Function Test', amount: 700, date: 'Apr 05, 2026', status: 'paid', method: 'Cash' },
  { invoice: 'INV-2026-003', tests: 'Blood Sugar Fasting + Urine Routine', amount: 370, date: 'Mar 28, 2026', status: 'paid', method: 'UPI' },
  { invoice: 'INV-2026-002', tests: 'CRP + Iron Studies', amount: 850, date: 'Mar 01, 2026', status: 'paid', method: 'Card' },
  { invoice: 'INV-2026-001', tests: 'Vitamin D', amount: 1200, date: 'Feb 14, 2026', status: 'paid', method: 'UPI' },
  { invoice: 'INV-2025-018', tests: 'HbA1c + CBC', amount: 850, date: 'Dec 10, 2025', status: 'paid', method: 'Cash' },
  { invoice: 'INV-2025-015', tests: 'CBC', amount: 350, date: 'Nov 05, 2025', status: 'paid', method: 'UPI' },
]

const AI_INSIGHTS = [
  { title: 'Blood Count (CBC)', icon: '🩸', summary: 'All CBC parameters are within normal range. Haemoglobin is 13.2 g/dL (normal: 12–16). White cell count is 7,200/μL — no signs of infection. Platelet count is healthy at 2,45,000/μL.', trend: 'stable', date: 'Jun 12, 2026', details: 'RBC: 4.8M/μL ✓ | MCV: 88 fL ✓ | MCH: 27.5 pg ✓' },
  { title: 'Blood Sugar (HbA1c)', icon: '🍬', summary: 'HbA1c has improved from 7.2% (Dec 2025) → 7.0% (Mar 2026) → 6.9% (Jun 2026) — excellent downward trend! Target is below 7.0%. Your fasting glucose was 108 mg/dL (borderline). Continue current diet and medication.', trend: 'improving', date: 'Jun 12, 2026', details: 'Fasting: 108 mg/dL (pref: <100) | HbA1c: 6.9% (target: <7%)' },
  { title: 'Lipid Profile', icon: '❤️', summary: 'LDL cholesterol is slightly elevated at 142 mg/dL (ideal: <130). Total cholesterol is 218 mg/dL (desirable: <200). HDL is good at 52 mg/dL. Triglycerides are normal at 148 mg/dL. Consider reducing saturated fats and increasing exercise.', trend: 'attention', date: 'May 28, 2026', details: 'Total: 218 | LDL: 142 ↑ | HDL: 52 ✓ | TG: 148 ✓' },
  { title: 'Thyroid Profile', icon: '🦋', summary: 'TSH is 3.8 μIU/mL — slightly elevated (normal: 0.4–4.0). T3 and T4 are within normal range. No immediate treatment needed, but monitor every 6 months. Symptoms like fatigue or weight gain should be reported.', trend: 'stable', date: 'May 15, 2026', details: 'TSH: 3.8 μIU/mL ✓ | T3: 1.2 ng/mL ✓ | T4: 8.5 μg/dL ✓' },
  { title: 'Liver Function', icon: '🫁', summary: 'All liver enzymes are normal. ALT is 28 U/L (normal: <40), AST is 24 U/L (normal: <40). Bilirubin is 0.8 mg/dL. Albumin is 4.2 g/dL. No signs of liver damage or inflammation.', trend: 'stable', date: 'Apr 05, 2026', details: 'ALT: 28 ✓ | AST: 24 ✓ | Bilirubin: 0.8 ✓ | Albumin: 4.2 ✓' },
  { title: 'Kidney Function', icon: '🫘', summary: 'Creatinine is 0.9 mg/dL (normal: 0.7–1.3). BUN is 15 mg/dL. eGFR is >90 mL/min — excellent kidney function. No protein detected in urine. Stay hydrated!', trend: 'stable', date: 'Mar 28, 2026', details: 'Creatinine: 0.9 ✓ | BUN: 15 ✓ | eGFR: >90 ✓' },
  { title: 'Vitamin D', icon: '☀️', summary: 'Vitamin D level is 22 ng/mL — insufficient (optimal: 30–60). Recommended supplement: 6000 IU daily for 8 weeks, then retest. Deficiency can cause bone weakness, fatigue, and mood changes.', trend: 'attention', date: 'Feb 14, 2026', details: '25-OH Vitamin D: 22 ng/mL ↑ (insufficient: <30)' },
  { title: 'Inflammation Marker (CRP)', icon: '🔬', summary: 'CRP is 2.1 mg/L — borderline elevated (normal: <1.0). Combined with slightly elevated ESR at 18 mm/hr, suggests mild systemic inflammation. Could be related to the viral episode in Feb. Recheck in 4 weeks.', trend: 'watch', date: 'Mar 01, 2026', details: 'CRP: 2.1 mg/L ↑ | ESR: 18 mm/hr ↑' },
]

// ─── Helper: generate full HTML report ────────────────────────────────────────
function buildReportHTML(r, patient) {
  const reportData = {
    'Complete Blood Count (CBC)': `
      <tr><td>Hemoglobin</td><td class="normal">13.2</td><td>g/dL</td><td>12.0–16.0</td><td class="normal">Normal</td></tr>
      <tr><td>WBC Count</td><td class="normal">7,200</td><td>/μL</td><td>4,000–11,000</td><td class="normal">Normal</td></tr>
      <tr><td>Platelet Count</td><td class="normal">2,45,000</td><td>/μL</td><td>1,50,000–4,00,000</td><td class="normal">Normal</td></tr>
      <tr><td>RBC Count</td><td class="normal">4.8</td><td>million/μL</td><td>4.5–5.5</td><td class="normal">Normal</td></tr>
      <tr><td>Hematocrit (HCT)</td><td class="normal">42.3</td><td>%</td><td>36–46</td><td class="normal">Normal</td></tr>
      <tr><td>MCV</td><td class="normal">88.1</td><td>fL</td><td>80–100</td><td class="normal">Normal</td></tr>
      <tr><td>MCH</td><td class="normal">27.5</td><td>pg</td><td>27–33</td><td class="normal">Normal</td></tr>`,
    'Lipid Profile': `
      <tr><td>Total Cholesterol</td><td class="abnormal">218</td><td>mg/dL</td><td>&lt;200</td><td class="abnormal">High</td></tr>
      <tr><td>LDL Cholesterol</td><td class="abnormal">142</td><td>mg/dL</td><td>&lt;130</td><td class="abnormal">High</td></tr>
      <tr><td>HDL Cholesterol</td><td class="normal">52</td><td>mg/dL</td><td>&gt;40</td><td class="normal">Normal</td></tr>
      <tr><td>Triglycerides</td><td class="normal">148</td><td>mg/dL</td><td>&lt;150</td><td class="normal">Normal</td></tr>
      <tr><td>VLDL</td><td class="normal">29.6</td><td>mg/dL</td><td>5–40</td><td class="normal">Normal</td></tr>`,
    'Thyroid Profile (T3,T4,TSH)': `
      <tr><td>TSH</td><td class="normal">3.8</td><td>μIU/mL</td><td>0.4–4.0</td><td class="normal">Normal</td></tr>
      <tr><td>T3 (Triiodothyronine)</td><td class="normal">1.2</td><td>ng/mL</td><td>0.8–2.0</td><td class="normal">Normal</td></tr>
      <tr><td>T4 (Thyroxine)</td><td class="normal">8.5</td><td>μg/dL</td><td>5.0–12.0</td><td class="normal">Normal</td></tr>`,
    'HbA1c': `
      <tr><td>HbA1c</td><td class="normal">6.9</td><td>%</td><td>&lt;5.7 (Normal)</td><td class="abnormal">Pre-diabetic</td></tr>
      <tr><td>Estimated Avg Glucose</td><td class="normal">149</td><td>mg/dL</td><td>70–105</td><td class="abnormal">High</td></tr>
      <tr><td>Interpretation</td><td colspan="4">Pre-diabetic range (5.7–6.4%). Previous: 7.2% (Dec 2025) → 6.9% (Jun 2026). Improving.</td></tr>`,
    'Liver Function Test (LFT)': `
      <tr><td>ALT (SGPT)</td><td class="normal">28</td><td>U/L</td><td>&lt;40</td><td class="normal">Normal</td></tr>
      <tr><td>AST (SGOT)</td><td class="normal">24</td><td>U/L</td><td>&lt;40</td><td class="normal">Normal</td></tr>
      <tr><td>Alkaline Phosphatase</td><td class="normal">78</td><td>U/L</td><td>44–147</td><td class="normal">Normal</td></tr>
      <tr><td>Total Bilirubin</td><td class="normal">0.8</td><td>mg/dL</td><td>0.1–1.2</td><td class="normal">Normal</td></tr>
      <tr><td>Albumin</td><td class="normal">4.2</td><td>g/dL</td><td>3.5–5.0</td><td class="normal">Normal</td></tr>
      <tr><td>Globulin</td><td class="normal">2.8</td><td>g/dL</td><td>2.0–3.5</td><td class="normal">Normal</td></tr>`,
  }

  const rows = reportData[r.test] || `
    <tr><td>Result</td><td class="normal">Within Range</td><td>—</td><td>Standard</td><td class="normal">Normal</td></tr>`

  return `<html><head><title>Report — ${r.test}</title>
    <style>
      body{font-family:'Segoe UI',sans-serif;padding:40px;color:#333;max-width:800px;margin:0 auto}
      h1{color:#059669;border-bottom:2px solid #059669;padding-bottom:8px;font-size:20px}
      h2{color:#334155;font-size:14px;margin-top:24px}
      table{width:100%;border-collapse:collapse;margin:16px 0;font-size:13px}
      td,th{border:1px solid #e2e8f0;padding:8px;text-align:left}
      th{background:#f0fdf4;font-weight:600}
      .normal{color:#16a34a}.abnormal{color:#dc2626;font-weight:bold}
      .header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
      .patient-info{background:#f8fafc;padding:16px;border-radius:8px;margin:16px 0}
      .patient-info p{margin:4px 0;font-size:13px}
      .footer{margin-top:32px;font-size:11px;color:#94a3b8;border-top:1px solid #e2e8f0;padding-top:12px}
      .badge{display:inline-block;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600}
      .badge-normal{background:#dcfce7;color:#166534}.badge-high{background:#fef2f2;color:#991b1b}
    </style></head><body>
    <div class="header">
      <h1>🏥 MediFlow Diagnostic Lab — Test Report</h1>
      <p style="font-size:11px;color:#64748b">${r.id || 'RPT-XXXX'}</p>
    </div>
    <div class="patient-info">
      <p><strong>Patient:</strong> ${patient.name} &nbsp;|&nbsp; <strong>ID:</strong> ${patient.id} &nbsp;|&nbsp; <strong>Age/Gender:</strong> ${patient.age} ${patient.gender}</p>
      <p><strong>Test:</strong> ${r.test} &nbsp;|&nbsp; <strong>Date:</strong> ${r.date}</p>
      <p><strong>Referred by:</strong> ${r.doctor || 'Dr. Rajesh Mehta'} &nbsp;|&nbsp; <strong>Lab:</strong> ${r.lab || 'City Diagnostics'}</p>
    </div>
    <h2>📋 Test Results</h2>
    <table>
      <thead><tr><th>Parameter</th><th>Result</th><th>Unit</th><th>Reference Range</th><th>Status</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <p style="font-size:12px;color:#64748b;margin-top:24px">⚕️ Generated by MediFlow Pro AI · Not a medical diagnosis</p>
    <div class="footer">
      <p>MediFlow Diagnostic Lab · 27, Rajendra Nagar, Raipur, Chhattisgarh 492001</p>
      <p>Ph: +91 98765 43210 · Email: city@diagnostics.com</p>
      <p>This report is digitally generated and does not require a physical signature.</p>
    </div></body></html>`
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PATIENT DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════════
export function PatientDashboard() {
  const navigate = useNavigate()
  const [showReportModal, setShowReportModal] = useState(false)
  const [selectedReport, setSelectedReport] = useState(null)

  const handleViewReport = (report) => {
    setSelectedReport(report)
    setShowReportModal(true)
  }

  const handleDownloadPDF = (report) => {
    const w = window.open('', '_blank')
    w.document.write(buildReportHTML(report, PATIENT))
    w.document.close()
    toast.success('PDF opened in new tab!')
  }

  const handleShare = (report) => {
    const msg = `🏥 *MediFlow Diagnostic Lab*\n\n📋 Test: ${report.test}\n📅 Date: ${report.date}\n✅ Status: ${report.status}\n\nYour report is ready! Download from the patient portal.`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
    toast.success('Opening WhatsApp...')
  }

  return (
    <div>
      {/* Patient header */}
      <div className="mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-lg shadow-glow">RS</div>
          <div>
            <h1 className="text-xl font-semibold text-slate-100">Welcome, {PATIENT.name}</h1>
            <p className="text-sm text-slate-500">Patient ID: {PATIENT.id} · {PATIENT.phone} · {PATIENT.age} {PATIENT.gender}</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={FileText} label="Total Reports" value="12" color="blue" />
        <StatCard icon={Activity} label="Tests Done" value="28" color="green" />
        <StatCard icon={CalendarDays} label="Last Visit" value="Jun 15" color="purple" />
        <StatCard icon={Wallet} label="Total Paid" value="₹10,620" color="amber" />
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { label: 'Book Test', icon: CalendarDays, route: '/patient/book', bg: 'bg-brand-500/10', text: 'text-brand-400' },
          { label: 'My Reports', icon: FileText, route: '/patient/reports', bg: 'bg-blue-500/10', text: 'text-blue-400' },
          { label: 'Test Status', icon: Activity, route: '/patient/status', bg: 'bg-green-500/10', text: 'text-green-400' },
          { label: 'AI Summary', icon: Bot, route: '/patient/ai', bg: 'bg-purple-500/10', text: 'text-purple-400' },
        ].map(a => (
          <button key={a.label} onClick={() => navigate(a.route)} className="bg-surface-900 border border-surface-700 rounded-2xl p-4 text-center hover:border-brand-500/30 hover:bg-surface-850 transition-all group">
            <div className={`w-10 h-10 rounded-xl ${a.bg} flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform`}>
              <a.icon size={18} className={a.text} />
            </div>
            <p className="text-sm font-medium text-slate-300">{a.label}</p>
          </button>
        ))}
      </div>

      {/* AI Health Summary */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-4 border-l-4 border-brand-500">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 bg-brand-500/15 rounded-xl flex items-center justify-center flex-shrink-0">
            <Bot size={18} className="text-brand-400" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <p className="font-semibold text-slate-300">AI Health Summary</p>
              <span className="text-xs text-brand-400 font-medium">Updated Jun 15, 2026</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Your latest CBC (Jun 12) is <span className="text-green-400 font-medium">fully normal</span>. HbA1c shows improvement: <span className="text-green-400 font-medium">7.2% → 6.9%</span> over 6 months — keep it up!
              Lipid Profile: LDL is <span className="text-amber-400 font-medium">slightly elevated at 142 mg/dL</span> — consider reducing fried foods.
              Vitamin D is <span className="text-amber-400 font-medium">insufficient at 22 ng/mL</span> — supplement recommended.
            </p>
            <div className="flex gap-2 mt-3">
              <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 border border-green-500/20">CBC Normal</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 border border-green-500/20">HbA1c Improving</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">LDL Elevated</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">Vitamin D Low</span>
            </div>
          </div>
        </div>
      </div>

      {/* Upcoming appointment */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-purple-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
            <CalendarDays size={18} className="text-purple-400" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-sm text-slate-300">Next Appointment</p>
            <p className="text-xs text-slate-500">Jun 28, 2026 at 10:00 AM — Dr. Rajesh Mehta (Follow-up)</p>
          </div>
          <span className="text-xs px-2 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">In 13 days</span>
        </div>
      </div>

      {/* Health Timeline Chart */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="font-semibold text-slate-300 flex items-center gap-2"><TrendingUp size={16} className="text-brand-400" /> Health Timeline</p>
            <p className="text-xs text-slate-500 mt-0.5">Key lab values over the past 8 months</p>
          </div>
          <div className="flex gap-2">
            {[
              { label: 'HbA1c', color: '#3DDC84' },
              { label: 'LDL', color: '#f43f5e' },
              { label: 'Vitamin D', color: '#f59e0b' },
            ].map(l => (
              <span key={l.label} className="flex items-center gap-1.5 text-xs text-slate-500">
                <span className="w-3 h-0.5 rounded inline-block" style={{ backgroundColor: l.color }} />{l.label}
              </span>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={[
            { month: 'Nov 25', hba1c: 8.2, ldl: 165, vitD: 18, hb: 12.8, crp: 3.2 },
            { month: 'Dec 25', hba1c: 7.5, ldl: 158, vitD: 18, hb: 13.0, crp: 2.8 },
            { month: 'Jan 26', hba1c: null, ldl: null, vitD: 20, hb: null, crp: null },
            { month: 'Feb 26', hba1c: null, ldl: null, vitD: 22, hb: null, crp: 2.1 },
            { month: 'Mar 26', hba1c: 7.2, ldl: 148, vitD: null, hb: 13.1, crp: 2.1 },
            { month: 'Apr 26', hba1c: 7.0, ldl: 145, vitD: null, hb: 13.0, crp: null },
            { month: 'May 26', hba1c: null, ldl: 142, vitD: null, hb: null, crp: null },
            { month: 'Jun 26', hba1c: 6.9, ldl: 142, vitD: null, hb: 13.2, crp: null },
          ]}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '12px', fontSize: '12px' }}
              itemStyle={{ color: '#e2e8f0' }}
              labelStyle={{ color: '#94a3b8', marginBottom: '4px' }}
            />
            <Line type="monotone" dataKey="hba1c" stroke="#3DDC84" strokeWidth={2.5} dot={{ r: 4, fill: '#3DDC84' }} name="HbA1c %" connectNulls />
            <Line type="monotone" dataKey="ldl" stroke="#f43f5e" strokeWidth={2.5} dot={{ r: 4, fill: '#f43f5e' }} name="LDL mg/dL" connectNulls />
            <Line type="monotone" dataKey="vitD" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3, fill: '#f59e0b' }} strokeDasharray="5 5" name="Vitamin D ng/mL" connectNulls />
          </LineChart>
        </ResponsiveContainer>
        {/* Key milestones */}
        <div className="flex gap-3 mt-3 overflow-x-auto pb-1">
          {[
            { date: 'Nov 2025', event: 'First visit — HbA1c 8.2%', color: 'red' },
            { date: 'Mar 2026', event: 'HbA1c improved to 7.2%', color: 'amber' },
            { date: 'Jun 2026', event: 'HbA1c 6.9% — target reached!', color: 'green' },
            { date: 'Jun 2026', event: 'LDL still elevated — monitoring', color: 'amber' },
          ].map((m, i) => (
            <div key={i} className="flex items-center gap-2 bg-surface-850 rounded-xl px-3 py-2 flex-shrink-0">
              <span className={`w-2 h-2 rounded-full flex-shrink-0 ${m.color === 'green' ? 'bg-green-400' : m.color === 'amber' ? 'bg-amber-400' : 'bg-red-400'}`} />
              <div>
                <p className="text-[10px] text-slate-500">{m.date}</p>
                <p className="text-xs text-slate-300 font-medium whitespace-nowrap">{m.event}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Reports */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700 flex items-center justify-between">
          <p className="font-semibold text-slate-300">Recent Reports</p>
          <span className="text-xs text-slate-500">Last 8 reports</span>
        </div>
        <div className="divide-y divide-surface-800">
          {RECENT_REPORTS.map((r, i) => (
            <div key={i} className="flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors">
              <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <FileText size={18} className="text-blue-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-slate-300 truncate">{r.test}</p>
                <p className="text-xs text-slate-500">{r.lab} · {r.date} · {r.doctor}</p>
              </div>
              <Badge status={r.status} />
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => handleViewReport(r)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={12} />View</button>
                <button onClick={() => handleDownloadPDF(r)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Download size={12} />PDF</button>
                <button onClick={() => handleShare(r)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Share2 size={12} />Share</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* View Report Modal */}
      <Modal open={showReportModal} onClose={() => setShowReportModal(false)} title={selectedReport?.test || 'Report'}>
        {selectedReport && (
          <div className="space-y-4">
            <div className="bg-surface-850 rounded-xl p-4 text-sm space-y-2">
              <div className="flex justify-between"><span className="text-slate-500">Patient:</span><span className="text-slate-200">{PATIENT.name}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Test:</span><span className="text-slate-200">{selectedReport.test}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Date:</span><span className="text-slate-200">{selectedReport.date}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Doctor:</span><span className="text-slate-200">{selectedReport.doctor || 'Dr. Rajesh Mehta'}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Status:</span><Badge status={selectedReport.status} /></div>
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => { handleDownloadPDF(selectedReport); setShowReportModal(false) }} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-1"><Download size={14} />Download PDF</button>
              <button onClick={() => { handleShare(selectedReport); setShowReportModal(false) }} className="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-1"><Share2 size={14} />WhatsApp</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  MY REPORTS
// ═══════════════════════════════════════════════════════════════════════════════
export function MyReports() {
  const [search, setSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('All')

  const categories = ['All', ...new Set(ALL_REPORTS.map(r => r.category))]

  const filtered = ALL_REPORTS.filter(r => {
    const matchSearch = r.test.toLowerCase().includes(search.toLowerCase()) || r.id.toLowerCase().includes(search.toLowerCase())
    const matchCat = categoryFilter === 'All' || r.category === categoryFilter
    return matchSearch && matchCat
  })

  const handleViewPDF = (r) => {
    const w = window.open('', '_blank')
    w.document.write(buildReportHTML(r, PATIENT))
    w.document.close()
    toast.success('PDF opened!')
  }

  const handleWhatsApp = (r) => {
    const msg = `🏥 *MediFlow Diagnostic Lab*\n\n📋 Report: ${r.test}\n📅 Date: ${r.date}\n🆔 Report ID: ${r.id}\n\nYour report is ready!`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
    toast.success('Opening WhatsApp...')
  }

  const handlePrint = (r) => {
    const w = window.open('', '_blank')
    w.document.write(buildReportHTML(r, PATIENT))
    w.document.close()
    w.print()
  }

  return (
    <div>
      <PageHeader title="My Reports" subtitle={`${ALL_REPORTS.length} diagnostic reports available`} />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search reports..." className="flex-1 bg-surface-900 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" />
        <div className="flex gap-2 flex-wrap">
          {categories.map(c => (
            <button key={c} onClick={() => setCategoryFilter(c)} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${categoryFilter === c ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 hover:text-slate-200 border border-surface-700'}`}>{c}</button>
          ))}
        </div>
      </div>

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="divide-y divide-surface-800">
          {filtered.map((r, i) => (
            <div key={i} className="flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors">
              <div className="w-10 h-10 bg-brand-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <CheckCircle size={18} className="text-brand-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-slate-300 truncate">{r.test}</p>
                <p className="text-xs text-slate-500">{r.id} · {r.date} · {r.category}</p>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => handleViewPDF(r)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Eye size={12} />View</button>
                <button onClick={() => handlePrint(r)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Printer size={12} />Print</button>
                <button onClick={() => handleWhatsApp(r)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Share2 size={12} />WhatsApp</button>
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="p-8 text-center text-slate-500 text-sm">No reports match your search.</div>
          )}
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TEST STATUS
// ═══════════════════════════════════════════════════════════════════════════════
export function TestStatus() {
  const stages = ['Collection', 'Processing', 'Verification', 'Report Ready']

  return (
    <div>
      <PageHeader title="Test Status" subtitle={`${ACTIVE_TESTS.length} tests from your visit on Jun 15, 2026`} />

      {/* Visit info */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 mb-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-slate-300">
            <CalendarDays size={16} className="text-brand-400" />
            <span>Visit Date: <strong>Jun 15, 2026</strong></span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-300">
            <Clock size={16} className="text-purple-400" />
            <span>Sampled at: <strong>08:15 AM</strong></span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-300">
            <Activity size={16} className="text-green-400" />
            <span>Token: <strong>#T-042</strong></span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {ACTIVE_TESTS.map((t, i) => {
          const stageIdx = t.status === 'completed' ? 3 : t.status === 'processing' ? 1 : 0
          const isUrgent = t.priority === 'urgent'
          return (
            <div key={i} className={`bg-surface-900 rounded-2xl border p-5 ${isUrgent ? 'border-amber-500/30' : 'border-surface-700'}`}>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-slate-300">{t.test}</p>
                    {isUrgent && <span className="text-xs px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/20">URGENT</span>}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">Order: {t.orderId} · Collected at {t.collected}</p>
                </div>
                <div className="text-right">
                  <Badge status={t.status} />
                  <p className="text-xs text-slate-500 mt-1">{t.eta}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {stages.map((s, si) => (
                  <React.Fragment key={s}>
                    <div className="flex flex-col items-center">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${si <= stageIdx ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-500'}`}>
                        {si <= stageIdx ? '✓' : si + 1}
                      </div>
                      <p className={`text-xs mt-1 text-center ${si <= stageIdx ? 'text-brand-400 font-medium' : 'text-slate-500'}`}>{s}</p>
                    </div>
                    {si < stages.length - 1 && (
                      <div className={`flex-1 h-0.5 mb-5 ${si < stageIdx ? 'bg-brand-500' : 'bg-surface-700'}`} />
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  BOOK TEST
// ═══════════════════════════════════════════════════════════════════════════════
export function BookTest() {
  const [form, setForm] = useState({ type: 'Visit Lab', tests: [], date: '', time: '', notes: '' })
  const [showConfirm, setShowConfirm] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState('All')

  const testCategories = ['All', ...new Set(BOOKABLE_TESTS.map(t => t.category))]

  const filteredTests = selectedCategory === 'All' ? BOOKABLE_TESTS : BOOKABLE_TESTS.filter(t => t.category === selectedCategory)

  const toggleTest = (testName) => {
    setForm(prev => ({
      ...prev,
      tests: prev.tests.includes(testName) ? prev.tests.filter(t => t !== testName) : [...prev.tests, testName]
    }))
  }

  const totalAmount = form.tests.reduce((sum, t) => {
    const test = BOOKABLE_TESTS.find(bt => bt.name === t)
    return sum + (test?.price || 0)
  }, 0)

  const handleFinalBook = () => {
    toast.success(`✅ Test booked successfully! Total: ₹${totalAmount}. You'll receive a confirmation SMS shortly.`)
    setShowConfirm(false)
    setForm({ type: 'Visit Lab', tests: [], date: '', time: '', notes: '' })
  }

  return (
    <div>
      <PageHeader title="Book a Test" subtitle="Schedule lab visit or home collection" />
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left: Form */}
        <div className="lg:col-span-2 bg-surface-900 rounded-2xl border border-surface-700 p-6">
          <div className="space-y-5">
            {/* Collection type */}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-2">Collection Type</label>
              <div className="grid grid-cols-2 gap-3">
                {[{ label: 'Visit Lab', icon: '🏥', desc: 'Walk-in at the lab' }, { label: 'Home Collection', icon: '🏠', desc: 'Phlebotomist visits you' }].map(t => (
                  <button key={t.label} onClick={() => setForm({ ...form, type: t.label })} className={`p-4 border-2 rounded-xl text-left transition-all ${form.type === t.label ? 'border-brand-500 bg-brand-500/10' : 'border-surface-700 hover:border-surface-500'}`}>
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{t.icon}</span>
                      <div>
                        <p className={`text-sm font-medium ${form.type === t.label ? 'text-brand-300' : 'text-slate-300'}`}>{t.label}</p>
                        <p className="text-xs text-slate-500">{t.desc}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Test category filter */}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-2">Category</label>
              <div className="flex gap-2 flex-wrap">
                {testCategories.map(c => (
                  <button key={c} onClick={() => setSelectedCategory(c)} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${selectedCategory === c ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700 hover:text-slate-200'}`}>{c}</button>
                ))}
              </div>
            </div>

            {/* Tests */}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-2">Select Tests ({form.tests.length} selected)</label>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {filteredTests.map(t => (
                  <button key={t.name} onClick={() => toggleTest(t.name)} className={`w-full text-left p-3 border-2 rounded-xl text-sm transition-all flex items-center justify-between ${form.tests.includes(t.name) ? 'border-brand-500 bg-brand-500/10' : 'border-surface-700 hover:border-surface-500'}`}>
                    <div className="min-w-0">
                      <p className={`font-medium ${form.tests.includes(t.name) ? 'text-brand-300' : 'text-slate-300'}`}>{t.name}</p>
                      <p className="text-xs text-slate-500">{t.category} · {t.tat} · {t.sample}</p>
                    </div>
                    <span className={`font-bold text-lg ${form.tests.includes(t.name) ? 'text-brand-400' : 'text-slate-500'}`}>₹{t.price}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">Preferred Date</label>
                <input type="date" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">Preferred Time</label>
                <input type="time" className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} />
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">Special Instructions (optional)</label>
              <textarea className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 resize-none" rows={2} placeholder="e.g., Fasting required, wheelchair assistance needed..." value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} />
            </div>

            {/* Total + Submit */}
            <button onClick={() => form.tests.length > 0 && setShowConfirm(true)} disabled={form.tests.length === 0} className={`w-full py-3 rounded-xl font-semibold text-sm transition-all ${form.tests.length > 0 ? 'bg-brand-500 hover:bg-brand-600 text-surface-950' : 'bg-surface-800 text-slate-500 cursor-not-allowed'}`}>
              {form.tests.length > 0 ? `Proceed to Confirm — ₹${totalAmount}` : 'Select tests to continue'}
            </button>
          </div>
        </div>

        {/* Right: Order summary */}
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 h-fit sticky top-6">
          <h3 className="font-semibold text-slate-300 mb-3">Order Summary</h3>
          {form.tests.length === 0 ? (
            <p className="text-sm text-slate-500 py-4 text-center">No tests selected yet</p>
          ) : (
            <div className="space-y-2">
              {form.tests.map(t => {
                const test = BOOKABLE_TESTS.find(bt => bt.name === t)
                return (
                  <div key={t} className="flex items-center justify-between text-sm">
                    <span className="text-slate-400 truncate mr-2">{t}</span>
                    <span className="text-slate-200 font-medium">₹{test?.price}</span>
                  </div>
                )
              })}
              <div className="border-t border-surface-700 pt-2 mt-2 flex justify-between font-bold">
                <span className="text-slate-300">Total</span>
                <span className="text-brand-400 text-lg">₹{totalAmount}</span>
              </div>
            </div>
          )}
          {form.tests.length > 0 && (
            <div className="mt-4 space-y-2 text-xs text-slate-500">
              <div className="flex items-center gap-2"><Clock size={12} /> Reports ready within 2–24 hrs</div>
              <div className="flex items-center gap-2"><CheckCircle size={12} /> Free home pickup available</div>
            </div>
          )}
        </div>
      </div>

      {/* Confirmation Modal */}
      <Modal open={showConfirm} onClose={() => setShowConfirm(false)} title="Confirm Booking">
        <div className="space-y-4">
          <div className="bg-surface-850 rounded-xl p-4 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Patient:</span><span className="text-slate-200">{PATIENT.name}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Type:</span><span className="text-slate-200">{form.type}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Tests ({form.tests.length}):</span><span className="text-slate-200 text-right max-w-[60%]">{form.tests.join(', ')}</span></div>
            {form.date && <div className="flex justify-between"><span className="text-slate-500">Date:</span><span className="text-slate-200">{form.date} {form.time || ''}</span></div>}
            {form.notes && <div className="flex justify-between"><span className="text-slate-500">Notes:</span><span className="text-slate-200 text-right max-w-[60%]">{form.notes}</span></div>}
            <div className="border-t border-surface-700 pt-2 flex justify-between font-bold"><span className="text-slate-300">Total:</span><span className="text-brand-400 text-xl">₹{totalAmount}</span></div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowConfirm(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Back</button>
            <button onClick={handleFinalBook} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-5 py-2 rounded-xl text-sm font-medium">Pay ₹{totalAmount} & Confirm</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PAYMENTS
// ═══════════════════════════════════════════════════════════════════════════════
export function Payments() {
  const [filter, setFilter] = useState('all')
  const filtered = filter === 'all' ? PAYMENTS_DATA : PAYMENTS_DATA.filter(p => p.status === filter)
  const totalPaid = PAYMENTS_DATA.reduce((s, p) => s + p.amount, 0)

  const handleDownload = (p) => {
    const w = window.open('', '_blank')
    w.document.write(`<html><head><title>Receipt — ${p.invoice}</title>
      <style>body{font-family:'Segoe UI',sans-serif;padding:40px;max-width:600px;margin:0 auto;color:#333}
      h1{color:#059669;border-bottom:2px solid #059669;padding-bottom:8px;font-size:18px}
      table{width:100%;border-collapse:collapse;margin:16px 0;font-size:13px}td,th{border:1px solid #e2e8f0;padding:8px}
      th{background:#f0fdf4}.footer{margin-top:32px;font-size:11px;color:#94a3b8;border-top:1px solid #e2e8f0;padding-top:12px}</style></head><body>
      <h1>🏥 MediFlow Diagnostic Lab — Payment Receipt</h1>
      <table>
        <tr><th>Invoice No</th><td>${p.invoice}</td></tr>
        <tr><th>Patient</th><td>${PATIENT.name} (${PATIENT.id})</td></tr>
        <tr><th>Tests</th><td>${p.tests}</td></tr>
        <tr><th>Amount</th><td>₹${p.amount.toLocaleString()}</td></tr>
        <tr><th>Date</th><td>${p.date}</td></tr>
        <tr><th>Payment Method</th><td>${p.method}</td></tr>
        <tr><th>Status</th><td style="color:green;font-weight:bold">${p.status.toUpperCase()}</td></tr>
      </table>
      <div class="footer">
        <p>MediFlow Diagnostic Lab · 27, Rajendra Nagar, Raipur, CG 492001</p>
        <p>Ph: +91 98765 43210 · Thank you for choosing MediFlow!</p>
      </div></body></html>`)
    w.document.close()
    toast.success('Receipt downloaded!')
  }

  const handleShare = (p) => {
    const msg = `🏥 *MediFlow Diagnostic Lab*\n\n📋 Invoice: ${p.invoice}\n🧪 Tests: ${p.tests}\n💰 Amount: ₹${p.amount}\n📅 Date: ${p.date}\n💳 Method: ${p.method}\n✅ Status: ${p.status.toUpperCase()}\n\nThank you for choosing MediFlow!`
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank')
    toast.success('Opening WhatsApp...')
  }

  return (
    <div>
      <PageHeader title="Payment History" subtitle={`${PAYMENTS_DATA.length} invoices · Total paid: ₹${totalPaid.toLocaleString()}`} />

      {/* Filter tabs */}
      <div className="flex gap-2 mb-4">
        {[{ k: 'all', l: 'All' }, { k: 'paid', l: 'Paid' }].map(f => (
          <button key={f.k} onClick={() => setFilter(f.k)} className={`px-4 py-1.5 rounded-xl text-xs font-medium transition-all ${filter === f.k ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700'}`}>{f.l} ({f.k === 'all' ? PAYMENTS_DATA.length : PAYMENTS_DATA.filter(p => p.status === f.k).length})</button>
        ))}
      </div>

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="divide-y divide-surface-800">
          {filtered.map((p, i) => (
            <div key={i} className="flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors">
              <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Wallet size={18} className="text-green-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-slate-300 truncate">{p.tests}</p>
                <p className="text-xs text-slate-500">{p.invoice} · {p.date} · {p.method}</p>
              </div>
              <p className="font-bold text-slate-200 flex-shrink-0">₹{p.amount.toLocaleString()}</p>
              <Badge status={p.status} />
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => handleDownload(p)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Download size={12} />PDF</button>
                <button onClick={() => handleShare(p)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Share2 size={12} />WhatsApp</button>
              </div>
            </div>
          ))}
        </div>
        <div className="p-4 border-t border-surface-700 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-400">Showing {filtered.length} of {PAYMENTS_DATA.length} invoices</span>
          </div>
          <div className="text-right">
            <span className="text-sm text-slate-400">Total Paid: </span>
            <span className="font-bold text-brand-400 text-lg">₹{totalPaid.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PATIENT AI SUMMARY
// ═══════════════════════════════════════════════════════════════════════════════
export function PatientAISummary() {
  const [expandedIdx, setExpandedIdx] = useState(null)

  const trendColors = { improving: 'green', stable: 'blue', attention: 'amber', watch: 'amber' }
  const trendLabels = { improving: '↑ Improving', stable: '→ Stable', attention: '⚠ Attention Needed', watch: '👁 Watch' }
  const trendStyles = {
    improving: 'bg-green-500/10 text-green-400 border-green-500/20',
    stable: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    attention: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    watch: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  }

  return (
    <div>
      <PageHeader title="AI Health Summary" subtitle="Personalised insights across 12 reports since Nov 2025" />

      {/* Health score overview */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-4">
        <div className="flex items-center gap-4 mb-3">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center flex-shrink-0">
            <span className="text-2xl font-bold text-white">78</span>
          </div>
          <div>
            <p className="font-semibold text-slate-200">Overall Health Score</p>
            <p className="text-sm text-slate-400">Based on 12 reports across 8 test categories</p>
          </div>
        </div>
        <div className="flex gap-3 flex-wrap">
          <div className="flex items-center gap-1.5 text-xs">
            <span className="w-2 h-2 rounded-full bg-green-400" /><span className="text-slate-400">5 Normal</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <span className="w-2 h-2 rounded-full bg-amber-400" /><span className="text-slate-400">2 Needs Attention</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <span className="w-2 h-2 rounded-full bg-red-400" /><span className="text-slate-400">0 Critical</span>
          </div>
        </div>
      </div>

      {/* Key trends */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
        {[
          { label: 'HbA1c Trend', values: '7.2% → 7.0% → 6.9%', trend: 'improving', icon: TrendingUp },
          { label: 'LDL Cholesterol', values: '138 → 140 → 142 mg/dL', trend: 'attention', icon: Heart },
          { label: 'Vitamin D', values: '18 → 20 → 22 ng/mL', trend: 'attention', icon: Activity },
        ].map((t, i) => (
          <div key={i} className="bg-surface-900 rounded-2xl border border-surface-700 p-4">
            <div className="flex items-center gap-2 mb-2">
              <t.icon size={16} className="text-brand-400" />
              <p className="text-sm font-medium text-slate-300">{t.label}</p>
            </div>
            <p className="text-xs text-slate-400 font-mono">{t.values}</p>
            <span className={`inline-block mt-1 text-xs px-2 py-0.5 rounded-full border ${trendStyles[t.trend]}`}>{trendLabels[t.trend]}</span>
          </div>
        ))}
      </div>

      {/* All insights */}
      <div className="space-y-3">
        {AI_INSIGHTS.map((s, i) => {
          const color = trendColors[s.trend]
          const isExpanded = expandedIdx === i
          return (
            <div key={i} className="bg-surface-900 rounded-2xl border border-surface-700 p-5 hover:border-surface-600 transition-all">
              <div className="flex items-start gap-3 cursor-pointer" onClick={() => setExpandedIdx(isExpanded ? null : i)}>
                <span className="text-2xl">{s.icon}</span>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <p className="font-semibold text-slate-300">{s.title}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full border ${trendStyles[s.trend]}`}>{trendLabels[s.trend]}</span>
                  </div>
                  <p className="text-sm text-slate-400 leading-relaxed">{s.summary}</p>
                  {isExpanded && s.details && (
                    <div className="mt-3 p-3 bg-surface-850 rounded-xl">
                      <p className="text-xs font-medium text-slate-500 mb-1">Detailed Values:</p>
                      <p className="text-xs text-slate-300 font-mono">{s.details}</p>
                    </div>
                  )}
                  <p className="text-xs text-slate-500 mt-2">Based on report dated {s.date}</p>
                </div>
                <span className={`text-xs text-slate-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`}>▼</span>
              </div>
            </div>
          )
        })}
      </div>

      {/* Recommendations */}
      <div className="bg-surface-900 rounded-2xl border border-brand-500/20 p-5 mt-4">
        <p className="font-semibold text-slate-300 mb-3 flex items-center gap-2"><Bot size={18} className="text-brand-400" /> AI Recommendations</p>
        <div className="space-y-2">
          {[
            { text: 'Take Vitamin D supplement (6000 IU/day) for 8 weeks, then retest.', priority: 'high' },
            { text: 'Reduce saturated fats — aim for LDL below 130 mg/dL.', priority: 'medium' },
            { text: 'Follow up on HbA1c in 3 months to confirm improvement trend.', priority: 'medium' },
            { text: 'Recheck CRP in 4 weeks to confirm inflammation has resolved.', priority: 'low' },
            { text: 'Schedule annual comprehensive health checkup in December.', priority: 'low' },
          ].map((r, i) => (
            <div key={i} className="flex items-start gap-2 text-sm">
              <span className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${r.priority === 'high' ? 'bg-red-400' : r.priority === 'medium' ? 'bg-amber-400' : 'bg-slate-500'}`} />
              <span className="text-slate-400">{r.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-surface-900 rounded-2xl border border-amber-500/20 p-4 mt-4 bg-amber-500/5">
        <p className="text-xs text-amber-400 leading-relaxed">
          ⚕️ <strong>Disclaimer:</strong> These insights are generated by AI based on your reports. They are for informational purposes only and do not constitute medical advice. Always consult your doctor for clinical decisions.
        </p>
      </div>
    </div>
  )
}
