import React, { useState } from 'react'
import { PageHeader, Badge, StatCard } from '../../components/UI'
import { FileText, Activity, CalendarDays, Wallet, Bot, Download, Share2, CheckCircle } from 'lucide-react'

export function PatientDashboard() {
  return (
    <div>
      <div className="mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-slate-500 to-slate-700 flex items-center justify-center text-white font-bold text-lg">RS</div>
          <div>
            <h1 className="text-xl font-semibold text-slate-100">Welcome, Rahul Sharma</h1>
            <p className="text-sm text-slate-500">Patient ID: P001 · +91 98765 43210</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={FileText} label="Total Reports" value="12" color="blue" />
        <StatCard icon={Activity} label="Tests Done" value="28" color="green" />
        <StatCard icon={CalendarDays} label="Last Visit" value="Jun 12" color="purple" />
        <StatCard icon={Wallet} label="Total Paid" value="₹8,400" color="amber" />
      </div>

      {/* AI Health Summary card */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 mb-4 border-l-4 border-brand-500">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 bg-brand-500/15 rounded-xl flex items-center justify-center flex-shrink-0">
            <Bot size={18} className="text-brand-400" />
          </div>
          <div>
            <p className="font-semibold text-slate-300 mb-1">AI Health Summary</p>
            <p className="text-sm text-slate-400 leading-relaxed">
              Your latest CBC (Jun 12) is within normal range. HbA1c shows improvement from 7.2% (Mar) to 6.9% (Jun) — keep it up! 
              Your Lipid Profile suggests LDL is slightly elevated at 142 mg/dL. Consider reducing saturated fats.
            </p>
            <p className="text-xs text-slate-500 mt-2">⚕️ This is AI-generated health insight, not a medical diagnosis. Consult your doctor.</p>
          </div>
        </div>
      </div>

      {/* Recent reports */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-4 border-b border-surface-700">
          <p className="font-semibold text-slate-300">Recent Reports</p>
        </div>
        <div className="divide-y divide-surface-800">
          {[
            { test: 'Complete Blood Count (CBC)', date: 'Jun 12, 2026', status: 'completed', lab: 'City Diagnostics' },
            { test: 'Lipid Profile', date: 'May 28, 2026', status: 'completed', lab: 'City Diagnostics' },
            { test: 'Thyroid Profile', date: 'Apr 15, 2026', status: 'completed', lab: 'City Diagnostics' },
          ].map((r, i) => (
            <div key={i} className="flex items-center gap-4 p-4">
              <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <FileText size={18} className="text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-sm text-slate-300">{r.test}</p>
                <p className="text-xs text-slate-500">{r.lab} · {r.date}</p>
              </div>
              <Badge status={r.status} />
              <div className="flex gap-2">
                <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1 flex items-center gap-1"><Download size={12} />PDF</button>
                <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1 flex items-center gap-1"><Share2 size={12} />Share</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function MyReports() {
  return (
    <div>
      <PageHeader title="My Reports" subtitle="Download and share your diagnostic reports" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="divide-y divide-surface-800">
          {[
            { test: 'Complete Blood Count (CBC)', date: 'Jun 12, 2026', id: 'RPT-001', status: 'completed' },
            { test: 'Lipid Profile', date: 'May 28, 2026', id: 'RPT-002', status: 'completed' },
            { test: 'Thyroid Profile (T3,T4,TSH)', date: 'Apr 15, 2026', id: 'RPT-003', status: 'completed' },
            { test: 'HbA1c', date: 'Mar 10, 2026', id: 'RPT-004', status: 'completed' },
            { test: 'Liver Function Test', date: 'Feb 8, 2026', id: 'RPT-005', status: 'completed' },
          ].map((r, i) => (
            <div key={i} className="flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors">
              <div className="w-10 h-10 bg-brand-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <CheckCircle size={18} className="text-brand-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-sm text-slate-300">{r.test}</p>
                <p className="text-xs text-slate-500">{r.id} · {r.date}</p>
              </div>
              <div className="flex gap-2">
                <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1.5 flex items-center gap-1"><Download size={12} />PDF</button>
                <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1.5 flex items-center gap-1"><Share2 size={12} />WhatsApp</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function TestStatus() {
  const tests = [
    { test: 'CBC', collected: '08:30 AM', status: 'completed', eta: 'Done' },
    { test: 'Lipid Profile', collected: '08:30 AM', status: 'processing', eta: 'Ready by 2:30 PM' },
    { test: 'HbA1c', collected: '08:30 AM', status: 'pending', eta: 'Ready by 4:00 PM' },
  ]
  const stages = ['Collection', 'Processing', 'Verification', 'Report Ready']
  return (
    <div>
      <PageHeader title="Test Status" subtitle="Live tracking of your current tests" />
      <div className="space-y-4">
        {tests.map((t, i) => {
          const stageIdx = t.status === 'completed' ? 3 : t.status === 'processing' ? 1 : 0
          return (
            <div key={i} className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="font-semibold text-slate-300">{t.test}</p>
                  <p className="text-xs text-slate-500">Collected at {t.collected}</p>
                </div>
                <div>
                  <Badge status={t.status} />
                  <p className="text-xs text-slate-500 mt-1 text-right">{t.eta}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {stages.map((s, si) => (
                  <React.Fragment key={s}>
                    <div className="flex flex-col items-center">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${si <= stageIdx ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-500'}`}>
                        {si <= stageIdx ? '✓' : si + 1}
                      </div>
                      <p className={`text-xs mt-1 text-center ${si <= stageIdx ? 'text-brand-400 font-medium' : 'text-slate-500'}`}>{s}</p>
                    </div>
                    {si < stages.length - 1 && (
                      <div className={`flex-1 h-0.5 mb-5 ${si < stageIdx ? 'bg-brand-500' : 'bg-surface-700'}`} />
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export function BookTest() {
  return (
    <div>
      <PageHeader title="Book a Test" subtitle="Schedule lab visit or home collection" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-6 max-w-xl">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Collection Type</label>
            <div className="grid grid-cols-2 gap-3">
              {['Visit Lab', 'Home Collection'].map(t => (
                <button key={t} className="p-3 border-2 border-surface-700 rounded-xl text-sm font-medium text-slate-400 hover:border-primary-400 transition-colors">
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Select Tests</label>
            <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" multiple style={{ height: 120 }}>
              <option>Complete Blood Count (CBC) — ₹350</option>
              <option>Lipid Profile — ₹600</option>
              <option>Thyroid Profile — ₹850</option>
              <option>Liver Function Test — ₹700</option>
              <option>HbA1c — ₹500</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1.5">Preferred Date & Time</label>
            <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" type="datetime-local" />
          </div>
          <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all w-full py-2.5">Confirm Booking</button>
        </div>
      </div>
    </div>
  )
}

export function Payments() {
  const payments = [
    { invoice: 'INV-2026-001', tests: 'CBC', amount: 350, date: 'Jun 12, 2026', status: 'paid' },
    { invoice: 'INV-2026-002', tests: 'Lipid Profile', amount: 600, date: 'May 28, 2026', status: 'paid' },
    { invoice: 'INV-2026-003', tests: 'Thyroid Profile', amount: 850, date: 'Apr 15, 2026', status: 'paid' },
  ]
  return (
    <div>
      <PageHeader title="Payment History" subtitle="Your invoices and payment records" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="divide-y divide-surface-800">
          {payments.map((p, i) => (
            <div key={i} className="flex items-center gap-4 p-4">
              <div className="flex-1">
                <p className="font-medium text-sm text-slate-300">{p.tests}</p>
                <p className="text-xs text-slate-500">{p.invoice} · {p.date}</p>
              </div>
              <p className="font-semibold text-slate-300">₹{p.amount}</p>
              <Badge status={p.status} />
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1"><Download size={12} /></button>
            </div>
          ))}
        </div>
        <div className="p-4 border-t border-surface-700 flex justify-between">
          <span className="text-sm font-medium text-slate-400">Total Paid</span>
          <span className="font-bold text-slate-100">₹8,400</span>
        </div>
      </div>
    </div>
  )
}

export function PatientAISummary() {
  return (
    <div>
      <PageHeader title="AI Health Summary" subtitle="Personalised AI-generated health insights" />
      <div className="space-y-4">
        {[
          { title: 'Blood Count (CBC)', icon: '🩸', summary: 'All CBC parameters are within normal range. Haemoglobin is 13.2 g/dL (normal: 12–16). White cell count is normal, no signs of infection.', trend: 'stable', date: 'Jun 12, 2026' },
          { title: 'Blood Sugar (HbA1c)', icon: '🍬', summary: 'HbA1c has improved from 7.2% in March to 6.9% in June — excellent progress! Target is below 7.0%. Continue current diet and medication.', trend: 'improving', date: 'Jun 1, 2026' },
          { title: 'Lipid Profile', icon: '❤️', summary: 'LDL cholesterol is slightly elevated at 142 mg/dL (ideal: <130). HDL is good at 52 mg/dL. Consider reducing red meat and fried foods. Follow up in 3 months.', trend: 'attention', date: 'May 28, 2026' },
        ].map((s, i) => (
          <div key={i} className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <div className="flex items-start gap-3">
              <span className="text-2xl">{s.icon}</span>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-semibold text-slate-300">{s.title}</p>
                  <span className={`badge text-xs ${s.trend === 'improving' ? 'badge-green' : s.trend === 'attention' ? 'badge-amber' : 'badge-blue'}`}>
                    {s.trend === 'improving' ? '↑ Improving' : s.trend === 'attention' ? '⚠ Attention' : '→ Stable'}
                  </span>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed">{s.summary}</p>
                <p className="text-xs text-slate-500 mt-2">Based on report dated {s.date}</p>
              </div>
            </div>
          </div>
        ))}
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 bg-amber-500/10 border border-amber-100">
          <p className="text-xs text-amber-400 leading-relaxed">
            ⚕️ <strong>Disclaimer:</strong> These insights are generated by AI based on your reports. They are for informational purposes only and do not constitute medical advice. Always consult your doctor.
          </p>
        </div>
      </div>
    </div>
  )
}
