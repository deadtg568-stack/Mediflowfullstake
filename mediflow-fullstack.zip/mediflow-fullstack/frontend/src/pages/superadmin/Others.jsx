import React, { useState } from 'react'
import { PageHeader, Badge, Table, Modal } from '../../components/UI'
import { mockLabs, revenueData } from '../../utils/mockData'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'
import { Activity, Server, Cpu, Database, Wifi, Send, Key, RefreshCw } from 'lucide-react'
import toast from 'react-hot-toast'

export function Subscriptions() {
  const [showKeyModal, setShowKeyModal] = useState(false)
  const [newKey, setNewKey] = useState('')

  const handleGenerateKey = () => {
    const key = `MFPAI-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`
    setNewKey(key)
    setShowKeyModal(true)
    toast.success('License key generated!')
  }

  const handleRenew = (lab) => {
    toast.success(`Subscription renewed for ${lab.name}!`)
  }

  const handleCopyKey = () => {
    navigator.clipboard.writeText(newKey)
    toast.success('Key copied to clipboard!')
  }

  return (
    <div>
      <PageHeader title="Subscriptions" subtitle="Manage all lab subscription plans and licenses" />
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { plan: 'Starter', price: '₹999', count: 2, color: 'border-emerald-500 bg-brand-500/10' },
          { plan: 'Professional', price: '₹1,999', count: 2, color: 'border-blue-500 bg-blue-500/10' },
          { plan: 'Enterprise AI', price: '₹3,999', count: 1, color: 'border-purple-500 bg-purple-500/10' },
        ].map(p => (
          <div key={p.plan} className={`card p-5 border-t-4 ${p.color}`}>
            <p className="font-semibold text-slate-300">{p.plan}</p>
            <p className="text-2xl font-bold text-slate-100 mt-1">{p.price}<span className="text-sm font-normal text-slate-500">/mo</span></p>
            <p className="text-sm text-slate-500 mt-1">{p.count} active labs</p>
          </div>
        ))}
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-5 border-b border-surface-700 flex justify-between items-center">
          <p className="font-semibold text-slate-300">License Keys</p>
          <button onClick={handleGenerateKey} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs flex items-center gap-1.5"><Key size={14} /> Generate Key</button>
        </div>
        <Table
          columns={[
            { key: 'id', label: 'Lab' },
            { key: 'name', label: 'Lab Name' },
            { key: 'plan', label: 'Plan' },
            { key: 'expiry', label: 'Expiry' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={mockLabs.map(l => ({ ...l, key: `MFPAI-2026-${l.id}` }))}
          actions={(row) => (
            <button onClick={() => handleRenew(row)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><RefreshCw size={12} /> Renew</button>
          )}
        />
      </div>

      <Modal open={showKeyModal} onClose={() => setShowKeyModal(false)} title="Generated License Key">
        <div className="space-y-4">
          <div className="bg-surface-850 rounded-xl p-4 text-center">
            <p className="text-xs text-slate-500 mb-2">Your new license key:</p>
            <p className="text-lg font-mono font-bold text-brand-400 tracking-wider">{newKey}</p>
          </div>
          <p className="text-xs text-slate-500">This key has been generated and is ready to use. Copy it and share with the lab owner.</p>
          <div className="flex gap-2 justify-end">
            <button onClick={handleCopyKey} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Copy Key</button>
            <button onClick={() => setShowKeyModal(false)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium">Done</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export function Revenue() {
  return (
    <div>
      <PageHeader title="Revenue Analytics" subtitle="Platform-wide revenue and financial insights" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Monthly Revenue Trend</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={revenueData}>
              <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v/1000}K`} />
              <Tooltip formatter={v => [`₹${v.toLocaleString()}`, 'Revenue']} />
              <Bar dataKey="revenue" fill="#3DDC84" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Patient Growth</p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={revenueData}>
              <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip />
              <Line type="monotone" dataKey="patients" stroke="#3DDC84" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

export function ServerHealth() {
  const metrics = [
    { label: 'CPU Usage', value: '34%', icon: Cpu, color: 'text-blue-500', ok: true },
    { label: 'Memory', value: '62%', icon: Server, color: 'text-purple-500', ok: true },
    { label: 'Database', value: '28%', icon: Database, color: 'text-emerald-500', ok: true },
    { label: 'Network', value: '12 MB/s', icon: Wifi, color: 'text-amber-500', ok: true },
  ]
  return (
    <div>
      <PageHeader title="Server Health" subtitle="Real-time infrastructure monitoring" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {metrics.map(m => (
          <div key={m.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
            <m.icon size={28} className={`${m.color} mx-auto mb-2`} />
            <p className="text-2xl font-bold text-slate-100">{m.value}</p>
            <p className="text-sm text-slate-500 mt-0.5">{m.label}</p>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium bg-brand-500/10 text-brand-400 mt-2">Healthy</span>
          </div>
        ))}
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <p className="font-semibold text-slate-300 mb-3">Uptime Log (last 7 days)</p>
        <div className="flex gap-1">
          {Array.from({ length: 48 }, (_, i) => (
            <div key={i} className={`flex-1 h-8 rounded-sm ${i === 23 ? 'bg-amber-300' : 'bg-emerald-400'}`} title={i === 23 ? '99.2% uptime' : '100% uptime'} />
          ))}
        </div>
        <div className="flex justify-between text-xs text-slate-500 mt-2">
          <span>7 days ago</span><span>Today</span>
        </div>
      </div>
    </div>
  )
}

export function AIAnalytics() {
  return (
    <div>
      <PageHeader title="AI Analytics" subtitle="Platform-wide AI usage and insights" />
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: 'AI Reports Generated', value: '2,847', sub: 'this month' },
          { label: 'Voice Commands Used', value: '634', sub: 'this month' },
          { label: 'AI Chat Sessions', value: '1,203', sub: 'this month' },
        ].map(s => (
          <div key={s.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="text-2xl font-bold text-slate-100">{s.value}</p>
            <p className="text-sm font-medium text-slate-400 mt-0.5">{s.label}</p>
            <p className="text-xs text-slate-500">{s.sub}</p>
          </div>
        ))}
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <p className="font-semibold text-slate-300 mb-3">Top AI Voice Commands</p>
        {['Aaj kitni billing hui?', 'Pending reports dikhao', 'Low stock items batao', 'CBC test ka rate kya hai?', 'Aaj ke patients list karo'].map((cmd, i) => (
          <div key={i} className="flex items-center gap-3 py-2.5 border-b border-surface-700 last:border-0">
            <span className="w-6 h-6 bg-brand-500/15 text-brand-400 rounded-lg flex items-center justify-center text-xs font-bold">{i + 1}</span>
            <span className="text-sm text-slate-400 flex-1">"{cmd}"</span>
            <span className="text-xs text-slate-500">{[234, 198, 167, 145, 112][i]} uses</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export function Support() {
  const [tickets, setTickets] = useState([
    { id: 'TKT001', lab: 'City Diagnostics', issue: 'Report PDF not generating', priority: 'high', status: 'open', time: '2h ago' },
    { id: 'TKT002', lab: 'Sharma Lab', issue: 'WhatsApp share not working', priority: 'medium', status: 'open', time: '5h ago' },
    { id: 'TKT003', lab: 'LifeCare Diagnostics', issue: 'Billing GST calculation issue', priority: 'high', status: 'resolved', time: '1d ago' },
  ])
  const [showReplyModal, setShowReplyModal] = useState(false)
  const [selectedTicket, setSelectedTicket] = useState(null)
  const [reply, setReply] = useState('')

  const handleReply = (ticket) => {
    setSelectedTicket(ticket)
    setReply('')
    setShowReplyModal(true)
  }

  const handleSendReply = (e) => {
    e.preventDefault()
    setTickets(prev => prev.map(t => t.id === selectedTicket.id ? { ...t, status: 'in-progress' } : t))
    setShowReplyModal(false)
    toast.success(`Reply sent to ${selectedTicket.lab}!`)
  }

  const handleResolve = (ticket) => {
    setTickets(prev => prev.map(t => t.id === ticket.id ? { ...t, status: 'resolved' } : t))
    toast.success(`Ticket ${ticket.id} resolved!`)
  }

  return (
    <div>
      <PageHeader title="Support Tickets" subtitle="Manage lab support requests" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'Ticket' },
            { key: 'lab', label: 'Lab' },
            { key: 'issue', label: 'Issue' },
            { key: 'priority', label: 'Priority', render: v => (
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium ${v === 'high' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'}`}>{v}</span>
            )},
            { key: 'time', label: 'Time' },
            { key: 'status', label: 'Status', render: v => <Badge status={v === 'in-progress' ? 'processing' : v} /> },
          ]}
          data={tickets}
          actions={(row) => (
            <>
              <button onClick={() => handleReply(row)} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all flex items-center gap-1"><Send size={12} /> Reply</button>
              {row.status !== 'resolved' && (
                <button onClick={() => handleResolve(row)} className="bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/20 px-3 py-1 rounded-xl text-xs font-medium transition-all">Resolve</button>
              )}
            </>
          )}
        />
      </div>

      <Modal open={showReplyModal} onClose={() => setShowReplyModal(false)} title={`Reply to ${selectedTicket?.lab || ''}`}>
        <form onSubmit={handleSendReply} className="space-y-4">
          <div className="bg-surface-850 rounded-xl p-3 text-sm space-y-1">
            <div className="flex justify-between"><span className="text-slate-500">Ticket:</span><span className="text-slate-200">{selectedTicket?.id}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Lab:</span><span className="text-slate-200">{selectedTicket?.lab}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Issue:</span><span className="text-slate-200">{selectedTicket?.issue}</span></div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-1">Reply Message *</label>
            <textarea required className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 h-28 resize-none" placeholder="Type your reply..." value={reply} onChange={e => setReply(e.target.value)} />
          </div>
          <div className="flex gap-2 justify-end">
            <button type="button" onClick={() => setShowReplyModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Cancel</button>
            <button type="submit" className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5"><Send size={14} /> Send Reply</button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
