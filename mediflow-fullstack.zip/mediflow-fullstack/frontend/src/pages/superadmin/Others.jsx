import React from 'react'
import { PageHeader, Badge, Table } from '../../components/UI'
import { mockLabs, revenueData } from '../../utils/mockData'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'
import { Activity, Server, Cpu, Database, Wifi } from 'lucide-react'

export function Subscriptions() {
  return (
    <div>
      <PageHeader title="Subscriptions" subtitle="Manage all lab subscription plans and licenses" />
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { plan: 'Starter', price: '₹999', count: 2, color: 'border-emerald-500 bg-brand-500/10' },
          { plan: 'Professional', price: '₹1,999', count: 2, color: 'border-blue-500 bg-blue-500/10' },
          { plan: 'Enterprise AI', price: '₹3,999', count: 1, color: 'border-purple-500 bg-purple-500/10' },
        ].map(p => (
          <div key={p.plan} className={`card p-5 border-t-4 ${p.color}`}>
            <p className="font-semibold text-slate-300">{p.plan}</p>
            <p className="text-2xl font-bold text-slate-100 mt-1">{p.price}<span className="text-sm font-normal text-slate-500">/mo</span></p>
            <p className="text-sm text-slate-500 mt-1">{p.count} active labs</p>
          </div>
        ))}
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-5 border-b border-surface-700 flex justify-between items-center">
          <p className="font-semibold text-slate-300">License Keys</p>
          <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs">Generate Key</button>
        </div>
        <Table
          columns={[
            { key: 'id', label: 'Lab' },
            { key: 'name', label: 'Lab Name' },
            { key: 'plan', label: 'Plan' },
            { key: 'expiry', label: 'Expiry' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={mockLabs.map(l => ({ ...l, key: `MFPAI-2026-${l.id}` }))}
          actions={() => (
            <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Renew</button>
          )}
        />
      </div>
    </div>
  )
}

export function Revenue() {
  return (
    <div>
      <PageHeader title="Revenue Analytics" subtitle="Platform-wide revenue and financial insights" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Monthly Revenue Trend</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={revenueData}>
              <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v/1000}K`} />
              <Tooltip formatter={v => [`₹${v.toLocaleString()}`, 'Revenue']} />
              <Bar dataKey="revenue" fill="#3DDC84" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-4">Patient Growth</p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={revenueData}>
              <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip />
              <Line type="monotone" dataKey="patients" stroke="#3DDC84" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

export function ServerHealth() {
  const metrics = [
    { label: 'CPU Usage', value: '34%', icon: Cpu, color: 'text-blue-500', ok: true },
    { label: 'Memory', value: '62%', icon: Server, color: 'text-purple-500', ok: true },
    { label: 'Database', value: '28%', icon: Database, color: 'text-emerald-500', ok: true },
    { label: 'Network', value: '12 MB/s', icon: Wifi, color: 'text-amber-500', ok: true },
  ]
  return (
    <div>
      <PageHeader title="Server Health" subtitle="Real-time infrastructure monitoring" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {metrics.map(m => (
          <div key={m.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
            <m.icon size={28} className={`${m.color} mx-auto mb-2`} />
            <p className="text-2xl font-bold text-slate-100">{m.value}</p>
            <p className="text-sm text-slate-500 mt-0.5">{m.label}</p>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium bg-brand-500/10 text-brand-400 mt-2">Healthy</span>
          </div>
        ))}
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <p className="font-semibold text-slate-300 mb-3">Uptime Log (last 7 days)</p>
        <div className="flex gap-1">
          {Array.from({ length: 48 }, (_, i) => (
            <div key={i} className={`flex-1 h-8 rounded-sm ${i === 23 ? 'bg-amber-300' : 'bg-emerald-400'}`} title={i === 23 ? '99.2% uptime' : '100% uptime'} />
          ))}
        </div>
        <div className="flex justify-between text-xs text-slate-500 mt-2">
          <span>7 days ago</span><span>Today</span>
        </div>
      </div>
    </div>
  )
}

export function AIAnalytics() {
  return (
    <div>
      <PageHeader title="AI Analytics" subtitle="Platform-wide AI usage and insights" />
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: 'AI Reports Generated', value: '2,847', sub: 'this month' },
          { label: 'Voice Commands Used', value: '634', sub: 'this month' },
          { label: 'AI Chat Sessions', value: '1,203', sub: 'this month' },
        ].map(s => (
          <div key={s.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            <p className="text-2xl font-bold text-slate-100">{s.value}</p>
            <p className="text-sm font-medium text-slate-400 mt-0.5">{s.label}</p>
            <p className="text-xs text-slate-500">{s.sub}</p>
          </div>
        ))}
      </div>
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <p className="font-semibold text-slate-300 mb-3">Top AI Voice Commands</p>
        {['Aaj kitni billing hui?', 'Pending reports dikhao', 'Low stock items batao', 'CBC test ka rate kya hai?', 'Aaj ke patients list karo'].map((cmd, i) => (
          <div key={i} className="flex items-center gap-3 py-2.5 border-b border-surface-700 last:border-0">
            <span className="w-6 h-6 bg-brand-500/15 text-brand-400 rounded-lg flex items-center justify-center text-xs font-bold">{i + 1}</span>
            <span className="text-sm text-slate-400 flex-1">"{cmd}"</span>
            <span className="text-xs text-slate-500">{[234, 198, 167, 145, 112][i]} uses</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export function Support() {
  const tickets = [
    { id: 'TKT001', lab: 'City Diagnostics', issue: 'Report PDF not generating', priority: 'high', status: 'open', time: '2h ago' },
    { id: 'TKT002', lab: 'Sharma Lab', issue: 'WhatsApp share not working', priority: 'medium', status: 'open', time: '5h ago' },
    { id: 'TKT003', lab: 'LifeCare Diagnostics', issue: 'Billing GST calculation issue', priority: 'high', status: 'resolved', time: '1d ago' },
  ]
  return (
    <div>
      <PageHeader title="Support Tickets" subtitle="Manage lab support requests" />
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'Ticket' },
            { key: 'lab', label: 'Lab' },
            { key: 'issue', label: 'Issue' },
            { key: 'priority', label: 'Priority', render: v => <span className={`badge ${v === 'high' ? 'badge-red' : 'badge-amber'}`}>{v}</span> },
            { key: 'time', label: 'Time' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={tickets}
          actions={() => <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Reply</button>}
        />
      </div>
    </div>
  )
}
