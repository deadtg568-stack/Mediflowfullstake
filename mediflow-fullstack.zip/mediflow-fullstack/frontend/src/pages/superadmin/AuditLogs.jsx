import React, { useState, useEffect } from 'react'
import { PageHeader, Badge, SearchBar } from '../../components/UI'
import { Clock, Filter, User, Building2, Shield, Activity, Search, X } from 'lucide-react'
import toast from 'react-hot-toast'
import { EmptyState } from '../../components/Animations'
import { superAdminAPI } from '../../utils/api'

const ACTION_LABELS = {
  'user.login': { label: 'User Login', icon: '🔑', color: 'blue' },
  'patient.create': { label: 'Patient Created', icon: '👤', color: 'green' },
  'billing.create': { label: 'Invoice Created', icon: '🧾', color: 'emerald' },
  'report.verify': { label: 'Report Verified', icon: '📋', color: 'purple' },
  'outbreak.detection': { label: 'Outbreak Scan', icon: '🦠', color: 'amber' },
  'inventory.stock-alert': { label: 'Stock Alert', icon: '📦', color: 'red' },
  'lab.create': { label: 'Lab Created', icon: '🏥', color: 'blue' },
  'subscription.renew': { label: 'Subscription Renewed', icon: '💳', color: 'green' },
}

const FALLBACK_LOGS = [
  { _id: '1', actor: { name: 'System', role: 'system' }, action: 'user.login', resource: 'User', details: { ip: '192.168.1.1' }, createdAt: '2026-06-18T10:32:00Z', success: true },
  { _id: '2', actor: { name: 'Kavita Sharma', role: 'labadmin' }, lab: { name: 'City Diagnostics' }, action: 'patient.create', resource: 'Patient', resourceId: 'P0048', createdAt: '2026-06-18T10:15:00Z', success: true },
  { _id: '3', actor: { name: 'Ravi Kumar', role: 'reception' }, lab: { name: 'City Diagnostics' }, action: 'billing.create', resource: 'Bill', resourceId: 'INV-2026-018', createdAt: '2026-06-18T09:45:00Z', success: true },
  { _id: '4', actor: { name: 'Kavita Sharma', role: 'technician' }, lab: { name: 'City Diagnostics' }, action: 'report.verify', resource: 'Report', resourceId: 'RPT-2026-015', createdAt: '2026-06-18T09:20:00Z', success: true },
  { _id: '5', actor: { name: 'System', role: 'system' }, action: 'outbreak.detection', resource: 'OutbreakAlert', details: { disease: 'Dengue', city: 'Raipur' }, createdAt: '2026-06-18T08:00:00Z', success: true },
  { _id: '6', actor: { name: 'Vikram Sharma', role: 'labadmin' }, lab: { name: 'Sharma Lab & Path' }, action: 'inventory.stock-alert', resource: 'Inventory', details: { item: 'Glucose Reagent', stock: 3 }, createdAt: '2026-06-18T07:30:00Z', success: true },
  { _id: '7', actor: { name: 'Admin', role: 'superadmin' }, action: 'lab.create', resource: 'Lab', resourceId: 'L006', details: { labName: 'New Diagnostics' }, createdAt: '2026-06-17T16:00:00Z', success: true },
  { _id: '8', actor: { name: 'Priya Nair', role: 'labadmin' }, lab: { name: 'LifeCare Diagnostics' }, action: 'subscription.renew', resource: 'Subscription', createdAt: '2026-06-17T14:30:00Z', success: true },
]

export default function AuditLogs() {
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [actionFilter, setActionFilter] = useState('all')

  useEffect(() => {
    const fetchAuditLogs = async () => {
      setLoading(true)
      try {
        const token = localStorage.getItem('mf_token')
        const base = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
        const res = await fetch(`${base}/superadmin/audit-logs`, {
          headers: { Authorization: `Bearer ${token}` },
        })
        if (res.ok) {
          const json = await res.json()
          if (json.data?.logs?.length > 0) {
            setLogs(json.data.logs)
            return
          }
        }
        // Fallback to dashboard's recentLogs
        const dashRes = await superAdminAPI.dashboard()
        if (dashRes.data.data?.recentLogs?.length > 0) {
          setLogs(dashRes.data.data.recentLogs)
        } else {
          setLogs(FALLBACK_LOGS)
        }
      } catch {
        setLogs(FALLBACK_LOGS)
      } finally { setLoading(false) }
    }
    fetchAuditLogs()
  }, [])

  const filtered = logs.filter(log => {
    const matchSearch = !search ||
      (log.actor?.name || '').toLowerCase().includes(search.toLowerCase()) ||
      (log.lab?.name || '').toLowerCase().includes(search.toLowerCase()) ||
      (log.resourceId || '').toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase())

    const matchAction = actionFilter === 'all' || log.action === actionFilter
    return matchSearch && matchAction
  })

  const uniqueActions = [...new Set(logs.map(l => l.action))]

  return (
    <div>
      <PageHeader title="Audit Logs" subtitle="Track all platform activity — patient registrations, billing, verifications & more" />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1 max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by user, lab, action..." className="w-full bg-surface-900 border border-surface-700 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setActionFilter('all')} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${actionFilter === 'all' ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700 hover:text-slate-200'}`}>
            All Actions
          </button>
          {uniqueActions.slice(0, 5).map(a => (
            <button key={a} onClick={() => setActionFilter(a)} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${actionFilter === a ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700 hover:text-slate-200'}`}>
              {ACTION_LABELS[a]?.label || a.split('.')[1] || a}
            </button>
          ))}
        </div>
      </div>

      {/* Stats summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        {[
          { label: 'Total Events', value: logs.length, icon: Activity, color: 'text-blue-400' },
          { label: 'Today', value: logs.filter(l => new Date(l.createdAt).toDateString() === new Date().toDateString()).length, icon: Clock, color: 'text-green-400' },
          { label: 'Users Active', value: new Set(logs.map(l => l.actor?.name)).size, icon: User, color: 'text-purple-400' },
          { label: 'Labs Active', value: new Set(logs.filter(l => l.lab).map(l => l.lab?.name)).size, icon: Building2, color: 'text-amber-400' },
        ].map(s => (
          <div key={s.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-surface-850 border border-surface-700">
              <s.icon size={16} className={s.color} />
            </div>
            <div>
              <p className="text-lg font-bold text-slate-100">{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Timeline */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading...</div>
        ) : filtered.length === 0 ? (
          <EmptyState icon={Shield} title="No audit events found" description="Try adjusting your search or filters" />
        ) : (
          <div className="divide-y divide-surface-800">
            {filtered.map((log, i) => {
              const meta = ACTION_LABELS[log.action] || { label: log.action, icon: '📝', color: 'slate' }
              const time = new Date(log.createdAt)
              const timeStr = time.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
              const dateStr = time.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
              return (
                <div key={log._id} className="flex items-start gap-4 p-4 hover:bg-surface-850 transition-colors group">
                  {/* Timeline dot */}
                  <div className="relative flex flex-col items-center pt-1">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs ${
                      log.success !== false ? 'bg-brand-500/15 text-brand-400' : 'bg-red-500/15 text-red-400'
                    }`}>
                      {log.success !== false ? '✓' : '✗'}
                    </div>
                    {i < filtered.length - 1 && <div className="w-0.5 flex-1 bg-surface-700 mt-1" />}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0 pb-4">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-slate-300">{meta.label}</span>
                      {log.resourceId && <span className="text-xs font-mono text-brand-400 bg-brand-500/10 px-1.5 py-0.5 rounded">{log.resourceId}</span>}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="flex items-center gap-1"><User size={11} /> {log.actor?.name || 'System'}</span>
                      {log.lab && <span className="flex items-center gap-1"><Building2 size={11} /> {log.lab.name}</span>}
                      <span className="flex items-center gap-1"><Clock size={11} /> {dateStr}, {timeStr}</span>
                    </div>
                    {log.details && Object.keys(log.details).length > 0 && (
                      <div className="mt-1.5 text-xs text-slate-600 font-mono">
                        {Object.entries(log.details).map(([k, v]) => `${k}: ${v}`).join(' · ')}
                      </div>
                    )}
                  </div>

                  {/* Role badge */}
                  <span className="text-[10px] px-2 py-1 rounded-full bg-surface-800 text-slate-500 border border-surface-700 flex-shrink-0 capitalize">
                    {log.actor?.role || 'system'}
                  </span>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
