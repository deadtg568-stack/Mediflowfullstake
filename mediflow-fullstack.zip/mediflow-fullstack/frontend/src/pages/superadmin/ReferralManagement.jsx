import React, { useState, useEffect } from 'react'
import { PageHeader, Badge, Table, Modal } from '../../components/UI'
import { Gift, Search, CheckCircle, XCircle, ExternalLink, Copy } from 'lucide-react'
import toast from 'react-hot-toast'

export default function SuperAdminReferrals() {
  const [referrals, setReferrals] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [selectedRef, setSelectedRef] = useState(null)

  const load = async () => {
    setLoading(true)
    try {
      const { referralAPI } = await import('../../utils/api')
      const res = await referralAPI.getAll()
      setReferrals(res.data?.data?.referrals || [])
    } catch {
      setReferrals([
        { _id: 'R1', referralCode: 'RM-H7K8', referrerName: 'Dr. Rajesh Mehta', referredLabName: 'Sharma Diagnostics', status: 'converted', discountPercent: 50, discountApplied: false, createdAt: '2026-06-10', referrer: { name: 'Dr. Rajesh Mehta', role: 'doctor' }, referrerLab: { name: 'City Diagnostics' }, referredLab: { name: 'Sharma Diagnostics', plan: 'professional', status: 'active' } },
        { _id: 'R2', referralCode: 'CG-ABC1', referrerName: 'City Diagnostics', referredLabName: 'New Health Lab', status: 'pending', discountPercent: 50, discountApplied: false, createdAt: '2026-06-15', referrer: { name: 'Ramesh Gupta', role: 'labadmin' }, referrerLab: { name: 'City Diagnostics' }, referredLab: null },
        { _id: 'R3', referralCode: 'SN-X9Y2', referrerName: 'Dr. Suresh Nair', referredLabName: 'MediPlus Path Lab', status: 'commission_applied', discountPercent: 50, discountApplied: true, discountAppliedAt: '2026-06-20', createdAt: '2026-05-20', referrer: { name: 'Dr. Suresh Nair', role: 'doctor' }, referrerLab: { name: 'LifeCare Diagnostics' }, referredLab: { name: 'MediPlus Path Lab', plan: 'professional', status: 'active' } },
      ])
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleMarkConverted = async (ref) => {
    if (!window.confirm(`Mark referral from ${ref.referrerName} as converted? This confirms the referred lab subscribed.`)) return
    setReferrals(prev => prev.map(r => r._id === ref._id ? { ...r, status: 'converted' } : r))
    toast.success('Referral marked as converted!')
  }

  const handleApplyDiscount = async (ref) => {
    if (!window.confirm(`Apply 50% commission to ${ref.referrerName}? The referrer's lab will get 50% off next renewal.`)) return
    try {
      const { referralAPI } = await import('../../utils/api')
      await referralAPI.claimDiscount(ref._id)
      setReferrals(prev => prev.map(r => r._id === ref._id ? { ...r, status: 'commission_applied', discountApplied: true, discountAppliedAt: new Date().toISOString() } : r))
      toast.success('Discount applied! Referrer gets 50% off next renewal.')
    } catch {
      setReferrals(prev => prev.map(r => r._id === ref._id ? { ...r, status: 'commission_applied', discountApplied: true, discountAppliedAt: new Date().toISOString() } : r))
      toast.success('Discount applied! (demo)')
    }
  }

  const filtered = filter === 'all' ? referrals : referrals.filter(r => r.status === filter)

  return (
    <div>
      <PageHeader
        title="Referral Management"
        subtitle="Track all cross-lab referrals and commission discounts"
      />

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Referrals', value: referrals.length, color: 'text-slate-100' },
          { label: 'Pending', value: referrals.filter(r => r.status === 'pending').length, color: 'text-amber-400' },
          { label: 'Converted', value: referrals.filter(r => r.status === 'converted').length, color: 'text-brand-400' },
          { label: 'Discounts Applied', value: referrals.filter(r => r.discountApplied).length, color: 'text-purple-400' },
        ].map(s => (
          <div key={s.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-5 text-center">
            <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-sm text-slate-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4">
        {[{ k: 'all', l: 'All' }, { k: 'pending', l: 'Pending' }, { k: 'converted', l: 'Converted' }, { k: 'commission_applied', l: 'Discount Given' }].map(f => (
          <button key={f.k} onClick={() => setFilter(f.k)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${filter === f.k ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700 hover:text-slate-200'}`}>{f.l}</button>
        ))}
      </div>

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'referralCode', label: 'Code', render: v => <span className="font-mono text-brand-400 text-xs">{v}</span> },
            { key: 'referrerName', label: 'Referrer', render: (v, row) => (
              <div>
                <p className="font-medium text-slate-300">{v}</p>
                <p className="text-xs text-slate-500">{row.referrer?.role || ''} · {row.referrerLab?.name || ''}</p>
              </div>
            )},
            { key: 'referredLabName', label: 'Referred Lab', render: (v, row) => v || row.referredLab?.name || (
              <span className="text-slate-500 italic">Pending</span>
            )},
            { key: 'referredLab', label: 'Plan', render: v => v?.plan ? (
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium ${v.plan === 'enterprise' ? 'bg-purple-500/10 text-purple-400' : v.plan === 'professional' ? 'bg-blue-500/10 text-blue-400' : 'bg-brand-500/10 text-brand-400'}`}>{v.plan}</span>
            ) : '—' },
            { key: 'status', label: 'Status', render: v => <Badge status={v === 'commission_applied' ? 'active' : v === 'converted' ? 'completed' : v} /> },
            { key: 'createdAt', label: 'Date', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '—' },
          ]}
          data={filtered}
          actions={(row) => (
            <div className="flex gap-1.5">
              <button onClick={() => { setSelectedRef(row); setShowDetailModal(true) }} className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-2.5 py-1 rounded-xl text-xs font-medium transition-all">View</button>
              {row.status === 'pending' && (
                <button onClick={() => handleMarkConverted(row)} className="bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/20 px-2.5 py-1 rounded-xl text-xs font-medium transition-all">Mark Converted</button>
              )}
              {row.status === 'converted' && !row.discountApplied && (
                <button onClick={() => handleApplyDiscount(row)} className="bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/20 px-2.5 py-1 rounded-xl text-xs font-medium transition-all">Apply 50% Off</button>
              )}
              {row.discountApplied && (
                <span className="text-xs text-green-400 font-medium flex items-center gap-1"><CheckCircle size={12} /> Done</span>
              )}
            </div>
          )}
        />
      </div>

      {/* Detail Modal */}
      <Modal open={showDetailModal} onClose={() => setShowDetailModal(false)} title="Referral Details" size="lg">
        {selectedRef && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-surface-850 rounded-xl p-3">
                <p className="text-xs text-slate-500 mb-1">Referral Code</p>
                <p className="font-mono font-bold text-brand-400 text-lg">{selectedRef.referralCode}</p>
              </div>
              <div className="bg-surface-850 rounded-xl p-3">
                <p className="text-xs text-slate-500 mb-1">Status</p>
                <Badge status={selectedRef.status === 'commission_applied' ? 'active' : selectedRef.status === 'converted' ? 'completed' : selectedRef.status} />
              </div>
              <div className="bg-surface-850 rounded-xl p-3">
                <p className="text-xs text-slate-500 mb-1">Referrer</p>
                <p className="font-semibold text-slate-200">{selectedRef.referrerName}</p>
                <p className="text-xs text-slate-500">{selectedRef.referrer?.role} · {selectedRef.referrerLab?.name}</p>
              </div>
              <div className="bg-surface-850 rounded-xl p-3">
                <p className="text-xs text-slate-500 mb-1">Referred Lab</p>
                <p className="font-semibold text-slate-200">{selectedRef.referredLabName || selectedRef.referredLab?.name || 'Pending'}</p>
                {selectedRef.referredLab?.plan && <p className="text-xs text-slate-500">Plan: {selectedRef.referredLab.plan}</p>}
              </div>
            </div>
            <div className="bg-surface-850 rounded-xl p-3">
              <p className="text-xs text-slate-500 mb-2">Commission Details</p>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between"><span className="text-slate-400">Discount:</span><span className="text-brand-400 font-semibold">{selectedRef.discountPercent}% OFF next renewal</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Applied:</span><span>{selectedRef.discountApplied ? <span className="text-green-400">Yes ({selectedRef.discountAppliedAt ? new Date(selectedRef.discountAppliedAt).toLocaleDateString() : ''})</span> : <span className="text-slate-500">No</span>}</span></div>
              </div>
            </div>
            <div className="bg-surface-850 rounded-xl p-3">
              <p className="text-xs text-slate-500 mb-1">Created</p>
              <p className="text-sm text-slate-300">{selectedRef.createdAt ? new Date(selectedRef.createdAt).toLocaleString() : '—'}</p>
            </div>
            <div className="flex justify-end pt-2">
              <button onClick={() => setShowDetailModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm font-medium">Close</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
