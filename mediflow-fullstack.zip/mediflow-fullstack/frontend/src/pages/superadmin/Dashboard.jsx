import React, { useEffect, useState } from 'react'
import { Building2, Users, CreditCard, Activity } from 'lucide-react'
import { StatCard, Badge, Table } from '../../components/UI'
import { superAdminAPI } from '../../utils/api'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

export default function SuperAdminDashboard() {
  const [data, setData] = useState(null)
  const [revenue, setRevenue] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([superAdminAPI.dashboard(), superAdminAPI.revenue()])
      .then(([d, r]) => { setData(d.data.data); setRevenue(r.data.data) })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-violet-600 border-t-transparent rounded-full animate-spin"></div></div>

  const plans = [
    { plan: 'Enterprise AI', key: 'enterprise', color: 'bg-purple-500' },
    { plan: 'Professional', key: 'professional', color: 'bg-blue-500' },
    { plan: 'Starter', key: 'starter', color: 'bg-brand-500' },
  ]
  const total = revenue ? Object.values(revenue.breakdown).reduce((a,b)=>a+b,0) : 1

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-slate-100">Super Admin Dashboard</h1>
        <p className="text-sm text-slate-500 mt-0.5">Platform overview — all labs & subscriptions</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Building2} label="Total Labs"     value={data?.totalLabs ?? 0}  sub={`${data?.activeLabs ?? 0} active`} color="blue" />
        <StatCard icon={Users}     label="Total Users"    value={data?.totalUsers ?? 0}                                         color="green" />
        <StatCard icon={CreditCard} label="Monthly Revenue" value={`₹${((revenue?.monthlyRevenue ?? 0)/1000).toFixed(0)}K`}    color="purple" />
        <StatCard icon={Activity}  label="Total Patients" value={data?.totalPatients ?? 0}                                     color="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5 lg:col-span-2">
          <p className="font-semibold text-slate-300 mb-2">Plan Distribution</p>
          <div className="space-y-3 mt-4">
            {plans.map(p => (
              <div key={p.key}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-400">{p.plan}</span>
                  <span className="font-medium">{revenue?.breakdown?.[p.key] ?? 0} labs</span>
                </div>
                <div className="h-2 bg-surface-800 rounded-full">
                  <div className={`h-2 ${p.color} rounded-full transition-all`} style={{ width: `${((revenue?.breakdown?.[p.key]??0)/total)*100}%` }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-surface-700">
            <p className="text-sm text-slate-500">Total Platform Revenue: <span className="font-bold text-slate-100">₹{(revenue?.monthlyRevenue ?? 0).toLocaleString('en-IN')}/month</span></p>
          </div>
        </div>

        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-semibold text-slate-300 mb-3">Quick Stats</p>
          <div className="space-y-3">
            {[
              { label: 'Active Labs', value: data?.activeLabs ?? 0, color: 'text-brand-400' },
              { label: 'Total Labs', value: data?.totalLabs ?? 0, color: 'text-blue-400' },
              { label: 'Total Patients', value: data?.totalPatients ?? 0, color: 'text-purple-400' },
              { label: 'Monthly MRR', value: `₹${(revenue?.monthlyRevenue ?? 0).toLocaleString('en-IN')}`, color: 'text-brand-400' },
            ].map(s => (
              <div key={s.label} className="flex justify-between items-center">
                <span className="text-sm text-slate-500">{s.label}</span>
                <span className={`font-semibold ${s.color}`}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <div className="p-5 border-b border-surface-700">
          <p className="font-semibold text-slate-300">All Labs</p>
        </div>
        <Table
          columns={[
            { key: 'name', label: 'Lab Name' },
            { key: 'ownerName', label: 'Owner' },
            { key: 'plan', label: 'Plan', render: v => <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium ${v==='enterprise'?'bg-purple-500/10 text-purple-400':v==='professional'?'bg-blue-500/10 text-blue-400':'bg-brand-500/10 text-brand-400'}`}>{v}</span> },
            { key: 'phone', label: 'Phone' },
            { key: 'city', label: 'City' },
            { key: 'subscriptionEnd', label: 'Expires', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '—' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={data?.labs ?? []}
          actions={row => (
            <button onClick={async () => {
              const newStatus = row.status === 'active' ? 'suspended' : 'active'
              await superAdminAPI.updateStatus(row._id, newStatus)
              window.location.reload()
            }} className={`px-3 py-1 rounded-xl text-xs font-medium ${row.status === 'active' ? 'bg-red-500/10 text-red-400 hover:bg-red-500/15' : 'bg-brand-500/10 text-brand-400 hover:bg-brand-500/15'}`}>
              {row.status === 'active' ? 'Suspend' : 'Activate'}
            </button>
          )}
        />
      </div>
    </div>
  )
}
