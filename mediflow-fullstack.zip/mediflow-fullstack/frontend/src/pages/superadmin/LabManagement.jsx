import React, { useState, useEffect } from 'react'
import { Plus, RefreshCw, CheckCircle, Copy } from 'lucide-react'
import { PageHeader, Table, Badge, SearchBar, Modal } from '../../components/UI'
import { superAdminAPI, apiErrorMessage } from '../../utils/api'
import { referralAPI } from '../../utils/referralAPI'
import toast from 'react-hot-toast'

const emptyForm = { name: '', ownerName: '', phone: '', email: '', city: '', state: '', plan: 'starter', password: '', referralCode: '' }

export default function LabManagement() {
  const [labs, setLabs]           = useState([])
  const [search, setSearch]       = useState('')
  const [loading, setLoading]     = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm]           = useState(emptyForm)
  const [saving, setSaving]       = useState(false)
  const [created, setCreated]     = useState(null)   // show credentials after create
  const [codeValid, setCodeValid] = useState(null)   // null | { valid, partnerName }
  const [checkingCode, setCheckingCode] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const res = await superAdminAPI.getAllLabs()
      setLabs(res.data.data)
    } catch (e) { toast.error(apiErrorMessage(e)) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  // Validate referral code as user types
  useEffect(() => {
    if (!form.referralCode || form.referralCode.length < 5) { setCodeValid(null); return }
    const t = setTimeout(async () => {
      setCheckingCode(true)
      try {
        const res = await referralAPI.verifyCode(form.referralCode)
        setCodeValid(res.data.data)
      } catch { setCodeValid({ valid: false }) }
      finally { setCheckingCode(false) }
    }, 500)
    return () => clearTimeout(t)
  }, [form.referralCode])

  const handleCreate = async (e) => {
    e.preventDefault()
    if (!form.name || !form.ownerName || !form.phone) return toast.error('Name, owner and phone required')
    setSaving(true)
    try {
      const res = await superAdminAPI.createLab({ ...form })
      setCreated(res.data.data)
      setForm(emptyForm)
      setCodeValid(null)
      load()
      toast.success('Lab created successfully!')
    } catch (e) { toast.error(apiErrorMessage(e, 'Failed to create lab')) }
    finally { setSaving(false) }
  }

  const handleStatus = async (lab) => {
    const newStatus = lab.status === 'active' ? 'suspended' : 'active'
    try {
      await superAdminAPI.updateStatus(lab._id, newStatus)
      toast.success(`Lab ${newStatus}`)
      load()
    } catch (e) { toast.error(apiErrorMessage(e)) }
  }

  const filtered = labs.filter(l =>
    l.name?.toLowerCase().includes(search.toLowerCase()) ||
    l.ownerName?.toLowerCase().includes(search.toLowerCase()) ||
    l.phone?.includes(search)
  )

  return (
    <div>
      <PageHeader
        title="Lab Management"
        subtitle={`${labs.length} labs on the platform`}
        actions={<>
          <SearchBar value={search} onChange={setSearch} placeholder="Search labs..." />
          <button onClick={load} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-2 rounded-xl text-sm flex items-center gap-1.5">
            <RefreshCw size={14} /> Refresh
          </button>
          <button onClick={() => { setShowModal(true); setCreated(null) }}
            className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-2">
            <Plus size={16} /> Create Lab
          </button>
        </>}
      />

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-400">Loading labs...</div>
        ) : (
          <Table
            columns={[
              { key: 'name', label: 'Lab Name', render: (v, row) => (
                <div>
                  <p className="font-medium text-slate-100">{v}</p>
                  <p className="text-xs text-slate-500">{row.ownerName} · {row.city}</p>
                </div>
              )},
              { key: 'plan', label: 'Plan', render: v => (
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium
                  ${v === 'enterprise' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                  : v === 'professional' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                  : 'bg-brand-500/10 text-brand-400 border border-brand-500/20'}`}>{v}</span>
              )},
              { key: 'phone', label: 'Phone' },
              { key: 'subscriptionEnd', label: 'Expires', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '—' },
              { key: 'licenseKey', label: 'License', render: v => (
                <code className="text-xs text-slate-500 font-mono-num">{v}</code>
              )},
              { key: 'referralCode', label: 'Referred By', render: v => v
                ? <span className="text-xs text-brand-400 font-mono-num">{v}</span>
                : <span className="text-xs text-slate-600">—</span>
              },
              { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
            ]}
            data={filtered}
            actions={row => (
              <button onClick={() => handleStatus(row)}
                className={`px-3 py-1 rounded-xl text-xs font-medium border transition-all ${
                  row.status === 'active'
                    ? 'bg-red-500/10 text-red-400 border-red-500/20 hover:bg-red-500/20'
                    : 'bg-brand-500/10 text-brand-400 border-brand-500/20 hover:bg-brand-500/20'
                }`}>
                {row.status === 'active' ? 'Suspend' : 'Activate'}
              </button>
            )}
          />
        )}
      </div>

      {/* Create Lab Modal */}
      <Modal open={showModal && !created} onClose={() => setShowModal(false)} title="Create New Lab" size="lg">
        <form onSubmit={handleCreate} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Lab Name*',      key: 'name',      placeholder: 'City Diagnostics' },
              { label: 'Owner Name*',    key: 'ownerName', placeholder: 'Full name' },
              { label: 'Phone*',         key: 'phone',     placeholder: '10-digit mobile' },
              { label: 'Email',          key: 'email',     placeholder: 'lab@email.com' },
              { label: 'City',           key: 'city',      placeholder: 'Raipur' },
              { label: 'State',          key: 'state',     placeholder: 'Chhattisgarh' },
              { label: 'Password',       key: 'password',  placeholder: 'Leave blank to auto-generate' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-400 mb-1">{f.label}</label>
                <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Plan</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                value={form.plan} onChange={e => setForm({...form, plan: e.target.value})}>
                <option value="starter">Starter — ₹999/mo</option>
                <option value="professional">Professional — ₹1,999/mo</option>
                <option value="enterprise">Enterprise AI — ₹3,999/mo</option>
              </select>
            </div>
          </div>

          {/* Referral code field */}
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Partner Referral Code (optional)</label>
            <div className="relative">
              <input
                className={`w-full bg-surface-850 border rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30 font-mono-num uppercase
                  ${codeValid?.valid === true ? 'border-brand-500/50' : codeValid?.valid === false ? 'border-red-500/50' : 'border-surface-700'}`}
                placeholder="MFPAI-REF-XXXXX"
                value={form.referralCode}
                onChange={e => setForm({...form, referralCode: e.target.value.toUpperCase()})}
              />
              {checkingCode && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500">Checking...</span>}
              {!checkingCode && codeValid?.valid === true && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-brand-400 flex items-center gap-1">
                  <CheckCircle size={12} /> {codeValid.partnerName}
                </span>
              )}
              {!checkingCode && codeValid?.valid === false && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-red-400">Invalid code</span>
              )}
            </div>
            {codeValid?.valid === true && (
              <p className="text-xs text-brand-400 mt-1">
                ✅ Valid! <strong>{codeValid.partnerName}</strong> will receive 50% commission (₹{
                  form.plan === 'starter' ? 499 : form.plan === 'professional' ? 999 : 1999
                }) when this lab subscribes.
              </p>
            )}
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowModal(false)}
              className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm">Cancel</button>
            <button type="submit" disabled={saving}
              className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm disabled:opacity-60">
              {saving ? 'Creating...' : 'Create Lab'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Created credentials modal */}
      <Modal open={!!created} onClose={() => { setCreated(null); setShowModal(false) }} title="✅ Lab Created Successfully" size="md">
        {created && (
          <div className="space-y-4">
            <div className="bg-brand-500/10 border border-brand-500/20 rounded-xl p-4 space-y-2 text-sm">
              <p className="font-semibold text-brand-400 mb-2">Share these credentials with the lab:</p>
              {[
                { label: 'Lab Name',    value: created.lab?.name },
                { label: 'Phone',       value: created.lab?.phone },
                { label: 'Password',    value: created.password },
                { label: 'License Key', value: created.licenseKey },
              ].map(r => (
                <div key={r.label} className="flex justify-between items-center">
                  <span className="text-slate-400">{r.label}:</span>
                  <code className="text-slate-100 font-mono-num bg-surface-850 px-2 py-0.5 rounded">{r.value}</code>
                </div>
              ))}
              {created.referralLogged && (
                <p className="text-brand-400 text-xs mt-2">🤝 Referral commission recorded for this lab.</p>
              )}
            </div>
            <p className="text-xs text-slate-500">Save this — password won't be shown again.</p>
            <button onClick={() => { setCreated(null); setShowModal(false) }}
              className="w-full bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold py-2.5 rounded-xl text-sm">
              Done
            </button>
          </div>
        )}
      </Modal>
    </div>
  )
}
