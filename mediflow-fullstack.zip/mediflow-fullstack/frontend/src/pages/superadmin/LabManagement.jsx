import React, { useState } from 'react'
import { Plus } from 'lucide-react'
import { PageHeader, Table, Badge, SearchBar, Modal } from '../../components/UI'
import { mockLabs } from '../../utils/mockData'

export default function LabManagement() {
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const filtered = mockLabs.filter(l =>
    l.name.toLowerCase().includes(search.toLowerCase()) ||
    l.owner.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <PageHeader
        title="Lab Management"
        subtitle="Create, manage and monitor all pathology labs"
        actions={
          <>
            <SearchBar value={search} onChange={setSearch} placeholder="Search labs..." />
            <button onClick={() => setShowModal(true)} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all flex items-center gap-2">
              <Plus size={16} /> Create Lab
            </button>
          </>
        }
      />

      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        <Table
          columns={[
            { key: 'id', label: 'ID' },
            { key: 'name', label: 'Lab Name' },
            { key: 'owner', label: 'Owner' },
            { key: 'plan', label: 'Plan', render: v => (
              <span className={`badge ${v === 'Enterprise AI' ? 'badge-purple' : v === 'Professional' ? 'badge-blue' : 'badge-green'}`}>{v}</span>
            )},
            { key: 'patients', label: 'Patients' },
            { key: 'revenue', label: 'Revenue', render: v => `₹${v.toLocaleString()}` },
            { key: 'expiry', label: 'Expires' },
            { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
          ]}
          data={filtered}
          actions={row => (
            <>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Login As</button>
              <button className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Edit</button>
              <button className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-4 py-2 rounded-xl font-medium text-sm transition-all text-xs py-1">Suspend</button>
            </>
          )}
        />
      </div>

      <Modal open={showModal} onClose={() => setShowModal(false)} title="Create New Lab">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Lab Name</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="e.g. City Diagnostics" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Owner Name</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Full name" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Phone</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Mobile number" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">Email</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="Email address" /></div>
            <div><label className="block text-xs font-medium text-slate-500 mb-1">City</label><input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all" placeholder="City" /></div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Plan</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 transition-all">
                <option>Starter – ₹999/mo</option>
                <option>Professional – ₹1,999/mo</option>
                <option>Enterprise AI – ₹3,999/mo</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-2">
            <button onClick={() => setShowModal(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm transition-all">Cancel</button>
            <button className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl font-medium text-sm transition-all">Create Lab</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
