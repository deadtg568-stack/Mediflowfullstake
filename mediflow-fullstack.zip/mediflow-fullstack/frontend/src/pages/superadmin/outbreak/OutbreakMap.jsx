import React, { useEffect, useState } from 'react'
import { Globe2, AlertTriangle, Building2, MapPin, RefreshCw, CheckCircle2, Activity } from 'lucide-react'
import { PageHeader, StatCard } from '../../../components/UI'
import { outbreakAPI, apiErrorMessage } from '../../../utils/api'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import toast from 'react-hot-toast'

const SEVERITY_STYLES = {
  critical: { badge: 'bg-red-500/10 text-red-400 border border-red-500/20', bar: '#ef4444' },
  warning:  { badge: 'bg-amber-500/10 text-amber-400 border border-amber-500/20', bar: '#f59e0b' },
  watch:    { badge: 'bg-blue-500/10 text-blue-400 border border-blue-500/20', bar: '#60a5fa' },
}

export default function OutbreakMap() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const load = async () => {
    try {
      const res = await outbreakAPI.getNational()
      setData(res.data.data)
    } catch (e) { toast.error(apiErrorMessage(e, 'Failed to load national outbreak data')) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleRefresh = async () => {
    setRefreshing(true)
    try {
      await outbreakAPI.triggerDetection()
      await load()
      toast.success('Detection refreshed across network')
    } catch (e) { toast.error(apiErrorMessage(e, 'Detection failed')) }
    finally { setRefreshing(false) }
  }

  const handleResolve = async (id) => {
    try {
      await outbreakAPI.resolveAlert(id)
      setData(d => ({ ...d, alerts: d.alerts.filter(a => a._id !== id) }))
      toast.success('Alert resolved')
    } catch (e) { toast.error(apiErrorMessage(e, 'Failed to resolve')) }
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  const { alerts = [], cities = [], networkStats = {} } = data || {}
  const chartData = cities.slice(0, 8).map(c => ({ name: c.city, value: c.total, hasAlert: c.hasAlert }))

  return (
    <div>
      <PageHeader
        title="Outbreak Radar — National View"
        subtitle="Cross-network disease intelligence, aggregated anonymously from every connected lab"
        actions={
          <button onClick={handleRefresh} disabled={refreshing}
            className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 disabled:opacity-60">
            <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} /> Run Detection Now
          </button>
        }
      />

      {/* Network stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <StatCard icon={Building2} label="Labs on Network" value={networkStats.totalLabs ?? 0} color="green" />
        <StatCard icon={MapPin} label="Cities Reporting" value={networkStats.participatingCities ?? 0} color="blue" />
        <StatCard icon={AlertTriangle} label="Active Alerts" value={alerts.length} color={alerts.length ? 'red' : 'green'} />
        <StatCard icon={Activity} label="Diseases Tracked" value={(networkStats.trackedDiseases || []).length} color="purple" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        {/* Active alerts */}
        <div className="lg:col-span-2 bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-display font-semibold text-slate-200 mb-4 flex items-center gap-2">
            <AlertTriangle size={15} className="text-red-400" /> Active Outbreak Alerts
          </p>
          {alerts.length > 0 ? (
            <div className="space-y-3">
              {alerts.map(a => {
                const style = SEVERITY_STYLES[a.severity]
                return (
                  <div key={a._id} className="bg-surface-850 border border-surface-700 rounded-xl p-4 flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-slate-100">{a.disease} — {a.city}{a.state ? `, ${a.state}` : ''}</p>
                        <span className={`px-2 py-0.5 rounded-lg text-xs font-medium uppercase ${style.badge}`}>{a.severity}</span>
                      </div>
                      <p className="text-sm text-slate-400 leading-relaxed">{a.message}</p>
                      <p className="text-xs text-slate-500 mt-1.5">{a.labCount} lab(s) reporting · detected {new Date(a.createdAt).toLocaleDateString('en-IN')}</p>
                    </div>
                    <button onClick={() => handleResolve(a._id)}
                      className="bg-surface-800 hover:bg-surface-700 text-slate-400 border border-surface-700 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 flex-shrink-0">
                      <CheckCircle2 size={13} /> Resolve
                    </button>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <CheckCircle2 size={32} className="text-brand-400 mx-auto mb-2" />
              <p className="text-slate-300 font-medium">No active alerts across the network</p>
              <p className="text-xs text-slate-500 mt-1">All cities are within normal disease-test baselines.</p>
            </div>
          )}
        </div>

        {/* City volumes chart */}
        <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
          <p className="font-display font-semibold text-slate-200 mb-4 flex items-center gap-2">
            <Globe2 size={15} className="text-brand-400" /> Disease-Test Volume (7d)
          </p>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={chartData} layout="vertical" margin={{ left: 10 }}>
                <XAxis type="number" tick={{ fontSize: 11, fill: '#5c6f67' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={80} />
                <Tooltip contentStyle={{ background: '#111815', border: '1px solid #1b2622', borderRadius: 12, fontSize: 12 }} labelStyle={{ color: '#94a3b8' }} />
                <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                  {chartData.map((c, i) => (
                    <Cell key={i} fill={c.hasAlert ? '#ef4444' : '#3DDC84'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="text-center py-12 text-slate-500 text-sm">No signal data yet.</div>
          )}
          <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-500" />Normal</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-500" />Active alert</span>
          </div>
        </div>
      </div>

      {/* Per-city breakdown */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
        <p className="font-display font-semibold text-slate-200 mb-4">City Breakdown — Last 7 Days</p>
        {cities.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {cities.map(c => (
              <div key={c.city} className={`rounded-xl border p-4 ${c.hasAlert ? 'border-red-500/20 bg-red-500/5' : 'border-surface-700 bg-surface-850'}`}>
                <div className="flex items-center justify-between mb-2">
                  <p className="font-medium text-slate-100 flex items-center gap-1.5">
                    <MapPin size={13} className="text-slate-500" /> {c.city}
                  </p>
                  {c.hasAlert && <AlertTriangle size={14} className="text-red-400" />}
                </div>
                <p className="text-xs text-slate-500 mb-2">{c.labCount} lab(s) · {c.total} tests this week</p>
                <div className="space-y-1">
                  {Object.entries(c.diseases).slice(0, 4).map(([disease, count]) => (
                    <div key={disease} className="flex justify-between text-xs">
                      <span className="text-slate-400">{disease}</span>
                      <span className="font-mono-num text-slate-300">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-slate-500 text-sm">
            No data yet — once labs across the network start billing disease-indicating tests, city breakdowns appear here.
          </div>
        )}
      </div>
    </div>
  )
}
