import React, { useEffect, useState } from 'react'
import { CheckCircle, XCircle, IndianRupee, Eye, Filter } from 'lucide-react'
import { PageHeader, Table, Badge, Modal } from '../../../components/UI'
import { referralAPI } from '../../../utils/referralAPI'
import { apiErrorMessage } from '../../../utils/api'
import toast from 'react-hot-toast'

const STATUS_COLORS = {
  pending:  'bg-amber-500/10 text-amber-400 border border-amber-500/20',
  verified: 'bg-blue-500/10 text-blue-400 border border-blue-500/20',
  approved: 'bg-brand-500/10 text-brand-400 border border-brand-500/20',
  paid:     'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20',
  rejected: 'bg-red-500/10 text-red-400 border border-red-500/20',
}

export default function ReferralLogs() {
  const [logs, setLogs]         = useState([])
  const [stats, setStats]       = useState(null)
  const [loading, setLoading]   = useState(true)
  const [statusFilter, setStatusFilter] = useState('')
  const [actionModal, setActionModal]   = useState(null) // { log, action }
  const [actionData, setActionData]     = useState({})
  const [processing, setProcessing]     = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const [l, s] = await Promise.all([
        referralAPI.getLogs({ status: statusFilter || undefined }),
        referralAPI.getStats(),
      ])
      setLogs(l.data.data.logs)
      setStats(l.data.data.stats)
    } catch (e) { toast.error(apiErrorMessage(e)) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [statusFilter])

  const doAction = async () => {
    if (!actionModal) return
    const { log, action } = actionModal
    setProcessing(true)
    try {
      if (action === 'verify')  await referralAPI.verify(log._id)
      if (action === 'approve') await referralAPI.approve(log._id, { rewardType: actionData.rewardType || 'cash' })
      if (action === 'reject')  await referralAPI.reject(log._id, { reason: actionData.reason })
      if (action === 'pay') {
        if (!actionData.paymentMode) return toast.error('Select payment mode')
        await referralAPI.pay(log._id, {
          paymentMode: actionData.paymentMode,
          paymentRef:  actionData.paymentRef,
          notes:       actionData.notes,
        })
      }
      toast.success(`Referral ${action}d successfully!`)
      setActionModal(null)
      setActionData({})
      load()
    } catch (e) { toast.error(apiErrorMessage(e, `Failed to ${action}`)) }
    finally { setProcessing(false) }
  }

  const STATUSES = ['', 'pending', 'verified', 'approved', 'paid', 'rejected']

  return (
    <div>
      <PageHeader title="Referral Logs" subtitle="Track and manage all partner referrals" />

      {/* Stats cards */}
      {stats && (
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
          {[
            { label: 'Total',    val: stats.total,    color: 'text-slate-300' },
            { label: 'Pending',  val: stats.pending,  color: 'text-amber-400' },
            { label: 'Verified', val: stats.verified, color: 'text-blue-400'  },
            { label: 'Approved', val: stats.approved, color: 'text-brand-400' },
            { label: 'Paid',     val: stats.paid,     color: 'text-emerald-400' },
            { label: 'Rejected', val: stats.rejected, color: 'text-red-400' },
          ].map(s => (
            <div key={s.label} className="bg-surface-900 border border-surface-700 rounded-2xl p-4 text-center">
              <p className={`text-2xl font-bold font-mono-num ${s.color}`}>{s.val}</p>
              <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Commission summary */}
      {stats && (
        <div className="grid grid-cols-3 gap-3 mb-4">
          {[
            { label: 'Total Commission Generated', val: `₹${stats.totalCommission?.toLocaleString('en-IN') || 0}`, color: 'text-brand-400' },
            { label: 'Pending Payout', val: `₹${(stats.totalCommission - stats.totalPaid)?.toLocaleString('en-IN') || 0}`, color: 'text-amber-400' },
            { label: 'Total Paid Out', val: `₹${stats.totalPaid?.toLocaleString('en-IN') || 0}`, color: 'text-emerald-400' },
          ].map(s => (
            <div key={s.label} className="bg-surface-900 border border-surface-700 rounded-2xl p-4">
              <p className={`text-2xl font-bold font-mono-num ${s.color}`}>{s.val}</p>
              <p className="text-sm text-slate-500 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Filter */}
      <div className="flex items-center gap-2 mb-4">
        <Filter size={15} className="text-slate-500" />
        <span className="text-sm text-slate-400">Filter by status:</span>
        {STATUSES.map(s => (
          <button key={s} onClick={() => setStatusFilter(s)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${statusFilter === s ? 'bg-brand-500/15 text-brand-400 border-brand-500/25' : 'bg-surface-900 text-slate-400 border-surface-700 hover:border-surface-600'}`}>
            {s || 'All'}
          </button>
        ))}
      </div>

      {/* Logs table */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-400">Loading...</div>
        ) : logs.length === 0 ? (
          <div className="text-center py-16 text-slate-500">
            <IndianRupee size={32} className="mx-auto mb-3 text-surface-600" />
            <p>No referral logs {statusFilter ? `with status "${statusFilter}"` : 'yet'}</p>
          </div>
        ) : (
          <Table
            columns={[
              { key: 'partner', label: 'Partner', render: (v) => (
                <div>
                  <p className="font-medium text-slate-100">{v?.name || '—'}</p>
                  <p className="text-xs text-slate-500 font-mono-num">{v?.referralCode}</p>
                </div>
              )},
              { key: 'labName', label: 'Lab Referred', render: (v, row) => (
                <div>
                  <p className="font-medium text-slate-100">{v}</p>
                  <p className="text-xs text-slate-500">{row.lab?.city || ''} · {row.plan}</p>
                </div>
              )},
              { key: 'subscriptionAmount', label: 'Sub Amount', render: v => `₹${v?.toLocaleString('en-IN') || 0}` },
              { key: 'commissionAmount', label: 'Commission (50%)', render: v => (
                <span className="font-semibold text-brand-400">₹{v?.toLocaleString('en-IN') || 0}</span>
              )},
              { key: 'status', label: 'Status', render: v => (
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-lg text-xs font-medium ${STATUS_COLORS[v] || ''}`}>{v}</span>
              )},
              { key: 'createdAt', label: 'Date', render: v => new Date(v).toLocaleDateString('en-IN') },
            ]}
            data={logs}
            actions={row => (
              <div className="flex gap-1.5">
                {row.status === 'pending' && (
                  <>
                    <button onClick={() => setActionModal({ log: row, action: 'verify' })}
                      className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 px-2.5 py-1 rounded-lg text-xs font-medium">
                      Verify
                    </button>
                    <button onClick={() => setActionModal({ log: row, action: 'reject' })}
                      className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-2.5 py-1 rounded-lg text-xs font-medium">
                      Reject
                    </button>
                  </>
                )}
                {row.status === 'verified' && (
                  <button onClick={() => setActionModal({ log: row, action: 'approve' })}
                    className="bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/20 px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1">
                    <CheckCircle size={12} /> Approve
                  </button>
                )}
                {row.status === 'approved' && (
                  <button onClick={() => setActionModal({ log: row, action: 'pay' })}
                    className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1">
                    <IndianRupee size={12} /> Pay Now
                  </button>
                )}
                {row.status === 'pending' || row.status === 'verified' ? null : null}
              </div>
            )}
          />
        )}
      </div>

      {/* Action Modal */}
      <Modal
        open={!!actionModal}
        onClose={() => { setActionModal(null); setActionData({}) }}
        title={actionModal ? `${actionModal.action.charAt(0).toUpperCase() + actionModal.action.slice(1)} Referral` : ''}
      >
        {actionModal && (
          <div className="space-y-4">
            {/* Log summary */}
            <div className="bg-surface-850 border border-surface-700 rounded-xl p-4 text-sm">
              <p className="text-slate-300"><span className="text-slate-500">Partner:</span> {actionModal.log.partner?.name}</p>
              <p className="text-slate-300 mt-1"><span className="text-slate-500">Lab:</span> {actionModal.log.labName} ({actionModal.log.plan})</p>
              <p className="text-brand-400 font-semibold mt-1">Commission: ₹{actionModal.log.commissionAmount?.toLocaleString('en-IN')}</p>
            </div>

            {/* Verify */}
            {actionModal.action === 'verify' && (
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3 text-sm text-blue-300">
                This will confirm that the lab is active and has subscribed. The referral will move to "Verified" status and be ready for approval.
              </div>
            )}

            {/* Approve */}
            {actionModal.action === 'approve' && (
              <div className="space-y-3">
                <div className="bg-brand-500/10 border border-brand-500/20 rounded-xl p-3 text-sm text-brand-300">
                  ₹{actionModal.log.commissionAmount?.toLocaleString('en-IN')} will be credited to {actionModal.log.partner?.name}'s wallet.
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Reward Type</label>
                  <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                    value={actionData.rewardType || 'cash'} onChange={e => setActionData({...actionData, rewardType: e.target.value})}>
                    <option value="cash">Cash Payout</option>
                    <option value="subscription_discount">Subscription Discount (50% off next month)</option>
                  </select>
                </div>
              </div>
            )}

            {/* Reject */}
            {actionModal.action === 'reject' && (
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">Rejection Reason</label>
                <textarea rows={3} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30 resize-none"
                  placeholder="Why is this referral being rejected?"
                  value={actionData.reason || ''} onChange={e => setActionData({...actionData, reason: e.target.value})} />
              </div>
            )}

            {/* Pay */}
            {actionModal.action === 'pay' && (
              <div className="space-y-3">
                <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 text-sm text-emerald-300">
                  Mark ₹{actionModal.log.commissionAmount?.toLocaleString('en-IN')} as paid to {actionModal.log.partner?.name}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Payment Mode*</label>
                    <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      value={actionData.paymentMode || ''} onChange={e => setActionData({...actionData, paymentMode: e.target.value})}>
                      <option value="">Select mode</option>
                      <option value="bank">Bank Transfer</option>
                      <option value="upi">UPI</option>
                      <option value="cash">Cash</option>
                      <option value="wallet">Wallet Adjust</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Transaction Ref.</label>
                    <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      placeholder="UTR / Transaction ID" value={actionData.paymentRef || ''}
                      onChange={e => setActionData({...actionData, paymentRef: e.target.value})} />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-medium text-slate-400 mb-1">Notes</label>
                    <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      placeholder="Optional payment notes" value={actionData.notes || ''}
                      onChange={e => setActionData({...actionData, notes: e.target.value})} />
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-2 justify-end pt-2">
              <button onClick={() => { setActionModal(null); setActionData({}) }}
                className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm">
                Cancel
              </button>
              <button onClick={doAction} disabled={processing}
                className={`font-semibold px-4 py-2 rounded-xl text-sm disabled:opacity-60 ${
                  actionModal.action === 'reject'
                    ? 'bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20'
                    : 'bg-brand-500 hover:bg-brand-600 text-surface-950'
                }`}>
                {processing ? 'Processing...' : {
                  verify: 'Confirm Verify',
                  approve: 'Approve & Credit Wallet',
                  reject: 'Reject Referral',
                  pay: 'Mark as Paid',
                }[actionModal.action]}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
