import React, { useEffect, useState } from 'react'
import { Plus, Eye, Phone, Copy, CheckCircle, TrendingUp, Wallet, Users, IndianRupee } from 'lucide-react'
import { PageHeader, Table, Badge, Modal, SearchBar, StatCard } from '../../../components/UI'
import { referralAPI } from '../../../utils/referralAPI'
import { apiErrorMessage } from '../../../utils/api'
import toast from 'react-hot-toast'

const PLAN_PRICES = { starter: 999, professional: 1999, enterprise: 3999 }
const TYPE_OPTIONS = ['doctor', 'agent', 'lab_owner', 'other']

const initialForm = {
  name: '', phone: '', email: '', type: 'doctor',
  bankName: '', accountNo: '', ifsc: '', upiId: '', notes: ''
}

export default function Partners() {
  const [partners, setPartners] = useState([])
  const [stats, setStats]       = useState(null)
  const [loading, setLoading]   = useState(true)
  const [search, setSearch]     = useState('')
  const [showAdd, setShowAdd]   = useState(false)
  const [showDetail, setShowDetail] = useState(null) // partner detail
  const [form, setForm]         = useState(initialForm)
  const [saving, setSaving]     = useState(false)
  const [copiedCode, setCopiedCode] = useState('')

  const load = async () => {
    setLoading(true)
    try {
      const [p, s] = await Promise.all([referralAPI.getPartners(), referralAPI.getStats()])
      setPartners(p.data.data)
      setStats(s.data.data)
    } catch (e) { toast.error(apiErrorMessage(e)) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleAdd = async (e) => {
    e.preventDefault()
    if (!form.name || !form.phone) return toast.error('Name and phone required')
    setSaving(true)
    try {
      await referralAPI.createPartner(form)
      toast.success('Partner created!')
      setShowAdd(false)
      setForm(initialForm)
      load()
    } catch (e) { toast.error(apiErrorMessage(e, 'Failed to create')) }
    finally { setSaving(false) }
  }

  const handleDeactivate = async (id) => {
    if (!window.confirm('Deactivate this partner?')) return
    try {
      await referralAPI.deletePartner(id)
      toast.success('Partner deactivated')
      load()
    } catch (e) { toast.error(apiErrorMessage(e)) }
  }

  const copyCode = (code) => {
    navigator.clipboard.writeText(code)
    setCopiedCode(code)
    toast.success('Referral code copied!')
    setTimeout(() => setCopiedCode(''), 2000)
  }

  const filtered = partners.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.phone.includes(search) ||
    p.referralCode.includes(search.toUpperCase())
  )

  return (
    <div>
      <PageHeader
        title="Referral Partners"
        subtitle="Manage partners who refer labs to MediFlow"
        actions={<>
          <SearchBar value={search} onChange={setSearch} placeholder="Search partners..." />
          <button onClick={() => setShowAdd(true)}
            className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-2">
            <Plus size={16} /> Add Partner
          </button>
        </>}
      />

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
          <StatCard icon={Users}        label="Total Partners"   value={stats.totalPartners}    color="blue" />
          <StatCard icon={TrendingUp}   label="Active Partners"  value={stats.activePartners}   color="green" />
          <StatCard icon={IndianRupee}  label="Total Commission" value={`₹${stats.totalCommissionEarned.toLocaleString('en-IN')}`} color="purple" />
          <StatCard icon={Wallet}       label="Pending Payout"   value={`₹${stats.pendingPayout.toLocaleString('en-IN')}`} color="amber" />
          <StatCard icon={CheckCircle}  label="Paid Out"         value={`₹${stats.totalPaid.toLocaleString('en-IN')}`}  color="green" />
        </div>
      )}

      {/* Partners table */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-400">Loading...</div>
        ) : (
          <Table
            columns={[
              { key: 'name', label: 'Partner', render: (v, row) => (
                <div>
                  <p className="font-medium text-slate-100">{v}</p>
                  <p className="text-xs text-slate-500">{row.phone} · {row.type}</p>
                </div>
              )},
              { key: 'referralCode', label: 'Referral Code', render: (v) => (
                <div className="flex items-center gap-2">
                  <code className="bg-surface-850 border border-surface-700 text-brand-400 text-xs px-2 py-1 rounded-lg font-mono-num">{v}</code>
                  <button onClick={() => copyCode(v)} className="text-slate-500 hover:text-brand-400">
                    {copiedCode === v ? <CheckCircle size={14} className="text-brand-400" /> : <Copy size={14} />}
                  </button>
                </div>
              )},
              { key: 'totalReferrals', label: 'Referrals' },
              { key: 'totalEarned', label: 'Total Earned', render: v => `₹${v.toLocaleString('en-IN')}` },
              { key: 'walletBalance', label: 'Wallet', render: v => (
                <span className={`font-semibold ${v > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                  ₹{v.toLocaleString('en-IN')}
                </span>
              )},
              { key: 'status', label: 'Status', render: v => <Badge status={v} /> },
            ]}
            data={filtered}
            actions={row => (
              <>
                <button onClick={() => setShowDetail(row)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-1 rounded-xl text-xs flex items-center gap-1">
                  <Eye size={12} /> View
                </button>
                {row.status === 'active' && (
                  <button onClick={() => handleDeactivate(row._id)} className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1 rounded-xl text-xs">
                    Deactivate
                  </button>
                )}
              </>
            )}
          />
        )}
      </div>

      {/* Add Partner Modal */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add New Partner" size="lg">
        <form onSubmit={handleAdd} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Full Name*', key:'name', placeholder:'Partner name' },
              { label:'Phone*', key:'phone', placeholder:'10-digit mobile' },
              { label:'Email', key:'email', placeholder:'email@example.com' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-400 mb-1">{f.label}</label>
                <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Partner Type</label>
              <select className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                value={form.type} onChange={e => setForm({...form, type: e.target.value})}>
                {TYPE_OPTIONS.map(t => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
              </select>
            </div>
          </div>

          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mt-2">Payment Details</p>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label:'Bank Name', key:'bankName', placeholder:'e.g. SBI' },
              { label:'Account No.', key:'accountNo', placeholder:'Account number' },
              { label:'IFSC Code', key:'ifsc', placeholder:'SBIN0001234' },
              { label:'UPI ID', key:'upiId', placeholder:'name@upi' },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-slate-400 mb-1">{f.label}</label>
                <input className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm({...form, [f.key]: e.target.value})} />
              </div>
            ))}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Notes</label>
            <textarea rows={2} className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30 resize-none"
              placeholder="Any notes about this partner..." value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} />
          </div>

          <div className="bg-brand-500/10 border border-brand-500/20 rounded-xl p-3 text-xs text-brand-300">
            ℹ️ A unique referral code will be auto-generated for this partner. They earn <strong>50% of the first subscription</strong> when a lab registers using their code.
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <button type="button" onClick={() => setShowAdd(false)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-4 py-2 rounded-xl text-sm">Cancel</button>
            <button type="submit" disabled={saving} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm disabled:opacity-60">
              {saving ? 'Creating...' : 'Create Partner'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Partner Detail Modal */}
      <Modal open={!!showDetail} onClose={() => setShowDetail(null)} title={showDetail?.name || 'Partner Details'} size="lg">
        {showDetail && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Referral Code', value: showDetail.referralCode, highlight: true },
                { label: 'Total Referrals', value: showDetail.totalReferrals },
                { label: 'Total Earned', value: `₹${showDetail.totalEarned?.toLocaleString('en-IN') || 0}` },
                { label: 'Wallet Balance', value: `₹${showDetail.walletBalance?.toLocaleString('en-IN') || 0}` },
                { label: 'Phone', value: showDetail.phone },
                { label: 'Type', value: showDetail.type },
              ].map(s => (
                <div key={s.label} className="bg-surface-850 border border-surface-700 rounded-xl p-3">
                  <p className="text-xs text-slate-500 mb-1">{s.label}</p>
                  <p className={`font-semibold text-sm ${s.highlight ? 'text-brand-400 font-mono-num' : 'text-slate-100'}`}>{s.value}</p>
                </div>
              ))}
            </div>
            {showDetail.bankName && (
              <div className="bg-surface-850 border border-surface-700 rounded-xl p-3 text-sm">
                <p className="text-xs text-slate-500 mb-2 font-semibold">Payment Details</p>
                <p className="text-slate-300">Bank: {showDetail.bankName} | A/C: {showDetail.accountNo} | IFSC: {showDetail.ifsc}</p>
                {showDetail.upiId && <p className="text-slate-300 mt-1">UPI: {showDetail.upiId}</p>}
              </div>
            )}
            <button onClick={() => { setShowDetail(null); copyCode(showDetail.referralCode) }}
              className="w-full bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/20 py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2">
              <Copy size={14} /> Copy Referral Code
            </button>
          </div>
        )}
      </Modal>
    </div>
  )
}
