import React, { useState, useEffect } from 'react'
import { PageHeader, Badge, SearchBar } from '../../components/UI'
import { superAdminAPI } from '../../utils/api'
import { User, Shield, Search, Building2, Activity } from 'lucide-react'

const FALLBACK_USERS = [
  { _id: 'U001', name: 'Ramesh Gupta', email: 'ramesh@citydiag.com', phone: '9876543210', role: 'labadmin', lab: 'City Diagnostics', status: 'active' },
  { _id: 'U002', name: 'Kavita Sharma', email: 'kavita@citydiag.com', phone: '9700000001', role: 'technician', lab: 'City Diagnostics', status: 'active' },
  { _id: 'U003', name: 'Ravi Kumar', email: 'ravi@citydiag.com', phone: '9700000002', role: 'reception', lab: 'City Diagnostics', status: 'active' },
  { _id: 'U004', name: 'Vikram Sharma', email: 'vikram@sharmalab.com', phone: '9876543211', role: 'labadmin', lab: 'Sharma Lab & Path', status: 'active' },
  { _id: 'U005', name: 'Priya Nair', email: 'priya@lifecare.com', phone: '9876500001', role: 'labadmin', lab: 'LifeCare Diagnostics', status: 'active' },
  { _id: 'U006', name: 'Dr. Rajesh Mehta', email: 'rajesh@citydiag.com', phone: '9812345678', role: 'doctor', lab: 'City Diagnostics', status: 'active' },
  { _id: 'U007', name: 'Anjali Singh', email: 'anjali@medpoint.com', phone: '9876543212', role: 'labadmin', lab: 'MedPoint Lab', status: 'suspended' },
]

const ROLE_COLORS = {
  superadmin: 'bg-red-500/10 text-red-400 border-red-500/20',
  labadmin: 'bg-brand-500/10 text-brand-400 border-brand-500/20',
  technician: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  reception: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  doctor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  patient: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
}

export default function UserManagement() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')

  const load = async () => {
    setLoading(true)
    try {
      const res = await superAdminAPI.getAllUsers()
      setUsers(res.data.data || [])
    } catch {
      setUsers(FALLBACK_USERS)
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const filtered = users.filter(u => {
    const matchSearch = !search ||
      u.name?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase()) ||
      u.phone?.includes(search) ||
      u.lab?.name?.toLowerCase().includes(search.toLowerCase())
    const matchRole = roleFilter === 'all' || u.role === roleFilter
    return matchSearch && matchRole
  })

  const roleCounts = users.reduce((acc, u) => {
    acc[u.role] = (acc[u.role] || 0) + 1
    return acc
  }, {})

  return (
    <div>
      <PageHeader
        title="User Management"
        subtitle="View and manage all platform users across labs"
      />

      {/* Role filters */}
      <div className="flex flex-wrap gap-2 mb-4">
        <button onClick={() => setRoleFilter('all')} className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${roleFilter === 'all' ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700 hover:text-slate-200'}`}>
          All ({users.length})
        </button>
        {['superadmin', 'labadmin', 'technician', 'reception', 'doctor', 'patient'].map(role => (
          roleCounts[role] > 0 && (
            <button key={role} onClick={() => setRoleFilter(role)} className={`px-3 py-1.5 rounded-xl text-xs font-medium capitalize transition-all ${roleFilter === role ? 'bg-brand-500 text-surface-950' : 'bg-surface-800 text-slate-400 border border-surface-700 hover:text-slate-200'}`}>
              {role} ({roleCounts[role]})
            </button>
          )
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md mb-4">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, email, phone, lab..." className="w-full bg-surface-900 border border-surface-700 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40" />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        {[
          { label: 'Total Users', value: users.length, icon: User, color: 'text-blue-400' },
          { label: 'Lab Admins', value: users.filter(u => u.role === 'labadmin').length, icon: Building2, color: 'text-brand-400' },
          { label: 'Staff (Tech+Rec)', value: users.filter(u => ['technician', 'reception'].includes(u.role)).length, icon: Activity, color: 'text-purple-400' },
          { label: 'Doctors', value: users.filter(u => u.role === 'doctor').length, icon: Shield, color: 'text-emerald-400' },
        ].map(s => (
          <div key={s.label} className="bg-surface-900 rounded-2xl border border-surface-700 p-4 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-surface-850 border border-surface-700">
              <s.icon size={16} className={s.color} />
            </div>
            <div>
              <p className="text-lg font-bold text-slate-100">{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Users table */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700">
        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500">No users match your search.</div>
        ) : (
          <div className="divide-y divide-surface-800">
            {filtered.map(u => (
              <div key={u._id} className="flex items-center gap-4 p-4 hover:bg-surface-850 transition-colors">
                <div className="w-10 h-10 rounded-full bg-surface-850 border border-surface-700 flex items-center justify-center text-slate-400 text-sm font-semibold flex-shrink-0">
                  {u.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || '?'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm text-slate-300">{u.name}</p>
                    {u.role && (
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-lg text-[10px] font-medium border ${ROLE_COLORS[u.role] || 'bg-surface-800 text-slate-500'}`}>
                        {u.role}
                      </span>
                    )}
                    <Badge status={u.status} />
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {u.email && <span>{u.email} · </span>}
                    {u.phone && <span>{u.phone}</span>}
                    {(u.lab?.name || u.lab) && <span> · {(u.lab?.name || u.lab)}</span>}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
