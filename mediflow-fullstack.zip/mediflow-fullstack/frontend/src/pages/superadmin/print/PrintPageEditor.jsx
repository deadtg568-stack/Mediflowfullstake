import React, { useEffect, useState, useRef } from 'react'
import {
  Save, Eye, Printer, ChevronDown, Upload, RotateCcw,
  Building2, Phone, Mail, Globe, MapPin, FileText,
  Palette, Type, AlignLeft, CheckSquare, Stamp,
} from 'lucide-react'
import { PageHeader } from '../../../components/UI'
import { superAdminAPI, superAdminPrintAPI, apiErrorMessage } from '../../../utils/api'
import toast from 'react-hot-toast'

const BORDER_STYLES = [
  { value: 'classic', label: 'Classic',  desc: 'Traditional double-border header' },
  { value: 'modern',  label: 'Modern',   desc: 'Clean single accent bar' },
  { value: 'minimal', label: 'Minimal',  desc: 'No border, clean whitespace' },
]
const FONT_SIZES = [
  { value: 'small',  label: 'Small (9pt)'  },
  { value: 'medium', label: 'Medium (10pt)' },
  { value: 'large',  label: 'Large (11pt)'  },
]
const ACCENT_COLORS = [
  '#16a34a','#0284c7','#7c3aed','#dc2626','#d97706',
  '#0891b2','#be185d','#1d4ed8','#059669','#374151',
]

const defaultSettings = {
  printLabName: '',       printTagline: '',
  printAddress: '',       printPhone: '',
  printEmail: '',         printWebsite: '',
  printGstin: '',         printRegNo: '',
  printAccreditation: '', printHeader: '',
  printFooter:        'Reports are generated electronically and are valid without signature unless specified.',
  printShowBarcode:   true,  printShowQR: true,
  printShowDrSign:    true,  printShowLabSign: true,
  printSignatoryName: '',    printSignatoryQual: '',
  printBorderStyle:   'classic',
  printAccentColor:   '#16a34a',
  printFontSize:      'medium',
  printWatermark:     '',
  printCopies:        1,
  printLogo:          '',
}

// ─── LIVE PREVIEW ─────────────────────────────────────────────────────────────
function PrintPreview({ s, lab }) {
  const accent = s.printAccentColor || '#16a34a'
  const name   = s.printLabName || lab?.name || 'Lab Name'
  const fontPx = s.printFontSize === 'small' ? '9pt' : s.printFontSize === 'large' ? '11pt' : '10pt'

  return (
    <div
      className="bg-white text-black shadow-lg mx-auto rounded-lg overflow-hidden"
      style={{ width: '210mm', minHeight: '297mm', fontSize: fontPx, fontFamily: 'Arial, sans-serif', position: 'relative', padding: '12mm' }}
    >
      {/* Watermark */}
      {s.printWatermark && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%',
          transform: 'translate(-50%,-50%) rotate(-35deg)',
          fontSize: '60px', fontWeight: 900, opacity: 0.04,
          color: accent, pointerEvents: 'none', userSelect: 'none', whiteSpace: 'nowrap',
          zIndex: 0,
        }}>
          {s.printWatermark}
        </div>
      )}

      {/* Header */}
      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Border style: classic */}
        {s.printBorderStyle === 'classic' && (
          <div style={{ border: `2px solid ${accent}`, borderRadius: 4, padding: '8px 12px', marginBottom: 8 }}>
            <div style={{ borderBottom: `1px solid ${accent}`, paddingBottom: 8, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 12 }}>
              {s.printLogo && (
                <img src={s.printLogo} alt="logo" style={{ height: 56, width: 56, objectFit: 'contain', flexShrink: 0 }} />
              )}
              {!s.printLogo && (
                <div style={{ width: 56, height: 56, background: accent, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 900, fontSize: 24, flexShrink: 0 }}>
                  {name[0]}
                </div>
              )}
              <div style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: '18pt', fontWeight: 900, color: accent, lineHeight: 1.2 }}>{name}</div>
                {s.printTagline && <div style={{ fontSize: '9pt', color: '#555', marginTop: 2 }}>{s.printTagline}</div>}
                {s.printAccreditation && <div style={{ fontSize: '8pt', color: accent, marginTop: 2, fontWeight: 600 }}>{s.printAccreditation}</div>}
              </div>
              {s.printShowBarcode && (
                <div style={{ textAlign: 'center', flexShrink: 0 }}>
                  <div style={{ background: '#000', width: 60, height: 20, marginBottom: 2 }} />
                  <div style={{ fontSize: '7pt', color: '#666' }}>PT-0001</div>
                </div>
              )}
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 20, fontSize: '8pt', color: '#444', flexWrap: 'wrap' }}>
              {s.printAddress && <span>📍 {s.printAddress}</span>}
              {s.printPhone && <span>📞 {s.printPhone}</span>}
              {s.printEmail && <span>✉ {s.printEmail}</span>}
              {s.printWebsite && <span>🌐 {s.printWebsite}</span>}
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 20, fontSize: '7.5pt', color: '#666', marginTop: 4, flexWrap: 'wrap' }}>
              {s.printRegNo && <span>Reg. No: {s.printRegNo}</span>}
              {s.printGstin && <span>GSTIN: {s.printGstin}</span>}
            </div>
          </div>
        )}

        {/* Border style: modern */}
        {s.printBorderStyle === 'modern' && (
          <div style={{ marginBottom: 8 }}>
            <div style={{ borderLeft: `5px solid ${accent}`, paddingLeft: 12, display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
              {s.printLogo
                ? <img src={s.printLogo} alt="logo" style={{ height: 48, objectFit: 'contain' }} />
                : <div style={{ width: 48, height: 48, background: accent, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 900, fontSize: 20 }}>{name[0]}</div>
              }
              <div>
                <div style={{ fontSize: '16pt', fontWeight: 900, color: accent }}>{name}</div>
                {s.printTagline && <div style={{ fontSize: '8.5pt', color: '#666' }}>{s.printTagline}</div>}
              </div>
            </div>
            <div style={{ background: accent, height: 2, marginBottom: 6 }} />
            <div style={{ display: 'flex', gap: 16, fontSize: '8pt', color: '#444', flexWrap: 'wrap' }}>
              {s.printAddress && <span>{s.printAddress}</span>}
              {s.printPhone && <span>Ph: {s.printPhone}</span>}
              {s.printEmail && <span>{s.printEmail}</span>}
              {s.printGstin && <span>GSTIN: {s.printGstin}</span>}
            </div>
          </div>
        )}

        {/* Border style: minimal */}
        {s.printBorderStyle === 'minimal' && (
          <div style={{ textAlign: 'center', paddingBottom: 8, marginBottom: 8, borderBottom: `1px solid #eee` }}>
            {s.printLogo && <img src={s.printLogo} alt="logo" style={{ height: 44, marginBottom: 4 }} />}
            <div style={{ fontSize: '15pt', fontWeight: 900, color: accent }}>{name}</div>
            {s.printTagline && <div style={{ fontSize: '8.5pt', color: '#888', marginTop: 2 }}>{s.printTagline}</div>}
            <div style={{ fontSize: '8pt', color: '#666', marginTop: 4 }}>
              {[s.printAddress, s.printPhone, s.printEmail].filter(Boolean).join(' | ')}
            </div>
          </div>
        )}

        {/* Optional custom header text */}
        {s.printHeader && (
          <div style={{ fontSize: '8.5pt', color: '#555', marginBottom: 8, borderBottom: `1px solid #eee`, paddingBottom: 6 }}>
            {s.printHeader}
          </div>
        )}

        {/* Patient info row (demo) */}
        <div style={{ background: '#f8f8f8', border: '1px solid #e5e5e5', borderRadius: 4, padding: '6px 10px', marginBottom: 8, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 4, fontSize: '8.5pt' }}>
          <div><b>Patient:</b> Rahul Sharma</div>
          <div><b>Age/Sex:</b> 34Y / Male</div>
          <div><b>PID:</b> P0001</div>
          <div><b>Ref. By:</b> Dr. Rajesh Mehta</div>
          <div><b>Sample:</b> 12 Jun 2026, 09:30 AM</div>
          <div><b>Report:</b> 12 Jun 2026, 02:00 PM</div>
        </div>

        {/* Sample test result table */}
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '8.5pt', marginBottom: 8 }}>
          <thead>
            <tr style={{ background: accent, color: '#fff' }}>
              <th style={{ padding: '4px 6px', textAlign: 'left' }}>Test Name</th>
              <th style={{ padding: '4px 6px', textAlign: 'center' }}>Result</th>
              <th style={{ padding: '4px 6px', textAlign: 'center' }}>Unit</th>
              <th style={{ padding: '4px 6px', textAlign: 'center' }}>Normal Range</th>
              <th style={{ padding: '4px 6px', textAlign: 'center' }}>Flag</th>
            </tr>
          </thead>
          <tbody>
            {[
              ['Haemoglobin (Hb)', '13.2', 'g/dL', '12.0 – 17.0', ''],
              ['WBC Count', '7,800', '/µL', '4,000 – 11,000', ''],
              ['Platelet Count', '2,45,000', '/µL', '1,50,000 – 4,50,000', ''],
              ['Blood Sugar Fasting', '112', 'mg/dL', '70 – 100', 'H'],
              ['Serum Creatinine', '1.1', 'mg/dL', '0.6 – 1.2', ''],
            ].map(([t, r, u, n, f], i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? '#fafafa' : '#fff', borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '3px 6px' }}>{t}</td>
                <td style={{ padding: '3px 6px', textAlign: 'center', fontWeight: f ? 700 : 400 }}>{r}</td>
                <td style={{ padding: '3px 6px', textAlign: 'center', color: '#666' }}>{u}</td>
                <td style={{ padding: '3px 6px', textAlign: 'center', color: '#666' }}>{n}</td>
                <td style={{ padding: '3px 6px', textAlign: 'center', color: f === 'H' ? 'red' : f === 'L' ? 'blue' : '' }}>{f}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Footer */}
        {s.printFooter && (
          <div style={{ fontSize: '7.5pt', color: '#777', borderTop: '1px solid #eee', paddingTop: 6, marginTop: 6 }}>
            {s.printFooter}
          </div>
        )}

        {/* Signatures */}
        {(s.printShowDrSign || s.printShowLabSign) && (
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 20, fontSize: '8pt' }}>
            {s.printShowDrSign && (
              <div style={{ textAlign: 'center' }}>
                <div style={{ borderTop: `1px solid ${accent}`, paddingTop: 4, marginTop: 30, width: 120 }}>
                  <div style={{ fontWeight: 700 }}>Referring Doctor</div>
                </div>
              </div>
            )}
            {s.printShowLabSign && (
              <div style={{ textAlign: 'center' }}>
                <div style={{ borderTop: `1px solid ${accent}`, paddingTop: 4, marginTop: 30, width: 140 }}>
                  <div style={{ fontWeight: 700 }}>{s.printSignatoryName || 'Lab Signatory'}</div>
                  {s.printSignatoryQual && <div style={{ color: '#666', fontSize: '7.5pt' }}>{s.printSignatoryQual}</div>}
                </div>
              </div>
            )}
          </div>
        )}

        {/* QR */}
        {s.printShowQR && (
          <div style={{ position: 'absolute', bottom: 12, right: 12, textAlign: 'center' }}>
            <div style={{ width: 44, height: 44, background: '#000', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 2, padding: 3, borderRadius: 3 }}>
              {Array(9).fill(0).map((_, i) => <div key={i} style={{ background: i % 3 === 1 ? '#fff' : '#000' }} />)}
            </div>
            <div style={{ fontSize: '6.5pt', color: '#888', marginTop: 2 }}>Scan to verify</div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function PrintPageEditor() {
  const [labs, setLabs] = useState([])
  const [selectedLabId, setSelectedLabId] = useState('')
  const [lab, setLab] = useState(null)
  const [settings, setSettings] = useState({ ...defaultSettings })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [activeTab, setActiveTab] = useState('identity')
  const logoInputRef = useRef()

  // Load all labs for the dropdown
  useEffect(() => {
    superAdminAPI.getAllLabs()
      .then(r => {
        setLabs(r.data.data)
        if (r.data.data.length > 0) setSelectedLabId(r.data.data[0]._id)
      })
      .catch(e => toast.error(apiErrorMessage(e)))
      .finally(() => setLoading(false))
  }, [])

  // Load print settings when lab changes
  useEffect(() => {
    if (!selectedLabId) return
    superAdminPrintAPI.getPrintSettings(selectedLabId)
      .then(r => {
        const data = r.data.data
        setLab(data)
        const s = data.settings || {}
        setSettings({
          ...defaultSettings,
          printLabName:       s.printLabName || data.name || '',
          printTagline:       s.printTagline || '',
          printAddress:       s.printAddress || data.address || '',
          printPhone:         s.printPhone || data.phone || '',
          printEmail:         s.printEmail || data.email || '',
          printWebsite:       s.printWebsite || '',
          printGstin:         s.printGstin || data.gstin || '',
          printRegNo:         s.printRegNo || '',
          printAccreditation: s.printAccreditation || '',
          printHeader:        s.printHeader || '',
          printFooter:        s.printFooter || defaultSettings.printFooter,
          printShowBarcode:   s.printShowBarcode !== undefined ? s.printShowBarcode : true,
          printShowQR:        s.printShowQR !== undefined ? s.printShowQR : true,
          printShowDrSign:    s.printShowDrSign !== undefined ? s.printShowDrSign : true,
          printShowLabSign:   s.printShowLabSign !== undefined ? s.printShowLabSign : true,
          printSignatoryName: s.printSignatoryName || '',
          printSignatoryQual: s.printSignatoryQual || '',
          printBorderStyle:   s.printBorderStyle || 'classic',
          printAccentColor:   s.printAccentColor || '#16a34a',
          printFontSize:      s.printFontSize || 'medium',
          printWatermark:     s.printWatermark || '',
          printCopies:        s.printCopies || 1,
          printLogo:          s.printLogo || '',
        })
      })
      .catch(e => toast.error(apiErrorMessage(e, 'Failed to load settings')))
  }, [selectedLabId])

  const set = (key, val) => setSettings(s => ({ ...s, [key]: val }))

  const handleSave = async () => {
    setSaving(true)
    try {
      await superAdminPrintAPI.savePrintSettings(selectedLabId, { settings })
      toast.success('Print settings saved successfully!')
    } catch (e) {
      toast.error(apiErrorMessage(e, 'Save failed'))
    } finally { setSaving(false) }
  }

  const handleReset = () => {
    setSettings({ ...defaultSettings, printLabName: lab?.name || '', printPhone: lab?.phone || '', printAddress: lab?.address || '', printGstin: lab?.gstin || '', printEmail: lab?.email || '' })
    toast('Settings reset to defaults')
  }

  const handleLogoUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return
    if (file.size > 500 * 1024) return toast.error('Logo must be under 500KB')
    const reader = new FileReader()
    reader.onload = ev => set('printLogo', ev.target.result)
    reader.readAsDataURL(file)
  }

  const tabs = [
    { id: 'identity',   label: 'Lab Identity',   icon: Building2 },
    { id: 'layout',     label: 'Layout & Style',  icon: Palette },
    { id: 'content',    label: 'Header & Footer', icon: AlignLeft },
    { id: 'signature',  label: 'Signatures',      icon: Stamp },
    { id: 'options',    label: 'Options',          icon: CheckSquare },
  ]

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )

  return (
    <div>
      <PageHeader
        title="Lab Print Page Editor"
        subtitle="Customize the report print template for any lab"
        actions={
          <div className="flex items-center gap-2">
            <button onClick={handleReset} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-2 rounded-xl text-sm flex items-center gap-2">
              <RotateCcw size={14} /> Reset
            </button>
            <button onClick={() => setShowPreview(p => !p)} className="bg-surface-800 hover:bg-surface-700 text-slate-300 border border-surface-700 px-3 py-2 rounded-xl text-sm flex items-center gap-2">
              <Eye size={14} /> {showPreview ? 'Hide' : 'Preview'}
            </button>
            <button onClick={handleSave} disabled={saving} className="bg-brand-500 hover:bg-brand-600 text-surface-950 font-semibold px-4 py-2 rounded-xl text-sm flex items-center gap-2 disabled:opacity-60">
              <Save size={14} /> {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        }
      />

      {/* Lab selector */}
      <div className="bg-surface-900 rounded-2xl border border-surface-700 p-4 mb-4">
        <label className="block text-xs font-semibold text-slate-400 tracking-wide mb-2">SELECT LAB TO EDIT</label>
        <div className="relative">
          <select
            value={selectedLabId}
            onChange={e => setSelectedLabId(e.target.value)}
            className="w-full bg-surface-850 border border-surface-700 rounded-xl px-4 py-2.5 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-500/40 appearance-none pr-10"
          >
            {labs.map(l => (
              <option key={l._id} value={l._id}>{l.name} — {l.city} ({l.plan})</option>
            ))}
          </select>
          <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>
      </div>

      <div className={`grid gap-4 ${showPreview ? 'grid-cols-1 xl:grid-cols-2' : 'grid-cols-1'}`}>
        {/* Editor panel */}
        <div className="space-y-4">
          {/* Tabs */}
          <div className="flex gap-1 bg-surface-900 border border-surface-700 rounded-2xl p-1.5">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium flex-1 justify-center transition-all
                  ${activeTab === t.id ? 'bg-brand-500/15 text-brand-400 border border-brand-500/20' : 'text-slate-400 hover:text-slate-200'}`}>
                <t.icon size={13} /> <span className="hidden sm:inline">{t.label}</span>
              </button>
            ))}
          </div>

          <div className="bg-surface-900 rounded-2xl border border-surface-700 p-5">
            {/* ── IDENTITY TAB ── */}
            {activeTab === 'identity' && (
              <div className="space-y-4">
                <p className="font-display font-semibold text-slate-200 mb-3 flex items-center gap-2"><Building2 size={15} className="text-brand-400" /> Lab Identity</p>

                {/* Logo upload */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-2">Lab Logo</label>
                  <div className="flex items-center gap-4">
                    <div className="w-20 h-20 rounded-xl border-2 border-dashed border-surface-600 flex items-center justify-center overflow-hidden bg-surface-850">
                      {settings.printLogo
                        ? <img src={settings.printLogo} alt="logo" className="w-full h-full object-contain" />
                        : <Upload size={20} className="text-slate-500" />}
                    </div>
                    <div className="space-y-2">
                      <button onClick={() => logoInputRef.current?.click()}
                        className="bg-surface-800 hover:bg-surface-700 border border-surface-700 text-slate-300 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5">
                        <Upload size={13} /> Upload Logo
                      </button>
                      {settings.printLogo && (
                        <button onClick={() => set('printLogo', '')} className="text-red-400 text-xs hover:text-red-300">Remove</button>
                      )}
                      <p className="text-xs text-slate-500">PNG/JPG, max 500KB</p>
                    </div>
                    <input ref={logoInputRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'Lab Name on Print', key: 'printLabName', placeholder: 'City Diagnostics' },
                    { label: 'Tagline', key: 'printTagline', placeholder: 'Quality • Accuracy • Speed' },
                    { label: 'Address', key: 'printAddress', placeholder: 'Plot 12, Raipur – 492001' },
                    { label: 'Phone', key: 'printPhone', placeholder: '+91 98765 43210' },
                    { label: 'Email', key: 'printEmail', placeholder: 'lab@email.com' },
                    { label: 'Website', key: 'printWebsite', placeholder: 'www.citydiag.com' },
                    { label: 'GSTIN', key: 'printGstin', placeholder: '22XXXXX1234X1Z5' },
                    { label: 'Lab Reg. No.', key: 'printRegNo', placeholder: 'LAB/CG/2024/001' },
                  ].map(f => (
                    <div key={f.key}>
                      <label className="block text-xs font-medium text-slate-400 mb-1">{f.label}</label>
                      <input
                        value={settings[f.key] || ''}
                        onChange={e => set(f.key, e.target.value)}
                        placeholder={f.placeholder}
                        className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      />
                    </div>
                  ))}
                  <div className="col-span-2">
                    <label className="block text-xs font-medium text-slate-400 mb-1">Accreditation (e.g. NABL Accredited · ISO 9001:2015)</label>
                    <input
                      value={settings.printAccreditation || ''}
                      onChange={e => set('printAccreditation', e.target.value)}
                      placeholder="NABL Accredited · ISO 15189:2022 Certified"
                      className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* ── LAYOUT TAB ── */}
            {activeTab === 'layout' && (
              <div className="space-y-5">
                <p className="font-display font-semibold text-slate-200 mb-3 flex items-center gap-2"><Palette size={15} className="text-brand-400" /> Layout & Style</p>

                {/* Border style */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-2">Header Style</label>
                  <div className="grid grid-cols-3 gap-2">
                    {BORDER_STYLES.map(b => (
                      <button key={b.value} onClick={() => set('printBorderStyle', b.value)}
                        className={`p-3 rounded-xl border text-left transition-all ${settings.printBorderStyle === b.value ? 'border-brand-500 bg-brand-500/10' : 'border-surface-700 bg-surface-850 hover:border-surface-600'}`}>
                        <p className="text-sm font-medium text-slate-200">{b.label}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{b.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Accent color */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-2">Accent Color</label>
                  <div className="flex items-center gap-3">
                    <div className="flex gap-2 flex-wrap">
                      {ACCENT_COLORS.map(c => (
                        <button key={c} onClick={() => set('printAccentColor', c)}
                          className={`w-8 h-8 rounded-lg border-2 transition-all ${settings.printAccentColor === c ? 'border-white scale-110' : 'border-transparent'}`}
                          style={{ background: c }} />
                      ))}
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="color" value={settings.printAccentColor || '#16a34a'} onChange={e => set('printAccentColor', e.target.value)}
                        className="w-10 h-10 rounded-lg border border-surface-700 cursor-pointer bg-surface-850 p-0.5" />
                      <span className="text-xs text-slate-400 font-mono-num">{settings.printAccentColor}</span>
                    </div>
                  </div>
                </div>

                {/* Font size */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-2">Report Font Size</label>
                  <div className="flex gap-2">
                    {FONT_SIZES.map(f => (
                      <button key={f.value} onClick={() => set('printFontSize', f.value)}
                        className={`px-4 py-2 rounded-xl border text-sm transition-all ${settings.printFontSize === f.value ? 'border-brand-500 bg-brand-500/10 text-brand-300' : 'border-surface-700 bg-surface-850 text-slate-400 hover:border-surface-600'}`}>
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Watermark */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Watermark Text (optional)</label>
                  <input value={settings.printWatermark || ''} onChange={e => set('printWatermark', e.target.value)}
                    placeholder='e.g. CONFIDENTIAL or leave blank'
                    className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30" />
                </div>

                {/* Copies */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Default Print Copies</label>
                  <select value={settings.printCopies} onChange={e => set('printCopies', Number(e.target.value))}
                    className="bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-500/30">
                    {[1,2,3,4].map(n => <option key={n} value={n}>{n} {n === 1 ? 'copy' : 'copies'}</option>)}
                  </select>
                </div>
              </div>
            )}

            {/* ── CONTENT TAB ── */}
            {activeTab === 'content' && (
              <div className="space-y-4">
                <p className="font-display font-semibold text-slate-200 mb-3 flex items-center gap-2"><AlignLeft size={15} className="text-brand-400" /> Header & Footer Text</p>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Custom Header Text (below lab info, above patient details)</label>
                  <textarea value={settings.printHeader || ''} onChange={e => set('printHeader', e.target.value)} rows={3}
                    placeholder="e.g. NABL Accredited Lab — Results are for diagnostic purposes only."
                    className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30 resize-none" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Custom Footer Text (below results table)</label>
                  <textarea value={settings.printFooter || ''} onChange={e => set('printFooter', e.target.value)} rows={3}
                    placeholder="e.g. This report is electronically generated and is valid without signature."
                    className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30 resize-none" />
                </div>
              </div>
            )}

            {/* ── SIGNATURE TAB ── */}
            {activeTab === 'signature' && (
              <div className="space-y-4">
                <p className="font-display font-semibold text-slate-200 mb-3 flex items-center gap-2"><Stamp size={15} className="text-brand-400" /> Signatory Details</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Signatory Name</label>
                    <input value={settings.printSignatoryName || ''} onChange={e => set('printSignatoryName', e.target.value)}
                      placeholder="Dr. Ramesh Gupta"
                      className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Qualification</label>
                    <input value={settings.printSignatoryQual || ''} onChange={e => set('printSignatoryQual', e.target.value)}
                      placeholder="MBBS, MD (Pathology)"
                      className="w-full bg-surface-850 border border-surface-700 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-500/30" />
                  </div>
                </div>
              </div>
            )}

            {/* ── OPTIONS TAB ── */}
            {activeTab === 'options' && (
              <div className="space-y-3">
                <p className="font-display font-semibold text-slate-200 mb-3 flex items-center gap-2"><CheckSquare size={15} className="text-brand-400" /> Print Options</p>
                {[
                  { key: 'printShowBarcode', label: 'Show Barcode', desc: 'Sample barcode in header' },
                  { key: 'printShowQR', label: 'Show QR Code', desc: 'QR for digital report verification' },
                  { key: 'printShowDrSign', label: 'Show Doctor Signature Line', desc: 'Referring doctor signature block' },
                  { key: 'printShowLabSign', label: 'Show Lab Signatory', desc: 'Lab in-charge signature block' },
                  { key: 'printShowPatientPhoto', label: 'Show Patient Photo', desc: 'If photo is uploaded (optional)' },
                ].map(o => (
                  <label key={o.key} className="flex items-center justify-between p-3 bg-surface-850 rounded-xl border border-surface-700 cursor-pointer hover:border-surface-600">
                    <div>
                      <p className="text-sm font-medium text-slate-200">{o.label}</p>
                      <p className="text-xs text-slate-500">{o.desc}</p>
                    </div>
                    <div className={`w-11 h-6 rounded-full transition-colors flex items-center px-0.5 ${settings[o.key] ? 'bg-brand-500' : 'bg-surface-700'}`}
                      onClick={() => set(o.key, !settings[o.key])}>
                      <div className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${settings[o.key] ? 'translate-x-5' : 'translate-x-0'}`} />
                    </div>
                  </label>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Live Preview */}
        {showPreview && (
          <div>
            <div className="sticky top-4">
              <div className="flex items-center justify-between mb-3">
                <p className="font-display font-semibold text-slate-200 flex items-center gap-2">
                  <Printer size={15} className="text-brand-400" /> Live Preview
                </p>
                <span className="text-xs text-slate-500">A4 Scale</span>
              </div>
              <div className="overflow-auto rounded-2xl border border-surface-700 bg-surface-850 p-4 max-h-[85vh]" style={{ transform: 'scale(0.55)', transformOrigin: 'top left', width: '182%', height: 'auto' }}>
                <PrintPreview s={settings} lab={lab} />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
