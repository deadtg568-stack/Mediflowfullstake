import { create } from 'zustand'

const saved = (() => {
  try {
    return {
      user:  JSON.parse(localStorage.getItem('mf_user') || 'null'),
      token: localStorage.getItem('mf_token') || null,
    }
  } catch { return { user: null, token: null } }
})()

export const useStore = create((set) => ({
  user:        saved.user,
  token:       saved.token,
  theme:       localStorage.getItem('mf_theme') || 'light',
  sidebarOpen: true,

  setUser: (user, token) => {
    localStorage.setItem('mf_user', JSON.stringify(user))
    if (token) localStorage.setItem('mf_token', token)
    set({ user, token })
  },

  logout: () => {
    localStorage.removeItem('mf_user')
    localStorage.removeItem('mf_token')
    set({ user: null, token: null })
  },

  toggleTheme: () => set((s) => {
    const next = s.theme === 'light' ? 'dark' : 'light'
    localStorage.setItem('mf_theme', next)
    document.documentElement.classList.toggle('dark', next === 'dark')
    return { theme: next }
  }),

  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
}))
