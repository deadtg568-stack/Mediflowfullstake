# 🏥 MediFlow Pro AI — Frontend

Smart Pathology Management Powered by AI

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

Open http://localhost:5173 in your browser.

## Login

On the login screen, select any role and use any phone number + OTP (demo mode — any digits work).

## Panels & Routes

| Role | Route | Description |
|------|-------|-------------|
| Super Admin | /superadmin | Platform management, all labs |
| Lab Admin | /labadmin | Full lab operations |
| Technician | /technician | Sample collection & reports |
| Reception | /reception | Patient desk & billing |
| Doctor | /doctor | Patient reports & referrals |
| Patient | /patient | Self-service portal |

## Tech Stack

- **React 18** + Vite
- **Tailwind CSS** — utility-first styling
- **React Router v6** — client-side routing
- **Zustand** — state management (auth + theme)
- **Recharts** — data visualizations
- **Framer Motion** — animations (ready to use)
- **Lucide React** — icons

## Project Structure

```
src/
├── App.jsx               # All routes
├── main.jsx              # Entry point
├── index.css             # Global styles + design tokens
├── store/
│   └── index.js          # Zustand store (auth, theme)
├── utils/
│   └── mockData.js       # Sample data for all panels
├── layouts/
│   └── Layout.jsx        # Sidebar + topbar layout
├── components/
│   └── UI.jsx            # StatCard, Table, Modal, Badge, etc.
└── pages/
    ├── Login.jsx
    ├── Settings.jsx
    ├── superadmin/       Dashboard, LabManagement, Others
    ├── labadmin/         Dashboard, PatientsDoctorsTests, BillingEtc, AIAndCCTV, AppointmentsSettings
    ├── technician/       TechnicianPages
    ├── reception/        ReceptionPages
    ├── doctor/           DoctorPages
    └── patient/          PatientPages
```

## Features Implemented

### Super Admin
- Dashboard with revenue chart & lab table
- Lab Management (create/view/edit labs)
- Subscriptions & license key management
- Revenue Analytics
- AI Analytics (voice command usage)
- Support Tickets
- Server Health Monitor

### Lab Admin
- Dashboard with charts (revenue, top tests)
- Patient Management
- Doctor Management + referrals
- Test Management
- Appointments
- Billing + GST invoices
- Reports (PDF/WhatsApp share)
- Staff Management
- Inventory + low stock alerts
- Finance (P&L)
- Analytics
- AI Chat Assistant (voice commands demo)
- CCTV Monitor (live camera UI)
- Settings

### Technician Panel
- Dashboard + pending work
- Sample collection + barcode scanner UI
- Pending Reports with status

### Reception Panel
- Dashboard with quick actions
- Patient Registration form
- Token Queue System
- Home Collection booking

### Doctor Portal
- Dashboard + patient reports
- Patient History
- Trend Analysis charts
- Referral Tracking

### Patient Portal
- Dashboard + AI health summary
- My Reports (download/share)
- Live Test Status tracking
- Book Test
- Payment History
- AI Health Insights

## Connecting Backend

Replace mock data in `src/utils/mockData.js` with actual API calls.
All components are ready to accept live data via props or Zustand store.

Recommended: use **TanStack Query** (already in package.json) for server state management.

## License Key Format
```
MFPAI-2026-ABCD1234
```

---
Built with ❤️ for Indian Pathology Labs
