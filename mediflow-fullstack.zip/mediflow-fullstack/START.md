# 🚀 MediFlow Pro AI — Start Guide

## Prerequisites
- Node.js 18+ → https://nodejs.org
- MongoDB → https://www.mongodb.com/try/download/community  
  OR use MongoDB Atlas (free cloud): https://cloud.mongodb.com
- **ffmpeg** (required for CCTV module — live streaming, recording, snapshots, AI motion detection)
  - Ubuntu/Debian: `sudo apt install ffmpeg`
  - macOS: `brew install ffmpeg`
  - Windows: https://ffmpeg.org/download.html (add to PATH)
  - Verify: `ffmpeg -version`

---

## ⚡ Quick Start (3 steps)

### Step 1 — Install Dependencies
Open terminal in this folder and run:
```bash
cd backend
npm install

cd ../frontend
npm install
```

---

### Step 2 — Start MongoDB
**Option A: Local MongoDB**
```bash
mongod
```

**Option B: MongoDB Atlas (Cloud)**
- Create free account at https://cloud.mongodb.com
- Create cluster → Get connection string
- Edit `backend/.env`:
```
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/mediflow
```

---

### Step 3 — Run the App

**Terminal 1 — Backend:**
```bash
cd backend
npm run seed    # ← Run once to create demo data
npm run dev     # ← Start backend API
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm run dev     # ← Start frontend
```

**Open browser:** http://localhost:5173

---

## 🔑 Demo Login Accounts

| Role       | Phone      | OTP shown in terminal |
|------------|------------|----------------------|
| Super Admin | 9999999999 | Shown in backend terminal |
| Lab Admin   | 9876543210 | Shown in backend terminal |
| Technician  | 9700000001 | Shown in backend terminal |
| Reception   | 9700000002 | Shown in backend terminal |

> **OTP appears in the backend terminal** during development.  
> On the login screen it also shows in a yellow box for convenience.

---

## 📁 Project Structure

```
mediflow-fullstack/
├── backend/
│   ├── src/
│   │   ├── server.js          ← Express server entry
│   │   ├── config/db.js       ← MongoDB connection
│   │   ├── models/index.js    ← All Mongoose models
│   │   ├── middleware/auth.js ← JWT + protect middleware
│   │   ├── controllers/       ← Business logic
│   │   ├── routes/            ← API routes
│   │   └── utils/seed.js      ← Demo data seeder
│   ├── .env                   ← Backend config
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx            ← All routes
│   │   ├── store/index.js     ← Zustand (auth state)
│   │   ├── utils/api.js       ← Axios API service layer
│   │   ├── layouts/Layout.jsx ← Sidebar + topbar
│   │   ├── components/UI.jsx  ← Shared components
│   │   └── pages/             ← All panel pages
│   ├── .env                   ← VITE_API_URL=http://localhost:5000/api
│   └── package.json
│
└── START.md                   ← This file
```

---

## 🌐 API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/auth/send-otp | Send OTP to phone |
| POST | /api/auth/verify-otp | Verify OTP → get JWT |
| GET  | /api/auth/me | Get current user |
| GET  | /api/patients | List patients |
| POST | /api/patients | Register patient |
| GET  | /api/billing | List bills |
| POST | /api/billing | Create bill |
| GET  | /api/billing/today/summary | Today's cash summary |
| GET  | /api/tests | List tests |
| POST | /api/tests | Create test |
| GET  | /api/doctors | List doctors |
| POST | /api/doctors | Add doctor |
| GET  | /api/reports | List reports |
| PUT  | /api/reports/:id | Update report result |
| GET  | /api/inventory | List inventory |
| PATCH| /api/inventory/:id/stock | Adjust stock |
| GET  | /api/analytics/dashboard | Dashboard stats |
| GET  | /api/analytics/monthly-revenue | Revenue chart data |
| GET  | /api/analytics/top-tests | Top tests |
| GET  | /api/superadmin/dashboard | Super admin stats |
| GET  | /api/superadmin/labs | All labs |
| POST | /api/superadmin/labs | Create lab |

### CCTV Module (Camera Management)
| Method | Route | Description |
|--------|-------|-------------|
| GET  | /api/cameras | List cameras |
| POST | /api/cameras | Add camera manually |
| PUT  | /api/cameras/:id | Update camera config |
| DELETE | /api/cameras/:id | Remove camera |
| GET  | /api/cameras/discover | ONVIF auto-discovery scan |
| POST | /api/cameras/discover/connect | Connect to discovered device, fetch RTSP URI |
| POST | /api/cameras/discover/add | Add camera found via ONVIF |
| POST | /api/cameras/:id/stream/start | Start RTSP→HLS live stream |
| POST | /api/cameras/:id/stream/stop | Stop live stream |
| GET  | /api/cameras/:id/snapshot | Capture JPEG snapshot |
| POST | /api/cameras/:id/recording/start | Start continuous recording |
| POST | /api/cameras/:id/recording/stop | Stop recording |
| GET  | /api/cameras/:id/recordings | List recorded clips |
| POST | /api/cameras/:id/motion/start | Start AI motion detection |
| POST | /api/cameras/:id/motion/stop | Stop AI motion detection |
| POST | /api/cameras/:id/motion/test | One-off motion check (tune sensitivity) |
| GET  | /api/cameras/motion-events | Motion event log |
| PATCH| /api/cameras/motion-events/:id/review | Mark event reviewed |

---

## 🔒 Environment Variables

### Backend (`backend/.env`)
```env
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb://localhost:27017/mediflow
JWT_SECRET=your_secret_key_change_in_production
JWT_EXPIRE=7d
```

### Frontend (`frontend/.env`)
```env
VITE_API_URL=http://localhost:5000/api
```

---

## 🛠️ Common Issues

**White page / CORS error:**
→ Make sure backend is running on port 5000 first

**MongoDB connection failed:**
→ Make sure `mongod` is running, or use Atlas URI

**OTP not received:**
→ In dev mode, OTP prints in the backend terminal  
→ Also shows in yellow box on login screen

**Port already in use:**
→ Backend: change `PORT=5001` in `backend/.env` and update `frontend/.env` VITE_API_URL

---

## 🚀 Production Deployment

**Backend:** Deploy to Railway / Render / VPS
- Set `NODE_ENV=production`
- Set real `MONGO_URI` (Atlas)
- Set strong `JWT_SECRET`

**Frontend:** Deploy to Vercel / Netlify
- Set `VITE_API_URL=https://your-backend-url.com/api`
- Run `npm run build` → upload `dist/` folder

---

Built with ❤️ for Indian Pathology Labs
MediFlow Pro AI v1.0
