# 📹 CCTV / Camera Management Module

Complete IP camera management for MediFlow Pro AI labs: ONVIF auto-discovery,
RTSP live streaming (via HLS), continuous recording with playback, and
AI-based motion detection.

---

## ✅ Features

| Feature | How it works |
|---|---|
| **Camera Management** | Add cameras manually (IP, RTSP path, credentials) or via ONVIF discovery. Full CRUD from the UI. |
| **ONVIF Auto Discovery** | WS-Discovery (UDP multicast) scan finds ONVIF cameras on the LAN. One click connects and fetches the RTSP stream URI + device info (manufacturer, model). |
| **RTSP Streaming** | Backend spawns `ffmpeg` per camera to transcode RTSP → HLS (`.m3u8` + `.ts` segments), served statically and played in-browser with `hls.js` — no plugins needed. |
| **Recording & Playback** | `ffmpeg -f segment` writes rolling MP4 clips (default 15 min) to `/recordings/<streamKey>/`. Browse, play, and download from the Recordings page. |
| **AI Motion Detection** | Lightweight frame-difference analysis: grabs two downscaled JPEG snapshots a fraction of a second apart, decodes with `jpeg-js`, computes the % of pixels with significant luma change. If above a per-camera sensitivity threshold, logs a `MotionEvent` with a snapshot and (optionally) triggers a recording burst. |

---

## 🖥️ Pages (Lab Admin sidebar → CCTV)

1. **Live View** (`/labadmin/cctv`) — grid of camera tiles, play/stop stream, toggle recording, toggle AI motion, fullscreen view.
2. **Cameras** (`/labadmin/cctv/cameras`) — add/remove cameras, run ONVIF discovery.
3. **Recordings** (`/labadmin/cctv/recordings`) — per-camera recorded clip browser with playback modal + download.
4. **Motion Events** (`/labadmin/cctv/motion`) — AI alert log with snapshots, review/acknowledge.
5. **Settings** (`/labadmin/cctv/settings`) — per-camera sensitivity slider, enable/disable recording & motion detection.

---

## ⚙️ Backend Architecture

```
backend/src/
├── models/index.js         → Camera, Recording, MotionEvent schemas
├── services/
│   ├── onvifService.js     → WS-Discovery + device/stream URI lookup (onvif npm pkg)
│   ├── streamService.js    → ffmpeg process management (HLS streaming + MP4 recording)
│   └── motionService.js    → frame-diff motion detection loop (jpeg-js)
├── controllers/camera.controller.js
└── routes/camera.routes.js

backend/streams/<streamKey>/      → live HLS segments (auto-cleaned on stop)
backend/recordings/<streamKey>/   → recorded MP4 clips
backend/recordings/_alerts/       → motion snapshot JPEGs
```

Static files are served at:
- `http://localhost:5000/streams/<streamKey>/index.m3u8`
- `http://localhost:5000/recordings/<streamKey>/<file>.mp4`
- `http://localhost:5000/recordings/_alerts/<file>.jpg`

---

## 🔧 Setup Requirements

### 1. Install ffmpeg
```bash
# Ubuntu/Debian
sudo apt install ffmpeg

# macOS
brew install ffmpeg

# Verify
ffmpeg -version
```

### 2. Install backend dependencies
```bash
cd backend
npm install     # installs onvif + jpeg-js along with everything else
```

### 3. Network requirements
- Cameras, the backend server, and ONVIF discovery must be on the **same LAN/subnet**.
- ONVIF WS-Discovery uses UDP multicast (`239.255.255.250:3702`). If running the
  backend in Docker, use `--network host` (Linux) so multicast packets reach the host NIC.
- RTSP typically uses TCP port `554`. ONVIF management typically uses HTTP port `80` (or `8000`).

---

## 🎥 Adding Cameras

### Option A — ONVIF Auto Discovery (recommended)
1. Go to **Cameras → ONVIF Discover**
2. Enter the camera's username/password (most cameras ship with `admin` / a default password — change this!)
3. Click **Start Scan** (5-second WS-Discovery probe)
4. Click **Connect & Add** on any found device — the backend fetches the RTSP stream URI automatically

### Option B — Manual Add
Enter:
- **IP address** (e.g. `192.168.1.64`)
- **RTSP port** (default `554`)
- **Username / Password**
- **RTSP path** — varies by brand:
  | Brand | Typical RTSP path |
  |---|---|
  | Hikvision | `/Streaming/Channels/101` |
  | Dahua | `/cam/realmonitor?channel=1&subtype=0` |
  | CP Plus | `/cam/realmonitor?channel=1&subtype=0` |
  | Generic ONVIF | `/onvif1` or `/stream1` |

The full RTSP URL is auto-built as:
```
rtsp://<username>:<password>@<ip>:<port><rtspPath>
```

---

## 📡 Live Streaming Flow

1. User clicks **Play** on a camera tile.
2. `POST /api/cameras/:id/stream/start` spawns:
   ```bash
   ffmpeg -rtsp_transport tcp -i <rtspUrl> \
     -c:v libx264 -preset veryfast -tune zerolatency \
     -c:a aac -ac 1 \
     -f hls -hls_time 2 -hls_list_size 6 \
     -hls_flags delete_segments+append_list \
     streams/<streamKey>/index.m3u8
   ```
3. Frontend's `HlsPlayer` (using `hls.js`) loads `streams/<streamKey>/index.m3u8` and plays it.
4. Clicking **Stop** kills the ffmpeg process and cleans up segment files.

> **Latency:** ~2-4 seconds (HLS segment-based). For sub-second latency, a WebRTC
> gateway (e.g. MediaMTX) would be needed — out of scope for this module but the
> `streamService.js` interface can be swapped without touching the frontend.

---

## 🔴 Recording Flow

`POST /api/cameras/:id/recording/start` spawns:
```bash
ffmpeg -rtsp_transport tcp -i <rtspUrl> \
  -c:v copy -c:a aac \
  -f segment -segment_time 900 -segment_format mp4 \
  -reset_timestamps 1 -strftime 1 \
  recordings/<streamKey>/rec_%Y%m%d_%H%M%S.mp4
```
`-c:v copy` avoids re-encoding (low CPU) by copying the camera's native stream directly into MP4 containers.
Each 15-minute segment becomes a separate playable file.

---

## 🤖 AI Motion Detection Flow

Every `intervalMs` (default 5000ms) per watched camera:
1. Capture frame A (160×90 JPEG via ffmpeg)
2. Wait 700ms
3. Capture frame B
4. Decode both with `jpeg-js`, compute per-pixel luma delta
5. `% changed pixels > threshold` (derived from `motionSensitivity`, 0-100, lower = more sensitive)
6. On detection:
   - Save full-resolution snapshot to `/recordings/_alerts/`
   - Create a `MotionEvent` document (camera, timestamp, confidence, snapshot, zone)
   - If `recordingEnabled` and not already recording → start a 5-minute recording burst

**Tuning sensitivity:** use `POST /api/cameras/:id/motion/test` to see the live
`changePercent` for a camera and adjust the `motionSensitivity` slider in CCTV Settings accordingly.

> For higher accuracy (e.g. person detection, not just any pixel change), swap
> `motionService.checkMotion` for a TensorFlow.js `coco-ssd` model running on the
> same snapshots — the rest of the pipeline (events, recording triggers, UI) stays unchanged.

---

## 🔒 Security Notes

- Camera passwords are stored in MongoDB and **never** returned to the frontend (`password` stripped in all responses).
- For production, encrypt the `password` field at rest (e.g. via a KMS or `crypto` AES before save).
- Restrict `/streams` and `/recordings` static routes behind the same auth/lab-scoping as the API in production (currently served as plain static files for simplicity — consider a signed-URL proxy).
