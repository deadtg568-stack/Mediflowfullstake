import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'
import rateLimit from 'express-rate-limit'
import connectDB from './config/db.js'

// Routes
import authRoutes from './routes/auth.routes.js'
import labRoutes from './routes/lab.routes.js'
import patientRoutes from './routes/patient.routes.js'
import doctorRoutes from './routes/doctor.routes.js'
import testRoutes from './routes/test.routes.js'
import billingRoutes from './routes/billing.routes.js'
import reportRoutes from './routes/report.routes.js'
import staffRoutes from './routes/staff.routes.js'
import inventoryRoutes from './routes/inventory.routes.js'
import appointmentRoutes from './routes/appointment.routes.js'
import analyticsRoutes from './routes/analytics.routes.js'
import subscriptionRoutes from './routes/subscription.routes.js'
import superAdminRoutes from './routes/superadmin.routes.js'
// import cameraRoutes from './routes/camera.routes.js'
import outbreakRoutes from './routes/outbreak.routes.js'
import referralRoutes from './routes/referral.routes.js'
import gpsRoutes from './routes/gps.routes.js'
import { runDetection } from './services/outbreakService.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

dotenv.config()
connectDB()

const app = express()

// Security
app.use(helmet())
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? ['https://mediflowproai.com']
    : ['http://localhost:5173', 'http://localhost:3000'],
  credentials: true
}))

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 })
app.use('/api/', limiter)

// Body parsing
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))
app.use(morgan('dev'))

// Static serving for HLS live streams and recorded clips/snapshots
// (CCTV module: streams/<streamKey>/index.m3u8, recordings/<streamKey>/*.mp4)
app.use('/streams', express.static(path.join(__dirname, '../streams')))
app.use('/recordings', express.static(path.join(__dirname, '../recordings')))

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'MediFlow Pro AI API is running',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  })
})

// API Routes
app.use('/api/auth',          authRoutes)
app.use('/api/superadmin',    superAdminRoutes)
app.use('/api/labs',          labRoutes)
app.use('/api/patients',      patientRoutes)
app.use('/api/doctors',       doctorRoutes)
app.use('/api/tests',         testRoutes)
app.use('/api/billing',       billingRoutes)
app.use('/api/reports',       reportRoutes)
app.use('/api/staff',         staffRoutes)
app.use('/api/inventory',     inventoryRoutes)
app.use('/api/appointments',  appointmentRoutes)
app.use('/api/analytics',     analyticsRoutes)
app.use('/api/subscriptions', subscriptionRoutes)
// app.use('/api/cameras', cameraRoutes)
app.use('/api/outbreak',      outbreakRoutes)
app.use('/api/referral',      referralRoutes)
app.use('/api/gps',           gpsRoutes)

// 404
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` })
})

// Global error handler
app.use((err, req, res, next) => {
  console.error(`❌ [${req.method}] ${req.originalUrl}:`, err.message)
  if (process.env.NODE_ENV === 'development') console.error(err.stack)

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map(e => e.message).join(', ')
    return res.status(400).json({ success: false, message: `Validation error: ${messages}` })
  }
  // Mongoose duplicate key
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || 'field'
    return res.status(400).json({ success: false, message: `${field} already exists` })
  }
  // Mongoose cast error (invalid ObjectId)
  if (err.name === 'CastError') {
    return res.status(400).json({ success: false, message: `Invalid ${err.path}: ${err.value}` })
  }

  res.status(err.statusCode || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
  })
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`🚀 MediFlow API running on http://localhost:${PORT}`)

  // Outbreak Radar: run spike-detection every 6 hours, plus once on boot
  // (after a short delay so the DB connection is ready).
  setTimeout(() => {
    runDetection()
      .then(alerts => console.log(`🦠 Outbreak Radar: ${alerts.length} active alert(s)`))
      .catch(err => console.error('🦠 Outbreak Radar detection failed:', err.message))
  }, 5000)

  setInterval(() => {
    runDetection().catch(err => console.error('🦠 Outbreak Radar detection failed:', err.message))
  }, 6 * 60 * 60 * 1000)
})

export default app
// import cameraRoutes from './routes/camera.routes.js'
// app.use('/api/cameras', cameraRoutes)