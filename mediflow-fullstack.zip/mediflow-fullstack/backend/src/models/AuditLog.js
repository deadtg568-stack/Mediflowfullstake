import mongoose from 'mongoose'

const { Schema } = mongoose

/**
 * AuditLog — immutable record of significant platform events.
 * Used by Super Admin to monitor all lab activity.
 */
const auditLogSchema = new Schema({
  // Who performed the action
  actor:     { type: Schema.Types.ObjectId, ref: 'User', required: true },
  actorRole: { type: String, enum: ['superadmin', 'labadmin', 'technician', 'reception', 'doctor', 'patient'] },
  lab:       { type: Schema.Types.ObjectId, ref: 'Lab' },

  // What action was performed
  action:    { type: String, required: true },   // e.g. 'patient.create', 'billing.pay', 'user.login', 'report.verify'
  resource:  { type: String },                     // e.g. 'Patient', 'Bill', 'User'
  resourceId:{ type: String },                     // doc ID or invoice number

  // Context
  details:   { type: Schema.Types.Mixed },         // free-form extra info
  ip:        { type: String },
  userAgent: { type: String },
  success:   { type: Boolean, default: true },
}, {
  timestamps: true,
  // TTL: logs older than 90 days are auto-deleted (MongoDB TTL index)
})

auditLogSchema.index({ createdAt: -1 })
auditLogSchema.index({ lab: 1, createdAt: -1 })
auditLogSchema.index({ action: 1, createdAt: -1 })
auditLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 90 * 24 * 60 * 60 }) // 90 day TTL

const AuditLog = mongoose.model('AuditLog', auditLogSchema)
export default AuditLog
