import mongoose from 'mongoose'
import bcrypt from 'bcryptjs'

const { Schema } = mongoose

// ─── LAB ─────────────────────────────────────────────────────────────────────
const labSchema = new Schema({
  name:         { type: String, required: true },
  ownerName:    { type: String, required: true },
  phone:        { type: String, required: true, unique: true },
  email:        { type: String },
  address:      { type: String },
  city:         { type: String },
  state:        { type: String },
  gstin:        { type: String },
  logo:         { type: String },
  licenseKey:   { type: String, unique: true },
  plan:         { type: String, enum: ['starter', 'professional', 'enterprise'], default: 'starter' },
  status:       { type: String, enum: ['active', 'expired', 'suspended'], default: 'active' },
  subscriptionStart: { type: Date, default: Date.now },
  subscriptionEnd:   { type: Date },
  settings: {
    reportHeader:       { type: String },
    reportFooter:       { type: String },
    showDrSignature:    { type: Boolean, default: true },
    autoWhatsApp:       { type: Boolean, default: false },
    // Print Page Branding
    printLogo:          { type: String },   // base64 or URL
    printLabName:       { type: String },
    printTagline:       { type: String },
    printAddress:       { type: String },
    printPhone:         { type: String },
    printEmail:         { type: String },
    printWebsite:       { type: String },
    printGstin:         { type: String },
    printRegNo:         { type: String },   // lab registration number
    printAccreditation: { type: String },   // e.g. NABL, CAP, ISO
    printHeader:        { type: String },   // free HTML/text above tests
    printFooter:        { type: String },   // free HTML/text below tests
    printShowBarcode:   { type: Boolean, default: true },
    printShowQR:        { type: Boolean, default: true },
    printShowDrSign:    { type: Boolean, default: true },
    printShowLabSign:   { type: Boolean, default: true },
    printSignatoryName: { type: String },   // e.g. "Dr. Ramesh Gupta, MD Path"
    printSignatoryQual: { type: String },   // e.g. "MBBS, MD (Pathology)"
    printBorderStyle:   { type: String, default: 'classic' }, // classic | modern | minimal
    printAccentColor:   { type: String, default: '#16a34a' },
    printFontSize:      { type: String, default: 'medium' }, // small | medium | large
    printWatermark:     { type: String },   // e.g. "CONFIDENTIAL" or blank
    printCopies:        { type: Number, default: 1 },
    printShowPatientPhoto: { type: Boolean, default: false },
  }
}, { timestamps: true })

// ─── USER ─────────────────────────────────────────────────────────────────────
const userSchema = new Schema({
  name:     { type: String, required: true },
  phone:    { type: String, required: true },
  email:    { type: String },
  password: { type: String },
  role:     { type: String, enum: ['superadmin', 'labadmin', 'technician', 'reception', 'doctor', 'patient'], required: true },
  lab:      { type: Schema.Types.ObjectId, ref: 'Lab' },
  isActive: { type: Boolean, default: true },
  otp:      { type: String },
  otpExpiry:{ type: Date },
  lastLogin:{ type: Date },
}, { timestamps: true })

userSchema.pre('save', async function (next) {
  if (this.password && this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 10)
  }
  next()
})

userSchema.methods.matchPassword = async function (entered) {
  return bcrypt.compare(entered, this.password)
}

// ─── PATIENT ──────────────────────────────────────────────────────────────────
const patientSchema = new Schema({
  lab:          { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  patientId:    { type: String, unique: true },
  name:         { type: String, required: true },
  phone:        { type: String, required: true },
  email:        { type: String },
  age:          { type: Number },
  dob:          { type: Date },
  gender:       { type: String, enum: ['male', 'female', 'other'] },
  address:      { type: String },
  referredBy:   { type: Schema.Types.ObjectId, ref: 'Doctor' },
  bloodGroup:   { type: String },
  totalVisits:  { type: Number, default: 0 },
}, { timestamps: true })

patientSchema.pre('save', async function (next) {
  if (!this.patientId) {
    const count = await mongoose.model('Patient').countDocuments({ lab: this.lab })
    this.patientId = `P${String(count + 1).padStart(4, '0')}`
  }
  next()
})

// ─── DOCTOR ───────────────────────────────────────────────────────────────────
const doctorSchema = new Schema({
  lab:          { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  name:         { type: String, required: true },
  phone:        { type: String, required: true },
  email:        { type: String },
  speciality:   { type: String },
  qualification:{ type: String },
  regNumber:    { type: String },
  commission:   { type: Number, default: 0 },
  isActive:     { type: Boolean, default: true },
}, { timestamps: true })

// ─── TEST ─────────────────────────────────────────────────────────────────────
const testSchema = new Schema({
  lab:          { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  name:         { type: String, required: true },
  code:         { type: String },
  category:     { type: String },
  price:        { type: Number, required: true },
  tat:          { type: String },
  sampleType:   { type: String },
  unit:         { type: String },
  normalRange:  { type: String },
  method:       { type: String },
  isActive:     { type: Boolean, default: true },
  // Outbreak Radar: which infectious disease this test indicates (auto-detected
  // from name if not set — see outbreakService.DISEASE_KEYWORDS)
  diseaseTag:   { type: String },
  parameters: [{
    name:        String,
    unit:        String,
    normalRange: String,
    method:      String,
  }]
}, { timestamps: true })

testSchema.pre('save', function (next) {
  if (!this.diseaseTag && this.isModified('name')) {
    this.diseaseTag = inferDiseaseTag(this.name)
  }
  next()
})

// Keyword map used to auto-tag tests for the Outbreak Radar module.
// Exported so the outbreak service & seed script can reuse it.
export const DISEASE_KEYWORDS = {
  Dengue:        ['dengue', 'ns1'],
  Malaria:       ['malaria', 'mp smear', 'malarial parasite', 'pf/pv'],
  Typhoid:       ['typhoid', 'widal', 'salmonella'],
  Chikungunya:   ['chikungunya'],
  'COVID-19':    ['covid', 'sars-cov-2', 'rt-pcr'],
  Influenza:     ['influenza', 'h1n1', 'flu'],
  Leptospirosis: ['leptospira', 'leptospirosis'],
  'Hepatitis A': ['hepatitis a', 'hav'],
  Gastroenteritis: ['stool routine', 'rotavirus', 'norovirus'],
  'Viral Fever': ['cbc', 'crp', 'esr'], // used only as a loose fallback signal
}

export function inferDiseaseTag(testName = '') {
  const lower = testName.toLowerCase()
  for (const [disease, keywords] of Object.entries(DISEASE_KEYWORDS)) {
    if (disease === 'Viral Fever') continue // never auto-tag the loose fallback
    if (keywords.some(k => lower.includes(k))) return disease
  }
  return null
}

// ─── BILL ─────────────────────────────────────────────────────────────────────
const billSchema = new Schema({
  lab:          { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  invoiceNo:    { type: String, unique: true },
  patient:      { type: Schema.Types.ObjectId, ref: 'Patient', required: true },
  referredBy:   { type: Schema.Types.ObjectId, ref: 'Doctor' },
  tests: [{
    test:       { type: Schema.Types.ObjectId, ref: 'Test' },
    testName:   String,
    price:      Number,
    discount:   { type: Number, default: 0 },
  }],
  subtotal:     { type: Number, default: 0 },
  discount:     { type: Number, default: 0 },
  gstPercent:   { type: Number, default: 0 },
  gstAmount:    { type: Number, default: 0 },
  totalAmount:  { type: Number, required: true },
  paidAmount:   { type: Number, default: 0 },
  dueAmount:    { type: Number, default: 0 },
  paymentMode:  { type: String, enum: ['cash', 'upi', 'card', 'online', 'credit'], default: 'cash' },
  paymentStatus:{ type: String, enum: ['paid', 'partial', 'unpaid', 'voided'], default: 'unpaid' },
  collectionType:{ type: String, enum: ['walkin', 'appointment', 'home'], default: 'walkin' },
  notes:        { type: String },
  createdBy:    { type: Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true })

billSchema.pre('save', async function (next) {
  if (!this.invoiceNo) {
    const count = await mongoose.model('Bill').countDocuments({ lab: this.lab })
    const year = new Date().getFullYear()
    this.invoiceNo = `INV-${year}-${String(count + 1).padStart(5, '0')}`
  }
  this.dueAmount = this.totalAmount - this.paidAmount
  next()
})

// ─── REPORT ───────────────────────────────────────────────────────────────────
const reportSchema = new Schema({
  lab:          { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  bill:         { type: Schema.Types.ObjectId, ref: 'Bill', required: true },
  patient:      { type: Schema.Types.ObjectId, ref: 'Patient', required: true },
  test:         { type: Schema.Types.ObjectId, ref: 'Test', required: true },
  testName:     { type: String },
  sampleId:     { type: String },
  barcode:      { type: String },
  collectedAt:  { type: Date, default: Date.now },
  collectedBy:  { type: Schema.Types.ObjectId, ref: 'User' },
  verifiedBy:   { type: Schema.Types.ObjectId, ref: 'User' },
  status:       { type: String, enum: ['pending', 'collected', 'processing', 'verification', 'completed'], default: 'pending' },
  results: [{
    parameter:  String,
    value:      String,
    unit:       String,
    normalRange:String,
    flag:       { type: String, enum: ['normal', 'high', 'low', 'critical'], default: 'normal' },
  }],
  remarks:      { type: String },
  pdfUrl:       { type: String },
  qrCode:       { type: String },
  reportedAt:   { type: Date },
  verifiedAt:   { type: Date },
}, { timestamps: true })

// ─── STAFF ────────────────────────────────────────────────────────────────────
const staffSchema = new Schema({
  lab:      { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  user:     { type: Schema.Types.ObjectId, ref: 'User' },
  name:     { type: String, required: true },
  phone:    { type: String, required: true },
  role:     { type: String, enum: ['technician', 'reception', 'accountant', 'helper'], required: true },
  shift:    { type: String, enum: ['morning', 'evening', 'night'], default: 'morning' },
  salary:   { type: Number },
  joinDate: { type: Date, default: Date.now },
  isActive: { type: Boolean, default: true },
}, { timestamps: true })

// ─── INVENTORY ────────────────────────────────────────────────────────────────
const inventorySchema = new Schema({
  lab:       { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  name:      { type: String, required: true },
  category:  { type: String, enum: ['reagents', 'consumables', 'equipment', 'other'], default: 'consumables' },
  stock:     { type: Number, default: 0 },
  minStock:  { type: Number, default: 10 },
  unit:      { type: String },
  expiryDate:{ type: Date },
  vendor:    { type: String },
  costPrice: { type: Number },
  batchNo:   { type: String },
}, { timestamps: true })

// ─── APPOINTMENT ──────────────────────────────────────────────────────────────
const appointmentSchema = new Schema({
  lab:          { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  patient:      { type: Schema.Types.ObjectId, ref: 'Patient', required: true },
  tests:        [{ type: Schema.Types.ObjectId, ref: 'Test' }],
  scheduledAt:  { type: Date, required: true },
  type:         { type: String, enum: ['walkin', 'appointment', 'home'], default: 'walkin' },
  address:      { type: String },
  assignedTo:   { type: Schema.Types.ObjectId, ref: 'User' },
  status:       { type: String, enum: ['scheduled', 'confirmed', 'completed', 'cancelled'], default: 'scheduled' },
  notes:        { type: String },
  tokenNo:      { type: Number },
  createdBy:    { type: Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true })

// ─── EXPENSE ──────────────────────────────────────────────────────────────────
const expenseSchema = new Schema({
  lab:         { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  category:    { type: String, enum: ['salary', 'inventory', 'utilities', 'maintenance', 'rent', 'other'], required: true },
  description: { type: String, required: true },
  amount:      { type: Number, required: true },
  date:        { type: Date, default: Date.now },
  paidBy:      { type: String },
  receipt:     { type: String },
  createdBy:   { type: Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true })

// ─── CAMERA ───────────────────────────────────────────────────────────────────
const cameraSchema = new Schema({
  lab:          { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  name:         { type: String, required: true },          // e.g. "Reception Area"
  location:     { type: String },                            // free text zone label
  brand:        { type: String },                            // e.g. Hikvision, Dahua
  model:        { type: String },
  ip:           { type: String, required: true },
  port:         { type: Number, default: 554 },
  onvifPort:    { type: Number, default: 80 },
  username:     { type: String },
  password:     { type: String },                            // stored encrypted in production
  rtspPath:     { type: String, default: '/Streaming/Channels/101' },
  rtspUrl:      { type: String },                            // full constructed/discovered RTSP URL
  manufacturer: { type: String },
  hardwareId:   { type: String },
  status:       { type: String, enum: ['online', 'offline', 'error'], default: 'offline' },
  lastSeen:     { type: Date },
  recordingEnabled: { type: Boolean, default: false },
  motionDetectionEnabled: { type: Boolean, default: true },
  motionSensitivity: { type: Number, default: 25 }, // 0-100, lower = more sensitive
  streamKey:    { type: String },  // unique key used for HLS folder/segment naming
  addedVia:     { type: String, enum: ['manual', 'onvif'], default: 'manual' },
}, { timestamps: true })

cameraSchema.pre('save', function (next) {
  if (!this.streamKey) {
    this.streamKey = `cam_${this._id || new mongoose.Types.ObjectId()}_${Date.now()}`
  }
  if (!this.rtspUrl && this.ip) {
    const auth = this.username ? `${this.username}:${this.password || ''}@` : ''
    this.rtspUrl = `rtsp://${auth}${this.ip}:${this.port}${this.rtspPath}`
  }
  next()
})

// ─── RECORDING ────────────────────────────────────────────────────────────────
const recordingSchema = new Schema({
  lab:        { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  camera:     { type: Schema.Types.ObjectId, ref: 'Camera', required: true },
  filename:   { type: String, required: true },
  filepath:   { type: String, required: true },
  startTime:  { type: Date, required: true },
  endTime:    { type: Date },
  duration:   { type: Number },  // seconds
  fileSize:   { type: Number },  // bytes
  triggeredBy:{ type: String, enum: ['scheduled', 'motion', 'manual'], default: 'scheduled' },
  status:     { type: String, enum: ['recording', 'completed', 'failed'], default: 'recording' },
  thumbnail:  { type: String },
}, { timestamps: true })

// ─── MOTION EVENT ─────────────────────────────────────────────────────────────
const motionEventSchema = new Schema({
  lab:        { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  camera:     { type: Schema.Types.ObjectId, ref: 'Camera', required: true },
  detectedAt: { type: Date, default: Date.now },
  confidence: { type: Number },         // 0-100
  snapshot:   { type: String },          // path/url to snapshot image
  recording:  { type: Schema.Types.ObjectId, ref: 'Recording' },
  reviewed:   { type: Boolean, default: false },
  zone:       { type: String },          // e.g. "Sample Storage"
}, { timestamps: true })

// ─── OUTBREAK SIGNAL ──────────────────────────────────────────────────────────
// One row per (disease, city, day) — a privacy-safe aggregate count.
// No patient identifiers are stored here, only an anonymized tally.
const outbreakSignalSchema = new Schema({
  disease:   { type: String, required: true, index: true },
  city:      { type: String, required: true, index: true },
  state:     { type: String },
  date:      { type: Date, required: true, index: true }, // truncated to start-of-day
  testCount: { type: Number, default: 0 },                  // tests ordered that day
  labIds:    [{ type: Schema.Types.ObjectId, ref: 'Lab' }],  // contributing labs (for labCount)
}, { timestamps: true })

outbreakSignalSchema.index({ disease: 1, city: 1, date: 1 }, { unique: true })

// ─── OUTBREAK ALERT ───────────────────────────────────────────────────────────
// Generated by outbreakService.runDetection() when a city/disease combo shows
// a statistically significant spike vs its rolling baseline.
const outbreakAlertSchema = new Schema({
  disease:         { type: String, required: true },
  city:            { type: String, required: true },
  state:           { type: String },
  severity:        { type: String, enum: ['watch', 'warning', 'critical'], default: 'watch' },
  currentCount:    { type: Number, required: true },  // tests in current 7-day window
  baselineAvg:     { type: Number, required: true },  // avg weekly count from prior weeks
  percentChange:   { type: Number, required: true },
  labCount:        { type: Number, default: 0 },      // distinct labs reporting in window
  windowStart:     { type: Date, required: true },
  windowEnd:       { type: Date, required: true },
  status:          { type: String, enum: ['active', 'resolved'], default: 'active' },
  message:         { type: String },
  recommendation:  { type: String },
}, { timestamps: true })

outbreakAlertSchema.index({ disease: 1, city: 1, status: 1 })

export const Lab          = mongoose.model('Lab', labSchema)
export const User         = mongoose.model('User', userSchema)
export const Patient      = mongoose.model('Patient', patientSchema)
export const Doctor       = mongoose.model('Doctor', doctorSchema)
export const Test         = mongoose.model('Test', testSchema)
export const Bill         = mongoose.model('Bill', billSchema)
export const Report       = mongoose.model('Report', reportSchema)
export const Staff        = mongoose.model('Staff', staffSchema)
export const Inventory    = mongoose.model('Inventory', inventorySchema)
export const Appointment  = mongoose.model('Appointment', appointmentSchema)
export const Expense      = mongoose.model('Expense', expenseSchema)
export const Camera       = mongoose.model('Camera', cameraSchema)
export const Recording    = mongoose.model('Recording', recordingSchema)
export const MotionEvent  = mongoose.model('MotionEvent', motionEventSchema)
export const OutbreakSignal = mongoose.model('OutbreakSignal', outbreakSignalSchema)
export const OutbreakAlert  = mongoose.model('OutbreakAlert', outbreakAlertSchema)

// ─── PARTNER REFERRAL SYSTEM ──────────────────────────────────────────────────

// Partner: koi bhi jo labs refer karta hai (doctor, agent, existing lab owner)
const partnerSchema = new Schema({
  name:         { type: String, required: true },
  phone:        { type: String, required: true, unique: true },
  email:        { type: String },
  type:         { type: String, enum: ['doctor', 'agent', 'lab_owner', 'other'], default: 'other' },
  referralCode: { type: String, unique: true, required: true },
  // Partner ke wallet mein kitna credit hai (approved referrals se)
  walletBalance: { type: Number, default: 0 },
  // Total lifetime earnings
  totalEarned:   { type: Number, default: 0 },
  // Total labs referred (active)
  totalReferrals: { type: Number, default: 0 },
  status:       { type: String, enum: ['active', 'inactive', 'suspended'], default: 'active' },
  bankName:     { type: String },
  accountNo:    { type: String },
  ifsc:         { type: String },
  upiId:        { type: String },
  notes:        { type: String },
  createdBy:    { type: Schema.Types.ObjectId, ref: 'User' }, // superadmin who added
}, { timestamps: true })

// ReferralLog: Ek lab ka referral track
const referralLogSchema = new Schema({
  partner:        { type: Schema.Types.ObjectId, ref: 'Partner', required: true },
  referralCode:   { type: String, required: true },
  // Lab jo register hui referral se
  lab:            { type: Schema.Types.ObjectId, ref: 'Lab' },
  labName:        { type: String },
  labPhone:       { type: String },
  plan:           { type: String, enum: ['starter', 'professional', 'enterprise'] },
  // Subscription amount jo lab ne pay kiya
  subscriptionAmount: { type: Number, default: 0 },
  // Commission: 50% of subscription
  commissionAmount:   { type: Number, default: 0 },
  commissionPercent:  { type: Number, default: 50 },
  // Status flow: pending → verified → approved → paid
  status: {
    type: String,
    enum: ['pending', 'verified', 'approved', 'paid', 'rejected'],
    default: 'pending'
  },
  // Reward type: credit to next subscription OR cash payout
  rewardType: { type: String, enum: ['subscription_discount', 'cash'], default: 'cash' },
  // When super admin approved/rejected
  approvedAt:  { type: Date },
  approvedBy:  { type: Schema.Types.ObjectId, ref: 'User' },
  rejectedAt:  { type: Date },
  rejectedBy:  { type: Schema.Types.ObjectId, ref: 'User' },
  rejectionReason: { type: String },
  // When payment was made to partner
  paidAt:      { type: Date },
  paidBy:      { type: Schema.Types.ObjectId, ref: 'User' },
  paymentMode: { type: String, enum: ['bank', 'upi', 'cash', 'wallet'], default: 'bank' },
  paymentRef:  { type: String }, // transaction ID / reference
  notes:       { type: String },
}, { timestamps: true })

// Wallet Transaction: partner wallet ka ledger
const walletTxSchema = new Schema({
  partner:     { type: Schema.Types.ObjectId, ref: 'Partner', required: true },
  type:        { type: String, enum: ['credit', 'debit'], required: true },
  amount:      { type: Number, required: true },
  balance:     { type: Number, required: true }, // balance after this tx
  description: { type: String },
  referralLog: { type: Schema.Types.ObjectId, ref: 'ReferralLog' },
  createdBy:   { type: Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true })

export const Partner      = mongoose.model('Partner', partnerSchema)
export const ReferralLog  = mongoose.model('ReferralLog', referralLogSchema)
export const WalletTx     = mongoose.model('WalletTx', walletTxSchema)
