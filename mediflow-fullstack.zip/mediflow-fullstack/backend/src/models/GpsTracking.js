import mongoose from 'mongoose'

const { Schema } = mongoose

// ─── GPS TRACKING SESSION ─────────────────────────────────────────────────────
// Created when a technician starts a home collection trip.
// Stores current location, destination, and a rolling history of location pings.
const gpsTrackingSchema = new Schema({
  lab:           { type: Schema.Types.ObjectId, ref: 'Lab', required: true },
  technician:    { type: Schema.Types.ObjectId, ref: 'User', required: true },
  appointment:   { type: Schema.Types.ObjectId, ref: 'Appointment' },
  patientName:   { type: String },
  patientPhone:  { type: String },
  patientAddress:{ type: String },
  // Destination coordinates (geocoded from address or manually set)
  destination: {
    lat: { type: Number },
    lng: { type: Number },
  },
  status: {
    type: String,
    enum: ['en_route', 'at_location', 'collecting', 'completed', 'cancelled'],
    default: 'en_route',
  },
  startedAt:  { type: Date, default: Date.now },
  completedAt:{ type: Date },
  // Current live location of the technician
  currentLocation: {
    lat: { type: Number },
    lng: { type: Number },
    accuracy: { type: Number },
    heading:  { type: Number },
    speed:    { type: Number },
    updatedAt:{ type: Date },
  },
}, { timestamps: true })

gpsTrackingSchema.index({ lab: 1, status: 1 })
gpsTrackingSchema.index({ technician: 1, status: 1 })

// ─── GPS LOCATION LOG ─────────────────────────────────────────────────────────
// Append-only log of every location ping — used for route replay & analytics.
const gpsLocationLogSchema = new Schema({
  tracking: { type: Schema.Types.ObjectId, ref: 'GpsTracking', required: true, index: true },
  lat:      { type: Number, required: true },
  lng:      { type: Number, required: true },
  accuracy: { type: Number },
  heading:  { type: Number },
  speed:    { type: Number },
  timestamp:{ type: Date, default: Date.now },
})

gpsLocationLogSchema.index({ tracking: 1, timestamp: 1 })

export const GpsTracking   = mongoose.model('GpsTracking', gpsTrackingSchema)
export const GpsLocationLog = mongoose.model('GpsLocationLog', gpsLocationLogSchema)
