/**
 * Reusable pagination helper for Mongoose queries.
 *
 * Usage:
 *   const result = await paginate(Patient.find({ lab }), req.query)
 *   res.json({ success: true, data: { ...result } })
 *
 * Query params supported:
 *   page, limit, sort, search (passed through to searchFields)
 */
export default async function paginate(query, { page, limit, sort, search, searchFields } = {}) {
  const pageNum   = Math.max(1, parseInt(page) || 1)
  const limitNum  = Math.min(100, Math.max(1, parseInt(limit) || 20))
  const skip      = (pageNum - 1) * limitNum

  // Parse sort string (e.g. "-createdAt,name" -> { createdAt: -1, name: 1 })
  let sortObj = { createdAt: -1 }
  if (sort) {
    sortObj = {}
    sort.split(',').forEach(field => {
      const trimmed = field.trim()
      if (trimmed.startsWith('-')) sortObj[trimmed.slice(1)] = -1
      else sortObj[trimmed] = 1
    })
  }

  // Text search across specified fields (simple regex, not text index)
  if (search && Array.isArray(searchFields) && searchFields.length > 0) {
    const escaped = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    query = query.or(searchFields.map(f => ({ [f]: { $regex: escaped, $options: 'i' } })))
  }

  const [data, total] = await Promise.all([
    query.sort(sortObj).skip(skip).limit(limitNum),
    query.model.countDocuments(query.getFilter()),
  ])

  return {
    data,
    pagination: {
      page: pageNum,
      limit: limitNum,
      total,
      pages: Math.ceil(total / limitNum),
      hasNext: pageNum * limitNum < total,
      hasPrev: pageNum > 1,
    },
  }
}
