import mongoose from 'mongoose'
import dotenv from 'dotenv'
import { Lab, User, Patient, Doctor, Test, Inventory, OutbreakSignal, OutbreakAlert } from '../models/index.js'
import { runDetection } from '../services/outbreakService.js'

dotenv.config()

// ─── 150+ TESTS ─────────────────────────────────────────────────────────────
const ALL_TESTS = [
  // ── HAEMATOLOGY (18) ──────────────────────────────────────────────────────
  { name: 'Complete Blood Count (CBC)', code: 'CBC', category: 'Haematology', price: 350, tat: '4 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Haemoglobin (Hb)', code: 'HB', category: 'Haematology', price: 120, tat: '1 hr', sampleType: 'Blood-EDTA' },
  { name: 'Erythrocyte Sedimentation Rate (ESR)', code: 'ESR', category: 'Haematology', price: 100, tat: '1 hr', sampleType: 'Blood-ESR' },
  { name: 'Total Leucocyte Count (TLC)', code: 'TLC', category: 'Haematology', price: 120, tat: '2 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Differential Leucocyte Count (DLC)', code: 'DLC', category: 'Haematology', price: 150, tat: '2 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Platelet Count', code: 'PLT', category: 'Haematology', price: 120, tat: '2 hrs', sampleType: 'Blood-EDTA' },
  { name: 'RBC Count', code: 'RBC', category: 'Haematology', price: 100, tat: '2 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Peripheral Blood Smear', code: 'PBS', category: 'Haematology', price: 250, tat: '4 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Reticulocyte Count', code: 'RETIC', category: 'Haematology', price: 300, tat: '4 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Iron Studies (Fe + TIBC)', code: 'IRON', category: 'Haematology', price: 400, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Ferritin', code: 'FERR', category: 'Haematology', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Folate', code: 'FOL', category: 'Haematology', price: 600, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Vitamin B12', code: 'B12', category: 'Haematology', price: 650, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Hemoglobin Electrophoresis', code: 'HBE', category: 'Haematology', price: 800, tat: '24 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Platelet Function Test (PFT)', code: 'PFT', category: 'Haematology', price: 500, tat: '4 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'Bleeding Time (BT)', code: 'BT', category: 'Haematology', price: 100, tat: '30 min', sampleType: 'Blood-EDTA' },
  { name: 'Clotting Time (CT)', code: 'CT', category: 'Haematology', price: 100, tat: '30 min', sampleType: 'Blood-EDTA' },
  { name: 'Bone Marrow Aspiration & Biopsy', code: 'BMA', category: 'Haematology', price: 3500, tat: '48 hrs', sampleType: 'Bone Marrow' },

  // ── COAGULATION (8) ───────────────────────────────────────────────────────
  { name: 'Prothrombin Time (PT)', code: 'PT', category: 'Coagulation', price: 250, tat: '2 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'INR (International Normalized Ratio)', code: 'INR', category: 'Coagulation', price: 300, tat: '2 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'Activated Partial Thromboplastin Time (APTT)', code: 'APTT', category: 'Coagulation', price: 300, tat: '2 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'Fibrinogen', code: 'FIB', category: 'Coagulation', price: 400, tat: '3 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'D-Dimer', code: 'DDIM', category: 'Coagulation', price: 800, tat: '4 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'Thrombin Time (TT)', code: 'TT', category: 'Coagulation', price: 350, tat: '3 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'Protein C', code: 'PROC', category: 'Coagulation', price: 1200, tat: '24 hrs', sampleType: 'Blood-Sodium Citrate' },
  { name: 'Protein S', code: 'PROS', category: 'Coagulation', price: 1200, tat: '24 hrs', sampleType: 'Blood-Sodium Citrate' },

  // ── BIOCHEMISTRY (22) ─────────────────────────────────────────────────────
  { name: 'Blood Sugar Fasting (FBS)', code: 'FBS', category: 'Biochemistry', price: 120, tat: '2 hrs', sampleType: 'Blood-Fluoride' },
  { name: 'Blood Sugar Random (RBS)', code: 'RBS', category: 'Biochemistry', price: 120, tat: '1 hr', sampleType: 'Blood-Fluoride' },
  { name: 'Blood Sugar Postprandial (PPBS)', code: 'PPBS', category: 'Biochemistry', price: 120, tat: '2 hrs', sampleType: 'Blood-Fluoride' },
  { name: 'HbA1c (Glycated Haemoglobin)', code: 'HBA1C', category: 'Biochemistry', price: 500, tat: '4 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Oral Glucose Tolerance Test (OGTT)', code: 'OGTT', category: 'Biochemistry', price: 400, tat: '3 hrs', sampleType: 'Blood-Fluoride' },
  { name: 'Serum Insulin (Fasting)', code: 'INS', category: 'Biochemistry', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'C-Peptide', code: 'CPEP', category: 'Biochemistry', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Liver Function Test (LFT)', code: 'LFT', category: 'Biochemistry', price: 700, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Kidney Function Test (KFT)', code: 'KFT', category: 'Biochemistry', price: 500, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Creatinine', code: 'CREAT', category: 'Biochemistry', price: 150, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'Blood Urea Nitrogen (BUN)', code: 'BUN', category: 'Biochemistry', price: 150, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Uric Acid', code: 'UA', category: 'Biochemistry', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Electrolytes (Na/K/Cl)', code: 'ELYT', category: 'Biochemistry', price: 400, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Calcium', code: 'CA', category: 'Biochemistry', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Phosphorus', code: 'PHOS', category: 'Biochemistry', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Magnesium', code: 'MG', category: 'Biochemistry', price: 300, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Sodium (Na+)', code: 'NA', category: 'Biochemistry', price: 150, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Potassium (K+)', code: 'K', category: 'Biochemistry', price: 150, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'Total Bilirubin', code: 'TBIL', category: 'Biochemistry', price: 150, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Direct Bilirubin', code: 'DBIL', category: 'Biochemistry', price: 150, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Albumin', code: 'ALB', category: 'Biochemistry', price: 150, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Globulin', code: 'GLOB', category: 'Biochemistry', price: 150, tat: '3 hrs', sampleType: 'Blood-SST' },

  // ── LIPID PROFILE & CARDIAC MARKERS (12) ─────────────────────────────────
  { name: 'Lipid Profile', code: 'LP', category: 'Lipid Profile', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Total Cholesterol', code: 'CHOL', category: 'Lipid Profile', price: 150, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'HDL Cholesterol', code: 'HDL', category: 'Lipid Profile', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'LDL Cholesterol', code: 'LDL', category: 'Lipid Profile', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Triglycerides', code: 'TG', category: 'Lipid Profile', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'VLDL Cholesterol', code: 'VLDL', category: 'Lipid Profile', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'hs-CRP (High Sensitivity CRP)', code: 'HSCRP', category: 'Cardiac Markers', price: 600, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Troponin I (Cardiac)', code: 'TROP', category: 'Cardiac Markers', price: 1200, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'CK-MB (Creatine Kinase)', code: 'CKMB', category: 'Cardiac Markers', price: 600, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'NT-proBNP', code: 'BNP', category: 'Cardiac Markers', price: 1500, tat: '4 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Homocysteine', code: 'HOMOC', category: 'Cardiac Markers', price: 700, tat: '6 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Lp(a) - Lipoprotein(a)', code: 'LPA', category: 'Lipid Profile', price: 900, tat: '8 hrs', sampleType: 'Blood-SST' },

  // ── IMMUNOLOGY & SEROLOGY (16) ────────────────────────────────────────────
  { name: 'CRP (C-Reactive Protein)', code: 'CRP', category: 'Immunology', price: 450, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Rheumatoid Factor (RF)', code: 'RF', category: 'Immunology', price: 400, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Anti-Nuclear Antibody (ANA)', code: 'ANA', category: 'Immunology', price: 800, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Anti-dsDNA', code: 'DSDNA', category: 'Immunology', price: 900, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Complement C3', code: 'C3', category: 'Immunology', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Complement C4', code: 'C4', category: 'Immunology', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'ASO Titer (Anti-Streptolysin O)', code: 'ASO', category: 'Immunology', price: 350, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Immunoglobulin IgA', code: 'IGA', category: 'Immunology', price: 600, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Immunoglobulin IgG', code: 'IGG', category: 'Immunology', price: 600, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Immunoglobulin IgM', code: 'IGM', category: 'Immunology', price: 600, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Dengue NS1 Antigen', code: 'DNS1', category: 'Serology', price: 800, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Dengue IgM/IgG', code: 'DIGM', category: 'Serology', price: 900, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Malaria MP Smear', code: 'MPS', category: 'Microbiology', price: 200, tat: '2 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Typhoid Widal Test', code: 'WID', category: 'Serology', price: 350, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Chikungunya IgM', code: 'CHIK', category: 'Serology', price: 950, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'COVID-19 RT-PCR', code: 'CVPCR', category: 'Serology', price: 1200, tat: '12 hrs', sampleType: 'Nasal Swab' },

  // ── THYROID (6) ───────────────────────────────────────────────────────────
  { name: 'Thyroid Profile (T3,T4,TSH)', code: 'TFT', category: 'Thyroid', price: 850, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'TSH (Thyroid Stimulating Hormone)', code: 'TSH', category: 'Thyroid', price: 400, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Free T3 (FT3)', code: 'FT3', category: 'Thyroid', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Free T4 (FT4)', code: 'FT4', category: 'Thyroid', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Anti-TPO (Anti-Thyroid Peroxidase)', code: 'ATPO', category: 'Thyroid', price: 700, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Thyroglobulin (Tg)', code: 'TG', category: 'Thyroid', price: 800, tat: '24 hrs', sampleType: 'Blood-SST' },

  // ── HORMONES (14) ─────────────────────────────────────────────────────────
  { name: 'Testosterone (Total)', code: 'TESTO', category: 'Hormones', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Testosterone (Free)', code: 'FTESTO', category: 'Hormones', price: 900, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Estradiol (E2)', code: 'E2', category: 'Hormones', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Progesterone', code: 'PROG', category: 'Hormones', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'FSH (Follicle Stimulating Hormone)', code: 'FSH', category: 'Hormones', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'LH (Luteinizing Hormone)', code: 'LH', category: 'Hormones', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Prolactin (PRL)', code: 'PRL', category: 'Hormones', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Cortisol (Morning)', code: 'CORT', category: 'Hormones', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'ACTH (Adrenocorticotropic Hormone)', code: 'ACTH', category: 'Hormones', price: 900, tat: '8 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Parathyroid Hormone (PTH)', code: 'PTH', category: 'Hormones', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Insulin-Like Growth Factor-1 (IGF-1)', code: 'IGF1', category: 'Hormones', price: 1000, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Human Chorionic Gonadotropin (hCG)', code: 'HCG', category: 'Hormones', price: 400, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Aldosterone', code: 'ALDO', category: 'Hormones', price: 1200, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'DHEA-S (Dehydroepiandrosterone)', code: 'DHEAS', category: 'Hormones', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },

  // ── LIVER (10) ────────────────────────────────────────────────────────────
  { name: 'Liver Function Test (LFT)', code: 'LFT2', category: 'Liver', price: 700, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'ALT (SGPT)', code: 'ALT', category: 'Liver', price: 150, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'AST (SGOT)', code: 'AST', category: 'Liver', price: 150, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'Alkaline Phosphatase (ALP)', code: 'ALP', category: 'Liver', price: 200, tat: '3 hrs', sampleType: 'Blood-SST' },
  { name: 'GGT (Gamma Glutamyl Transferase)', code: 'GGT', category: 'Liver', price: 300, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Protein Electrophoresis (SPE)', code: 'SPE', category: 'Liver', price: 1200, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Hepatitis B Surface Antigen (HBsAg)', code: 'HBSAG', category: 'Liver', price: 400, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Hepatitis C Antibody (Anti-HCV)', code: 'HCV', category: 'Liver', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Hepatitis A IgM (HAV IgM)', code: 'HAV', category: 'Liver', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Hepatitis E IgM (HEV IgM)', code: 'HEV', category: 'Liver', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },

  // ── KIDNEY (6) ────────────────────────────────────────────────────────────
  { name: 'Kidney Function Test (KFT)', code: 'KFT2', category: 'Kidney', price: 500, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Microalbumin Urine', code: 'MALB', category: 'Kidney', price: 400, tat: '6 hrs', sampleType: 'Urine-First' },
  { name: 'Urine Albumin-to-Creatinine Ratio (ACR)', code: 'ACR', category: 'Kidney', price: 500, tat: '6 hrs', sampleType: 'Urine-First' },
  { name: 'Cystatin C', code: 'CYSC', category: 'Kidney', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: '24-Hour Urine Protein', code: '24UP', category: 'Kidney', price: 300, tat: '24 hrs', sampleType: 'Urine-24hr' },
  { name: 'Urine Creatinine', code: 'UCR', category: 'Kidney', price: 150, tat: '3 hrs', sampleType: 'Urine-First' },

  // ── DIABETES (6) ──────────────────────────────────────────────────────────
  { name: 'Diabetes Panel (FBS+PPBS+HbA1c)', code: 'DMP', category: 'Diabetes', price: 800, tat: '6 hrs', sampleType: 'Blood-Fluoride' },
  { name: 'Fructosamine', code: 'FRUC', category: 'Diabetes', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Urine Glucose', code: 'UGLC', category: 'Diabetes', price: 80, tat: '30 min', sampleType: 'Urine-Fresh' },
  { name: 'Urine Ketones', code: 'UKET', category: 'Diabetes', price: 80, tat: '30 min', sampleType: 'Urine-Fresh' },
  { name: 'Anti-GAD65 Antibodies', code: 'GAD', category: 'Diabetes', price: 1500, tat: '48 hrs', sampleType: 'Blood-SST' },
  { name: 'Islet Cell Antibodies (ICA)', code: 'ICA', category: 'Diabetes', price: 1500, tat: '48 hrs', sampleType: 'Blood-SST' },

  // ── VITAMINS & TRACE ELEMENTS (8) ────────────────────────────────────────
  { name: 'Vitamin D (25-OH)', code: 'VITD', category: 'Vitamins', price: 1200, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Vitamin B12', code: 'VB12', category: 'Vitamins', price: 650, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Vitamin B9 (Folic Acid)', code: 'FOL2', category: 'Vitamins', price: 600, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Vitamin A (Retinol)', code: 'VITA', category: 'Vitamins', price: 900, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Vitamin E (Tocopherol)', code: 'VITE', category: 'Vitamins', price: 1000, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Zinc', code: 'ZN', category: 'Vitamins', price: 500, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Copper', code: 'CU', category: 'Vitamins', price: 500, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Lead (Blood)', code: 'PB', category: 'Vitamins', price: 800, tat: '24 hrs', sampleType: 'Blood-EDTA' },

  // ── URINE (12) ────────────────────────────────────────────────────────────
  { name: 'Urine Routine & Microscopy', code: 'URM', category: 'Urine', price: 250, tat: '2 hrs', sampleType: 'Urine-Fresh' },
  { name: 'Complete Urine Analysis (CUE)', code: 'CUE', category: 'Urine', price: 250, tat: '2 hrs', sampleType: 'Urine-Fresh' },
  { name: 'Urine Culture & Sensitivity', code: 'UCS', category: 'Urine', price: 600, tat: '48 hrs', sampleType: 'Urine-Midstream' },
  { name: 'Urine Pregnancy Test (UPT)', code: 'UPT', category: 'Urine', price: 100, tat: '30 min', sampleType: 'Urine-Fresh' },
  { name: 'Urine Protein', code: 'UPROT', category: 'Urine', price: 100, tat: '1 hr', sampleType: 'Urine-Fresh' },
  { name: 'Urine Bilirubin', code: 'UBIL', category: 'Urine', price: 100, tat: '1 hr', sampleType: 'Urine-Fresh' },
  { name: 'Urine Blood (Occult)', code: 'UBLD', category: 'Urine', price: 100, tat: '1 hr', sampleType: 'Urine-Fresh' },
  { name: 'Urine Nitrites', code: 'UNIT', category: 'Urine', price: 100, tat: '30 min', sampleType: 'Urine-Fresh' },
  { name: 'Urine Leucocyte Esterase', code: 'ULE', category: 'Urine', price: 100, tat: '30 min', sampleType: 'Urine-Fresh' },
  { name: '24-Hour Urine Volume', code: '24UV', category: 'Urine', price: 100, tat: '24 hrs', sampleType: 'Urine-24hr' },
  { name: 'Urine Calcium', code: 'UCA', category: 'Urine', price: 200, tat: '3 hrs', sampleType: 'Urine-24hr' },
  { name: 'Urine Uric Acid', code: 'UUA', category: 'Urine', price: 200, tat: '3 hrs', sampleType: 'Urine-24hr' },

  // ── MICROBIOLOGY (10) ─────────────────────────────────────────────────────
  { name: 'Blood Culture (Aerobic)', code: 'BCA', category: 'Microbiology', price: 600, tat: '48 hrs', sampleType: 'Blood-Bottle' },
  { name: 'Blood Culture (Anaerobic)', code: 'BCN', category: 'Microbiology', price: 600, tat: '72 hrs', sampleType: 'Blood-Bottle' },
  { name: 'Stool Routine & Microscopy', code: 'SRM', category: 'Microbiology', price: 250, tat: '4 hrs', sampleType: 'Stool' },
  { name: 'Stool Culture & Sensitivity', code: 'SCS', category: 'Microbiology', price: 600, tat: '72 hrs', sampleType: 'Stool' },
  { name: 'Throat Swab Culture', code: 'TSC', category: 'Microbiology', price: 500, tat: '48 hrs', sampleType: 'Throat Swab' },
  { name: 'Sputum Culture & Sensitivity', code: 'SPC', category: 'Microbiology', price: 500, tat: '48 hrs', sampleType: 'Sputum' },
  { name: 'AFB Smear (Acid Fast Bacilli)', code: 'AFB', category: 'Microbiology', price: 300, tat: '24 hrs', sampleType: 'Sputum' },
  { name: 'GeneXpert MTB/RIF', code: 'GXPT', category: 'Microbiology', price: 2500, tat: '24 hrs', sampleType: 'Sputum' },
  { name: 'Wound Swab Culture & Sensitivity', code: 'WSC', category: 'Microbiology', price: 500, tat: '48 hrs', sampleType: 'Wound Swab' },
  { name: 'Semen Analysis', code: 'SEM', category: 'Microbiology', price: 500, tat: '4 hrs', sampleType: 'Semen' },

  // ── ONCOLOGY MARKERS (14) ─────────────────────────────────────────────────
  { name: 'AFP (Alpha Feto Protein)', code: 'AFP', category: 'Oncology Markers', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'CEA (Carcinoembryonic Antigen)', code: 'CEA', category: 'Oncology Markers', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'CA 125 (Ovarian Marker)', code: 'CA125', category: 'Oncology Markers', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'CA 15-3 (Breast Marker)', code: 'CA153', category: 'Oncology Markers', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'CA 19-9 (Pancreatic Marker)', code: 'CA199', category: 'Oncology Markers', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'PSA (Prostate Specific Antigen)', code: 'PSA', category: 'Oncology Markers', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Free PSA', code: 'FPSA', category: 'Oncology Markers', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'CA 72-4 (Gastric Marker)', code: 'CA724', category: 'Oncology Markers', price: 900, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'SCC Antigen (Squamous Cell)', code: 'SCC', category: 'Oncology Markers', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'NSE (Neuron Specific Enolase)', code: 'NSE', category: 'Oncology Markers', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Cyfra 21-1', code: 'CYF211', category: 'Oncology Markers', price: 900, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'HCG (Tumor Marker)', code: 'HCGT', category: 'Oncology Markers', price: 400, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Ferritin (Tumor Marker)', code: 'FERTR', category: 'Oncology Markers', price: 500, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'ProGRP (Gastrin Releasing Peptide)', code: 'PGRP', category: 'Oncology Markers', price: 1200, tat: '24 hrs', sampleType: 'Blood-EDTA' },

  // ── CARDIAC RISK (6) ─────────────────────────────────────────────────────
  { name: 'Cardiac Risk Profile', code: 'CRP2', category: 'Cardiac Risk', price: 2500, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Apolipoprotein A1', code: 'APOA', category: 'Cardiac Risk', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Apolipoprotein B', code: 'APOB', category: 'Cardiac Risk', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Lp-PLA2 (Lipoprotein-Associated Phospholipase)', code: 'LPLA2', category: 'Cardiac Risk', price: 1500, tat: '24 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Myoglobin', code: 'MYO', category: 'Cardiac Markers', price: 600, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'hs-CRP + Lipid + Homocysteine Panel', code: 'CARP', category: 'Cardiac Risk', price: 1800, tat: '8 hrs', sampleType: 'Blood-SST' },

  // ── NUTRITION & DEFICIENCY (6) ────────────────────────────────────────────
  { name: 'Vitamin D + Calcium Panel', code: 'VDCA', category: 'Nutrition', price: 1400, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Complete Nutrition Panel (B12+D+Folate+Iron)', code: 'NUTP', category: 'Nutrition', price: 2200, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Transferrin', code: 'TRANS', category: 'Nutrition', price: 600, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Serum Prealbumin', code: 'PREAB', category: 'Nutrition', price: 800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Retinol Binding Protein (RBP)', code: 'RBP', category: 'Nutrition', price: 900, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Omega-3 Index', code: 'OM3', category: 'Nutrition', price: 2500, tat: '48 hrs', sampleType: 'Blood-EDTA' },

  // ── AUTOIMMUNE (6) ────────────────────────────────────────────────────────
  { name: 'Anti-CCP Antibodies', code: 'ACCP', category: 'Autoimmune', price: 900, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'ANCA (C-ANCA + P-ANCA)', code: 'ANCA', category: 'Autoimmune', price: 1200, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Anti-Phospholipid Antibodies (aCL)', code: 'APL', category: 'Autoimmune', price: 1000, tat: '48 hrs', sampleType: 'Blood-SST' },
  { name: 'Anti-Thyroglobulin Antibodies', code: 'ATG', category: 'Autoimmune', price: 600, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Anti-Mitochondrial Antibody (AMA)', code: 'AMA', category: 'Autoimmune', price: 800, tat: '24 hrs', sampleType: 'Blood-SST' },
  { name: 'Anti-Tissue Transglutaminase (tTG-IgA)', code: 'TTGA', category: 'Autoimmune', price: 800, tat: '24 hrs', sampleType: 'Blood-SST' },

  // ── INFECTIOUS DISEASE (8) ────────────────────────────────────────────────
  { name: 'HIV 1 & 2 Antibody', code: 'HIV', category: 'Infectious Disease', price: 500, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'HIV Viral Load (RNA PCR)', code: 'HIVVL', category: 'Infectious Disease', price: 3000, tat: '48 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Hepatitis B DNA (Quantitative)', code: 'HBDNA', category: 'Infectious Disease', price: 2500, tat: '48 hrs', sampleType: 'Blood-EDTA' },
  { name: 'Hepatitis C RNA (Qualitative)', code: 'HCRNA', category: 'Infectious Disease', price: 3000, tat: '48 hrs', sampleType: 'Blood-EDTA' },
  { name: 'VDRL (Syphilis)', code: 'VDRL', category: 'Infectious Disease', price: 200, tat: '2 hrs', sampleType: 'Blood-SST' },
  { name: 'TPHA (Treponema Pallidum)', code: 'TPHA', category: 'Infectious Disease', price: 400, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'IgM Measles', code: 'IGMME', category: 'Infectious Disease', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'IgM Rubella', code: 'IGMRU', category: 'Infectious Disease', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },

  // ── STOOL (6) ─────────────────────────────────────────────────────────────
  { name: 'Stool Routine Examination', code: 'SRE', category: 'Stool', price: 200, tat: '2 hrs', sampleType: 'Stool' },
  { name: 'Stool Occult Blood Test (OB)', code: 'OBT', category: 'Stool', price: 200, tat: '2 hrs', sampleType: 'Stool' },
  { name: 'Stool Reducing Substances', code: 'SRS', category: 'Stool', price: 200, tat: '2 hrs', sampleType: 'Stool' },
  { name: 'Stool Fat (Qualitative)', code: 'SFQ', category: 'Stool', price: 300, tat: '4 hrs', sampleType: 'Stool' },
  { name: 'Ova & Parasite Examination (O&P)', code: 'OP', category: 'Stool', price: 300, tat: '4 hrs', sampleType: 'Stool' },
  { name: 'Stool Calprotectin', code: 'SCAL', category: 'Stool', price: 1200, tat: '24 hrs', sampleType: 'Stool' },

  // ── CHEMISTRY PANELS (6) ──────────────────────────────────────────────────
  { name: 'Comprehensive Metabolic Panel (CMP)', code: 'CMP', category: 'Panels', price: 1200, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Renal Function Panel', code: 'RFP', category: 'Panels', price: 800, tat: '4 hrs', sampleType: 'Blood-SST' },
  { name: 'Hepatic Function Panel', code: 'HFP', category: 'Panels', price: 900, tat: '6 hrs', sampleType: 'Blood-SST' },
  { name: 'Diabetes Comprehensive Panel', code: 'DCP', category: 'Panels', price: 1500, tat: '6 hrs', sampleType: 'Blood-Fluoride' },
  { name: 'Pre-Operative Panel', code: 'PREOP', category: 'Panels', price: 1800, tat: '8 hrs', sampleType: 'Blood-SST' },
  { name: 'Annual Health Checkup Panel', code: 'AHC', category: 'Panels', price: 3500, tat: '24 hrs', sampleType: 'Blood-SST' },
]

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI)
  console.log('🌱 Seeding database...')

  await Promise.all([Lab.deleteMany(), User.deleteMany(), Patient.deleteMany(), Doctor.deleteMany(), Test.deleteMany(), Inventory.deleteMany(), OutbreakSignal.deleteMany(), OutbreakAlert.deleteMany()])

  // Super Admin
  await User.create({ name: 'Super Admin', phone: '9999999999', password: 'admin123', role: 'superadmin', isActive: true })
  console.log('✅ Super Admin created | Phone: 9999999999')

  // Demo Lab
  const lab = await Lab.create({
    name: 'City Diagnostics', ownerName: 'Ramesh Gupta', phone: '9876543210', email: 'city@diagnostics.com',
    city: 'Raipur', state: 'Chhattisgarh', plan: 'professional', licenseKey: 'MFPAI-2026-DEMO1234', status: 'active',
    subscriptionStart: new Date(), subscriptionEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
  })

  // Lab Admin
  await User.create({ name: 'Ramesh Gupta', phone: '9876543210', password: 'admin123', role: 'labadmin', lab: lab._id, isActive: true })
  await User.create({ name: 'Kavita Sharma', phone: '9700000001', password: 'tech123', role: 'technician', lab: lab._id, isActive: true })
  await User.create({ name: 'Ravi Kumar', phone: '9700000002', password: 'recep123', role: 'reception', lab: lab._id, isActive: true })
  console.log('✅ Lab + Users created')

  // Doctors
  const doctors = await Doctor.insertMany([
    { lab: lab._id, name: 'Dr. Rajesh Mehta', phone: '9800000001', speciality: 'General Physician', commission: 10 },
    { lab: lab._id, name: 'Dr. Anita Gupta', phone: '9800000002', speciality: 'Gynaecologist', commission: 10 },
    { lab: lab._id, name: 'Dr. Suresh Nair', phone: '9800000003', speciality: 'Cardiologist', commission: 8 },
  ])

  await User.create({ name: 'Dr. Rajesh Mehta', phone: '9800000001', password: 'doctor123', role: 'doctor', lab: lab._id, isActive: true })
  await User.create({ name: 'Rahul Sharma', phone: '9111000001', password: 'patient123', role: 'patient', lab: lab._id, isActive: true })

  // Patients
  const patients = await Patient.insertMany([
    { lab: lab._id, name: 'Rahul Sharma', phone: '9111000001', age: 34, gender: 'male', patientId: 'P0001' },
    { lab: lab._id, name: 'Priya Verma', phone: '9111000002', age: 28, gender: 'female', patientId: 'P0002' },
    { lab: lab._id, name: 'Anil Kumar', phone: '9111000003', age: 52, gender: 'male', patientId: 'P0003', referredBy: doctors[0]._id },
    { lab: lab._id, name: 'Sunita Patel', phone: '9111000004', age: 45, gender: 'female', patientId: 'P0004' },
  ])

  // Tests — 150+ comprehensive pathology tests
  const testDocs = await Test.insertMany(ALL_TESTS.map(t => ({ ...t, lab: lab._id })))
  console.log(`✅ Seeded ${testDocs.length} tests across ${[...new Set(ALL_TESTS.map(t => t.category))].length} categories`)

  // Inventory
  await Inventory.insertMany([
    { lab: lab._id, name: 'EDTA Vacutainer', category: 'consumables', stock: 450, minStock: 100, unit: 'pcs', vendor: 'BD India', expiryDate: new Date('2027-12-01') },
    { lab: lab._id, name: 'CBC Reagent Kit', category: 'reagents', stock: 8, minStock: 5, unit: 'kits', vendor: 'Sysmex India', expiryDate: new Date('2026-09-15') },
    { lab: lab._id, name: 'Glucose Reagent', category: 'reagents', stock: 3, minStock: 5, unit: 'bottles', vendor: 'Transasia', expiryDate: new Date('2026-07-20') },
    { lab: lab._id, name: 'SST Vacutainer', category: 'consumables', stock: 380, minStock: 100, unit: 'pcs', vendor: 'BD India', expiryDate: new Date('2027-06-01') },
    { lab: lab._id, name: 'Urine Cups', category: 'consumables', stock: 200, minStock: 50, unit: 'pcs', vendor: 'Himedia', expiryDate: new Date('2027-08-01') },
    { lab: lab._id, name: 'Culture Media (Blood Agar)', category: 'reagents', stock: 15, minStock: 10, unit: 'plates', vendor: 'HiMedia', expiryDate: new Date('2026-12-01') },
  ])

  console.log('✅ Tests, Patients, Doctors, Inventory seeded')

  // ─── Outbreak Radar demo data ───────────────────────────────────────────
  const networkLabs = await Lab.insertMany([
    { name: 'LifeCare Diagnostics', ownerName: 'Priya Nair', phone: '9876500001', email: 'lifecare@example.com', city: 'Bilaspur', state: 'Chhattisgarh', plan: 'professional', licenseKey: 'MFPAI-2026-NET00001', status: 'active', subscriptionStart: new Date(), subscriptionEnd: new Date(Date.now() + 365*24*60*60*1000) },
    { name: 'Arogya Pathology', ownerName: 'Suresh Patel', phone: '9876500002', email: 'arogya@example.com', city: 'Bhilai', state: 'Chhattisgarh', plan: 'starter', licenseKey: 'MFPAI-2026-NET00002', status: 'active', subscriptionStart: new Date(), subscriptionEnd: new Date(Date.now() + 365*24*60*60*1000) },
  ])

  const DAY = 24 * 60 * 60 * 1000
  const startOfDay = (d) => { const x = new Date(d); x.setHours(0,0,0,0); return x }
  const today = startOfDay(new Date())
  const signalDocs = []

  const seedDays = (disease, city, labRefs, daysBack, countFn) => {
    for (let i = daysBack; i >= 1; i--) {
      const date = startOfDay(new Date(today.getTime() - i * DAY))
      const count = countFn(i)
      if (count <= 0) continue
      signalDocs.push({ disease, city, state: 'Chhattisgarh', date, testCount: count, labIds: labRefs })
    }
  }

  seedDays('Dengue', 'Raipur', [lab._id], 35, (d) => d <= 7 ? 12 + Math.floor(Math.random() * 7) : 1 + Math.floor(Math.random() * 4))
  seedDays('Typhoid', 'Raipur', [lab._id], 35, (d) => d <= 7 ? 3 + Math.floor(Math.random() * 3) : 1 + Math.floor(Math.random() * 2))
  seedDays('Malaria', 'Bilaspur', [networkLabs[0]._id], 35, () => 1 + Math.floor(Math.random() * 2))
  seedDays('Chikungunya', 'Bhilai', [networkLabs[1]._id], 35, (d) => d <= 7 ? 6 + Math.floor(Math.random() * 4) : 1)

  await OutbreakSignal.insertMany(signalDocs)
  console.log(`✅ Outbreak Radar: seeded ${signalDocs.length} daily signal rows across 3 cities`)

  const alerts = await runDetection()
  console.log(`✅ Outbreak Radar: generated ${alerts.length} active alert(s)`)
  alerts.forEach(a => console.log(`   • [${a.severity.toUpperCase()}] ${a.disease} in ${a.city} — ${a.percentChange > 0 ? '+' : ''}${a.percentChange}%`))

  console.log('\n🎉 SEED COMPLETE')
  console.log('─────────────────────────────────────────')
  console.log('Role         | Phone       | Password')
  console.log('─────────────────────────────────────────')
  console.log('Super Admin  | 9999999999  | admin123')
  console.log('Lab Admin    | 9876543210  | admin123')
  console.log('Technician   | 9700000001  | tech123')
  console.log('Reception    | 9700000002  | recep123')
  console.log('Doctor       | 9800000001  | doctor123')
  console.log('Patient      | 9111000001  | patient123')
  console.log('─────────────────────────────────────────')
  console.log(`Total tests seeded: ${testDocs.length}`)
  console.log('─────────────────────────────────────────')
  process.exit(0)
}

seed().catch(e => { console.error(e); process.exit(1) })
