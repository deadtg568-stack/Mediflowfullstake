import mongoose from 'mongoose'
import dotenv from 'dotenv'
import { Lab, User, Patient, Doctor, Test, Inventory, OutbreakSignal, OutbreakAlert } from '../models/index.js'
import { runDetection } from '../services/outbreakService.js'

dotenv.config()

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI)
  console.log('🌱 Seeding database...')

  await Promise.all([Lab.deleteMany(), User.deleteMany(), Patient.deleteMany(), Doctor.deleteMany(), Test.deleteMany(), Inventory.deleteMany(), OutbreakSignal.deleteMany(), OutbreakAlert.deleteMany()])

  // Super Admin
  await User.create({ name: 'Super Admin', phone: '9999999999', password: 'admin123', role: 'superadmin', isActive: true })
  console.log('✅ Super Admin created | Phone: 9999999999')

  // Demo Lab
  const lab = await Lab.create({
    name: 'City Diagnostics',
    ownerName: 'Ramesh Gupta',
    phone: '9876543210',
    email: 'city@diagnostics.com',
    city: 'Raipur',
    state: 'Chhattisgarh',
    plan: 'professional',
    licenseKey: 'MFPAI-2026-DEMO1234',
    status: 'active',
    subscriptionStart: new Date(),
    subscriptionEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
  })

  // Lab Admin
  await User.create({ name: 'Ramesh Gupta', phone: '9876543210', password: 'admin123', role: 'labadmin', lab: lab._id, isActive: true })
  await User.create({ name: 'Kavita Sharma', phone: '9700000001', password: 'tech123', role: 'technician', lab: lab._id, isActive: true })
  await User.create({ name: 'Ravi Kumar', phone: '9700000002', password: 'recep123', role: 'reception', lab: lab._id, isActive: true })
  console.log('✅ Lab + Users created')

  // Doctors
  const doctors = await Doctor.insertMany([
    { lab: lab._id, name: 'Dr. Rajesh Mehta', phone: '9800000001', speciality: 'General Physician', commission: 10 },
    { lab: lab._id, name: 'Dr. Anita Gupta', phone: '9800000002', speciality: 'Gynaecologist', commission: 10 },
    { lab: lab._id, name: 'Dr. Suresh Nair', phone: '9800000003', speciality: 'Cardiologist', commission: 8 },
  ])

  // Doctor portal login (linked to Dr. Rajesh Mehta)
  await User.create({ name: 'Dr. Rajesh Mehta', phone: '9800000001', password: 'doctor123', role: 'doctor', lab: lab._id, isActive: true })

  // Patient portal login
  await User.create({ name: 'Rahul Sharma', phone: '9111000001', password: 'patient123', role: 'patient', lab: lab._id, isActive: true })

  // Patients
  const patients = await Patient.insertMany([
    { lab: lab._id, name: 'Rahul Sharma', phone: '9111000001', age: 34, gender: 'male', patientId: 'P0001' },
    { lab: lab._id, name: 'Priya Verma', phone: '9111000002', age: 28, gender: 'female', patientId: 'P0002' },
    { lab: lab._id, name: 'Anil Kumar', phone: '9111000003', age: 52, gender: 'male', patientId: 'P0003', referredBy: doctors[0]._id },
    { lab: lab._id, name: 'Sunita Patel', phone: '9111000004', age: 45, gender: 'female', patientId: 'P0004' },
  ])

  // Tests
  await Test.insertMany([
    { lab: lab._id, name: 'Complete Blood Count (CBC)', code: 'CBC', category: 'Haematology', price: 350, tat: '4 hrs', sampleType: 'Blood-EDTA' },
    { lab: lab._id, name: 'Lipid Profile', code: 'LP', category: 'Biochemistry', price: 600, tat: '6 hrs', sampleType: 'Blood-SST' },
    { lab: lab._id, name: 'Thyroid Profile (T3,T4,TSH)', code: 'TFT', category: 'Immunology', price: 850, tat: '8 hrs', sampleType: 'Blood-SST' },
    { lab: lab._id, name: 'Liver Function Test (LFT)', code: 'LFT', category: 'Biochemistry', price: 700, tat: '6 hrs', sampleType: 'Blood-SST' },
    { lab: lab._id, name: 'HbA1c', code: 'HBA1C', category: 'Biochemistry', price: 500, tat: '4 hrs', sampleType: 'Blood-EDTA' },
    { lab: lab._id, name: 'Urine Routine & Microscopy', code: 'URM', category: 'Urine', price: 250, tat: '2 hrs', sampleType: 'Urine' },
    { lab: lab._id, name: 'Blood Sugar Fasting', code: 'BSF', category: 'Biochemistry', price: 120, tat: '2 hrs', sampleType: 'Blood-Fluoride' },
    { lab: lab._id, name: 'CRP (C-Reactive Protein)', code: 'CRP', category: 'Immunology', price: 450, tat: '4 hrs', sampleType: 'Blood-SST' },
    // Disease-indicating tests — auto-tagged via diseaseTag pre-save hook,
    // these power the Outbreak Radar module
    { lab: lab._id, name: 'Dengue NS1 Antigen', code: 'DNS1', category: 'Serology', price: 800, tat: '4 hrs', sampleType: 'Blood-SST' },
    { lab: lab._id, name: 'Dengue IgM/IgG', code: 'DIGM', category: 'Serology', price: 900, tat: '6 hrs', sampleType: 'Blood-SST' },
    { lab: lab._id, name: 'Malaria MP Smear', code: 'MPS', category: 'Microbiology', price: 200, tat: '2 hrs', sampleType: 'Blood-EDTA' },
    { lab: lab._id, name: 'Typhoid Widal Test', code: 'WID', category: 'Serology', price: 350, tat: '4 hrs', sampleType: 'Blood-SST' },
    { lab: lab._id, name: 'Chikungunya IgM', code: 'CHIK', category: 'Serology', price: 950, tat: '6 hrs', sampleType: 'Blood-SST' },
  ])

  // Inventory
  await Inventory.insertMany([
    { lab: lab._id, name: 'EDTA Vacutainer', category: 'consumables', stock: 450, minStock: 100, unit: 'pcs', vendor: 'BD India', expiryDate: new Date('2027-12-01') },
    { lab: lab._id, name: 'CBC Reagent Kit', category: 'reagents', stock: 8, minStock: 5, unit: 'kits', vendor: 'Sysmex India', expiryDate: new Date('2026-09-15') },
    { lab: lab._id, name: 'Glucose Reagent', category: 'reagents', stock: 3, minStock: 5, unit: 'bottles', vendor: 'Transasia', expiryDate: new Date('2026-07-20') },
    { lab: lab._id, name: 'SST Vacutainer', category: 'consumables', stock: 380, minStock: 100, unit: 'pcs', vendor: 'BD India', expiryDate: new Date('2027-06-01') },
  ])

  console.log('✅ Tests, Patients, Doctors, Inventory seeded')

  // ─── Outbreak Radar demo data ───────────────────────────────────────────
  // Create a couple of "network" labs in other cities so the Super Admin
  // national view has multiple cities, then seed 5 weeks of OutbreakSignal
  // history with a deliberate Dengue spike in Raipur (current week) so the
  // detection algorithm produces a live demo alert.
  const networkLabs = await Lab.insertMany([
    {
      name: 'LifeCare Diagnostics', ownerName: 'Priya Nair', phone: '9876500001',
      email: 'lifecare@example.com', city: 'Bilaspur', state: 'Chhattisgarh',
      plan: 'professional', licenseKey: 'MFPAI-2026-NET00001', status: 'active',
      subscriptionStart: new Date(), subscriptionEnd: new Date(Date.now() + 365*24*60*60*1000),
    },
    {
      name: 'Arogya Pathology', ownerName: 'Suresh Patel', phone: '9876500002',
      email: 'arogya@example.com', city: 'Bhilai', state: 'Chhattisgarh',
      plan: 'starter', licenseKey: 'MFPAI-2026-NET00002', status: 'active',
      subscriptionStart: new Date(), subscriptionEnd: new Date(Date.now() + 365*24*60*60*1000),
    },
  ])

  const DAY = 24 * 60 * 60 * 1000
  const startOfDay = (d) => { const x = new Date(d); x.setHours(0,0,0,0); return x }
  const today = startOfDay(new Date())

  const signalDocs = []

  // Helper to push N days of signal data for a (disease, city, lab) combo
  const seedDays = (disease, city, labRefs, daysBack, countFn) => {
    for (let i = daysBack; i >= 1; i--) {
      const date = startOfDay(new Date(today.getTime() - i * DAY))
      const count = countFn(i)
      if (count <= 0) continue
      signalDocs.push({
        disease, city, state: 'Chhattisgarh', date,
        testCount: count,
        labIds: labRefs,
      })
    }
  }

  // Raipur (our main demo lab): Dengue baseline ~2-4/day for 5 weeks, then a
  // sharp spike to ~12-18/day in the most recent 7 days -> triggers a CRITICAL alert
  seedDays('Dengue', 'Raipur', [lab._id], 35, (daysAgo) => {
    if (daysAgo <= 7) return 12 + Math.floor(Math.random() * 7) // 12-18/day this week
    return 1 + Math.floor(Math.random() * 4) // 1-4/day baseline
  })

  // Typhoid in Raipur: mild upward trend (~+60%) -> WARNING/WATCH alert
  seedDays('Typhoid', 'Raipur', [lab._id], 35, (daysAgo) => {
    if (daysAgo <= 7) return 3 + Math.floor(Math.random() * 3) // 3-5/day
    return 1 + Math.floor(Math.random() * 2) // 1-2/day
  })

  // Malaria in Bilaspur (network lab): steady, no spike -> demonstrates
  // "normal" trend on the national map
  seedDays('Malaria', 'Bilaspur', [networkLabs[0]._id], 35, () => 1 + Math.floor(Math.random() * 2))

  // Chikungunya in Bhilai (network lab): moderate spike -> WARNING alert,
  // shows cross-network visibility from Raipur's perspective
  seedDays('Chikungunya', 'Bhilai', [networkLabs[1]._id], 35, (daysAgo) => {
    if (daysAgo <= 7) return 6 + Math.floor(Math.random() * 4) // 6-9/day
    return 1
  })

  await OutbreakSignal.insertMany(signalDocs)
  console.log(`✅ Outbreak Radar: seeded ${signalDocs.length} daily signal rows across 3 cities`)

  // Run detection immediately so alerts are visible right after seeding
  const alerts = await runDetection()
  console.log(`✅ Outbreak Radar: generated ${alerts.length} active alert(s)`)
  alerts.forEach(a => console.log(`   • [${a.severity.toUpperCase()}] ${a.disease} in ${a.city} — ${a.percentChange > 0 ? '+' : ''}${a.percentChange}%`))

  console.log('\n🎉 SEED COMPLETE')
  console.log('─────────────────────────────────────────')
  console.log('Role         | Phone       | Password')
  console.log('─────────────────────────────────────────')
  console.log('Super Admin  | 9999999999  | admin123')
  console.log('Lab Admin    | 9876543210  | admin123')
  console.log('Technician   | 9700000001  | tech123')
  console.log('Reception    | 9700000002  | recep123')
  console.log('Doctor       | 9800000001  | doctor123')
  console.log('Patient      | 9111000001  | patient123')
  console.log('─────────────────────────────────────────')
  process.exit(0)
}

seed().catch(e => { console.error(e); process.exit(1) })
