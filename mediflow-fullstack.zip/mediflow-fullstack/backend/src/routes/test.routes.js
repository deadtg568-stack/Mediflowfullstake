import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getTests, createTest, updateTest, deleteTest } from '../controllers/other.controllers.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getTests)
router.post('/', createTest)
router.put('/:id', updateTest)
router.delete('/:id', deleteTest)
export default router
