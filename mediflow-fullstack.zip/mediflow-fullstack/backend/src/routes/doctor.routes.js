import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getDoctors, createDoctor, updateDoctor, deleteDoctor } from '../controllers/other.controllers.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getDoctors)
router.post('/', createDoctor)
router.put('/:id', updateDoctor)
router.delete('/:id', deleteDoctor)
export default router
