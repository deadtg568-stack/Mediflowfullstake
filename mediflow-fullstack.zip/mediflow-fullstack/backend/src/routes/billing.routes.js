import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getBills, createBill, getBill, updatePayment, getTodaySummary } from '../controllers/billing.controller.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/today/summary', getTodaySummary)
router.get('/', getBills)
router.post('/', createBill)
router.get('/:id', getBill)
router.patch('/:id/payment', updatePayment)
export default router
