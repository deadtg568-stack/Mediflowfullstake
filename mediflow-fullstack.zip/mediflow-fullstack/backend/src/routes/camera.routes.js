import express from 'express'
import { protect, authorize, labContext } from '../middleware/auth.js'
import {
  getCameras, getCamera, createCamera, updateCamera, deleteCamera,
  discoverOnvifCameras, connectOnvifCamera, addOnvifCamera,
  startStream, stopStream, getActiveStreamList, getSnapshot,
  startCameraRecording, stopCameraRecording, getCameraRecordings,
  startMotion, stopMotion, testMotion, getMotionEvents, reviewMotionEvent,
} from '../controllers/camera.controller.js'

const router = express.Router()

router.use(protect, labContext)

// Discovery
router.get('/discover', authorize('labadmin', 'superadmin'), discoverOnvifCameras)
router.post('/discover/connect', authorize('labadmin', 'superadmin'), connectOnvifCamera)
router.post('/discover/add', authorize('labadmin', 'superadmin'), addOnvifCamera)

// Active streams overview
router.get('/streams/active', getActiveStreamList)

// Motion events (global routes before /:id to avoid collision)
router.get('/motion-events', getMotionEvents)
router.patch('/motion-events/:id/review', reviewMotionEvent)

// Camera CRUD
router.get('/', getCameras)
router.post('/', authorize('labadmin', 'superadmin'), createCamera)
router.get('/:id', getCamera)
router.put('/:id', authorize('labadmin', 'superadmin'), updateCamera)
router.delete('/:id', authorize('labadmin', 'superadmin'), deleteCamera)

// Streaming
router.post('/:id/stream/start', startStream)
router.post('/:id/stream/stop', stopStream)
router.get('/:id/snapshot', getSnapshot)

// Recording & Playback
router.post('/:id/recording/start', authorize('labadmin', 'superadmin'), startCameraRecording)
router.post('/:id/recording/stop', authorize('labadmin', 'superadmin'), stopCameraRecording)
router.get('/:id/recordings', getCameraRecordings)

// AI Motion Detection
router.post('/:id/motion/start', authorize('labadmin', 'superadmin'), startMotion)
router.post('/:id/motion/stop', authorize('labadmin', 'superadmin'), stopMotion)
router.post('/:id/motion/test', testMotion)

export default router
