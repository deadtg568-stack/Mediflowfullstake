import express from 'express'
import { protect, authorize } from '../middleware/auth.js'
import { getSuperDashboard, getAllLabs, createLab, updateLabStatus, renewSubscription, getPlatformRevenue, getAllUsers } from '../controllers/superadmin.controller.js'
const router = express.Router()
router.use(protect, authorize('superadmin'))
router.get('/dashboard', getSuperDashboard)
router.get('/labs', getAllLabs)
router.post('/labs', createLab)
router.patch('/labs/:id/status', updateLabStatus)
router.post('/labs/:id/renew', renewSubscription)
router.get('/revenue', getPlatformRevenue)
router.get('/users', getAllUsers)
export default router
