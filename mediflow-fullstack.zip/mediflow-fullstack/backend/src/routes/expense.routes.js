import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getExpenses, createExpense, updateExpense, deleteExpense } from '../controllers/other.controllers.js'

const router = express.Router()
router.use(protect, labContext)

router.get('/', getExpenses)
router.post('/', createExpense)
router.put('/:id', updateExpense)
router.delete('/:id', deleteExpense)

export default router
