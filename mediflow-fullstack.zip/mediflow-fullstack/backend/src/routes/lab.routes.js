import express from 'express'
import { protect, asyncHandler, sendResponse } from '../middleware/auth.js'
import { Lab } from '../models/index.js'

const router = express.Router()
router.use(protect)

// GET /api/labs/my
router.get('/my', asyncHandler(async (req, res) => {
  const lab = await Lab.findById(req.user.lab)
  res.json({ success: true, data: lab })
}))

// PUT /api/labs/my
router.put('/my', asyncHandler(async (req, res) => {
  const lab = await Lab.findByIdAndUpdate(req.user.lab, req.body, { new: true })
  res.json({ success: true, data: lab })
}))

// GET /api/labs/my/print-settings — Lab Admin can view their own print config
router.get('/my/print-settings', asyncHandler(async (req, res) => {
  const lab = await Lab.findById(req.user.lab).select('name ownerName phone email address city state gstin settings')
  sendResponse(res, 200, lab)
}))

// PUT /api/labs/my/print-settings — Lab Admin can edit their own print config
router.put('/my/print-settings', asyncHandler(async (req, res) => {
  const { settings, name, address, city, state, gstin, email } = req.body
  const lab = await Lab.findById(req.user.lab)
  if (!lab) return res.status(404).json({ success: false, message: 'Lab not found' })
  if (name)    lab.name    = name
  if (address) lab.address = address
  if (city)    lab.city    = city
  if (state)   lab.state   = state
  if (gstin)   lab.gstin   = gstin
  if (email)   lab.email   = email
  if (settings) lab.settings = { ...lab.settings?.toObject?.() || {}, ...settings }
  await lab.save()
  sendResponse(res, 200, lab, 'Print settings saved')
}))

export default router
