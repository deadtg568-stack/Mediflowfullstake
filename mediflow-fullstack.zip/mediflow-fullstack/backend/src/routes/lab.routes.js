// lab.routes.js
import express from 'express'
import { protect, authorize, labContext } from '../middleware/auth.js'
import { Lab } from '../models/index.js'
const router = express.Router()
router.use(protect)
router.get('/my', async (req, res) => {
  const lab = await Lab.findById(req.user.lab)
  res.json({ success: true, data: lab })
})
router.put('/my', async (req, res) => {
  const lab = await Lab.findByIdAndUpdate(req.user.lab, req.body, { new: true })
  res.json({ success: true, data: lab })
})
export default router
