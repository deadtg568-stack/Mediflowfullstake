import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getAppointments, createAppointment, updateAppointment, deleteAppointment } from '../controllers/other.controllers.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getAppointments)
router.post('/', createAppointment)
router.put('/:id', updateAppointment)
router.delete('/:id', deleteAppointment)
export default router
