import express from 'express'
import { protect, authorize } from '../middleware/auth.js'
import { getTrends, getAlerts, triggerDetection, getNational, resolveAlert } from '../controllers/outbreak.controller.js'

const router = express.Router()
router.use(protect)

// Lab-scoped (any authenticated lab user can view their city's trends/alerts)
router.get('/trends', getTrends)
router.get('/alerts', getAlerts)

// Super Admin: cross-network view + manual detection trigger
router.get('/national', authorize('superadmin'), getNational)
router.post('/detect', authorize('superadmin', 'labadmin'), triggerDetection)

// Either role can dismiss an alert relevant to them
router.patch('/alerts/:id/resolve', authorize('superadmin', 'labadmin'), resolveAlert)

export default router
