import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getDashboardStats, getMonthlyRevenue, getTopTests, getTopDoctors } from '../controllers/analytics.controller.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/dashboard', getDashboardStats)
router.get('/monthly-revenue', getMonthlyRevenue)
router.get('/top-tests', getTopTests)
router.get('/top-doctors', getTopDoctors)
export default router
