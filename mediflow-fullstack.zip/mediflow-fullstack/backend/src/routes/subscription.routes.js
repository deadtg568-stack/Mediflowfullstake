import express from 'express'
import { protect, authorize } from '../middleware/auth.js'
import { Lab } from '../models/index.js'
const router = express.Router()
router.use(protect)
router.get('/plans', (req, res) => {
  res.json({ success: true, data: [
    { id: 'starter',      name: 'Starter',      price: 999,  features: ['50 patients/month', 'Basic reports', 'Billing'] },
    { id: 'professional', name: 'Professional', price: 1999, features: ['Unlimited patients', 'GST billing', 'WhatsApp share', 'Analytics'] },
    { id: 'enterprise',   name: 'Enterprise AI', price: 3999, features: ['All features', 'AI Assistant', 'CCTV', 'Multi-staff', 'Priority support'] },
  ]})
})
router.get('/my', async (req, res) => {
  const lab = await Lab.findById(req.user.lab).select('plan status subscriptionEnd licenseKey')
  res.json({ success: true, data: lab })
})
export default router
