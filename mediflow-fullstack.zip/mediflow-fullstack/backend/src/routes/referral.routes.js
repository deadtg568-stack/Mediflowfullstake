import express from 'express'
import { protect, authorize } from '../middleware/auth.js'
import {
  getPartners, createPartner, getPartner, updatePartner, deletePartner,
  verifyCode, getReferralLogs, verifyReferral, approveReferral,
  rejectReferral, payReferral, getReferralStats,
} from '../controllers/referral.controller.js'

const router = express.Router()

// Public — verify referral code (used during lab registration)
router.get('/verify/:code', verifyCode)

// Protected routes
router.use(protect, authorize('superadmin'))

// Stats
router.get('/stats', getReferralStats)

// Partners
router.get('/partners',     getPartners)
router.post('/partners',    createPartner)
router.get('/partners/:id', getPartner)
router.put('/partners/:id', updatePartner)
router.delete('/partners/:id', deletePartner)

// Referral logs management
router.get('/logs',                    getReferralLogs)
router.patch('/logs/:id/verify',       verifyReferral)
router.patch('/logs/:id/approve',      approveReferral)
router.patch('/logs/:id/reject',       rejectReferral)
router.patch('/logs/:id/pay',          payReferral)

export default router
