import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import {
  startTracking,
  updateLocation,
  updateTrackingStatus,
  stopTracking,
  getActiveTrackings,
  getTrackingHistory,
  getAllTrackings,
} from '../controllers/gps.controller.js'

const router = express.Router()
router.use(protect)

// ─── Technician routes ──────────────────────────────────────────────────────────
// require labContext so superadmin/non-lab users don't interfere
router.post('/start',      labContext, startTracking)
router.post('/location',   labContext, updateLocation)
router.patch('/:id/status',labContext, updateTrackingStatus)
router.post('/:id/stop',   labContext, stopTracking)

// ─── Lab-admin routes ───────────────────────────────────────────────────────────
router.get('/active',      labContext, getActiveTrackings)
router.get('/history/:id', labContext, getTrackingHistory)
router.get('/',            labContext, getAllTrackings)

export default router
