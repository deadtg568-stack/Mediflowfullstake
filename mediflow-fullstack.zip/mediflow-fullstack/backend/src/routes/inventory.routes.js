import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getInventory, createInventoryItem, updateInventoryItem, adjustStock } from '../controllers/other.controllers.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getInventory)
router.post('/', createInventoryItem)
router.put('/:id', updateInventoryItem)
router.patch('/:id/stock', adjustStock)
export default router
