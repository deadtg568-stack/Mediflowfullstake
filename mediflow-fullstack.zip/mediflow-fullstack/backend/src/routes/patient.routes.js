import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getPatients, createPatient, getPatient, updatePatient, deletePatient } from '../controllers/patient.controller.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getPatients)
router.post('/', createPatient)
router.get('/:id', getPatient)
router.put('/:id', updatePatient)
router.delete('/:id', deletePatient)
export default router
