import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getStaff, createStaff, updateStaff } from '../controllers/other.controllers.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getStaff)
router.post('/', createStaff)
router.put('/:id', updateStaff)
export default router
