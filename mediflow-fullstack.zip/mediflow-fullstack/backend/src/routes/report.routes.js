import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getReports, updateReport } from '../controllers/other.controllers.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getReports)
router.put('/:id', updateReport)
export default router
