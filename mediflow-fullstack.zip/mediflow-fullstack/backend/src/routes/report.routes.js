import express from 'express'
import { protect, labContext } from '../middleware/auth.js'
import { getReports, createReport, updateReport, deleteReport } from '../controllers/other.controllers.js'
const router = express.Router()
router.use(protect, labContext)
router.get('/', getReports)
router.post('/', createReport)
router.put('/:id', updateReport)
router.delete('/:id', deleteReport)
export default router
