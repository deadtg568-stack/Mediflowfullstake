/**
 * Motion Detection Service
 * ─────────────────────────────────────────────────────────────────────────
 * Lightweight motion detection using frame-difference analysis on JPEG
 * snapshots pulled from the RTSP stream via ffmpeg, decoded with `jpeg-js`,
 * and compared pixel-by-pixel.
 *
 * Pipeline per camera (every `intervalMs`):
 *  1. Capture snapshot A via ffmpeg (-vframes 1, downscaled to 160x90)
 *  2. Wait `frameGapMs`
 *  3. Capture snapshot B
 *  4. Decode both JPEGs -> raw RGBA buffers
 *  5. Compute % of pixels whose luma delta exceeds threshold
 *  6. If % > threshold derived from camera.motionSensitivity -> motion event
 *
 * For production-grade accuracy this can be swapped for a TensorFlow.js
 * object-detection model (e.g. coco-ssd) on the same snapshots — the
 * `checkMotion` interface stays identical.
 */

import { spawn } from 'child_process'
import fs from 'fs'
import path from 'path'
import jpeg from 'jpeg-js'
import { fileURLToPath } from 'url'
import { Camera, MotionEvent } from '../models/index.js'
import { startRecording, isRecording } from './streamService.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const SNAPSHOT_DIR = path.join(__dirname, '../../streams/_motion')
const ALERTS_DIR   = path.join(__dirname, '../../recordings/_alerts')

if (!fs.existsSync(SNAPSHOT_DIR)) fs.mkdirSync(SNAPSHOT_DIR, { recursive: true })
if (!fs.existsSync(ALERTS_DIR))   fs.mkdirSync(ALERTS_DIR, { recursive: true })

// streamKey -> interval handle
const watchers = new Map()

/** Capture one raw JPEG frame via ffmpeg, scaled down for fast processing. */
const grabFrame = (rtspUrl, outPath) => new Promise((resolve, reject) => {
  const args = [
    '-rtsp_transport', 'tcp',
    '-i', rtspUrl,
    '-vframes', '1',
    '-vf', 'scale=160:90',
    '-q:v', '5',
    '-y', outPath,
  ]
  const proc = spawn('ffmpeg', args)
  let err = ''
  proc.stderr.on('data', d => { err += d.toString() })
  proc.on('exit', code => {
    if (code === 0 && fs.existsSync(outPath)) resolve(outPath)
    else reject(new Error(`grabFrame failed: ${err.slice(-200)}`))
  })
  proc.on('error', reject)
})

/** Capture a full-resolution snapshot (used for alert evidence). */
const grabFullFrame = (rtspUrl, outPath) => new Promise((resolve, reject) => {
  const args = ['-rtsp_transport', 'tcp', '-i', rtspUrl, '-vframes', '1', '-q:v', '2', '-y', outPath]
  const proc = spawn('ffmpeg', args)
  proc.on('exit', code => code === 0 ? resolve(outPath) : reject(new Error('snapshot failed')))
  proc.on('error', reject)
})

/** Compare two JPEG buffers, return % of pixels with significant luma change. */
const diffFrames = (bufA, bufB) => {
  const a = jpeg.decode(bufA, { useTArray: true })
  const b = jpeg.decode(bufB, { useTArray: true })
  if (a.width !== b.width || a.height !== b.height) return 0

  const total = a.width * a.height
  let changed = 0
  const LUMA_THRESHOLD = 28

  for (let i = 0; i < a.data.length; i += 4) {
    const lumaA = 0.299 * a.data[i] + 0.587 * a.data[i+1] + 0.114 * a.data[i+2]
    const lumaB = 0.299 * b.data[i] + 0.587 * b.data[i+1] + 0.114 * b.data[i+2]
    if (Math.abs(lumaA - lumaB) > LUMA_THRESHOLD) changed++
  }

  return (changed / total) * 100
}

/**
 * Run a single motion check for one camera.
 * Returns { motionDetected, changePercent, threshold }
 */
export const checkMotion = async (camera) => {
  const frameA = path.join(SNAPSHOT_DIR, `${camera.streamKey}_a.jpg`)
  const frameB = path.join(SNAPSHOT_DIR, `${camera.streamKey}_b.jpg`)

  await grabFrame(camera.rtspUrl, frameA)
  await new Promise(r => setTimeout(r, 700))
  await grabFrame(camera.rtspUrl, frameB)

  const bufA = fs.readFileSync(frameA)
  const bufB = fs.readFileSync(frameB)
  const changePercent = diffFrames(bufA, bufB)

  // motionSensitivity (0-100, lower = more sensitive) maps to a % threshold
  const threshold = Math.max(0.5, (camera.motionSensitivity ?? 25) / 10)

  return { motionDetected: changePercent > threshold, changePercent, threshold }
}

/**
 * Start continuous motion monitoring for a camera.
 * On detection: saves a snapshot, creates a MotionEvent, and (if enabled)
 * triggers a short clip recording.
 */
export const startMotionWatch = (camera, intervalMs = 5000) => {
  if (watchers.has(camera.streamKey)) return { alreadyRunning: true }

  const handle = setInterval(async () => {
    try {
      const fresh = await Camera.findById(camera._id)
      if (!fresh || !fresh.motionDetectionEnabled) return

      const { motionDetected, changePercent } = await checkMotion(fresh)
      if (!motionDetected) return

      const snapName = `motion_${fresh.streamKey}_${Date.now()}.jpg`
      const snapPath = path.join(ALERTS_DIR, snapName)
      await grabFullFrame(fresh.rtspUrl, snapPath).catch(() => null)

      await MotionEvent.create({
        lab: fresh.lab,
        camera: fresh._id,
        confidence: Math.min(100, Math.round(changePercent * 5)),
        snapshot: `/recordings/_alerts/${snapName}`,
        zone: fresh.location,
      })

      console.log(`Motion detected: ${fresh.name} (${changePercent.toFixed(1)}% change)`)

      if (fresh.recordingEnabled && !isRecording(fresh.streamKey)) {
        startRecording(fresh, 5)
      }
    } catch (e) {
      console.error(`[motion:${camera.streamKey}]`, e.message)
    }
  }, intervalMs)

  watchers.set(camera.streamKey, handle)
  return { alreadyRunning: false }
}

export const stopMotionWatch = (streamKey) => {
  const handle = watchers.get(streamKey)
  if (!handle) return false
  clearInterval(handle)
  watchers.delete(streamKey)
  return true
}

export const isWatching = (streamKey) => watchers.has(streamKey)
export const getActiveWatchers = () => Array.from(watchers.keys())
