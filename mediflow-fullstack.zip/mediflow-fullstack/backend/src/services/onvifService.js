/**
 * ONVIF Service
 * - Auto-discovers ONVIF-compliant cameras on the local network (WS-Discovery)
 * - Connects to a camera to fetch device info & stream URIs
 * - Controls PTZ (if supported) and motion detection config
 *
 * Uses the `onvif` npm package (https://www.npmjs.com/package/onvif)
 */

import onvif from 'onvif';

const { Discovery, Cam } = onvif;
/**
 * Discover ONVIF cameras on the local network using WS-Discovery multicast.
 * Returns a list of { urn, name, hardware, location, xaddrs }
 *
 * NOTE: Requires UDP multicast (239.255.255.250:3702) access on the network.
 * In Docker, run with --network host for discovery to work.
 */
export const discoverCameras = (timeout = 5000) => {
  return new Promise((resolve) => {
    const found = []

    Discovery.on('device', (cam, rinfo, xml) => {
      try {
        found.push({
          ip: cam.hostname || rinfo?.address,
          xaddr: cam.xaddrs?.[0] || null,
          urn: cam.urn || null,
          rawXml: undefined, // omit raw XML to keep payload small
        })
      } catch (e) {
        console.error('ONVIF parse error:', e.message)
      }
    })

    Discovery.on('error', (err) => {
      console.error('ONVIF discovery error:', err.message)
    })

    try {
      Discovery.probe({ timeout, resolve: false })
    } catch (e) {
      console.error('ONVIF probe failed:', e.message)
    }

    setTimeout(() => {
      // Deduplicate by IP
      const unique = Array.from(new Map(found.map(f => [f.ip, f])).values())
      resolve(unique)
    }, timeout + 500)
  })
}

/**
 * Connect to a specific camera via ONVIF and fetch its details + RTSP stream URI.
 * @param {Object} params - { ip, port, username, password }
 */
export const getCameraDetails = (params) => {
  return new Promise((resolve, reject) => {
    const cam = new Cam(
      {
        hostname: params.ip,
        username: params.username || 'admin',
        password: params.password || '',
        port: params.port || 80,
        timeout: 8000,
      },
      function (err) {
        if (err) return reject(err)

        const cameraInfo = {
          manufacturer: this.deviceInformation?.manufacturer || 'Unknown',
          model:        this.deviceInformation?.model || 'Unknown',
          firmware:     this.deviceInformation?.firmwareVersion || '',
          serialNumber: this.deviceInformation?.serialNumber || '',
          hardwareId:   this.deviceInformation?.hardwareId || '',
        }

        // Fetch RTSP stream URI for the primary profile
        this.getStreamUri({ protocol: 'RTSP' }, (err2, stream) => {
          if (err2) {
            return resolve({ ...cameraInfo, rtspUri: null, error: err2.message })
          }
          resolve({ ...cameraInfo, rtspUri: stream?.uri || null })
        })
      }
    )
  })
}

/**
 * Build an RTSP URL with embedded credentials for ffmpeg consumption.
 */
export const buildRtspUrl = (rtspUri, username, password) => {
  if (!rtspUri) return null
  if (!username) return rtspUri
  try {
    const url = new URL(rtspUri)
    url.username = username
    url.password = password || ''
    return url.toString()
  } catch {
    // Fallback: manual injection
    return rtspUri.replace('rtsp://', `rtsp://${username}:${password || ''}@`)
  }
}

/**
 * Enable/configure motion detection analytics on camera (best-effort).
 * Many cameras require vendor-specific CGI calls; ONVIF Analytics profile
 * support varies. This attempts the standard ONVIF Events/Analytics path.
 */
export const configureMotionDetection = (params) => {
  return new Promise((resolve, reject) => {
    const cam = new Cam(
      {
        hostname: params.ip,
        username: params.username || 'admin',
        password: params.password || '',
        port: params.port || 80,
        timeout: 8000,
      },
      function (err) {
        if (err) return reject(err)
        // Most cameras emit motion alarm events via PullPoint subscription.
        // We resolve with capability info; actual event subscription is
        // handled in motionService for cameras that support it natively.
        resolve({
          supportsEvents: !!this.capabilities?.events,
          supportsAnalytics: !!this.capabilities?.analytics,
        })
      }
    )
  })
}
