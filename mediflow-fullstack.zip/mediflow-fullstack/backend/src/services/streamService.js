/**
 * Stream Service
 * - Converts RTSP camera feeds to HLS (HTTP Live Streaming) so they can be
 *   played directly in the browser via <video> + hls.js (no plugins needed).
 * - Manages one ffmpeg process per active camera stream.
 * - Also supports continuous recording of a stream to MP4 segments.
 */

import { spawn } from 'child_process'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const STREAMS_DIR     = path.join(__dirname, '../../streams')
const RECORDINGS_DIR  = path.join(__dirname, '../../recordings')

if (!fs.existsSync(STREAMS_DIR))    fs.mkdirSync(STREAMS_DIR, { recursive: true })
if (!fs.existsSync(RECORDINGS_DIR)) fs.mkdirSync(RECORDINGS_DIR, { recursive: true })

// In-memory registry of running ffmpeg processes: streamKey -> { proc, startedAt }
const activeStreams   = new Map()
const activeRecorders = new Map()

/**
 * Start an HLS stream for a camera.
 * Produces: streams/<streamKey>/index.m3u8 + segmentN.ts
 */
export const startHlsStream = (camera) => {
  const { streamKey, rtspUrl } = camera
  if (activeStreams.has(streamKey)) {
    return { alreadyRunning: true, hlsPath: `/streams/${streamKey}/index.m3u8` }
  }

  const outDir = path.join(STREAMS_DIR, streamKey)
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true })

  const outputPath = path.join(outDir, 'index.m3u8')

  // -rtsp_transport tcp avoids UDP packet loss issues common on local networks
  // -re reads input at native frame rate
  // hls_flags delete_segments keeps disk usage bounded (rolling window)
  const args = [
    '-rtsp_transport', 'tcp',
    '-i', rtspUrl,
    '-c:v', 'libx264',
    '-preset', 'veryfast',
    '-tune', 'zerolatency',
    '-c:a', 'aac',
    '-ac', '1',
    '-f', 'hls',
    '-hls_time', '2',
    '-hls_list_size', '6',
    '-hls_flags', 'delete_segments+append_list',
    '-hls_segment_filename', path.join(outDir, 'seg_%03d.ts'),
    outputPath,
  ]

  const proc = spawn('ffmpeg', args)

  proc.stderr.on('data', (data) => {
    const line = data.toString()
    if (line.toLowerCase().includes('error')) {
      console.error(`[ffmpeg:${streamKey}]`, line.trim())
    }
  })

  proc.on('exit', (code) => {
    console.log(`[ffmpeg:${streamKey}] exited with code ${code}`)
    activeStreams.delete(streamKey)
  })

  proc.on('error', (err) => {
    console.error(`[ffmpeg:${streamKey}] spawn error:`, err.message)
    activeStreams.delete(streamKey)
  })

  activeStreams.set(streamKey, { proc, startedAt: new Date(), camera })

  return { alreadyRunning: false, hlsPath: `/streams/${streamKey}/index.m3u8` }
}

/**
 * Stop an HLS stream and clean up its segment files.
 */
export const stopHlsStream = (streamKey) => {
  const entry = activeStreams.get(streamKey)
  if (!entry) return false
  entry.proc.kill('SIGTERM')
  activeStreams.delete(streamKey)

  const outDir = path.join(STREAMS_DIR, streamKey)
  setTimeout(() => {
    fs.rm(outDir, { recursive: true, force: true }, () => {})
  }, 2000)

  return true
}

/**
 * Get status of all active streams.
 */
export const getActiveStreams = () => {
  return Array.from(activeStreams.entries()).map(([key, v]) => ({
    streamKey: key,
    startedAt: v.startedAt,
    cameraId: v.camera?._id,
    cameraName: v.camera?.name,
  }))
}

/**
 * Capture a single JPEG snapshot from the RTSP stream.
 */
export const captureSnapshot = (camera, outPath) => {
  return new Promise((resolve, reject) => {
    const args = [
      '-rtsp_transport', 'tcp',
      '-i', camera.rtspUrl,
      '-vframes', '1',
      '-q:v', '2',
      '-y',
      outPath,
    ]
    const proc = spawn('ffmpeg', args)
    let errOutput = ''
    proc.stderr.on('data', d => { errOutput += d.toString() })
    proc.on('exit', (code) => {
      if (code === 0 && fs.existsSync(outPath)) resolve(outPath)
      else reject(new Error(`Snapshot failed (code ${code}): ${errOutput.slice(-300)}`))
    })
    proc.on('error', reject)
  })
}

/**
 * Start continuous recording of a camera stream to timestamped MP4 segments.
 */
export const startRecording = (camera, segmentMinutes = 15) => {
  const { streamKey } = camera
  if (activeRecorders.has(streamKey)) {
    return { alreadyRunning: true }
  }

  const outDir = path.join(RECORDINGS_DIR, streamKey)
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true })

  const segmentSeconds = segmentMinutes * 60
  const outputPattern = path.join(outDir, 'rec_%Y%m%d_%H%M%S.mp4')

  const args = [
    '-rtsp_transport', 'tcp',
    '-i', camera.rtspUrl,
    '-c:v', 'copy',
    '-c:a', 'aac',
    '-f', 'segment',
    '-segment_time', String(segmentSeconds),
    '-segment_format', 'mp4',
    '-reset_timestamps', '1',
    '-strftime', '1',
    outputPattern,
  ]

  const proc = spawn('ffmpeg', args)

  proc.stderr.on('data', (data) => {
    const line = data.toString()
    if (line.toLowerCase().includes('error')) {
      console.error(`[record:${streamKey}]`, line.trim())
    }
  })

  proc.on('exit', (code) => {
    console.log(`[record:${streamKey}] exited with code ${code}`)
    activeRecorders.delete(streamKey)
  })

  activeRecorders.set(streamKey, { proc, startedAt: new Date(), camera, outDir })

  return { alreadyRunning: false, outDir }
}

/**
 * Stop continuous recording for a camera.
 */
export const stopRecording = (streamKey) => {
  const entry = activeRecorders.get(streamKey)
  if (!entry) return false
  entry.proc.kill('SIGINT')
  activeRecorders.delete(streamKey)
  return true
}

export const isRecording = (streamKey) => activeRecorders.has(streamKey)
export const isStreaming  = (streamKey) => activeStreams.has(streamKey)

/**
 * List recorded segment files for a camera with metadata.
 */
export const listRecordings = (streamKey) => {
  const outDir = path.join(RECORDINGS_DIR, streamKey)
  if (!fs.existsSync(outDir)) return []
  return fs.readdirSync(outDir)
    .filter(f => f.endsWith('.mp4'))
    .map(f => {
      const fp = path.join(outDir, f)
      const stat = fs.statSync(fp)
      return {
        filename: f,
        path: fp,
        url: `/recordings/${streamKey}/${f}`,
        size: stat.size,
        createdAt: stat.birthtime,
      }
    })
    .sort((a, b) => b.createdAt - a.createdAt)
}

export const RECORDINGS_DIR_PATH = RECORDINGS_DIR
export const STREAMS_DIR_PATH = STREAMS_DIR
