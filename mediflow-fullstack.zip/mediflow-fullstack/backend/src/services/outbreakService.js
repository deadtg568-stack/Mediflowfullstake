/**
 * Outbreak Radar Service
 * ─────────────────────────────────────────────────────────────────────────
 * The "network effect" feature: every lab on the platform anonymously
 * contributes a daily count of disease-indicating tests ordered, grouped by
 * city. As more labs join, the signal gets statistically stronger.
 *
 * Privacy: only (disease, city, date) -> count is stored. No patient name,
 * phone, or lab identity is exposed in any API response — labIds are kept
 * server-side only to compute labCount.
 *
 * Pipeline:
 *  1. recordSignal()  — called from billing.controller.createBill whenever a
 *     bill includes a test with a diseaseTag. Upserts today's
 *     OutbreakSignal counter for (disease, lab.city).
 *  2. runDetection()  — compares the last 7 days' total for each
 *     (disease, city) against the average of the prior 4 weeks. If the
 *     current week is significantly higher AND the absolute volume clears a
 *     minimum threshold (avoids false alarms from tiny sample sizes), an
 *     OutbreakAlert is created or updated.
 *  3. getCityTrend()  — daily counts for a city's tracked diseases, for
 *     charting in the Lab Admin "Outbreak Radar" page.
 *  4. getNationalSnapshot() — city-wise active alerts + totals for the
 *     Super Admin "Outbreak Map".
 */

import { OutbreakSignal, OutbreakAlert, Test, Lab } from '../models/index.js'
import { DISEASE_KEYWORDS, inferDiseaseTag } from '../models/index.js'

const DAY_MS = 24 * 60 * 60 * 1000

const startOfDay = (d = new Date()) => {
  const x = new Date(d)
  x.setHours(0, 0, 0, 0)
  return x
}

/**
 * Record one disease-test occurrence for a lab's city on today's date.
 * Called once per matching test line-item when a bill is created.
 */
export const recordSignal = async ({ disease, lab }) => {
  if (!disease || !lab?.city) return null
  const date = startOfDay()

  return OutbreakSignal.findOneAndUpdate(
    { disease, city: lab.city, date },
    {
      $inc: { testCount: 1 },
      $addToSet: { labIds: lab._id },
      $setOnInsert: { state: lab.state },
    },
    { upsert: true, new: true }
  )
}

/**
 * Given a set of bill line-items (each with a `testName`), resolve which
 * ones map to a tracked disease and record signals for each.
 * Used by billing.controller right after a Bill is created.
 */
export const recordSignalsForBillItems = async (testItems, lab) => {
  const seen = new Set() // avoid double-counting same disease twice per bill
  for (const item of testItems) {
    const disease = inferDiseaseTag(item.testName || '')
    if (!disease || seen.has(disease)) continue
    seen.add(disease)
    await recordSignal({ disease, lab })
  }
}

/**
 * Run spike detection across all (disease, city) pairs that have recent data.
 * Returns the list of alerts that are currently active after this run.
 */
export const runDetection = async () => {
  const today = startOfDay()
  const weekStart = new Date(today.getTime() - 7 * DAY_MS)
  const baselineStart = new Date(today.getTime() - 35 * DAY_MS) // 5 weeks back

  // Pull everything in the analysis window in one go
  const signals = await OutbreakSignal.find({ date: { $gte: baselineStart, $lt: today } })

  // Group by disease+city
  const groups = new Map()
  for (const s of signals) {
    const key = `${s.disease}|||${s.city}`
    if (!groups.has(key)) groups.set(key, { disease: s.disease, city: s.city, state: s.state, signals: [] })
    groups.get(key).signals.push(s)
  }

  const activeKeys = []

  for (const [, group] of groups) {
    const { disease, city, state, signals: rows } = group

    let currentWeek = 0
    let priorTotal = 0
    let priorDays = 0
    const labSet = new Set()

    for (const row of rows) {
      if (row.date >= weekStart) {
        currentWeek += row.testCount
        row.labIds?.forEach(id => labSet.add(String(id)))
      } else {
        priorTotal += row.testCount
        priorDays += 1
      }
    }

    // Baseline = average DAILY count over prior weeks, scaled to a 7-day window
    const priorAvgPerDay = priorDays > 0 ? priorTotal / priorDays : 0
    const baselineAvg = priorAvgPerDay * 7

    const MIN_CURRENT = 5      // ignore tiny absolute numbers (noise)
    const MIN_BASELINE = 1     // need at least some history to compare against

    if (currentWeek < MIN_CURRENT) continue

    const percentChange = baselineAvg >= MIN_BASELINE
      ? ((currentWeek - baselineAvg) / baselineAvg) * 100
      : currentWeek >= MIN_CURRENT * 2 ? 100 : 0 // no baseline at all -> only flag if volume is notable

    if (percentChange < 50) continue // require at least +50% vs baseline

    let severity = 'watch'
    if (percentChange >= 200) severity = 'critical'
    else if (percentChange >= 100) severity = 'warning'

    const recommendation = RECOMMENDATIONS[disease] || RECOMMENDATIONS.default

    const alert = await OutbreakAlert.findOneAndUpdate(
      { disease, city, status: 'active' },
      {
        disease, city, state, severity,
        currentCount: currentWeek,
        baselineAvg: Math.round(baselineAvg * 10) / 10,
        percentChange: Math.round(percentChange),
        labCount: labSet.size,
        windowStart: weekStart,
        windowEnd: today,
        message: `${disease} tests in ${city} are up ${Math.round(percentChange)}% vs the recent baseline (${currentWeek} vs ~${Math.round(baselineAvg)} expected).`,
        recommendation,
      },
      { upsert: true, new: true }
    )

    activeKeys.push(`${alert.disease}|||${alert.city}`)
  }

  // Auto-resolve alerts that no longer meet the threshold
  const allActive = await OutbreakAlert.find({ status: 'active' })
  for (const a of allActive) {
    const key = `${a.disease}|||${a.city}`
    if (!activeKeys.includes(key)) {
      a.status = 'resolved'
      await a.save()
    }
  }

  return OutbreakAlert.find({ status: 'active' }).sort({ percentChange: -1 })
}

const RECOMMENDATIONS = {
  Dengue: 'Stock up on Dengue NS1/IgM/IgG kits and platelet-count reagents. Notify referring doctors to screen febrile patients early.',
  Malaria: 'Ensure MP smear & rapid malaria kit availability. Recommend mosquito-control advisory to patients in the area.',
  Typhoid: 'Stock Widal/Typhidot kits. Advise patients on safe drinking water precautions.',
  Chikungunya: 'Stock Chikungunya IgM kits and ensure joint-pain triage protocols are in place.',
  'COVID-19': 'Stock RT-PCR/RAT kits and review isolation protocols with referring clinics.',
  Influenza: 'Stock Influenza panels; consider flu-vaccine awareness messaging for at-risk patients.',
  Leptospirosis: 'Stock Leptospira IgM kits — common after flooding/waterlogging in the area.',
  'Hepatitis A': 'Stock Hepatitis A panels and advise on food/water hygiene to referring clinics.',
  Gastroenteritis: 'Stock stool routine & rotavirus kits; flag a possible water-contamination cluster to local health authority.',
  default: 'Monitor closely and ensure adequate reagent stock for related tests.',
}

/**
 * Daily counts for the last `days` days for a given city, broken down by
 * disease — used to render the Lab Admin trend charts.
 */
export const getCityTrend = async (city, days = 30) => {
  const since = startOfDay(new Date(Date.now() - days * DAY_MS))
  const signals = await OutbreakSignal.find({ city, date: { $gte: since } }).sort({ date: 1 })

  // Pivot into { date: 'YYYY-MM-DD', [disease]: count, ... }[]
  const byDate = new Map()
  for (const s of signals) {
    const key = s.date.toISOString().slice(0, 10)
    if (!byDate.has(key)) byDate.set(key, { date: key })
    byDate.get(key)[s.disease] = s.testCount
  }
  return Array.from(byDate.values())
}

/**
 * National snapshot for Super Admin: active alerts grouped, plus per-city
 * totals for the last 7 days across all tracked diseases.
 */
export const getNationalSnapshot = async () => {
  const today = startOfDay()
  const weekStart = new Date(today.getTime() - 7 * DAY_MS)

  const [alerts, recentSignals, labs] = await Promise.all([
    OutbreakAlert.find({ status: 'active' }).sort({ percentChange: -1 }),
    OutbreakSignal.find({ date: { $gte: weekStart } }),
    Lab.find({ status: 'active' }).select('city state'),
  ])

  // City -> { disease -> count, totalLabs }
  const cityTotals = new Map()
  for (const s of recentSignals) {
    if (!cityTotals.has(s.city)) cityTotals.set(s.city, { city: s.city, state: s.state, diseases: {}, total: 0, labIds: new Set() })
    const entry = cityTotals.get(s.city)
    entry.diseases[s.disease] = (entry.diseases[s.disease] || 0) + s.testCount
    entry.total += s.testCount
    s.labIds?.forEach(id => entry.labIds.add(String(id)))
  }

  const cities = Array.from(cityTotals.values()).map(c => ({
    city: c.city,
    state: c.state,
    total: c.total,
    labCount: c.labIds.size,
    diseases: c.diseases,
    hasAlert: alerts.some(a => a.city === c.city),
  })).sort((a, b) => b.total - a.total)

  const participatingCities = new Set(labs.map(l => l.city).filter(Boolean))

  return {
    alerts,
    cities,
    networkStats: {
      totalLabs: labs.length,
      participatingCities: participatingCities.size,
      trackedDiseases: Object.keys(DISEASE_KEYWORDS).filter(d => d !== 'Viral Fever'),
    },
  }
}
