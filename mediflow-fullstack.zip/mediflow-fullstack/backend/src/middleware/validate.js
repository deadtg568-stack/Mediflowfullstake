import { validationResult } from 'express-validator'

/**
 * Middleware factory: wraps express-validator checks and returns
 * a unified 400 response with all validation errors.
 *
 * Usage:
 *   import { body, query } from 'express-validator'
 *   import validate from '../middleware/validate.js'
 *
 *   router.post('/patients', [
 *     body('name').trim().notEmpty().withMessage('Patient name is required'),
 *     body('phone').isMobilePhone('any').withMessage('Valid phone number required'),
 *     validate,
 *   ], controller.create)
 */
export default function validate(req, res, next) {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    const messages = errors.array().map(e => e.msg)
    return res.status(400).json({
      success: false,
      message: messages[0],
      errors: messages,
    })
  }
  next()
}
