import AuditLog from '../models/AuditLog.js'

/**
 * Middleware to log significant platform actions.
 * Attach to routes that need auditing.
 *
 * Usage:
 *   router.post('/patients', audit('patient.create', 'Patient'), controller.create)
 *
 * Or call directly in a controller:
 *   await logAudit(req, 'patient.create', 'Patient', patient._id, { patientId: patient.patientId })
 */
export default function audit(action, resource) {
  return (req, res, next) => {
    // Store original json to intercept response
    const originalJson = res.json.bind(res)
    res.json = function (body) {
      // Log if request was successful
      if (res.statusCode < 400 && body?.success !== false) {
        logAudit(req, action, resource, null, { body }, true).catch(() => {})
      }
      return originalJson(body)
    }
    next()
  }
}

export async function logAudit(req, action, resource, resourceId, details = {}, success = true) {
  try {
    const user = req.user
    await AuditLog.create({
      actor:      user?._id,
      actorRole:  user?.role,
      lab:        user?.lab,
      action,
      resource,
      resourceId: resourceId ? String(resourceId) : undefined,
      details:    Object.keys(details).length > 0 ? details : undefined,
      ip:         req.ip || req.connection?.remoteAddress,
      userAgent:  req.headers?.['user-agent']?.slice(0, 200),
      success,
    })
  } catch (err) {
    console.error('⚠️ Audit log failed:', err.message)
  }
}
