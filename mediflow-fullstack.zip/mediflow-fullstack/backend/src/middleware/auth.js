import jwt from 'jsonwebtoken'
import { User } from '../models/index.js'

// Protect routes
export const protect = async (req, res, next) => {
  let token
  if (req.headers.authorization?.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1]
  }
  if (!token) return res.status(401).json({ success: false, message: 'Not authorized - no token' })

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.user = await User.findById(decoded.id).select('-password -otp -otpExpiry').populate('lab')
    if (!req.user) return res.status(401).json({ success: false, message: 'User not found' })
    if (!req.user.isActive) return res.status(403).json({ success: false, message: 'Account disabled' })
    next()
  } catch (err) {
    console.error('JWT Error:', err.message)
    return res.status(401).json({ success: false, message: 'Invalid token - please login again' })
  }
}

// Role authorization (optional - only used where needed)
export const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ success: false, message: `Role '${req.user.role}' is not allowed here` })
  }
  next()
}

// Lab context - sets req.labId from the logged-in user's lab
export const labContext = (req, res, next) => {
  try {
    if (req.user.role === 'superadmin') {
      // superadmin can pass labId as query param or body, or use req.params
      const labId = req.query.labId || req.body.labId || req.params.labId
      req.labId = labId || null
    } else {
      if (!req.user.lab) {
        return res.status(403).json({ success: false, message: 'No lab assigned to your account. Contact admin.' })
      }
      // Handle both populated object and plain ObjectId
      req.labId = req.user.lab._id ? req.user.lab._id.toString() : req.user.lab.toString()
    }
    next()
  } catch (err) {
    console.error('labContext error:', err.message)
    return res.status(500).json({ success: false, message: 'Lab context error' })
  }
}

// Generate JWT
export const generateToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || '7d' })

// Async error wrapper
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next)

// Send success response
export const sendResponse = (res, statusCode, data, message = 'Success') =>
  res.status(statusCode).json({ success: true, message, data })
