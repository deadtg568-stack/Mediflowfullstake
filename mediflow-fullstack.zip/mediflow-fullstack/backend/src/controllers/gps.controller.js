import { GpsTracking, GpsLocationLog } from '../models/GpsTracking.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'

// ─── START TRACKING ───────────────────────────────────────────────────────────
// Technician starts a home collection trip
export const startTracking = asyncHandler(async (req, res) => {
  const { appointment, patientName, patientPhone, patientAddress, destLat, destLng } = req.body

  // End any existing active tracking for this technician
  await GpsTracking.updateMany(
    { technician: req.user._id, status: { $in: ['en_route', 'at_location', 'collecting'] } },
    { status: 'cancelled', completedAt: new Date() }
  )

  const tracking = await GpsTracking.create({
    lab:          req.labId,
    technician:   req.user._id,
    appointment,
    patientName,
    patientPhone,
    patientAddress,
    destination:  { lat: destLat, lng: destLng },
    startedAt:    new Date(),
    status:       'en_route',
  })

  sendResponse(res, 201, tracking, 'GPS tracking started')
})

// ─── UPDATE LOCATION ──────────────────────────────────────────────────────────
// Technician sends their current GPS location (called every 5-10 seconds)
export const updateLocation = asyncHandler(async (req, res) => {
  const { trackingId, lat, lng, accuracy, heading, speed } = req.body
  if (!trackingId || lat == null || lng == null) {
    return res.status(400).json({ success: false, message: 'trackingId, lat and lng are required' })
  }

  const tracking = await GpsTracking.findOne({ _id: trackingId, technician: req.user._id })
  if (!tracking) return res.status(404).json({ success: false, message: 'Tracking session not found' })
  if (['completed', 'cancelled'].includes(tracking.status)) {
    return res.status(400).json({ success: false, message: 'Tracking session already ended' })
  }

  // Update current location
  tracking.currentLocation = { lat, lng, accuracy, heading, speed, updatedAt: new Date() }
  await tracking.save()

  // Append to location log (fire-and-forget, don't await)
  GpsLocationLog.create({ tracking: trackingId, lat, lng, accuracy, heading, speed }).catch(() => {})

  sendResponse(res, 200, tracking, 'Location updated')
})

// ─── UPDATE STATUS ────────────────────────────────────────────────────────────
// Technician changes status: en_route → at_location → collecting → completed
export const updateTrackingStatus = asyncHandler(async (req, res) => {
  const { id } = req.params
  const { status } = req.body

  const validTransitions = ['en_route', 'at_location', 'collecting', 'completed', 'cancelled']
  if (!validTransitions.includes(status)) {
    return res.status(400).json({ success: false, message: `Invalid status. Must be one of: ${validTransitions.join(', ')}` })
  }

  const tracking = await GpsTracking.findOne({ _id: id, technician: req.user._id })
  if (!tracking) return res.status(404).json({ success: false, message: 'Tracking session not found' })

  tracking.status = status
  if (status === 'completed' || status === 'cancelled') {
    tracking.completedAt = new Date()
  }
  await tracking.save()

  sendResponse(res, 200, tracking, `Status updated to ${status}`)
})

// ─── STOP TRACKING ────────────────────────────────────────────────────────────
export const stopTracking = asyncHandler(async (req, res) => {
  const { id } = req.params
  const tracking = await GpsTracking.findOneAndUpdate(
    { _id: id, technician: req.user._id },
    { status: 'completed', completedAt: new Date() },
    { new: true }
  )
  if (!tracking) return res.status(404).json({ success: false, message: 'Tracking session not found' })
  sendResponse(res, 200, tracking, 'Tracking ended')
})

// ─── GET ACTIVE TRACKINGS (lab admin) ──────────────────────────────────────────
// Returns all active tracking sessions for the lab
export const getActiveTrackings = asyncHandler(async (req, res) => {
  const trackings = await GpsTracking.find({
    lab: req.labId,
    status: { $in: ['en_route', 'at_location', 'collecting'] },
  })
    .populate('technician', 'name phone')
    .populate('appointment', 'scheduledAt type')
    .sort({ startedAt: -1 })

  sendResponse(res, 200, trackings)
})

// ─── GET TRACKING HISTORY (lab admin) ──────────────────────────────────────────
// Returns completed tracking sessions and their location logs
export const getTrackingHistory = asyncHandler(async (req, res) => {
  const { id } = req.params
  const tracking = await GpsTracking.findOne({ _id: id, lab: req.labId })
    .populate('technician', 'name phone')
  if (!tracking) return res.status(404).json({ success: false, message: 'Tracking not found' })

  const locationLogs = await GpsLocationLog.find({ tracking: id }).sort({ timestamp: 1 }).limit(1000)
  sendResponse(res, 200, { tracking, locationLogs })
})

// ─── GET ALL TRACKINGS BY DATE (lab admin) ─────────────────────────────────────
export const getAllTrackings = asyncHandler(async (req, res) => {
  const { date } = req.query
  const query = { lab: req.labId }
  if (date) {
    const d = new Date(date)
    d.setHours(0, 0, 0, 0)
    const e = new Date(d)
    e.setDate(d.getDate() + 1)
    query.createdAt = { $gte: d, $lt: e }
  }
  const trackings = await GpsTracking.find(query)
    .populate('technician', 'name phone')
    .populate('appointment', 'scheduledAt')
    .sort({ createdAt: -1 })
    .limit(50)

  sendResponse(res, 200, trackings)
})
