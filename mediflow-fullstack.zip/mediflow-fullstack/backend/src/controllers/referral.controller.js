import { Partner, ReferralLog, WalletTx, Lab, User } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'
import { v4 as uuid } from 'uuid'

// ─── Helper: generate unique referral code ────────────────────────────────────
const genCode = (name) => {
  const clean = name.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 6).padEnd(4, 'X')
  const rand  = Math.random().toString(36).toUpperCase().slice(2, 6)
  return `MFPAI-REF-${clean}${rand}`
}

// ─── Helper: commission amount by plan ───────────────────────────────────────
const PLAN_PRICES = { starter: 999, professional: 1999, enterprise: 3999 }
const calcCommission = (plan, percent = 50) =>
  Math.round((PLAN_PRICES[plan] || 0) * percent / 100)

// ─── PARTNER CRUD (Super Admin) ───────────────────────────────────────────────

// GET /api/referral/partners
export const getPartners = asyncHandler(async (req, res) => {
  const { search, status } = req.query
  const query = {}
  if (status) query.status = status
  if (search) query.$or = [
    { name:  { $regex: search, $options: 'i' } },
    { phone: { $regex: search, $options: 'i' } },
    { referralCode: { $regex: search, $options: 'i' } },
  ]
  const partners = await Partner.find(query).sort({ createdAt: -1 })
  sendResponse(res, 200, partners)
})

// POST /api/referral/partners
export const createPartner = asyncHandler(async (req, res) => {
  const { name, phone, email, type, bankName, accountNo, ifsc, upiId, notes } = req.body
  if (!name || !phone) return res.status(400).json({ success: false, message: 'Name and phone required' })

  const exists = await Partner.findOne({ phone })
  if (exists) return res.status(400).json({ success: false, message: 'Partner with this phone already exists' })

  const referralCode = genCode(name)
  const partner = await Partner.create({
    name, phone, email, type: type || 'other',
    referralCode, bankName, accountNo, ifsc, upiId, notes,
    createdBy: req.user._id,
  })
  sendResponse(res, 201, partner, 'Partner created successfully')
})

// GET /api/referral/partners/:id
export const getPartner = asyncHandler(async (req, res) => {
  const partner = await Partner.findById(req.params.id)
  if (!partner) return res.status(404).json({ success: false, message: 'Partner not found' })

  const logs    = await ReferralLog.find({ partner: partner._id }).populate('lab', 'name city plan status').sort({ createdAt: -1 })
  const txns    = await WalletTx.find({ partner: partner._id }).sort({ createdAt: -1 }).limit(20)

  // Stats
  const totalPending  = logs.filter(l => l.status === 'pending').length
  const totalApproved = logs.filter(l => l.status === 'approved').length
  const totalPaid     = logs.filter(l => l.status === 'paid').reduce((s, l) => s + l.commissionAmount, 0)

  sendResponse(res, 200, { partner, logs, txns, stats: { totalPending, totalApproved, totalPaid } })
})

// PUT /api/referral/partners/:id
export const updatePartner = asyncHandler(async (req, res) => {
  const partner = await Partner.findByIdAndUpdate(req.params.id, req.body, { new: true })
  if (!partner) return res.status(404).json({ success: false, message: 'Partner not found' })
  sendResponse(res, 200, partner, 'Partner updated')
})

// DELETE /api/referral/partners/:id
export const deletePartner = asyncHandler(async (req, res) => {
  await Partner.findByIdAndUpdate(req.params.id, { status: 'inactive' })
  sendResponse(res, 200, null, 'Partner deactivated')
})

// ─── REFERRAL CODE VERIFY (public — used during lab registration) ─────────────

// GET /api/referral/verify/:code
export const verifyCode = asyncHandler(async (req, res) => {
  const partner = await Partner.findOne({
    referralCode: req.params.code.toUpperCase(),
    status: 'active',
  }).select('name referralCode type')

  if (!partner) return res.status(404).json({ success: false, message: 'Invalid or expired referral code' })
  sendResponse(res, 200, { valid: true, partnerName: partner.name, code: partner.referralCode })
})

// ─── REFERRAL LOG (when a lab registers with a referral code) ─────────────────

// POST /api/referral/log  (called internally when lab is created)
export const logReferral = async ({ referralCode, lab, plan }) => {
  if (!referralCode) return null
  const partner = await Partner.findOne({ referralCode: referralCode.toUpperCase(), status: 'active' })
  if (!partner) return null

  const commissionAmount = calcCommission(plan, 50)

  const log = await ReferralLog.create({
    partner:            partner._id,
    referralCode:       partner.referralCode,
    lab:                lab._id,
    labName:            lab.name,
    labPhone:           lab.phone,
    plan,
    subscriptionAmount: PLAN_PRICES[plan] || 0,
    commissionAmount,
    commissionPercent:  50,
    status:             'pending',
    rewardType:         'cash',
  })

  return log
}

// ─── REFERRAL MANAGEMENT (Super Admin) ────────────────────────────────────────

// GET /api/referral/logs
export const getReferralLogs = asyncHandler(async (req, res) => {
  const { status, partnerId } = req.query
  const query = {}
  if (status)    query.status  = status
  if (partnerId) query.partner = partnerId

  const logs = await ReferralLog.find(query)
    .populate('partner', 'name phone referralCode')
    .populate('lab', 'name city plan status')
    .populate('approvedBy', 'name')
    .sort({ createdAt: -1 })

  // Summary stats
  const stats = {
    total:    logs.length,
    pending:  logs.filter(l => l.status === 'pending').length,
    verified: logs.filter(l => l.status === 'verified').length,
    approved: logs.filter(l => l.status === 'approved').length,
    paid:     logs.filter(l => l.status === 'paid').length,
    rejected: logs.filter(l => l.status === 'rejected').length,
    totalCommission: logs.filter(l => ['approved','paid'].includes(l.status))
                         .reduce((s, l) => s + l.commissionAmount, 0),
    totalPaid: logs.filter(l => l.status === 'paid')
                   .reduce((s, l) => s + l.commissionAmount, 0),
  }

  sendResponse(res, 200, { logs, stats })
})

// PATCH /api/referral/logs/:id/verify  — Super Admin verifies the lab subscribed
export const verifyReferral = asyncHandler(async (req, res) => {
  const log = await ReferralLog.findById(req.params.id).populate('lab')
  if (!log) return res.status(404).json({ success: false, message: 'Referral log not found' })
  if (log.status !== 'pending') return res.status(400).json({ success: false, message: `Cannot verify — status is ${log.status}` })

  // Double-check: lab must be active (subscribed)
  if (log.lab && log.lab.status !== 'active') {
    return res.status(400).json({ success: false, message: 'Lab is not yet active/subscribed' })
  }

  log.status = 'verified'
  await log.save()
  sendResponse(res, 200, log, 'Referral verified — ready to approve')
})

// PATCH /api/referral/logs/:id/approve
export const approveReferral = asyncHandler(async (req, res) => {
  const { rewardType = 'cash' } = req.body
  const log = await ReferralLog.findById(req.params.id).populate('partner')
  if (!log) return res.status(404).json({ success: false, message: 'Referral log not found' })
  if (!['pending','verified'].includes(log.status)) {
    return res.status(400).json({ success: false, message: `Cannot approve — status is ${log.status}` })
  }

  log.status     = 'approved'
  log.rewardType = rewardType
  log.approvedAt = new Date()
  log.approvedBy = req.user._id
  await log.save()

  // Credit partner wallet
  const partner = await Partner.findById(log.partner._id || log.partner)
  partner.walletBalance += log.commissionAmount
  partner.totalEarned   += log.commissionAmount
  partner.totalReferrals = await ReferralLog.countDocuments({ partner: partner._id, status: { $in: ['approved','paid'] } })
  await partner.save()

  // Wallet ledger entry
  await WalletTx.create({
    partner:     partner._id,
    type:        'credit',
    amount:      log.commissionAmount,
    balance:     partner.walletBalance,
    description: `Commission for referring ${log.labName} (${log.plan} plan)`,
    referralLog: log._id,
    createdBy:   req.user._id,
  })

  sendResponse(res, 200, { log, partner }, `₹${log.commissionAmount} credited to ${partner.name}'s wallet`)
})

// PATCH /api/referral/logs/:id/reject
export const rejectReferral = asyncHandler(async (req, res) => {
  const { reason } = req.body
  const log = await ReferralLog.findById(req.params.id)
  if (!log) return res.status(404).json({ success: false, message: 'Referral log not found' })

  log.status          = 'rejected'
  log.rejectedAt      = new Date()
  log.rejectedBy      = req.user._id
  log.rejectionReason = reason || 'Rejected by admin'
  await log.save()
  sendResponse(res, 200, log, 'Referral rejected')
})

// PATCH /api/referral/logs/:id/pay  — Mark commission as paid out
export const payReferral = asyncHandler(async (req, res) => {
  const { paymentMode, paymentRef, notes } = req.body
  const log = await ReferralLog.findById(req.params.id).populate('partner')
  if (!log) return res.status(404).json({ success: false, message: 'Referral log not found' })
  if (log.status !== 'approved') {
    return res.status(400).json({ success: false, message: 'Only approved referrals can be marked paid' })
  }

  log.status      = 'paid'
  log.paidAt      = new Date()
  log.paidBy      = req.user._id
  log.paymentMode = paymentMode || 'bank'
  log.paymentRef  = paymentRef || ''
  log.notes       = notes || ''
  await log.save()

  // Debit partner wallet
  const partner = await Partner.findById(log.partner._id || log.partner)
  partner.walletBalance = Math.max(0, partner.walletBalance - log.commissionAmount)
  await partner.save()

  await WalletTx.create({
    partner:     partner._id,
    type:        'debit',
    amount:      log.commissionAmount,
    balance:     partner.walletBalance,
    description: `Payout for ${log.labName} referral via ${paymentMode || 'bank'}${paymentRef ? ' — Ref: ' + paymentRef : ''}`,
    referralLog: log._id,
    createdBy:   req.user._id,
  })

  sendResponse(res, 200, { log, partner }, `Payment of ₹${log.commissionAmount} marked done`)
})

// ─── PARTNER STATS (Super Admin dashboard widget) ─────────────────────────────

// GET /api/referral/stats
export const getReferralStats = asyncHandler(async (req, res) => {
  const [totalPartners, activePartners, logs] = await Promise.all([
    Partner.countDocuments(),
    Partner.countDocuments({ status: 'active' }),
    ReferralLog.find(),
  ])

  const totalCommissionEarned = logs.filter(l => ['approved','paid'].includes(l.status))
                                    .reduce((s, l) => s + l.commissionAmount, 0)
  const pendingPayout = logs.filter(l => l.status === 'approved')
                            .reduce((s, l) => s + l.commissionAmount, 0)
  const totalPaid     = logs.filter(l => l.status === 'paid')
                            .reduce((s, l) => s + l.commissionAmount, 0)

  // Top partners by earnings
  const topPartners = await Partner.find({ status: 'active' })
    .sort({ totalEarned: -1 }).limit(5)
    .select('name phone referralCode totalReferrals totalEarned walletBalance')

  sendResponse(res, 200, {
    totalPartners, activePartners,
    totalCommissionEarned, pendingPayout, totalPaid,
    topPartners,
    byStatus: {
      pending:  logs.filter(l => l.status === 'pending').length,
      verified: logs.filter(l => l.status === 'verified').length,
      approved: logs.filter(l => l.status === 'approved').length,
      paid:     logs.filter(l => l.status === 'paid').length,
      rejected: logs.filter(l => l.status === 'rejected').length,
    }
  })
})
