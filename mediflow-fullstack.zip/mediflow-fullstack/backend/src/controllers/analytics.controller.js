import { Bill, Patient, Report, Test, Doctor, Inventory, Expense } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'

export const getDashboardStats = asyncHandler(async (req, res) => {
  const labId = req.labId
  const today = new Date(); today.setHours(0,0,0,0)
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1)
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1)

  const [
    todayBills, monthBills, totalPatients, todayPatients,
    pendingReports, lowStock, totalTests
  ] = await Promise.all([
    Bill.find({ lab: labId, createdAt: { $gte: today, $lt: tomorrow } }),
    Bill.find({ lab: labId, createdAt: { $gte: monthStart } }),
    Patient.countDocuments({ lab: labId }),
    Patient.countDocuments({ lab: labId, createdAt: { $gte: today, $lt: tomorrow } }),
    Report.countDocuments({ lab: labId, status: { $in: ['pending', 'processing', 'verification'] } }),
    Inventory.countDocuments({ lab: labId, $expr: { $lte: ['$stock', '$minStock'] } }),
    Test.countDocuments({ lab: labId, isActive: true }),
  ])

  sendResponse(res, 200, {
    today: {
      patients:  todayPatients,
      revenue:   todayBills.reduce((s, b) => s + b.totalAmount, 0),
      collected: todayBills.reduce((s, b) => s + b.paidAmount, 0),
      bills:     todayBills.length,
    },
    month: {
      revenue:  monthBills.reduce((s, b) => s + b.totalAmount, 0),
      collected:monthBills.reduce((s, b) => s + b.paidAmount, 0),
      bills:    monthBills.length,
    },
    totalPatients,
    pendingReports,
    lowStock,
    totalTests,
  })
})

export const getMonthlyRevenue = asyncHandler(async (req, res) => {
  const labId = req.labId
  const months = []
  for (let i = 5; i >= 0; i--) {
    const d = new Date()
    d.setMonth(d.getMonth() - i)
    months.push({ year: d.getFullYear(), month: d.getMonth() })
  }

  const data = await Promise.all(months.map(async ({ year, month }) => {
    const start = new Date(year, month, 1)
    const end   = new Date(year, month + 1, 1)
    const bills = await Bill.find({ lab: labId, createdAt: { $gte: start, $lt: end } })
    const patients = await Patient.countDocuments({ lab: labId, createdAt: { $gte: start, $lt: end } })
    return {
      month: start.toLocaleString('default', { month: 'short' }),
      year,
      revenue:  bills.reduce((s, b) => s + b.totalAmount, 0),
      collected:bills.reduce((s, b) => s + b.paidAmount, 0),
      patients,
      bills:    bills.length,
    }
  }))

  sendResponse(res, 200, data)
})

export const getTopTests = asyncHandler(async (req, res) => {
  const labId = req.labId
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0)

  const result = await Bill.aggregate([
    { $match: { lab: labId, createdAt: { $gte: monthStart } } },
    { $unwind: '$tests' },
    { $group: { _id: '$tests.testName', count: { $sum: 1 }, revenue: { $sum: '$tests.price' } } },
    { $sort: { count: -1 } },
    { $limit: 10 },
    { $project: { name: '$_id', count: 1, revenue: 1, _id: 0 } }
  ])
  sendResponse(res, 200, result)
})

export const getTopDoctors = asyncHandler(async (req, res) => {
  const labId = req.labId
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0)

  const result = await Bill.aggregate([
    { $match: { lab: labId, referredBy: { $exists: true }, createdAt: { $gte: monthStart } } },
    { $group: { _id: '$referredBy', count: { $sum: 1 }, revenue: { $sum: '$totalAmount' } } },
    { $sort: { count: -1 } },
    { $limit: 5 },
    { $lookup: { from: 'doctors', localField: '_id', foreignField: '_id', as: 'doctor' } },
    { $unwind: '$doctor' },
    { $project: { name: '$doctor.name', speciality: '$doctor.speciality', count: 1, revenue: 1, _id: 0 } }
  ])
  sendResponse(res, 200, result)
})
