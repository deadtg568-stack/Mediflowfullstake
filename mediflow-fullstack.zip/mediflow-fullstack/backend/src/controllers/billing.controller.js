import { Bill, Patient, Test, Report, Lab } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'
import { recordSignalsForBillItems } from '../services/outbreakService.js'

// GET /api/billing
export const getBills = asyncHandler(async (req, res) => {
  const { search, status, page = 1, limit = 20, from, to } = req.query
  const query = { lab: req.labId }
  if (status) query.paymentStatus = status
  if (from || to) {
    query.createdAt = {}
    if (from) query.createdAt.$gte = new Date(from)
    if (to)   query.createdAt.$lte = new Date(to + 'T23:59:59')
  }
  const total = await Bill.countDocuments(query)
  const bills = await Bill.find(query)
    .populate('patient', 'name phone patientId')
    .populate('referredBy', 'name')
    .populate('tests.test', 'name')
    .populate('createdBy', 'name')
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(Number(limit))
  sendResponse(res, 200, { bills, total, page: Number(page), pages: Math.ceil(total / limit) })
})

// POST /api/billing
export const createBill = asyncHandler(async (req, res) => {
  const { patientId, tests, discount, gstPercent, paidAmount, paymentMode, referredBy, collectionType, notes } = req.body

  const patient = await Patient.findById(patientId)
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found' })

  // Build test items
  const testItems = []
  let subtotal = 0
  for (const t of tests) {
    const testDoc = await Test.findById(t.testId)
    if (testDoc) {
      const itemPrice = t.price || testDoc.price
      testItems.push({ test: testDoc._id, testName: testDoc.name, price: itemPrice, discount: t.discount || 0 })
      subtotal += itemPrice - (t.discount || 0)
    }
  }

  const gstAmount = (subtotal - discount) * (gstPercent / 100)
  const totalAmount = subtotal - (discount || 0) + gstAmount
  const paid = paidAmount || 0

  const bill = await Bill.create({
    lab: req.labId,
    patient: patientId,
    referredBy,
    tests: testItems,
    subtotal,
    discount: discount || 0,
    gstPercent: gstPercent || 0,
    gstAmount,
    totalAmount,
    paidAmount: paid,
    dueAmount: totalAmount - paid,
    paymentStatus: paid >= totalAmount ? 'paid' : paid > 0 ? 'partial' : 'unpaid',
    paymentMode: paymentMode || 'cash',
    collectionType: collectionType || 'walkin',
    notes,
    createdBy: req.user._id,
  })

  // Auto-create report entries
  for (const t of testItems) {
    await Report.create({
      lab: req.labId,
      bill: bill._id,
      patient: patientId,
      test: t.test,
      testName: t.testName,
      sampleId: `S${Date.now()}`,
      status: 'pending',
    })
  }

  // Update patient visit count
  await Patient.findByIdAndUpdate(patientId, { $inc: { totalVisits: 1 } })

  // Outbreak Radar: anonymously tally any disease-indicating tests for this
  // lab's city. Best-effort — never block bill creation on this.
  try {
    const lab = await Lab.findById(req.labId).select('city state _id')
    if (lab) await recordSignalsForBillItems(testItems, lab)
  } catch (e) {
    console.error('[outbreak] failed to record signal:', e.message)
  }

  const populated = await Bill.findById(bill._id)
    .populate('patient', 'name phone patientId')
    .populate('tests.test', 'name')

  sendResponse(res, 201, populated, 'Bill created successfully')
})

// GET /api/billing/:id
export const getBill = asyncHandler(async (req, res) => {
  const bill = await Bill.findOne({ _id: req.params.id, lab: req.labId })
    .populate('patient', 'name phone age gender address patientId')
    .populate('referredBy', 'name speciality')
    .populate('tests.test', 'name category')
    .populate('createdBy', 'name')
  if (!bill) return res.status(404).json({ success: false, message: 'Bill not found' })
  sendResponse(res, 200, bill)
})

// PATCH /api/billing/:id/payment
export const updatePayment = asyncHandler(async (req, res) => {
  const { paidAmount, paymentMode } = req.body
  const bill = await Bill.findOne({ _id: req.params.id, lab: req.labId })
  if (!bill) return res.status(404).json({ success: false, message: 'Bill not found' })
  bill.paidAmount = paidAmount
  bill.dueAmount  = bill.totalAmount - paidAmount
  bill.paymentMode = paymentMode || bill.paymentMode
  bill.paymentStatus = paidAmount >= bill.totalAmount ? 'paid' : paidAmount > 0 ? 'partial' : 'unpaid'
  await bill.save()
  sendResponse(res, 200, bill, 'Payment updated')
})

// GET /api/billing/today/summary
export const getTodaySummary = asyncHandler(async (req, res) => {
  const today = new Date(); today.setHours(0,0,0,0)
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1)
  const bills = await Bill.find({ lab: req.labId, createdAt: { $gte: today, $lt: tomorrow } })
  const summary = {
    totalBills:   bills.length,
    totalRevenue: bills.reduce((s, b) => s + b.totalAmount, 0),
    totalPaid:    bills.reduce((s, b) => s + b.paidAmount, 0),
    totalDue:     bills.reduce((s, b) => s + b.dueAmount, 0),
    cash:   bills.filter(b => b.paymentMode === 'cash').reduce((s, b) => s + b.paidAmount, 0),
    upi:    bills.filter(b => b.paymentMode === 'upi').reduce((s, b) => s + b.paidAmount, 0),
    card:   bills.filter(b => b.paymentMode === 'card').reduce((s, b) => s + b.paidAmount, 0),
  }
  sendResponse(res, 200, summary)
})
