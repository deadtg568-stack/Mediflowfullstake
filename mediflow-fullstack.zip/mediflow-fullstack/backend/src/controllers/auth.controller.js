import { User, Lab } from '../models/index.js'
import { generateToken, asyncHandler, sendResponse } from '../middleware/auth.js'

// @route POST /api/auth/login
// body: { phone, password, role }
export const login = asyncHandler(async (req, res) => {
  const { phone, password, role } = req.body
  if (!phone || !password) {
    return res.status(400).json({ success: false, message: 'Phone and password are required' })
  }

  const query = { phone }
  if (role) query.role = role

  const user = await User.findOne(query).populate('lab')
  if (!user) return res.status(404).json({ success: false, message: 'Account not found for this phone/role' })

  if (!user.password) {
    return res.status(400).json({ success: false, message: 'No password set for this account. Contact admin.' })
  }

  const isMatch = await user.matchPassword(password)
  if (!isMatch) return res.status(401).json({ success: false, message: 'Incorrect password' })

  if (!user.isActive) {
    return res.status(403).json({ success: false, message: 'Account disabled. Contact admin.' })
  }

  // Check lab subscription
  if (user.lab && user.lab.status !== 'active') {
    return res.status(403).json({ success: false, message: 'Lab subscription expired. Contact admin.' })
  }

  user.lastLogin = new Date()
  await user.save()

  const token = generateToken(user._id)
  sendResponse(res, 200, {
    token,
    user: {
      _id:   user._id,
      name:  user.name,
      phone: user.phone,
      role:  user.role,
      lab:   user.lab,
    }
  }, 'Login successful')
})

// @route POST /api/auth/change-password
export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ success: false, message: 'New password must be at least 6 characters' })
  }

  const user = await User.findById(req.user._id)

  if (user.password) {
    if (!currentPassword) return res.status(400).json({ success: false, message: 'Current password is required' })
    const isMatch = await user.matchPassword(currentPassword)
    if (!isMatch) return res.status(401).json({ success: false, message: 'Current password is incorrect' })
  }

  user.password = newPassword
  await user.save()
  sendResponse(res, 200, null, 'Password updated successfully')
})

// @route GET /api/auth/me
export const getMe = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).populate('lab').select('-password')
  sendResponse(res, 200, user)
})

// @route POST /api/auth/logout
export const logout = asyncHandler(async (req, res) => {
  res.json({ success: true, message: 'Logged out successfully' })
})
