import { Lab, OutbreakAlert, OutbreakSignal } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'
import { getCityTrend, getNationalSnapshot, runDetection } from '../services/outbreakService.js'
import { DISEASE_KEYWORDS } from '../models/index.js'

// GET /api/outbreak/trends — daily disease-test counts for the logged-in lab's city
export const getTrends = asyncHandler(async (req, res) => {
  const lab = req.user.lab
  if (!lab?.city) {
    return sendResponse(res, 200, { city: null, trend: [], diseases: [] }, 'Lab city not set')
  }

  const days = Number(req.query.days) || 30
  const trend = await getCityTrend(lab.city, days)

  // Active diseases present in the trend data
  const diseases = new Set()
  trend.forEach(row => Object.keys(row).forEach(k => { if (k !== 'date') diseases.add(k) }))

  sendResponse(res, 200, {
    city: lab.city,
    trend,
    diseases: Array.from(diseases),
    trackedDiseases: Object.keys(DISEASE_KEYWORDS).filter(d => d !== 'Viral Fever'),
  })
})

// GET /api/outbreak/alerts — active alerts relevant to the logged-in lab's city
// Also returns nearby/other-city alerts (anonymized) so labs can see regional trends
export const getAlerts = asyncHandler(async (req, res) => {
  const lab = req.user.lab
  const allAlerts = await OutbreakAlert.find({ status: 'active' }).sort({ percentChange: -1 })

  const localAlerts = lab?.city ? allAlerts.filter(a => a.city === lab.city) : []
  const otherAlerts = lab?.city ? allAlerts.filter(a => a.city !== lab.city) : allAlerts

  sendResponse(res, 200, {
    city: lab?.city || null,
    localAlerts,
    networkAlerts: otherAlerts.slice(0, 10), // top 10 from across the network
  })
})

// POST /api/outbreak/detect — manually trigger detection (also runnable via cron)
export const triggerDetection = asyncHandler(async (req, res) => {
  const alerts = await runDetection()
  sendResponse(res, 200, alerts, `Detection complete — ${alerts.length} active alert(s)`)
})

// GET /api/outbreak/national — Super Admin: cross-network snapshot
export const getNational = asyncHandler(async (req, res) => {
  const snapshot = await getNationalSnapshot()
  sendResponse(res, 200, snapshot)
})

// PATCH /api/outbreak/alerts/:id/resolve — Super Admin / Lab Admin can dismiss an alert
export const resolveAlert = asyncHandler(async (req, res) => {
  const alert = await OutbreakAlert.findByIdAndUpdate(req.params.id, { status: 'resolved' }, { new: true })
  if (!alert) return res.status(404).json({ success: false, message: 'Alert not found' })
  sendResponse(res, 200, alert, 'Alert resolved')
})
