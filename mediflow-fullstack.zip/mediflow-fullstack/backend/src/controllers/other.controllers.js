import mongoose from 'mongoose'
import { Report, Doctor, Test, Staff, Inventory, Appointment, User } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'

// ─── REPORTS ─────────────────────────────────────────────────────────────────
export const getReports = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 20 } = req.query
  const query = { lab: req.labId }
  if (status) query.status = status
  const total = await Report.countDocuments(query)
  const reports = await Report.find(query)
    .populate('patient', 'name phone patientId age gender')
    .populate('test', 'name category')
    .populate('collectedBy', 'name')
    .populate('verifiedBy', 'name')
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit).limit(Number(limit))
  sendResponse(res, 200, { reports, total })
})

export const updateReport = asyncHandler(async (req, res) => {
  const { results, remarks, status } = req.body
  const report = await Report.findOne({ _id: req.params.id, lab: req.labId })
  if (!report) return res.status(404).json({ success: false, message: 'Report not found' })
  if (results) report.results = results
  if (remarks) report.remarks = remarks
  if (status)  report.status = status
  if (status === 'completed') { report.reportedAt = new Date(); report.verifiedBy = req.user._id }
  if (status === 'collected') { report.collectedBy = req.user._id; report.collectedAt = new Date() }
  await report.save()
  sendResponse(res, 200, report, 'Report updated')
})

// ─── DOCTORS ──────────────────────────────────────────────────────────────────
export const getDoctors = asyncHandler(async (req, res) => {
  const { search } = req.query
  const query = { lab: req.labId, isActive: true }
  if (search) query.name = { $regex: search, $options: 'i' }
  const doctors = await Doctor.find(query).sort({ name: 1 })
  sendResponse(res, 200, doctors)
})

export const createDoctor = asyncHandler(async (req, res) => {
  const doctor = await Doctor.create({ ...req.body, lab: req.labId })
  sendResponse(res, 201, doctor, 'Doctor added')
})

export const updateDoctor = asyncHandler(async (req, res) => {
  const doctor = await Doctor.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, req.body, { new: true })
  sendResponse(res, 200, doctor, 'Doctor updated')
})

export const deleteDoctor = asyncHandler(async (req, res) => {
  await Doctor.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, { isActive: false })
  sendResponse(res, 200, null, 'Doctor removed')
})

// ─── TESTS ────────────────────────────────────────────────────────────────────
export const getTests = asyncHandler(async (req, res) => {
  const { search, category } = req.query
  const query = { lab: req.labId, isActive: true }
  if (search)   query.name = { $regex: search, $options: 'i' }
  if (category) query.category = category
  const tests = await Test.find(query).sort({ name: 1 })
  sendResponse(res, 200, tests)
})

export const createTest = asyncHandler(async (req, res) => {
  const test = await Test.create({ ...req.body, lab: req.labId })
  sendResponse(res, 201, test, 'Test created')
})

export const updateTest = asyncHandler(async (req, res) => {
  const test = await Test.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, req.body, { new: true })
  sendResponse(res, 200, test, 'Test updated')
})

export const deleteTest = asyncHandler(async (req, res) => {
  await Test.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, { isActive: false })
  sendResponse(res, 200, null, 'Test disabled')
})

// ─── STAFF ────────────────────────────────────────────────────────────────────
export const getStaff = asyncHandler(async (req, res) => {
  const staff = await Staff.find({ lab: req.labId }).populate('user', 'phone lastLogin').sort({ name: 1 })
  sendResponse(res, 200, staff)
})

export const createStaff = asyncHandler(async (req, res) => {
  const { name, phone, role, shift, salary, password } = req.body
  // Create a user account too, with a default/provided password
  let user = await User.findOne({ phone })
  if (!user) {
    user = await User.create({ name, phone, role, lab: req.labId, password: password || 'mediflow123' })
  }
  const staff = await Staff.create({ lab: req.labId, user: user._id, name, phone, role, shift, salary })
  sendResponse(res, 201, { ...staff.toObject(), defaultPassword: password ? undefined : 'mediflow123' }, 'Staff added')
})

export const updateStaff = asyncHandler(async (req, res) => {
  const staff = await Staff.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, req.body, { new: true })
  sendResponse(res, 200, staff, 'Staff updated')
})

// ─── INVENTORY ────────────────────────────────────────────────────────────────
export const getInventory = asyncHandler(async (req, res) => {
  const items = await Inventory.find({ lab: req.labId }).sort({ name: 1 })
  const lowStock = items.filter(i => i.stock <= i.minStock)
  sendResponse(res, 200, { items, lowStock })
})

export const createInventoryItem = asyncHandler(async (req, res) => {
  const item = await Inventory.create({ ...req.body, lab: req.labId })
  sendResponse(res, 201, item, 'Item added')
})

export const updateInventoryItem = asyncHandler(async (req, res) => {
  const item = await Inventory.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, req.body, { new: true })
  sendResponse(res, 200, item, 'Item updated')
})

export const adjustStock = asyncHandler(async (req, res) => {
  const { quantity, type } = req.body // type: 'add' or 'subtract'
  const item = await Inventory.findOne({ _id: req.params.id, lab: req.labId })
  if (!item) return res.status(404).json({ success: false, message: 'Item not found' })
  item.stock = type === 'add' ? item.stock + quantity : Math.max(0, item.stock - quantity)
  await item.save()
  sendResponse(res, 200, item, 'Stock updated')
})

// ─── APPOINTMENTS ─────────────────────────────────────────────────────────────
export const getAppointments = asyncHandler(async (req, res) => {
  const { date, status } = req.query
  const query = { lab: req.labId }
  if (status) query.status = status
  if (date) {
    const d = new Date(date); d.setHours(0,0,0,0)
    const e = new Date(d);   e.setDate(d.getDate() + 1)
    query.scheduledAt = { $gte: d, $lt: e }
  }
  const appointments = await Appointment.find(query)
    .populate('patient', 'name phone patientId')
    .populate('tests', 'name price')
    .populate('assignedTo', 'name')
    .sort({ scheduledAt: 1 })
  sendResponse(res, 200, appointments)
})

export const createAppointment = asyncHandler(async (req, res) => {
  // Auto-assign token number for today
  const today = new Date(); today.setHours(0,0,0,0)
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1)
  const todayCount = await Appointment.countDocuments({ lab: req.labId, createdAt: { $gte: today, $lt: tomorrow } })
  const appt = await Appointment.create({ ...req.body, lab: req.labId, tokenNo: todayCount + 1, createdBy: req.user._id })
  const populated = await Appointment.findById(appt._id).populate('patient', 'name phone').populate('tests', 'name')
  sendResponse(res, 201, populated, 'Appointment booked')
})

export const updateAppointment = asyncHandler(async (req, res) => {
  const appt = await Appointment.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, req.body, { new: true })
  sendResponse(res, 200, appt, 'Appointment updated')
})
