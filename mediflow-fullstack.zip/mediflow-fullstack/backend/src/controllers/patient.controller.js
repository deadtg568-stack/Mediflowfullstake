import mongoose from 'mongoose'
import { Patient, Bill, Report } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'

// GET /api/patients
export const getPatients = asyncHandler(async (req, res) => {
  const { search, page = 1, limit = 20 } = req.query
  const query = { lab: req.labId }
  if (search) query.$or = [
    { name: { $regex: search, $options: 'i' } },
    { phone: { $regex: search, $options: 'i' } },
    { patientId: { $regex: search, $options: 'i' } },
  ]
  const total = await Patient.countDocuments(query)
  const patients = await Patient.find(query)
    .populate('referredBy', 'name speciality')
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(Number(limit))
  sendResponse(res, 200, { patients, total, page: Number(page), pages: Math.ceil(total / limit) })
})

// POST /api/patients
export const createPatient = asyncHandler(async (req, res) => {
  const patient = await Patient.create({ ...req.body, lab: req.labId })
  sendResponse(res, 201, patient, 'Patient registered successfully')
})

// GET /api/patients/:id
export const getPatient = asyncHandler(async (req, res) => {
  const patient = await Patient.findOne({ _id: req.params.id, lab: req.labId })
    .populate('referredBy', 'name speciality phone')
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found' })
  const bills   = await Bill.find({ patient: patient._id }).sort({ createdAt: -1 }).limit(10)
  const reports = await Report.find({ patient: patient._id }).sort({ createdAt: -1 }).limit(10)
    .populate('test', 'name category')
  sendResponse(res, 200, { patient, bills, reports })
})

// PUT /api/patients/:id
export const updatePatient = asyncHandler(async (req, res) => {
  const patient = await Patient.findOneAndUpdate(
    { _id: req.params.id, lab: req.labId },
    req.body,
    { new: true, runValidators: true }
  )
  if (!patient) return res.status(404).json({ success: false, message: 'Patient not found' })
  sendResponse(res, 200, patient, 'Patient updated')
})

// DELETE /api/patients/:id
export const deletePatient = asyncHandler(async (req, res) => {
  await Patient.findOneAndDelete({ _id: req.params.id, lab: req.labId })
  sendResponse(res, 200, null, 'Patient deleted')
})
