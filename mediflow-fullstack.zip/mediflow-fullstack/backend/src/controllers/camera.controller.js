import path from 'path'
import fs from 'fs'
import { Camera, Recording, MotionEvent } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'
import { discoverCameras, getCameraDetails, buildRtspUrl } from '../services/onvifService.js'
import {
  startHlsStream, stopHlsStream, isStreaming, getActiveStreams,
  startRecording, stopRecording, isRecording, listRecordings,
  captureSnapshot, RECORDINGS_DIR_PATH,
} from '../services/streamService.js'
import { startMotionWatch, stopMotionWatch, isWatching, checkMotion } from '../services/motionService.js'

// ─── CAMERA CRUD ───────────────────────────────────────────────────────────────

// GET /api/cameras
export const getCameras = asyncHandler(async (req, res) => {
  const cameras = await Camera.find({ lab: req.labId }).sort({ createdAt: -1 })
  const withStatus = cameras.map(c => ({
    ...c.toObject(),
    streaming: isStreaming(c.streamKey),
    recording: isRecording(c.streamKey),
    motionWatch: isWatching(c.streamKey),
    password: undefined, // never send password to client
  }))
  sendResponse(res, 200, withStatus)
})

// GET /api/cameras/:id
export const getCamera = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })
  const obj = camera.toObject()
  delete obj.password
  sendResponse(res, 200, {
    ...obj,
    streaming: isStreaming(camera.streamKey),
    recording: isRecording(camera.streamKey),
    motionWatch: isWatching(camera.streamKey),
  })
})

// POST /api/cameras  (manual add)
export const createCamera = asyncHandler(async (req, res) => {
  const { name, location, ip, port, onvifPort, username, password, rtspPath, brand, model } = req.body
  if (!name || !ip) return res.status(400).json({ success: false, message: 'Name and IP are required' })

  const camera = await Camera.create({
    lab: req.labId, name, location, ip,
    port: port || 554,
    onvifPort: onvifPort || 80,
    username, password,
    rtspPath: rtspPath || '/Streaming/Channels/101',
    brand, model,
    addedVia: 'manual',
  })

  sendResponse(res, 201, { ...camera.toObject(), password: undefined }, 'Camera added')
})

// PUT /api/cameras/:id
export const updateCamera = asyncHandler(async (req, res) => {
  const updates = { ...req.body }
  delete updates.streamKey // immutable
  const camera = await Camera.findOneAndUpdate({ _id: req.params.id, lab: req.labId }, updates, { new: true })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })
  sendResponse(res, 200, { ...camera.toObject(), password: undefined }, 'Camera updated')
})

// DELETE /api/cameras/:id
export const deleteCamera = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  // Clean up any running processes
  stopHlsStream(camera.streamKey)
  stopRecording(camera.streamKey)
  stopMotionWatch(camera.streamKey)

  await camera.deleteOne()
  sendResponse(res, 200, null, 'Camera removed')
})

// ─── ONVIF DISCOVERY ────────────────────────────────────────────────────────────

// GET /api/cameras/discover?timeout=5000
// Scans the local network for ONVIF-compliant cameras
export const discoverOnvifCameras = asyncHandler(async (req, res) => {
  const timeout = Number(req.query.timeout) || 5000
  const found = await discoverCameras(timeout)
  sendResponse(res, 200, found, `Found ${found.length} ONVIF device(s)`)
})

// POST /api/cameras/discover/connect
// body: { ip, port, username, password }
// Connects to a discovered device to fetch its details + RTSP URI
export const connectOnvifCamera = asyncHandler(async (req, res) => {
  const { ip, port, username, password } = req.body
  if (!ip) return res.status(400).json({ success: false, message: 'IP is required' })

  const details = await getCameraDetails({ ip, port, username, password })
  const rtspUrl = buildRtspUrl(details.rtspUri, username, password)

  sendResponse(res, 200, { ...details, rtspUrl }, 'Device connected')
})

// POST /api/cameras/discover/add
// Adds a camera discovered via ONVIF directly using its returned RTSP URI
export const addOnvifCamera = asyncHandler(async (req, res) => {
  const { name, location, ip, onvifPort, username, password, rtspUri, manufacturer, model } = req.body
  if (!name || !ip || !rtspUri) return res.status(400).json({ success: false, message: 'name, ip and rtspUri are required' })

  const camera = await Camera.create({
    lab: req.labId, name, location, ip,
    onvifPort: onvifPort || 80,
    username, password,
    manufacturer, model,
    rtspUrl: buildRtspUrl(rtspUri, username, password),
    addedVia: 'onvif',
  })

  sendResponse(res, 201, { ...camera.toObject(), password: undefined }, 'ONVIF camera added')
})

// ─── LIVE STREAMING ──────────────────────────────────────────────────────────────

// POST /api/cameras/:id/stream/start
export const startStream = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  const result = startHlsStream(camera)
  camera.status = 'online'
  camera.lastSeen = new Date()
  await camera.save()

  sendResponse(res, 200, result, result.alreadyRunning ? 'Stream already running' : 'Stream started')
})

// POST /api/cameras/:id/stream/stop
export const stopStream = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })
  const stopped = stopHlsStream(camera.streamKey)
  sendResponse(res, 200, { stopped }, stopped ? 'Stream stopped' : 'Stream was not running')
})

// GET /api/cameras/streams/active
export const getActiveStreamList = asyncHandler(async (req, res) => {
  sendResponse(res, 200, getActiveStreams())
})

// GET /api/cameras/:id/snapshot — capture and return a JPEG snapshot
export const getSnapshot = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  const outPath = path.join(RECORDINGS_DIR_PATH, '_alerts', `snap_${camera.streamKey}_${Date.now()}.jpg`)
  try {
    await captureSnapshot(camera, outPath)
    camera.status = 'online'; camera.lastSeen = new Date(); await camera.save()
    res.sendFile(outPath)
  } catch (e) {
    camera.status = 'offline'; await camera.save()
    res.status(502).json({ success: false, message: 'Could not reach camera: ' + e.message })
  }
})

// ─── RECORDING ────────────────────────────────────────────────────────────────────

// POST /api/cameras/:id/recording/start
export const startCameraRecording = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  const { segmentMinutes } = req.body
  const result = startRecording(camera, segmentMinutes || 15)
  camera.recordingEnabled = true
  await camera.save()

  sendResponse(res, 200, result, result.alreadyRunning ? 'Recording already active' : 'Recording started')
})

// POST /api/cameras/:id/recording/stop
export const stopCameraRecording = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  const stopped = stopRecording(camera.streamKey)
  camera.recordingEnabled = false
  await camera.save()

  sendResponse(res, 200, { stopped }, stopped ? 'Recording stopped' : 'Recording was not active')
})

// GET /api/cameras/:id/recordings — list & playback
export const getCameraRecordings = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  const files = listRecordings(camera.streamKey)
  sendResponse(res, 200, files)
})

// ─── AI MOTION DETECTION ─────────────────────────────────────────────────────────────

// POST /api/cameras/:id/motion/start
export const startMotion = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  const { intervalMs, sensitivity } = req.body
  if (sensitivity !== undefined) { camera.motionSensitivity = sensitivity }
  camera.motionDetectionEnabled = true
  await camera.save()

  const result = startMotionWatch(camera, intervalMs || 5000)
  sendResponse(res, 200, result, result.alreadyRunning ? 'Already watching' : 'Motion detection started')
})

// POST /api/cameras/:id/motion/stop
export const stopMotion = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  const stopped = stopMotionWatch(camera.streamKey)
  camera.motionDetectionEnabled = false
  await camera.save()

  sendResponse(res, 200, { stopped }, stopped ? 'Motion detection stopped' : 'Was not running')
})

// POST /api/cameras/:id/motion/test — run one-off check (useful for tuning sensitivity)
export const testMotion = asyncHandler(async (req, res) => {
  const camera = await Camera.findOne({ _id: req.params.id, lab: req.labId })
  if (!camera) return res.status(404).json({ success: false, message: 'Camera not found' })

  try {
    const result = await checkMotion(camera)
    sendResponse(res, 200, result)
  } catch (e) {
    res.status(502).json({ success: false, message: e.message })
  }
})

// GET /api/cameras/motion-events
export const getMotionEvents = asyncHandler(async (req, res) => {
  const { cameraId, page = 1, limit = 30 } = req.query
  const query = { lab: req.labId }
  if (cameraId) query.camera = cameraId

  const total = await MotionEvent.countDocuments(query)
  const events = await MotionEvent.find(query)
    .populate('camera', 'name location')
    .sort({ detectedAt: -1 })
    .skip((page - 1) * limit)
    .limit(Number(limit))

  sendResponse(res, 200, { events, total })
})

// PATCH /api/cameras/motion-events/:id/review
export const reviewMotionEvent = asyncHandler(async (req, res) => {
  const event = await MotionEvent.findOneAndUpdate(
    { _id: req.params.id, lab: req.labId },
    { reviewed: true },
    { new: true }
  )
  if (!event) return res.status(404).json({ success: false, message: 'Event not found' })
  sendResponse(res, 200, event)
})
