import { Lab, User, Bill, Patient } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'
import { v4 as uuid } from 'uuid'
import { logReferral } from './referral.controller.js'

// GET /api/superadmin/dashboard
export const getSuperDashboard = asyncHandler(async (req, res) => {
  const [totalLabs, activeLabs, totalUsers, totalPatients] = await Promise.all([
    Lab.countDocuments(),
    Lab.countDocuments({ status: 'active' }),
    User.countDocuments({ role: { $ne: 'patient' } }),
    Patient.countDocuments(),
  ])
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0)
  const labs = await Lab.find().sort({ createdAt: -1 })
  sendResponse(res, 200, { totalLabs, activeLabs, totalUsers, totalPatients, labs })
})

// GET /api/superadmin/labs
export const getAllLabs = asyncHandler(async (req, res) => {
  const labs = await Lab.find().sort({ createdAt: -1 })
  sendResponse(res, 200, labs)
})

// POST /api/superadmin/labs
export const createLab = asyncHandler(async (req, res) => {
  const { name, ownerName, phone, email, plan, city, state, password, referralCode } = req.body

  const exists = await Lab.findOne({ phone })
  if (exists) return res.status(400).json({ success: false, message: 'Lab with this phone already exists' })

  const licenseKey = `MFPAI-${new Date().getFullYear()}-${uuid().toUpperCase().slice(0, 8)}`
  const subEnd = new Date()
  subEnd.setMonth(subEnd.getMonth() + 1)

  const lab = await Lab.create({
    name, ownerName, phone, email, plan: plan || 'starter',
    city, state, licenseKey,
    subscriptionStart: new Date(),
    subscriptionEnd: subEnd,
    status: 'active',
    referralCode: referralCode || null,
  })

  const generatedPassword = password || Math.random().toString(36).slice(-8)
  const adminUser = await User.create({
    name: ownerName, phone, password: generatedPassword,
    role: 'labadmin', lab: lab._id, isActive: true,
  })

  // If referral code provided, log it (best effort — don't block lab creation)
  let referralLog = null
  if (referralCode) {
    try {
      referralLog = await logReferral({ referralCode, lab, plan: plan || 'starter' })
    } catch (e) {
      console.error('Referral log error:', e.message)
    }
  }

  sendResponse(res, 201, {
    lab,
    adminUser: { _id: adminUser._id, name: adminUser.name, phone: adminUser.phone, role: adminUser.role },
    licenseKey,
    password: generatedPassword,
    referralLogged: !!referralLog,
  }, 'Lab created successfully')
})

// PATCH /api/superadmin/labs/:id/status
export const updateLabStatus = asyncHandler(async (req, res) => {
  const { status } = req.body
  const lab = await Lab.findByIdAndUpdate(req.params.id, { status }, { new: true })
  sendResponse(res, 200, lab, `Lab ${status}`)
})

// POST /api/superadmin/labs/:id/renew
export const renewSubscription = asyncHandler(async (req, res) => {
  const { months = 1 } = req.body
  const lab = await Lab.findById(req.params.id)
  if (!lab) return res.status(404).json({ success: false, message: 'Lab not found' })
  const base = lab.subscriptionEnd > new Date() ? lab.subscriptionEnd : new Date()
  base.setMonth(base.getMonth() + months)
  lab.subscriptionEnd = base
  lab.status = 'active'
  await lab.save()
  sendResponse(res, 200, lab, 'Subscription renewed')
})

// GET /api/superadmin/revenue
export const getPlatformRevenue = asyncHandler(async (req, res) => {
  const plans = { starter: 999, professional: 1999, enterprise: 3999 }
  const labs = await Lab.find({ status: 'active' })
  const monthly = labs.reduce((s, l) => s + (plans[l.plan] || 0), 0)
  const breakdown = { starter: 0, professional: 0, enterprise: 0 }
  labs.forEach(l => { if (breakdown[l.plan] !== undefined) breakdown[l.plan]++ })
  sendResponse(res, 200, { monthlyRevenue: monthly, labCount: labs.length, breakdown })
})

// GET /api/superadmin/users
export const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find({ role: { $ne: 'patient' } })
    .populate('lab', 'name')
    .select('-password -otp -otpExpiry')
    .sort({ createdAt: -1 })
  sendResponse(res, 200, users)
})

// GET /api/superadmin/labs/:id/print-settings
export const getPrintSettings = asyncHandler(async (req, res) => {
  const lab = await Lab.findById(req.params.id).select('name ownerName phone email address city state gstin settings')
  if (!lab) return res.status(404).json({ success: false, message: 'Lab not found' })
  sendResponse(res, 200, lab)
})

// PUT /api/superadmin/labs/:id/print-settings
export const updatePrintSettings = asyncHandler(async (req, res) => {
  const { settings, name, address, city, state, gstin, email, phone } = req.body
  const lab = await Lab.findById(req.params.id)
  if (!lab) return res.status(404).json({ success: false, message: 'Lab not found' })

  // Update top-level lab fields
  if (name)    lab.name    = name
  if (address) lab.address = address
  if (city)    lab.city    = city
  if (state)   lab.state   = state
  if (gstin)   lab.gstin   = gstin
  if (email)   lab.email   = email
  if (phone)   lab.phone   = phone

  // Merge settings
  if (settings) {
    lab.settings = { ...lab.settings?.toObject?.() || lab.settings || {}, ...settings }
  }

  await lab.save()
  sendResponse(res, 200, lab, 'Print settings saved successfully')
})
