import { Lab, User, Bill, Patient } from '../models/index.js'
import { asyncHandler, sendResponse } from '../middleware/auth.js'
import { v4 as uuid } from 'uuid'

// GET /api/superadmin/dashboard
export const getSuperDashboard = asyncHandler(async (req, res) => {
  const [totalLabs, activeLabs, totalUsers, totalPatients] = await Promise.all([
    Lab.countDocuments(),
    Lab.countDocuments({ status: 'active' }),
    User.countDocuments({ role: { $ne: 'patient' } }),
    Patient.countDocuments(),
  ])
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0)
  const labs = await Lab.find().sort({ createdAt: -1 })
  sendResponse(res, 200, { totalLabs, activeLabs, totalUsers, totalPatients, labs })
})

// GET /api/superadmin/labs
export const getAllLabs = asyncHandler(async (req, res) => {
  const labs = await Lab.find().sort({ createdAt: -1 })
  sendResponse(res, 200, labs)
})

// POST /api/superadmin/labs
export const createLab = asyncHandler(async (req, res) => {
  const { name, ownerName, phone, email, plan, city, state, password } = req.body

  // Check if lab already exists
  const exists = await Lab.findOne({ phone })
  if (exists) return res.status(400).json({ success: false, message: 'Lab with this phone already exists' })

  // Generate license key
  const licenseKey = `MFPAI-${new Date().getFullYear()}-${uuid().toUpperCase().slice(0, 8)}`

  // Set subscription end based on plan
  const months = { starter: 1, professional: 1, enterprise: 1 }
  const subEnd = new Date()
  subEnd.setMonth(subEnd.getMonth() + (months[plan] || 1))

  const lab = await Lab.create({
    name, ownerName, phone, email, plan: plan || 'starter',
    city, state, licenseKey,
    subscriptionStart: new Date(),
    subscriptionEnd: subEnd,
    status: 'active',
  })

  // Create lab admin user with a password (provided or generated)
  const generatedPassword = password || Math.random().toString(36).slice(-8)
  const adminUser = await User.create({
    name: ownerName,
    phone,
    password: generatedPassword,
    role: 'labadmin',
    lab: lab._id,
    isActive: true,
  })

  sendResponse(res, 201, {
    lab,
    adminUser: { _id: adminUser._id, name: adminUser.name, phone: adminUser.phone, role: adminUser.role },
    licenseKey,
    password: generatedPassword, // shown once so super admin can share with lab owner
  }, 'Lab created successfully')
})

// PATCH /api/superadmin/labs/:id/status
export const updateLabStatus = asyncHandler(async (req, res) => {
  const { status } = req.body
  const lab = await Lab.findByIdAndUpdate(req.params.id, { status }, { new: true })
  sendResponse(res, 200, lab, `Lab ${status}`)
})

// POST /api/superadmin/labs/:id/renew
export const renewSubscription = asyncHandler(async (req, res) => {
  const { months = 1 } = req.body
  const lab = await Lab.findById(req.params.id)
  if (!lab) return res.status(404).json({ success: false, message: 'Lab not found' })
  const base = lab.subscriptionEnd > new Date() ? lab.subscriptionEnd : new Date()
  base.setMonth(base.getMonth() + months)
  lab.subscriptionEnd = base
  lab.status = 'active'
  await lab.save()
  sendResponse(res, 200, lab, 'Subscription renewed')
})

// GET /api/superadmin/revenue
export const getPlatformRevenue = asyncHandler(async (req, res) => {
  const plans = { starter: 999, professional: 1999, enterprise: 3999 }
  const labs = await Lab.find({ status: 'active' })
  const monthly = labs.reduce((s, l) => s + (plans[l.plan] || 0), 0)
  const breakdown = { starter: 0, professional: 0, enterprise: 0 }
  labs.forEach(l => { if (breakdown[l.plan] !== undefined) breakdown[l.plan]++ })
  sendResponse(res, 200, { monthlyRevenue: monthly, labCount: labs.length, breakdown })
})

// GET /api/superadmin/users
export const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find({ role: { $ne: 'patient' } })
    .populate('lab', 'name')
    .select('-password -otp -otpExpiry')
    .sort({ createdAt: -1 })
  sendResponse(res, 200, users)
})
